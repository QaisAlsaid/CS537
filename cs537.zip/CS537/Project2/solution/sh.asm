
_sh:     file format elf32-i386


Disassembly of section .text:

00000000 <runcmd>:
struct cmd *parsecmd(char*);

// Execute cmd.  Never returns.
void
runcmd(struct cmd *cmd)
{
       0:	55                   	push   %ebp
       1:	89 e5                	mov    %esp,%ebp
       3:	83 ec 28             	sub    $0x28,%esp
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  if(cmd == 0)
       6:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
       a:	75 05                	jne    11 <runcmd+0x11>
    exit();
       c:	e8 1f 0f 00 00       	call   f30 <exit>

  switch(cmd->type){
      11:	8b 45 08             	mov    0x8(%ebp),%eax
      14:	8b 00                	mov    (%eax),%eax
      16:	83 f8 05             	cmp    $0x5,%eax
      19:	0f 84 2b 02 00 00    	je     24a <runcmd+0x24a>
      1f:	83 f8 05             	cmp    $0x5,%eax
      22:	7f 26                	jg     4a <runcmd+0x4a>
      24:	83 f8 04             	cmp    $0x4,%eax
      27:	0f 84 e3 00 00 00    	je     110 <runcmd+0x110>
      2d:	83 f8 04             	cmp    $0x4,%eax
      30:	7f 18                	jg     4a <runcmd+0x4a>
      32:	83 f8 03             	cmp    $0x3,%eax
      35:	0f 84 12 01 00 00    	je     14d <runcmd+0x14d>
      3b:	83 f8 03             	cmp    $0x3,%eax
      3e:	7f 0a                	jg     4a <runcmd+0x4a>
      40:	83 f8 01             	cmp    $0x1,%eax
      43:	74 15                	je     5a <runcmd+0x5a>
      45:	83 f8 02             	cmp    $0x2,%eax
      48:	74 5c                	je     a6 <runcmd+0xa6>
  default:
    panic("runcmd");
      4a:	83 ec 0c             	sub    $0xc,%esp
      4d:	68 63 14 00 00       	push   $0x1463
      52:	e8 6e 03 00 00       	call   3c5 <panic>
      57:	83 c4 10             	add    $0x10,%esp

  case EXEC:
    ecmd = (struct execcmd*)cmd;
      5a:	8b 45 08             	mov    0x8(%ebp),%eax
      5d:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(ecmd->argv[0] == 0)
      60:	8b 45 e4             	mov    -0x1c(%ebp),%eax
      63:	8b 40 04             	mov    0x4(%eax),%eax
      66:	85 c0                	test   %eax,%eax
      68:	75 05                	jne    6f <runcmd+0x6f>
      exit();
      6a:	e8 c1 0e 00 00       	call   f30 <exit>
    exec(ecmd->argv[0], ecmd->argv);
      6f:	8b 45 e4             	mov    -0x1c(%ebp),%eax
      72:	8d 50 04             	lea    0x4(%eax),%edx
      75:	8b 45 e4             	mov    -0x1c(%ebp),%eax
      78:	8b 40 04             	mov    0x4(%eax),%eax
      7b:	83 ec 08             	sub    $0x8,%esp
      7e:	52                   	push   %edx
      7f:	50                   	push   %eax
      80:	e8 e3 0e 00 00       	call   f68 <exec>
      85:	83 c4 10             	add    $0x10,%esp
    printf(2, "exec %s failed\n", ecmd->argv[0]);
      88:	8b 45 e4             	mov    -0x1c(%ebp),%eax
      8b:	8b 40 04             	mov    0x4(%eax),%eax
      8e:	83 ec 04             	sub    $0x4,%esp
      91:	50                   	push   %eax
      92:	68 6a 14 00 00       	push   $0x146a
      97:	6a 02                	push   $0x2
      99:	e8 0e 10 00 00       	call   10ac <printf>
      9e:	83 c4 10             	add    $0x10,%esp
    break;
      a1:	e9 c6 01 00 00       	jmp    26c <runcmd+0x26c>

  case REDIR:
    rcmd = (struct redircmd*)cmd;
      a6:	8b 45 08             	mov    0x8(%ebp),%eax
      a9:	89 45 e8             	mov    %eax,-0x18(%ebp)
    close(rcmd->fd);
      ac:	8b 45 e8             	mov    -0x18(%ebp),%eax
      af:	8b 40 14             	mov    0x14(%eax),%eax
      b2:	83 ec 0c             	sub    $0xc,%esp
      b5:	50                   	push   %eax
      b6:	e8 9d 0e 00 00       	call   f58 <close>
      bb:	83 c4 10             	add    $0x10,%esp
    if(open(rcmd->file, rcmd->mode) < 0){
      be:	8b 45 e8             	mov    -0x18(%ebp),%eax
      c1:	8b 50 10             	mov    0x10(%eax),%edx
      c4:	8b 45 e8             	mov    -0x18(%ebp),%eax
      c7:	8b 40 08             	mov    0x8(%eax),%eax
      ca:	83 ec 08             	sub    $0x8,%esp
      cd:	52                   	push   %edx
      ce:	50                   	push   %eax
      cf:	e8 9c 0e 00 00       	call   f70 <open>
      d4:	83 c4 10             	add    $0x10,%esp
      d7:	85 c0                	test   %eax,%eax
      d9:	79 1e                	jns    f9 <runcmd+0xf9>
      printf(2, "open %s failed\n", rcmd->file);
      db:	8b 45 e8             	mov    -0x18(%ebp),%eax
      de:	8b 40 08             	mov    0x8(%eax),%eax
      e1:	83 ec 04             	sub    $0x4,%esp
      e4:	50                   	push   %eax
      e5:	68 7a 14 00 00       	push   $0x147a
      ea:	6a 02                	push   $0x2
      ec:	e8 bb 0f 00 00       	call   10ac <printf>
      f1:	83 c4 10             	add    $0x10,%esp
      exit();
      f4:	e8 37 0e 00 00       	call   f30 <exit>
    }
    runcmd(rcmd->cmd);
      f9:	8b 45 e8             	mov    -0x18(%ebp),%eax
      fc:	8b 40 04             	mov    0x4(%eax),%eax
      ff:	83 ec 0c             	sub    $0xc,%esp
     102:	50                   	push   %eax
     103:	e8 f8 fe ff ff       	call   0 <runcmd>
     108:	83 c4 10             	add    $0x10,%esp
    break;
     10b:	e9 5c 01 00 00       	jmp    26c <runcmd+0x26c>

  case LIST:
    lcmd = (struct listcmd*)cmd;
     110:	8b 45 08             	mov    0x8(%ebp),%eax
     113:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(fork1() == 0)
     116:	e8 ca 02 00 00       	call   3e5 <fork1>
     11b:	85 c0                	test   %eax,%eax
     11d:	75 12                	jne    131 <runcmd+0x131>
      runcmd(lcmd->left);
     11f:	8b 45 f0             	mov    -0x10(%ebp),%eax
     122:	8b 40 04             	mov    0x4(%eax),%eax
     125:	83 ec 0c             	sub    $0xc,%esp
     128:	50                   	push   %eax
     129:	e8 d2 fe ff ff       	call   0 <runcmd>
     12e:	83 c4 10             	add    $0x10,%esp
    wait();
     131:	e8 02 0e 00 00       	call   f38 <wait>
    runcmd(lcmd->right);
     136:	8b 45 f0             	mov    -0x10(%ebp),%eax
     139:	8b 40 08             	mov    0x8(%eax),%eax
     13c:	83 ec 0c             	sub    $0xc,%esp
     13f:	50                   	push   %eax
     140:	e8 bb fe ff ff       	call   0 <runcmd>
     145:	83 c4 10             	add    $0x10,%esp
    break;
     148:	e9 1f 01 00 00       	jmp    26c <runcmd+0x26c>

  case PIPE:
    pcmd = (struct pipecmd*)cmd;
     14d:	8b 45 08             	mov    0x8(%ebp),%eax
     150:	89 45 ec             	mov    %eax,-0x14(%ebp)
    if(pipe(p) < 0)
     153:	83 ec 0c             	sub    $0xc,%esp
     156:	8d 45 dc             	lea    -0x24(%ebp),%eax
     159:	50                   	push   %eax
     15a:	e8 e1 0d 00 00       	call   f40 <pipe>
     15f:	83 c4 10             	add    $0x10,%esp
     162:	85 c0                	test   %eax,%eax
     164:	79 10                	jns    176 <runcmd+0x176>
      panic("pipe");
     166:	83 ec 0c             	sub    $0xc,%esp
     169:	68 8a 14 00 00       	push   $0x148a
     16e:	e8 52 02 00 00       	call   3c5 <panic>
     173:	83 c4 10             	add    $0x10,%esp
    if(fork1() == 0){
     176:	e8 6a 02 00 00       	call   3e5 <fork1>
     17b:	85 c0                	test   %eax,%eax
     17d:	75 4c                	jne    1cb <runcmd+0x1cb>
      close(1);
     17f:	83 ec 0c             	sub    $0xc,%esp
     182:	6a 01                	push   $0x1
     184:	e8 cf 0d 00 00       	call   f58 <close>
     189:	83 c4 10             	add    $0x10,%esp
      dup(p[1]);
     18c:	8b 45 e0             	mov    -0x20(%ebp),%eax
     18f:	83 ec 0c             	sub    $0xc,%esp
     192:	50                   	push   %eax
     193:	e8 10 0e 00 00       	call   fa8 <dup>
     198:	83 c4 10             	add    $0x10,%esp
      close(p[0]);
     19b:	8b 45 dc             	mov    -0x24(%ebp),%eax
     19e:	83 ec 0c             	sub    $0xc,%esp
     1a1:	50                   	push   %eax
     1a2:	e8 b1 0d 00 00       	call   f58 <close>
     1a7:	83 c4 10             	add    $0x10,%esp
      close(p[1]);
     1aa:	8b 45 e0             	mov    -0x20(%ebp),%eax
     1ad:	83 ec 0c             	sub    $0xc,%esp
     1b0:	50                   	push   %eax
     1b1:	e8 a2 0d 00 00       	call   f58 <close>
     1b6:	83 c4 10             	add    $0x10,%esp
      runcmd(pcmd->left);
     1b9:	8b 45 ec             	mov    -0x14(%ebp),%eax
     1bc:	8b 40 04             	mov    0x4(%eax),%eax
     1bf:	83 ec 0c             	sub    $0xc,%esp
     1c2:	50                   	push   %eax
     1c3:	e8 38 fe ff ff       	call   0 <runcmd>
     1c8:	83 c4 10             	add    $0x10,%esp
    }
    if(fork1() == 0){
     1cb:	e8 15 02 00 00       	call   3e5 <fork1>
     1d0:	85 c0                	test   %eax,%eax
     1d2:	75 4c                	jne    220 <runcmd+0x220>
      close(0);
     1d4:	83 ec 0c             	sub    $0xc,%esp
     1d7:	6a 00                	push   $0x0
     1d9:	e8 7a 0d 00 00       	call   f58 <close>
     1de:	83 c4 10             	add    $0x10,%esp
      dup(p[0]);
     1e1:	8b 45 dc             	mov    -0x24(%ebp),%eax
     1e4:	83 ec 0c             	sub    $0xc,%esp
     1e7:	50                   	push   %eax
     1e8:	e8 bb 0d 00 00       	call   fa8 <dup>
     1ed:	83 c4 10             	add    $0x10,%esp
      close(p[0]);
     1f0:	8b 45 dc             	mov    -0x24(%ebp),%eax
     1f3:	83 ec 0c             	sub    $0xc,%esp
     1f6:	50                   	push   %eax
     1f7:	e8 5c 0d 00 00       	call   f58 <close>
     1fc:	83 c4 10             	add    $0x10,%esp
      close(p[1]);
     1ff:	8b 45 e0             	mov    -0x20(%ebp),%eax
     202:	83 ec 0c             	sub    $0xc,%esp
     205:	50                   	push   %eax
     206:	e8 4d 0d 00 00       	call   f58 <close>
     20b:	83 c4 10             	add    $0x10,%esp
      runcmd(pcmd->right);
     20e:	8b 45 ec             	mov    -0x14(%ebp),%eax
     211:	8b 40 08             	mov    0x8(%eax),%eax
     214:	83 ec 0c             	sub    $0xc,%esp
     217:	50                   	push   %eax
     218:	e8 e3 fd ff ff       	call   0 <runcmd>
     21d:	83 c4 10             	add    $0x10,%esp
    }
    close(p[0]);
     220:	8b 45 dc             	mov    -0x24(%ebp),%eax
     223:	83 ec 0c             	sub    $0xc,%esp
     226:	50                   	push   %eax
     227:	e8 2c 0d 00 00       	call   f58 <close>
     22c:	83 c4 10             	add    $0x10,%esp
    close(p[1]);
     22f:	8b 45 e0             	mov    -0x20(%ebp),%eax
     232:	83 ec 0c             	sub    $0xc,%esp
     235:	50                   	push   %eax
     236:	e8 1d 0d 00 00       	call   f58 <close>
     23b:	83 c4 10             	add    $0x10,%esp
    wait();
     23e:	e8 f5 0c 00 00       	call   f38 <wait>
    wait();
     243:	e8 f0 0c 00 00       	call   f38 <wait>
    break;
     248:	eb 22                	jmp    26c <runcmd+0x26c>

  case BACK:
    bcmd = (struct backcmd*)cmd;
     24a:	8b 45 08             	mov    0x8(%ebp),%eax
     24d:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(fork1() == 0)
     250:	e8 90 01 00 00       	call   3e5 <fork1>
     255:	85 c0                	test   %eax,%eax
     257:	75 12                	jne    26b <runcmd+0x26b>
      runcmd(bcmd->cmd);
     259:	8b 45 f4             	mov    -0xc(%ebp),%eax
     25c:	8b 40 04             	mov    0x4(%eax),%eax
     25f:	83 ec 0c             	sub    $0xc,%esp
     262:	50                   	push   %eax
     263:	e8 98 fd ff ff       	call   0 <runcmd>
     268:	83 c4 10             	add    $0x10,%esp
    break;
     26b:	90                   	nop
  }
  exit();
     26c:	e8 bf 0c 00 00       	call   f30 <exit>

00000271 <getcmd>:
}

int
getcmd(char *buf, int nbuf)
{
     271:	55                   	push   %ebp
     272:	89 e5                	mov    %esp,%ebp
     274:	83 ec 08             	sub    $0x8,%esp
  printf(2, "$ ");
     277:	83 ec 08             	sub    $0x8,%esp
     27a:	68 8f 14 00 00       	push   $0x148f
     27f:	6a 02                	push   $0x2
     281:	e8 26 0e 00 00       	call   10ac <printf>
     286:	83 c4 10             	add    $0x10,%esp
  memset(buf, 0, nbuf);
     289:	8b 45 0c             	mov    0xc(%ebp),%eax
     28c:	83 ec 04             	sub    $0x4,%esp
     28f:	50                   	push   %eax
     290:	6a 00                	push   $0x0
     292:	ff 75 08             	push   0x8(%ebp)
     295:	e8 fb 0a 00 00       	call   d95 <memset>
     29a:	83 c4 10             	add    $0x10,%esp
  gets(buf, nbuf);
     29d:	83 ec 08             	sub    $0x8,%esp
     2a0:	ff 75 0c             	push   0xc(%ebp)
     2a3:	ff 75 08             	push   0x8(%ebp)
     2a6:	e8 37 0b 00 00       	call   de2 <gets>
     2ab:	83 c4 10             	add    $0x10,%esp
  if(buf[0] == 0) // EOF
     2ae:	8b 45 08             	mov    0x8(%ebp),%eax
     2b1:	0f b6 00             	movzbl (%eax),%eax
     2b4:	84 c0                	test   %al,%al
     2b6:	75 07                	jne    2bf <getcmd+0x4e>
    return -1;
     2b8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     2bd:	eb 05                	jmp    2c4 <getcmd+0x53>
  return 0;
     2bf:	b8 00 00 00 00       	mov    $0x0,%eax
}
     2c4:	c9                   	leave
     2c5:	c3                   	ret

000002c6 <main>:

int
main(void)
{
     2c6:	8d 4c 24 04          	lea    0x4(%esp),%ecx
     2ca:	83 e4 f0             	and    $0xfffffff0,%esp
     2cd:	ff 71 fc             	push   -0x4(%ecx)
     2d0:	55                   	push   %ebp
     2d1:	89 e5                	mov    %esp,%ebp
     2d3:	51                   	push   %ecx
     2d4:	83 ec 14             	sub    $0x14,%esp
  static char buf[100];
  int fd;

  // Ensure that three file descriptors are open.
  while((fd = open("console", O_RDWR)) >= 0){
     2d7:	eb 16                	jmp    2ef <main+0x29>
    if(fd >= 3){
     2d9:	83 7d f4 02          	cmpl   $0x2,-0xc(%ebp)
     2dd:	7e 10                	jle    2ef <main+0x29>
      close(fd);
     2df:	83 ec 0c             	sub    $0xc,%esp
     2e2:	ff 75 f4             	push   -0xc(%ebp)
     2e5:	e8 6e 0c 00 00       	call   f58 <close>
     2ea:	83 c4 10             	add    $0x10,%esp
      break;
     2ed:	eb 1b                	jmp    30a <main+0x44>
  while((fd = open("console", O_RDWR)) >= 0){
     2ef:	83 ec 08             	sub    $0x8,%esp
     2f2:	6a 02                	push   $0x2
     2f4:	68 92 14 00 00       	push   $0x1492
     2f9:	e8 72 0c 00 00       	call   f70 <open>
     2fe:	83 c4 10             	add    $0x10,%esp
     301:	89 45 f4             	mov    %eax,-0xc(%ebp)
     304:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     308:	79 cf                	jns    2d9 <main+0x13>
    }
  }

  // Read and run input commands.
  while(getcmd(buf, sizeof(buf)) >= 0){
     30a:	e9 97 00 00 00       	jmp    3a6 <main+0xe0>
    if(buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' '){
     30f:	0f b6 05 00 1a 00 00 	movzbl 0x1a00,%eax
     316:	3c 63                	cmp    $0x63,%al
     318:	75 5f                	jne    379 <main+0xb3>
     31a:	0f b6 05 01 1a 00 00 	movzbl 0x1a01,%eax
     321:	3c 64                	cmp    $0x64,%al
     323:	75 54                	jne    379 <main+0xb3>
     325:	0f b6 05 02 1a 00 00 	movzbl 0x1a02,%eax
     32c:	3c 20                	cmp    $0x20,%al
     32e:	75 49                	jne    379 <main+0xb3>
      // Chdir must be called by the parent, not the child.
      buf[strlen(buf)-1] = 0;  // chop \n
     330:	83 ec 0c             	sub    $0xc,%esp
     333:	68 00 1a 00 00       	push   $0x1a00
     338:	e8 31 0a 00 00       	call   d6e <strlen>
     33d:	83 c4 10             	add    $0x10,%esp
     340:	83 e8 01             	sub    $0x1,%eax
     343:	c6 80 00 1a 00 00 00 	movb   $0x0,0x1a00(%eax)
      if(chdir(buf+3) < 0)
     34a:	b8 03 1a 00 00       	mov    $0x1a03,%eax
     34f:	83 ec 0c             	sub    $0xc,%esp
     352:	50                   	push   %eax
     353:	e8 48 0c 00 00       	call   fa0 <chdir>
     358:	83 c4 10             	add    $0x10,%esp
     35b:	85 c0                	test   %eax,%eax
     35d:	79 46                	jns    3a5 <main+0xdf>
        printf(2, "cannot cd %s\n", buf+3);
     35f:	b8 03 1a 00 00       	mov    $0x1a03,%eax
     364:	83 ec 04             	sub    $0x4,%esp
     367:	50                   	push   %eax
     368:	68 9a 14 00 00       	push   $0x149a
     36d:	6a 02                	push   $0x2
     36f:	e8 38 0d 00 00       	call   10ac <printf>
     374:	83 c4 10             	add    $0x10,%esp
      continue;
     377:	eb 2c                	jmp    3a5 <main+0xdf>
    }
    if(fork1() == 0)
     379:	e8 67 00 00 00       	call   3e5 <fork1>
     37e:	85 c0                	test   %eax,%eax
     380:	75 1c                	jne    39e <main+0xd8>
      runcmd(parsecmd(buf));
     382:	83 ec 0c             	sub    $0xc,%esp
     385:	68 00 1a 00 00       	push   $0x1a00
     38a:	e8 ad 03 00 00       	call   73c <parsecmd>
     38f:	83 c4 10             	add    $0x10,%esp
     392:	83 ec 0c             	sub    $0xc,%esp
     395:	50                   	push   %eax
     396:	e8 65 fc ff ff       	call   0 <runcmd>
     39b:	83 c4 10             	add    $0x10,%esp
    wait();
     39e:	e8 95 0b 00 00       	call   f38 <wait>
     3a3:	eb 01                	jmp    3a6 <main+0xe0>
      continue;
     3a5:	90                   	nop
  while(getcmd(buf, sizeof(buf)) >= 0){
     3a6:	83 ec 08             	sub    $0x8,%esp
     3a9:	6a 64                	push   $0x64
     3ab:	68 00 1a 00 00       	push   $0x1a00
     3b0:	e8 bc fe ff ff       	call   271 <getcmd>
     3b5:	83 c4 10             	add    $0x10,%esp
     3b8:	85 c0                	test   %eax,%eax
     3ba:	0f 89 4f ff ff ff    	jns    30f <main+0x49>
  }
  exit();
     3c0:	e8 6b 0b 00 00       	call   f30 <exit>

000003c5 <panic>:
}

void
panic(char *s)
{
     3c5:	55                   	push   %ebp
     3c6:	89 e5                	mov    %esp,%ebp
     3c8:	83 ec 08             	sub    $0x8,%esp
  printf(2, "%s\n", s);
     3cb:	83 ec 04             	sub    $0x4,%esp
     3ce:	ff 75 08             	push   0x8(%ebp)
     3d1:	68 a8 14 00 00       	push   $0x14a8
     3d6:	6a 02                	push   $0x2
     3d8:	e8 cf 0c 00 00       	call   10ac <printf>
     3dd:	83 c4 10             	add    $0x10,%esp
  exit();
     3e0:	e8 4b 0b 00 00       	call   f30 <exit>

000003e5 <fork1>:
}

int
fork1(void)
{
     3e5:	55                   	push   %ebp
     3e6:	89 e5                	mov    %esp,%ebp
     3e8:	83 ec 18             	sub    $0x18,%esp
  int pid;

  pid = fork();
     3eb:	e8 38 0b 00 00       	call   f28 <fork>
     3f0:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(pid == -1)
     3f3:	83 7d f4 ff          	cmpl   $0xffffffff,-0xc(%ebp)
     3f7:	75 10                	jne    409 <fork1+0x24>
    panic("fork");
     3f9:	83 ec 0c             	sub    $0xc,%esp
     3fc:	68 ac 14 00 00       	push   $0x14ac
     401:	e8 bf ff ff ff       	call   3c5 <panic>
     406:	83 c4 10             	add    $0x10,%esp
  return pid;
     409:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
     40c:	c9                   	leave
     40d:	c3                   	ret

0000040e <execcmd>:
//PAGEBREAK!
// Constructors

struct cmd*
execcmd(void)
{
     40e:	55                   	push   %ebp
     40f:	89 e5                	mov    %esp,%ebp
     411:	83 ec 18             	sub    $0x18,%esp
  struct execcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     414:	83 ec 0c             	sub    $0xc,%esp
     417:	6a 54                	push   $0x54
     419:	e8 62 0f 00 00       	call   1380 <malloc>
     41e:	83 c4 10             	add    $0x10,%esp
     421:	89 45 f4             	mov    %eax,-0xc(%ebp)
  memset(cmd, 0, sizeof(*cmd));
     424:	83 ec 04             	sub    $0x4,%esp
     427:	6a 54                	push   $0x54
     429:	6a 00                	push   $0x0
     42b:	ff 75 f4             	push   -0xc(%ebp)
     42e:	e8 62 09 00 00       	call   d95 <memset>
     433:	83 c4 10             	add    $0x10,%esp
  cmd->type = EXEC;
     436:	8b 45 f4             	mov    -0xc(%ebp),%eax
     439:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  return (struct cmd*)cmd;
     43f:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
     442:	c9                   	leave
     443:	c3                   	ret

00000444 <redircmd>:

struct cmd*
redircmd(struct cmd *subcmd, char *file, char *efile, int mode, int fd)
{
     444:	55                   	push   %ebp
     445:	89 e5                	mov    %esp,%ebp
     447:	83 ec 18             	sub    $0x18,%esp
  struct redircmd *cmd;

  cmd = malloc(sizeof(*cmd));
     44a:	83 ec 0c             	sub    $0xc,%esp
     44d:	6a 18                	push   $0x18
     44f:	e8 2c 0f 00 00       	call   1380 <malloc>
     454:	83 c4 10             	add    $0x10,%esp
     457:	89 45 f4             	mov    %eax,-0xc(%ebp)
  memset(cmd, 0, sizeof(*cmd));
     45a:	83 ec 04             	sub    $0x4,%esp
     45d:	6a 18                	push   $0x18
     45f:	6a 00                	push   $0x0
     461:	ff 75 f4             	push   -0xc(%ebp)
     464:	e8 2c 09 00 00       	call   d95 <memset>
     469:	83 c4 10             	add    $0x10,%esp
  cmd->type = REDIR;
     46c:	8b 45 f4             	mov    -0xc(%ebp),%eax
     46f:	c7 00 02 00 00 00    	movl   $0x2,(%eax)
  cmd->cmd = subcmd;
     475:	8b 45 f4             	mov    -0xc(%ebp),%eax
     478:	8b 55 08             	mov    0x8(%ebp),%edx
     47b:	89 50 04             	mov    %edx,0x4(%eax)
  cmd->file = file;
     47e:	8b 45 f4             	mov    -0xc(%ebp),%eax
     481:	8b 55 0c             	mov    0xc(%ebp),%edx
     484:	89 50 08             	mov    %edx,0x8(%eax)
  cmd->efile = efile;
     487:	8b 45 f4             	mov    -0xc(%ebp),%eax
     48a:	8b 55 10             	mov    0x10(%ebp),%edx
     48d:	89 50 0c             	mov    %edx,0xc(%eax)
  cmd->mode = mode;
     490:	8b 45 f4             	mov    -0xc(%ebp),%eax
     493:	8b 55 14             	mov    0x14(%ebp),%edx
     496:	89 50 10             	mov    %edx,0x10(%eax)
  cmd->fd = fd;
     499:	8b 45 f4             	mov    -0xc(%ebp),%eax
     49c:	8b 55 18             	mov    0x18(%ebp),%edx
     49f:	89 50 14             	mov    %edx,0x14(%eax)
  return (struct cmd*)cmd;
     4a2:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
     4a5:	c9                   	leave
     4a6:	c3                   	ret

000004a7 <pipecmd>:

struct cmd*
pipecmd(struct cmd *left, struct cmd *right)
{
     4a7:	55                   	push   %ebp
     4a8:	89 e5                	mov    %esp,%ebp
     4aa:	83 ec 18             	sub    $0x18,%esp
  struct pipecmd *cmd;

  cmd = malloc(sizeof(*cmd));
     4ad:	83 ec 0c             	sub    $0xc,%esp
     4b0:	6a 0c                	push   $0xc
     4b2:	e8 c9 0e 00 00       	call   1380 <malloc>
     4b7:	83 c4 10             	add    $0x10,%esp
     4ba:	89 45 f4             	mov    %eax,-0xc(%ebp)
  memset(cmd, 0, sizeof(*cmd));
     4bd:	83 ec 04             	sub    $0x4,%esp
     4c0:	6a 0c                	push   $0xc
     4c2:	6a 00                	push   $0x0
     4c4:	ff 75 f4             	push   -0xc(%ebp)
     4c7:	e8 c9 08 00 00       	call   d95 <memset>
     4cc:	83 c4 10             	add    $0x10,%esp
  cmd->type = PIPE;
     4cf:	8b 45 f4             	mov    -0xc(%ebp),%eax
     4d2:	c7 00 03 00 00 00    	movl   $0x3,(%eax)
  cmd->left = left;
     4d8:	8b 45 f4             	mov    -0xc(%ebp),%eax
     4db:	8b 55 08             	mov    0x8(%ebp),%edx
     4de:	89 50 04             	mov    %edx,0x4(%eax)
  cmd->right = right;
     4e1:	8b 45 f4             	mov    -0xc(%ebp),%eax
     4e4:	8b 55 0c             	mov    0xc(%ebp),%edx
     4e7:	89 50 08             	mov    %edx,0x8(%eax)
  return (struct cmd*)cmd;
     4ea:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
     4ed:	c9                   	leave
     4ee:	c3                   	ret

000004ef <listcmd>:

struct cmd*
listcmd(struct cmd *left, struct cmd *right)
{
     4ef:	55                   	push   %ebp
     4f0:	89 e5                	mov    %esp,%ebp
     4f2:	83 ec 18             	sub    $0x18,%esp
  struct listcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     4f5:	83 ec 0c             	sub    $0xc,%esp
     4f8:	6a 0c                	push   $0xc
     4fa:	e8 81 0e 00 00       	call   1380 <malloc>
     4ff:	83 c4 10             	add    $0x10,%esp
     502:	89 45 f4             	mov    %eax,-0xc(%ebp)
  memset(cmd, 0, sizeof(*cmd));
     505:	83 ec 04             	sub    $0x4,%esp
     508:	6a 0c                	push   $0xc
     50a:	6a 00                	push   $0x0
     50c:	ff 75 f4             	push   -0xc(%ebp)
     50f:	e8 81 08 00 00       	call   d95 <memset>
     514:	83 c4 10             	add    $0x10,%esp
  cmd->type = LIST;
     517:	8b 45 f4             	mov    -0xc(%ebp),%eax
     51a:	c7 00 04 00 00 00    	movl   $0x4,(%eax)
  cmd->left = left;
     520:	8b 45 f4             	mov    -0xc(%ebp),%eax
     523:	8b 55 08             	mov    0x8(%ebp),%edx
     526:	89 50 04             	mov    %edx,0x4(%eax)
  cmd->right = right;
     529:	8b 45 f4             	mov    -0xc(%ebp),%eax
     52c:	8b 55 0c             	mov    0xc(%ebp),%edx
     52f:	89 50 08             	mov    %edx,0x8(%eax)
  return (struct cmd*)cmd;
     532:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
     535:	c9                   	leave
     536:	c3                   	ret

00000537 <backcmd>:

struct cmd*
backcmd(struct cmd *subcmd)
{
     537:	55                   	push   %ebp
     538:	89 e5                	mov    %esp,%ebp
     53a:	83 ec 18             	sub    $0x18,%esp
  struct backcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     53d:	83 ec 0c             	sub    $0xc,%esp
     540:	6a 08                	push   $0x8
     542:	e8 39 0e 00 00       	call   1380 <malloc>
     547:	83 c4 10             	add    $0x10,%esp
     54a:	89 45 f4             	mov    %eax,-0xc(%ebp)
  memset(cmd, 0, sizeof(*cmd));
     54d:	83 ec 04             	sub    $0x4,%esp
     550:	6a 08                	push   $0x8
     552:	6a 00                	push   $0x0
     554:	ff 75 f4             	push   -0xc(%ebp)
     557:	e8 39 08 00 00       	call   d95 <memset>
     55c:	83 c4 10             	add    $0x10,%esp
  cmd->type = BACK;
     55f:	8b 45 f4             	mov    -0xc(%ebp),%eax
     562:	c7 00 05 00 00 00    	movl   $0x5,(%eax)
  cmd->cmd = subcmd;
     568:	8b 45 f4             	mov    -0xc(%ebp),%eax
     56b:	8b 55 08             	mov    0x8(%ebp),%edx
     56e:	89 50 04             	mov    %edx,0x4(%eax)
  return (struct cmd*)cmd;
     571:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
     574:	c9                   	leave
     575:	c3                   	ret

00000576 <gettoken>:
char whitespace[] = " \t\r\n\v";
char symbols[] = "<|>&;()";

int
gettoken(char **ps, char *es, char **q, char **eq)
{
     576:	55                   	push   %ebp
     577:	89 e5                	mov    %esp,%ebp
     579:	83 ec 18             	sub    $0x18,%esp
  char *s;
  int ret;

  s = *ps;
     57c:	8b 45 08             	mov    0x8(%ebp),%eax
     57f:	8b 00                	mov    (%eax),%eax
     581:	89 45 f4             	mov    %eax,-0xc(%ebp)
  while(s < es && strchr(whitespace, *s))
     584:	eb 04                	jmp    58a <gettoken+0x14>
    s++;
     586:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  while(s < es && strchr(whitespace, *s))
     58a:	8b 45 f4             	mov    -0xc(%ebp),%eax
     58d:	3b 45 0c             	cmp    0xc(%ebp),%eax
     590:	73 1e                	jae    5b0 <gettoken+0x3a>
     592:	8b 45 f4             	mov    -0xc(%ebp),%eax
     595:	0f b6 00             	movzbl (%eax),%eax
     598:	0f be c0             	movsbl %al,%eax
     59b:	83 ec 08             	sub    $0x8,%esp
     59e:	50                   	push   %eax
     59f:	68 d4 19 00 00       	push   $0x19d4
     5a4:	e8 06 08 00 00       	call   daf <strchr>
     5a9:	83 c4 10             	add    $0x10,%esp
     5ac:	85 c0                	test   %eax,%eax
     5ae:	75 d6                	jne    586 <gettoken+0x10>
  if(q)
     5b0:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
     5b4:	74 08                	je     5be <gettoken+0x48>
    *q = s;
     5b6:	8b 45 10             	mov    0x10(%ebp),%eax
     5b9:	8b 55 f4             	mov    -0xc(%ebp),%edx
     5bc:	89 10                	mov    %edx,(%eax)
  ret = *s;
     5be:	8b 45 f4             	mov    -0xc(%ebp),%eax
     5c1:	0f b6 00             	movzbl (%eax),%eax
     5c4:	0f be c0             	movsbl %al,%eax
     5c7:	89 45 f0             	mov    %eax,-0x10(%ebp)
  switch(*s){
     5ca:	8b 45 f4             	mov    -0xc(%ebp),%eax
     5cd:	0f b6 00             	movzbl (%eax),%eax
     5d0:	0f be c0             	movsbl %al,%eax
     5d3:	83 f8 7c             	cmp    $0x7c,%eax
     5d6:	74 2c                	je     604 <gettoken+0x8e>
     5d8:	83 f8 7c             	cmp    $0x7c,%eax
     5db:	7f 48                	jg     625 <gettoken+0xaf>
     5dd:	83 f8 3e             	cmp    $0x3e,%eax
     5e0:	74 28                	je     60a <gettoken+0x94>
     5e2:	83 f8 3e             	cmp    $0x3e,%eax
     5e5:	7f 3e                	jg     625 <gettoken+0xaf>
     5e7:	83 f8 3c             	cmp    $0x3c,%eax
     5ea:	7f 39                	jg     625 <gettoken+0xaf>
     5ec:	83 f8 3b             	cmp    $0x3b,%eax
     5ef:	7d 13                	jge    604 <gettoken+0x8e>
     5f1:	83 f8 29             	cmp    $0x29,%eax
     5f4:	7f 2f                	jg     625 <gettoken+0xaf>
     5f6:	83 f8 28             	cmp    $0x28,%eax
     5f9:	7d 09                	jge    604 <gettoken+0x8e>
     5fb:	85 c0                	test   %eax,%eax
     5fd:	74 79                	je     678 <gettoken+0x102>
     5ff:	83 f8 26             	cmp    $0x26,%eax
     602:	75 21                	jne    625 <gettoken+0xaf>
  case '(':
  case ')':
  case ';':
  case '&':
  case '<':
    s++;
     604:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    break;
     608:	eb 75                	jmp    67f <gettoken+0x109>
  case '>':
    s++;
     60a:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    if(*s == '>'){
     60e:	8b 45 f4             	mov    -0xc(%ebp),%eax
     611:	0f b6 00             	movzbl (%eax),%eax
     614:	3c 3e                	cmp    $0x3e,%al
     616:	75 63                	jne    67b <gettoken+0x105>
      ret = '+';
     618:	c7 45 f0 2b 00 00 00 	movl   $0x2b,-0x10(%ebp)
      s++;
     61f:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    }
    break;
     623:	eb 56                	jmp    67b <gettoken+0x105>
  default:
    ret = 'a';
     625:	c7 45 f0 61 00 00 00 	movl   $0x61,-0x10(%ebp)
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
     62c:	eb 04                	jmp    632 <gettoken+0xbc>
      s++;
     62e:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
     632:	8b 45 f4             	mov    -0xc(%ebp),%eax
     635:	3b 45 0c             	cmp    0xc(%ebp),%eax
     638:	73 44                	jae    67e <gettoken+0x108>
     63a:	8b 45 f4             	mov    -0xc(%ebp),%eax
     63d:	0f b6 00             	movzbl (%eax),%eax
     640:	0f be c0             	movsbl %al,%eax
     643:	83 ec 08             	sub    $0x8,%esp
     646:	50                   	push   %eax
     647:	68 d4 19 00 00       	push   $0x19d4
     64c:	e8 5e 07 00 00       	call   daf <strchr>
     651:	83 c4 10             	add    $0x10,%esp
     654:	85 c0                	test   %eax,%eax
     656:	75 26                	jne    67e <gettoken+0x108>
     658:	8b 45 f4             	mov    -0xc(%ebp),%eax
     65b:	0f b6 00             	movzbl (%eax),%eax
     65e:	0f be c0             	movsbl %al,%eax
     661:	83 ec 08             	sub    $0x8,%esp
     664:	50                   	push   %eax
     665:	68 dc 19 00 00       	push   $0x19dc
     66a:	e8 40 07 00 00       	call   daf <strchr>
     66f:	83 c4 10             	add    $0x10,%esp
     672:	85 c0                	test   %eax,%eax
     674:	74 b8                	je     62e <gettoken+0xb8>
    break;
     676:	eb 06                	jmp    67e <gettoken+0x108>
    break;
     678:	90                   	nop
     679:	eb 04                	jmp    67f <gettoken+0x109>
    break;
     67b:	90                   	nop
     67c:	eb 01                	jmp    67f <gettoken+0x109>
    break;
     67e:	90                   	nop
  }
  if(eq)
     67f:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
     683:	74 0e                	je     693 <gettoken+0x11d>
    *eq = s;
     685:	8b 45 14             	mov    0x14(%ebp),%eax
     688:	8b 55 f4             	mov    -0xc(%ebp),%edx
     68b:	89 10                	mov    %edx,(%eax)

  while(s < es && strchr(whitespace, *s))
     68d:	eb 04                	jmp    693 <gettoken+0x11d>
    s++;
     68f:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  while(s < es && strchr(whitespace, *s))
     693:	8b 45 f4             	mov    -0xc(%ebp),%eax
     696:	3b 45 0c             	cmp    0xc(%ebp),%eax
     699:	73 1e                	jae    6b9 <gettoken+0x143>
     69b:	8b 45 f4             	mov    -0xc(%ebp),%eax
     69e:	0f b6 00             	movzbl (%eax),%eax
     6a1:	0f be c0             	movsbl %al,%eax
     6a4:	83 ec 08             	sub    $0x8,%esp
     6a7:	50                   	push   %eax
     6a8:	68 d4 19 00 00       	push   $0x19d4
     6ad:	e8 fd 06 00 00       	call   daf <strchr>
     6b2:	83 c4 10             	add    $0x10,%esp
     6b5:	85 c0                	test   %eax,%eax
     6b7:	75 d6                	jne    68f <gettoken+0x119>
  *ps = s;
     6b9:	8b 45 08             	mov    0x8(%ebp),%eax
     6bc:	8b 55 f4             	mov    -0xc(%ebp),%edx
     6bf:	89 10                	mov    %edx,(%eax)
  return ret;
     6c1:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
     6c4:	c9                   	leave
     6c5:	c3                   	ret

000006c6 <peek>:

int
peek(char **ps, char *es, char *toks)
{
     6c6:	55                   	push   %ebp
     6c7:	89 e5                	mov    %esp,%ebp
     6c9:	83 ec 18             	sub    $0x18,%esp
  char *s;

  s = *ps;
     6cc:	8b 45 08             	mov    0x8(%ebp),%eax
     6cf:	8b 00                	mov    (%eax),%eax
     6d1:	89 45 f4             	mov    %eax,-0xc(%ebp)
  while(s < es && strchr(whitespace, *s))
     6d4:	eb 04                	jmp    6da <peek+0x14>
    s++;
     6d6:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  while(s < es && strchr(whitespace, *s))
     6da:	8b 45 f4             	mov    -0xc(%ebp),%eax
     6dd:	3b 45 0c             	cmp    0xc(%ebp),%eax
     6e0:	73 1e                	jae    700 <peek+0x3a>
     6e2:	8b 45 f4             	mov    -0xc(%ebp),%eax
     6e5:	0f b6 00             	movzbl (%eax),%eax
     6e8:	0f be c0             	movsbl %al,%eax
     6eb:	83 ec 08             	sub    $0x8,%esp
     6ee:	50                   	push   %eax
     6ef:	68 d4 19 00 00       	push   $0x19d4
     6f4:	e8 b6 06 00 00       	call   daf <strchr>
     6f9:	83 c4 10             	add    $0x10,%esp
     6fc:	85 c0                	test   %eax,%eax
     6fe:	75 d6                	jne    6d6 <peek+0x10>
  *ps = s;
     700:	8b 45 08             	mov    0x8(%ebp),%eax
     703:	8b 55 f4             	mov    -0xc(%ebp),%edx
     706:	89 10                	mov    %edx,(%eax)
  return *s && strchr(toks, *s);
     708:	8b 45 f4             	mov    -0xc(%ebp),%eax
     70b:	0f b6 00             	movzbl (%eax),%eax
     70e:	84 c0                	test   %al,%al
     710:	74 23                	je     735 <peek+0x6f>
     712:	8b 45 f4             	mov    -0xc(%ebp),%eax
     715:	0f b6 00             	movzbl (%eax),%eax
     718:	0f be c0             	movsbl %al,%eax
     71b:	83 ec 08             	sub    $0x8,%esp
     71e:	50                   	push   %eax
     71f:	ff 75 10             	push   0x10(%ebp)
     722:	e8 88 06 00 00       	call   daf <strchr>
     727:	83 c4 10             	add    $0x10,%esp
     72a:	85 c0                	test   %eax,%eax
     72c:	74 07                	je     735 <peek+0x6f>
     72e:	b8 01 00 00 00       	mov    $0x1,%eax
     733:	eb 05                	jmp    73a <peek+0x74>
     735:	b8 00 00 00 00       	mov    $0x0,%eax
}
     73a:	c9                   	leave
     73b:	c3                   	ret

0000073c <parsecmd>:
struct cmd *parseexec(char**, char*);
struct cmd *nulterminate(struct cmd*);

struct cmd*
parsecmd(char *s)
{
     73c:	55                   	push   %ebp
     73d:	89 e5                	mov    %esp,%ebp
     73f:	53                   	push   %ebx
     740:	83 ec 14             	sub    $0x14,%esp
  char *es;
  struct cmd *cmd;

  es = s + strlen(s);
     743:	8b 5d 08             	mov    0x8(%ebp),%ebx
     746:	8b 45 08             	mov    0x8(%ebp),%eax
     749:	83 ec 0c             	sub    $0xc,%esp
     74c:	50                   	push   %eax
     74d:	e8 1c 06 00 00       	call   d6e <strlen>
     752:	83 c4 10             	add    $0x10,%esp
     755:	01 d8                	add    %ebx,%eax
     757:	89 45 f4             	mov    %eax,-0xc(%ebp)
  cmd = parseline(&s, es);
     75a:	83 ec 08             	sub    $0x8,%esp
     75d:	ff 75 f4             	push   -0xc(%ebp)
     760:	8d 45 08             	lea    0x8(%ebp),%eax
     763:	50                   	push   %eax
     764:	e8 61 00 00 00       	call   7ca <parseline>
     769:	83 c4 10             	add    $0x10,%esp
     76c:	89 45 f0             	mov    %eax,-0x10(%ebp)
  peek(&s, es, "");
     76f:	83 ec 04             	sub    $0x4,%esp
     772:	68 b1 14 00 00       	push   $0x14b1
     777:	ff 75 f4             	push   -0xc(%ebp)
     77a:	8d 45 08             	lea    0x8(%ebp),%eax
     77d:	50                   	push   %eax
     77e:	e8 43 ff ff ff       	call   6c6 <peek>
     783:	83 c4 10             	add    $0x10,%esp
  if(s != es){
     786:	8b 45 08             	mov    0x8(%ebp),%eax
     789:	39 45 f4             	cmp    %eax,-0xc(%ebp)
     78c:	74 26                	je     7b4 <parsecmd+0x78>
    printf(2, "leftovers: %s\n", s);
     78e:	8b 45 08             	mov    0x8(%ebp),%eax
     791:	83 ec 04             	sub    $0x4,%esp
     794:	50                   	push   %eax
     795:	68 b2 14 00 00       	push   $0x14b2
     79a:	6a 02                	push   $0x2
     79c:	e8 0b 09 00 00       	call   10ac <printf>
     7a1:	83 c4 10             	add    $0x10,%esp
    panic("syntax");
     7a4:	83 ec 0c             	sub    $0xc,%esp
     7a7:	68 c1 14 00 00       	push   $0x14c1
     7ac:	e8 14 fc ff ff       	call   3c5 <panic>
     7b1:	83 c4 10             	add    $0x10,%esp
  }
  nulterminate(cmd);
     7b4:	83 ec 0c             	sub    $0xc,%esp
     7b7:	ff 75 f0             	push   -0x10(%ebp)
     7ba:	e8 ef 03 00 00       	call   bae <nulterminate>
     7bf:	83 c4 10             	add    $0x10,%esp
  return cmd;
     7c2:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
     7c5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     7c8:	c9                   	leave
     7c9:	c3                   	ret

000007ca <parseline>:

struct cmd*
parseline(char **ps, char *es)
{
     7ca:	55                   	push   %ebp
     7cb:	89 e5                	mov    %esp,%ebp
     7cd:	83 ec 18             	sub    $0x18,%esp
  struct cmd *cmd;

  cmd = parsepipe(ps, es);
     7d0:	83 ec 08             	sub    $0x8,%esp
     7d3:	ff 75 0c             	push   0xc(%ebp)
     7d6:	ff 75 08             	push   0x8(%ebp)
     7d9:	e8 99 00 00 00       	call   877 <parsepipe>
     7de:	83 c4 10             	add    $0x10,%esp
     7e1:	89 45 f4             	mov    %eax,-0xc(%ebp)
  while(peek(ps, es, "&")){
     7e4:	eb 23                	jmp    809 <parseline+0x3f>
    gettoken(ps, es, 0, 0);
     7e6:	6a 00                	push   $0x0
     7e8:	6a 00                	push   $0x0
     7ea:	ff 75 0c             	push   0xc(%ebp)
     7ed:	ff 75 08             	push   0x8(%ebp)
     7f0:	e8 81 fd ff ff       	call   576 <gettoken>
     7f5:	83 c4 10             	add    $0x10,%esp
    cmd = backcmd(cmd);
     7f8:	83 ec 0c             	sub    $0xc,%esp
     7fb:	ff 75 f4             	push   -0xc(%ebp)
     7fe:	e8 34 fd ff ff       	call   537 <backcmd>
     803:	83 c4 10             	add    $0x10,%esp
     806:	89 45 f4             	mov    %eax,-0xc(%ebp)
  while(peek(ps, es, "&")){
     809:	83 ec 04             	sub    $0x4,%esp
     80c:	68 c8 14 00 00       	push   $0x14c8
     811:	ff 75 0c             	push   0xc(%ebp)
     814:	ff 75 08             	push   0x8(%ebp)
     817:	e8 aa fe ff ff       	call   6c6 <peek>
     81c:	83 c4 10             	add    $0x10,%esp
     81f:	85 c0                	test   %eax,%eax
     821:	75 c3                	jne    7e6 <parseline+0x1c>
  }
  if(peek(ps, es, ";")){
     823:	83 ec 04             	sub    $0x4,%esp
     826:	68 ca 14 00 00       	push   $0x14ca
     82b:	ff 75 0c             	push   0xc(%ebp)
     82e:	ff 75 08             	push   0x8(%ebp)
     831:	e8 90 fe ff ff       	call   6c6 <peek>
     836:	83 c4 10             	add    $0x10,%esp
     839:	85 c0                	test   %eax,%eax
     83b:	74 35                	je     872 <parseline+0xa8>
    gettoken(ps, es, 0, 0);
     83d:	6a 00                	push   $0x0
     83f:	6a 00                	push   $0x0
     841:	ff 75 0c             	push   0xc(%ebp)
     844:	ff 75 08             	push   0x8(%ebp)
     847:	e8 2a fd ff ff       	call   576 <gettoken>
     84c:	83 c4 10             	add    $0x10,%esp
    cmd = listcmd(cmd, parseline(ps, es));
     84f:	83 ec 08             	sub    $0x8,%esp
     852:	ff 75 0c             	push   0xc(%ebp)
     855:	ff 75 08             	push   0x8(%ebp)
     858:	e8 6d ff ff ff       	call   7ca <parseline>
     85d:	83 c4 10             	add    $0x10,%esp
     860:	83 ec 08             	sub    $0x8,%esp
     863:	50                   	push   %eax
     864:	ff 75 f4             	push   -0xc(%ebp)
     867:	e8 83 fc ff ff       	call   4ef <listcmd>
     86c:	83 c4 10             	add    $0x10,%esp
     86f:	89 45 f4             	mov    %eax,-0xc(%ebp)
  }
  return cmd;
     872:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
     875:	c9                   	leave
     876:	c3                   	ret

00000877 <parsepipe>:

struct cmd*
parsepipe(char **ps, char *es)
{
     877:	55                   	push   %ebp
     878:	89 e5                	mov    %esp,%ebp
     87a:	83 ec 18             	sub    $0x18,%esp
  struct cmd *cmd;

  cmd = parseexec(ps, es);
     87d:	83 ec 08             	sub    $0x8,%esp
     880:	ff 75 0c             	push   0xc(%ebp)
     883:	ff 75 08             	push   0x8(%ebp)
     886:	e8 f0 01 00 00       	call   a7b <parseexec>
     88b:	83 c4 10             	add    $0x10,%esp
     88e:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(peek(ps, es, "|")){
     891:	83 ec 04             	sub    $0x4,%esp
     894:	68 cc 14 00 00       	push   $0x14cc
     899:	ff 75 0c             	push   0xc(%ebp)
     89c:	ff 75 08             	push   0x8(%ebp)
     89f:	e8 22 fe ff ff       	call   6c6 <peek>
     8a4:	83 c4 10             	add    $0x10,%esp
     8a7:	85 c0                	test   %eax,%eax
     8a9:	74 35                	je     8e0 <parsepipe+0x69>
    gettoken(ps, es, 0, 0);
     8ab:	6a 00                	push   $0x0
     8ad:	6a 00                	push   $0x0
     8af:	ff 75 0c             	push   0xc(%ebp)
     8b2:	ff 75 08             	push   0x8(%ebp)
     8b5:	e8 bc fc ff ff       	call   576 <gettoken>
     8ba:	83 c4 10             	add    $0x10,%esp
    cmd = pipecmd(cmd, parsepipe(ps, es));
     8bd:	83 ec 08             	sub    $0x8,%esp
     8c0:	ff 75 0c             	push   0xc(%ebp)
     8c3:	ff 75 08             	push   0x8(%ebp)
     8c6:	e8 ac ff ff ff       	call   877 <parsepipe>
     8cb:	83 c4 10             	add    $0x10,%esp
     8ce:	83 ec 08             	sub    $0x8,%esp
     8d1:	50                   	push   %eax
     8d2:	ff 75 f4             	push   -0xc(%ebp)
     8d5:	e8 cd fb ff ff       	call   4a7 <pipecmd>
     8da:	83 c4 10             	add    $0x10,%esp
     8dd:	89 45 f4             	mov    %eax,-0xc(%ebp)
  }
  return cmd;
     8e0:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
     8e3:	c9                   	leave
     8e4:	c3                   	ret

000008e5 <parseredirs>:

struct cmd*
parseredirs(struct cmd *cmd, char **ps, char *es)
{
     8e5:	55                   	push   %ebp
     8e6:	89 e5                	mov    %esp,%ebp
     8e8:	83 ec 18             	sub    $0x18,%esp
  int tok;
  char *q, *eq;

  while(peek(ps, es, "<>")){
     8eb:	e9 ba 00 00 00       	jmp    9aa <parseredirs+0xc5>
    tok = gettoken(ps, es, 0, 0);
     8f0:	6a 00                	push   $0x0
     8f2:	6a 00                	push   $0x0
     8f4:	ff 75 10             	push   0x10(%ebp)
     8f7:	ff 75 0c             	push   0xc(%ebp)
     8fa:	e8 77 fc ff ff       	call   576 <gettoken>
     8ff:	83 c4 10             	add    $0x10,%esp
     902:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(gettoken(ps, es, &q, &eq) != 'a')
     905:	8d 45 ec             	lea    -0x14(%ebp),%eax
     908:	50                   	push   %eax
     909:	8d 45 f0             	lea    -0x10(%ebp),%eax
     90c:	50                   	push   %eax
     90d:	ff 75 10             	push   0x10(%ebp)
     910:	ff 75 0c             	push   0xc(%ebp)
     913:	e8 5e fc ff ff       	call   576 <gettoken>
     918:	83 c4 10             	add    $0x10,%esp
     91b:	83 f8 61             	cmp    $0x61,%eax
     91e:	74 10                	je     930 <parseredirs+0x4b>
      panic("missing file for redirection");
     920:	83 ec 0c             	sub    $0xc,%esp
     923:	68 ce 14 00 00       	push   $0x14ce
     928:	e8 98 fa ff ff       	call   3c5 <panic>
     92d:	83 c4 10             	add    $0x10,%esp
    switch(tok){
     930:	83 7d f4 3e          	cmpl   $0x3e,-0xc(%ebp)
     934:	74 31                	je     967 <parseredirs+0x82>
     936:	83 7d f4 3e          	cmpl   $0x3e,-0xc(%ebp)
     93a:	7f 6e                	jg     9aa <parseredirs+0xc5>
     93c:	83 7d f4 2b          	cmpl   $0x2b,-0xc(%ebp)
     940:	74 47                	je     989 <parseredirs+0xa4>
     942:	83 7d f4 3c          	cmpl   $0x3c,-0xc(%ebp)
     946:	75 62                	jne    9aa <parseredirs+0xc5>
    case '<':
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
     948:	8b 55 ec             	mov    -0x14(%ebp),%edx
     94b:	8b 45 f0             	mov    -0x10(%ebp),%eax
     94e:	83 ec 0c             	sub    $0xc,%esp
     951:	6a 00                	push   $0x0
     953:	6a 00                	push   $0x0
     955:	52                   	push   %edx
     956:	50                   	push   %eax
     957:	ff 75 08             	push   0x8(%ebp)
     95a:	e8 e5 fa ff ff       	call   444 <redircmd>
     95f:	83 c4 20             	add    $0x20,%esp
     962:	89 45 08             	mov    %eax,0x8(%ebp)
      break;
     965:	eb 43                	jmp    9aa <parseredirs+0xc5>
    case '>':
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
     967:	8b 55 ec             	mov    -0x14(%ebp),%edx
     96a:	8b 45 f0             	mov    -0x10(%ebp),%eax
     96d:	83 ec 0c             	sub    $0xc,%esp
     970:	6a 01                	push   $0x1
     972:	68 01 02 00 00       	push   $0x201
     977:	52                   	push   %edx
     978:	50                   	push   %eax
     979:	ff 75 08             	push   0x8(%ebp)
     97c:	e8 c3 fa ff ff       	call   444 <redircmd>
     981:	83 c4 20             	add    $0x20,%esp
     984:	89 45 08             	mov    %eax,0x8(%ebp)
      break;
     987:	eb 21                	jmp    9aa <parseredirs+0xc5>
    case '+':  // >>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
     989:	8b 55 ec             	mov    -0x14(%ebp),%edx
     98c:	8b 45 f0             	mov    -0x10(%ebp),%eax
     98f:	83 ec 0c             	sub    $0xc,%esp
     992:	6a 01                	push   $0x1
     994:	68 01 02 00 00       	push   $0x201
     999:	52                   	push   %edx
     99a:	50                   	push   %eax
     99b:	ff 75 08             	push   0x8(%ebp)
     99e:	e8 a1 fa ff ff       	call   444 <redircmd>
     9a3:	83 c4 20             	add    $0x20,%esp
     9a6:	89 45 08             	mov    %eax,0x8(%ebp)
      break;
     9a9:	90                   	nop
  while(peek(ps, es, "<>")){
     9aa:	83 ec 04             	sub    $0x4,%esp
     9ad:	68 eb 14 00 00       	push   $0x14eb
     9b2:	ff 75 10             	push   0x10(%ebp)
     9b5:	ff 75 0c             	push   0xc(%ebp)
     9b8:	e8 09 fd ff ff       	call   6c6 <peek>
     9bd:	83 c4 10             	add    $0x10,%esp
     9c0:	85 c0                	test   %eax,%eax
     9c2:	0f 85 28 ff ff ff    	jne    8f0 <parseredirs+0xb>
    }
  }
  return cmd;
     9c8:	8b 45 08             	mov    0x8(%ebp),%eax
}
     9cb:	c9                   	leave
     9cc:	c3                   	ret

000009cd <parseblock>:

struct cmd*
parseblock(char **ps, char *es)
{
     9cd:	55                   	push   %ebp
     9ce:	89 e5                	mov    %esp,%ebp
     9d0:	83 ec 18             	sub    $0x18,%esp
  struct cmd *cmd;

  if(!peek(ps, es, "("))
     9d3:	83 ec 04             	sub    $0x4,%esp
     9d6:	68 ee 14 00 00       	push   $0x14ee
     9db:	ff 75 0c             	push   0xc(%ebp)
     9de:	ff 75 08             	push   0x8(%ebp)
     9e1:	e8 e0 fc ff ff       	call   6c6 <peek>
     9e6:	83 c4 10             	add    $0x10,%esp
     9e9:	85 c0                	test   %eax,%eax
     9eb:	75 10                	jne    9fd <parseblock+0x30>
    panic("parseblock");
     9ed:	83 ec 0c             	sub    $0xc,%esp
     9f0:	68 f0 14 00 00       	push   $0x14f0
     9f5:	e8 cb f9 ff ff       	call   3c5 <panic>
     9fa:	83 c4 10             	add    $0x10,%esp
  gettoken(ps, es, 0, 0);
     9fd:	6a 00                	push   $0x0
     9ff:	6a 00                	push   $0x0
     a01:	ff 75 0c             	push   0xc(%ebp)
     a04:	ff 75 08             	push   0x8(%ebp)
     a07:	e8 6a fb ff ff       	call   576 <gettoken>
     a0c:	83 c4 10             	add    $0x10,%esp
  cmd = parseline(ps, es);
     a0f:	83 ec 08             	sub    $0x8,%esp
     a12:	ff 75 0c             	push   0xc(%ebp)
     a15:	ff 75 08             	push   0x8(%ebp)
     a18:	e8 ad fd ff ff       	call   7ca <parseline>
     a1d:	83 c4 10             	add    $0x10,%esp
     a20:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(!peek(ps, es, ")"))
     a23:	83 ec 04             	sub    $0x4,%esp
     a26:	68 fb 14 00 00       	push   $0x14fb
     a2b:	ff 75 0c             	push   0xc(%ebp)
     a2e:	ff 75 08             	push   0x8(%ebp)
     a31:	e8 90 fc ff ff       	call   6c6 <peek>
     a36:	83 c4 10             	add    $0x10,%esp
     a39:	85 c0                	test   %eax,%eax
     a3b:	75 10                	jne    a4d <parseblock+0x80>
    panic("syntax - missing )");
     a3d:	83 ec 0c             	sub    $0xc,%esp
     a40:	68 fd 14 00 00       	push   $0x14fd
     a45:	e8 7b f9 ff ff       	call   3c5 <panic>
     a4a:	83 c4 10             	add    $0x10,%esp
  gettoken(ps, es, 0, 0);
     a4d:	6a 00                	push   $0x0
     a4f:	6a 00                	push   $0x0
     a51:	ff 75 0c             	push   0xc(%ebp)
     a54:	ff 75 08             	push   0x8(%ebp)
     a57:	e8 1a fb ff ff       	call   576 <gettoken>
     a5c:	83 c4 10             	add    $0x10,%esp
  cmd = parseredirs(cmd, ps, es);
     a5f:	83 ec 04             	sub    $0x4,%esp
     a62:	ff 75 0c             	push   0xc(%ebp)
     a65:	ff 75 08             	push   0x8(%ebp)
     a68:	ff 75 f4             	push   -0xc(%ebp)
     a6b:	e8 75 fe ff ff       	call   8e5 <parseredirs>
     a70:	83 c4 10             	add    $0x10,%esp
     a73:	89 45 f4             	mov    %eax,-0xc(%ebp)
  return cmd;
     a76:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
     a79:	c9                   	leave
     a7a:	c3                   	ret

00000a7b <parseexec>:

struct cmd*
parseexec(char **ps, char *es)
{
     a7b:	55                   	push   %ebp
     a7c:	89 e5                	mov    %esp,%ebp
     a7e:	83 ec 28             	sub    $0x28,%esp
  char *q, *eq;
  int tok, argc;
  struct execcmd *cmd;
  struct cmd *ret;

  if(peek(ps, es, "("))
     a81:	83 ec 04             	sub    $0x4,%esp
     a84:	68 ee 14 00 00       	push   $0x14ee
     a89:	ff 75 0c             	push   0xc(%ebp)
     a8c:	ff 75 08             	push   0x8(%ebp)
     a8f:	e8 32 fc ff ff       	call   6c6 <peek>
     a94:	83 c4 10             	add    $0x10,%esp
     a97:	85 c0                	test   %eax,%eax
     a99:	74 16                	je     ab1 <parseexec+0x36>
    return parseblock(ps, es);
     a9b:	83 ec 08             	sub    $0x8,%esp
     a9e:	ff 75 0c             	push   0xc(%ebp)
     aa1:	ff 75 08             	push   0x8(%ebp)
     aa4:	e8 24 ff ff ff       	call   9cd <parseblock>
     aa9:	83 c4 10             	add    $0x10,%esp
     aac:	e9 fb 00 00 00       	jmp    bac <parseexec+0x131>

  ret = execcmd();
     ab1:	e8 58 f9 ff ff       	call   40e <execcmd>
     ab6:	89 45 f0             	mov    %eax,-0x10(%ebp)
  cmd = (struct execcmd*)ret;
     ab9:	8b 45 f0             	mov    -0x10(%ebp),%eax
     abc:	89 45 ec             	mov    %eax,-0x14(%ebp)

  argc = 0;
     abf:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  ret = parseredirs(ret, ps, es);
     ac6:	83 ec 04             	sub    $0x4,%esp
     ac9:	ff 75 0c             	push   0xc(%ebp)
     acc:	ff 75 08             	push   0x8(%ebp)
     acf:	ff 75 f0             	push   -0x10(%ebp)
     ad2:	e8 0e fe ff ff       	call   8e5 <parseredirs>
     ad7:	83 c4 10             	add    $0x10,%esp
     ada:	89 45 f0             	mov    %eax,-0x10(%ebp)
  while(!peek(ps, es, "|)&;")){
     add:	e9 87 00 00 00       	jmp    b69 <parseexec+0xee>
    if((tok=gettoken(ps, es, &q, &eq)) == 0)
     ae2:	8d 45 e0             	lea    -0x20(%ebp),%eax
     ae5:	50                   	push   %eax
     ae6:	8d 45 e4             	lea    -0x1c(%ebp),%eax
     ae9:	50                   	push   %eax
     aea:	ff 75 0c             	push   0xc(%ebp)
     aed:	ff 75 08             	push   0x8(%ebp)
     af0:	e8 81 fa ff ff       	call   576 <gettoken>
     af5:	83 c4 10             	add    $0x10,%esp
     af8:	89 45 e8             	mov    %eax,-0x18(%ebp)
     afb:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
     aff:	0f 84 84 00 00 00    	je     b89 <parseexec+0x10e>
      break;
    if(tok != 'a')
     b05:	83 7d e8 61          	cmpl   $0x61,-0x18(%ebp)
     b09:	74 10                	je     b1b <parseexec+0xa0>
      panic("syntax");
     b0b:	83 ec 0c             	sub    $0xc,%esp
     b0e:	68 c1 14 00 00       	push   $0x14c1
     b13:	e8 ad f8 ff ff       	call   3c5 <panic>
     b18:	83 c4 10             	add    $0x10,%esp
    cmd->argv[argc] = q;
     b1b:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
     b1e:	8b 45 ec             	mov    -0x14(%ebp),%eax
     b21:	8b 55 f4             	mov    -0xc(%ebp),%edx
     b24:	89 4c 90 04          	mov    %ecx,0x4(%eax,%edx,4)
    cmd->eargv[argc] = eq;
     b28:	8b 55 e0             	mov    -0x20(%ebp),%edx
     b2b:	8b 45 ec             	mov    -0x14(%ebp),%eax
     b2e:	8b 4d f4             	mov    -0xc(%ebp),%ecx
     b31:	83 c1 08             	add    $0x8,%ecx
     b34:	89 54 88 0c          	mov    %edx,0xc(%eax,%ecx,4)
    argc++;
     b38:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    if(argc >= MAXARGS)
     b3c:	83 7d f4 09          	cmpl   $0x9,-0xc(%ebp)
     b40:	7e 10                	jle    b52 <parseexec+0xd7>
      panic("too many args");
     b42:	83 ec 0c             	sub    $0xc,%esp
     b45:	68 10 15 00 00       	push   $0x1510
     b4a:	e8 76 f8 ff ff       	call   3c5 <panic>
     b4f:	83 c4 10             	add    $0x10,%esp
    ret = parseredirs(ret, ps, es);
     b52:	83 ec 04             	sub    $0x4,%esp
     b55:	ff 75 0c             	push   0xc(%ebp)
     b58:	ff 75 08             	push   0x8(%ebp)
     b5b:	ff 75 f0             	push   -0x10(%ebp)
     b5e:	e8 82 fd ff ff       	call   8e5 <parseredirs>
     b63:	83 c4 10             	add    $0x10,%esp
     b66:	89 45 f0             	mov    %eax,-0x10(%ebp)
  while(!peek(ps, es, "|)&;")){
     b69:	83 ec 04             	sub    $0x4,%esp
     b6c:	68 1e 15 00 00       	push   $0x151e
     b71:	ff 75 0c             	push   0xc(%ebp)
     b74:	ff 75 08             	push   0x8(%ebp)
     b77:	e8 4a fb ff ff       	call   6c6 <peek>
     b7c:	83 c4 10             	add    $0x10,%esp
     b7f:	85 c0                	test   %eax,%eax
     b81:	0f 84 5b ff ff ff    	je     ae2 <parseexec+0x67>
     b87:	eb 01                	jmp    b8a <parseexec+0x10f>
      break;
     b89:	90                   	nop
  }
  cmd->argv[argc] = 0;
     b8a:	8b 45 ec             	mov    -0x14(%ebp),%eax
     b8d:	8b 55 f4             	mov    -0xc(%ebp),%edx
     b90:	c7 44 90 04 00 00 00 	movl   $0x0,0x4(%eax,%edx,4)
     b97:	00 
  cmd->eargv[argc] = 0;
     b98:	8b 45 ec             	mov    -0x14(%ebp),%eax
     b9b:	8b 55 f4             	mov    -0xc(%ebp),%edx
     b9e:	83 c2 08             	add    $0x8,%edx
     ba1:	c7 44 90 0c 00 00 00 	movl   $0x0,0xc(%eax,%edx,4)
     ba8:	00 
  return ret;
     ba9:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
     bac:	c9                   	leave
     bad:	c3                   	ret

00000bae <nulterminate>:

// NUL-terminate all the counted strings.
struct cmd*
nulterminate(struct cmd *cmd)
{
     bae:	55                   	push   %ebp
     baf:	89 e5                	mov    %esp,%ebp
     bb1:	83 ec 28             	sub    $0x28,%esp
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  if(cmd == 0)
     bb4:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
     bb8:	75 0a                	jne    bc4 <nulterminate+0x16>
    return 0;
     bba:	b8 00 00 00 00       	mov    $0x0,%eax
     bbf:	e9 13 01 00 00       	jmp    cd7 <nulterminate+0x129>

  switch(cmd->type){
     bc4:	8b 45 08             	mov    0x8(%ebp),%eax
     bc7:	8b 00                	mov    (%eax),%eax
     bc9:	83 f8 05             	cmp    $0x5,%eax
     bcc:	0f 84 e9 00 00 00    	je     cbb <nulterminate+0x10d>
     bd2:	83 f8 05             	cmp    $0x5,%eax
     bd5:	0f 8f f9 00 00 00    	jg     cd4 <nulterminate+0x126>
     bdb:	83 f8 04             	cmp    $0x4,%eax
     bde:	0f 84 ab 00 00 00    	je     c8f <nulterminate+0xe1>
     be4:	83 f8 04             	cmp    $0x4,%eax
     be7:	0f 8f e7 00 00 00    	jg     cd4 <nulterminate+0x126>
     bed:	83 f8 03             	cmp    $0x3,%eax
     bf0:	74 71                	je     c63 <nulterminate+0xb5>
     bf2:	83 f8 03             	cmp    $0x3,%eax
     bf5:	0f 8f d9 00 00 00    	jg     cd4 <nulterminate+0x126>
     bfb:	83 f8 01             	cmp    $0x1,%eax
     bfe:	74 0a                	je     c0a <nulterminate+0x5c>
     c00:	83 f8 02             	cmp    $0x2,%eax
     c03:	74 3b                	je     c40 <nulterminate+0x92>
     c05:	e9 ca 00 00 00       	jmp    cd4 <nulterminate+0x126>
  case EXEC:
    ecmd = (struct execcmd*)cmd;
     c0a:	8b 45 08             	mov    0x8(%ebp),%eax
     c0d:	89 45 e0             	mov    %eax,-0x20(%ebp)
    for(i=0; ecmd->argv[i]; i++)
     c10:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
     c17:	eb 14                	jmp    c2d <nulterminate+0x7f>
      *ecmd->eargv[i] = 0;
     c19:	8b 45 e0             	mov    -0x20(%ebp),%eax
     c1c:	8b 55 f4             	mov    -0xc(%ebp),%edx
     c1f:	83 c2 08             	add    $0x8,%edx
     c22:	8b 44 90 0c          	mov    0xc(%eax,%edx,4),%eax
     c26:	c6 00 00             	movb   $0x0,(%eax)
    for(i=0; ecmd->argv[i]; i++)
     c29:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
     c2d:	8b 45 e0             	mov    -0x20(%ebp),%eax
     c30:	8b 55 f4             	mov    -0xc(%ebp),%edx
     c33:	8b 44 90 04          	mov    0x4(%eax,%edx,4),%eax
     c37:	85 c0                	test   %eax,%eax
     c39:	75 de                	jne    c19 <nulterminate+0x6b>
    break;
     c3b:	e9 94 00 00 00       	jmp    cd4 <nulterminate+0x126>

  case REDIR:
    rcmd = (struct redircmd*)cmd;
     c40:	8b 45 08             	mov    0x8(%ebp),%eax
     c43:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    nulterminate(rcmd->cmd);
     c46:	8b 45 e4             	mov    -0x1c(%ebp),%eax
     c49:	8b 40 04             	mov    0x4(%eax),%eax
     c4c:	83 ec 0c             	sub    $0xc,%esp
     c4f:	50                   	push   %eax
     c50:	e8 59 ff ff ff       	call   bae <nulterminate>
     c55:	83 c4 10             	add    $0x10,%esp
    *rcmd->efile = 0;
     c58:	8b 45 e4             	mov    -0x1c(%ebp),%eax
     c5b:	8b 40 0c             	mov    0xc(%eax),%eax
     c5e:	c6 00 00             	movb   $0x0,(%eax)
    break;
     c61:	eb 71                	jmp    cd4 <nulterminate+0x126>

  case PIPE:
    pcmd = (struct pipecmd*)cmd;
     c63:	8b 45 08             	mov    0x8(%ebp),%eax
     c66:	89 45 e8             	mov    %eax,-0x18(%ebp)
    nulterminate(pcmd->left);
     c69:	8b 45 e8             	mov    -0x18(%ebp),%eax
     c6c:	8b 40 04             	mov    0x4(%eax),%eax
     c6f:	83 ec 0c             	sub    $0xc,%esp
     c72:	50                   	push   %eax
     c73:	e8 36 ff ff ff       	call   bae <nulterminate>
     c78:	83 c4 10             	add    $0x10,%esp
    nulterminate(pcmd->right);
     c7b:	8b 45 e8             	mov    -0x18(%ebp),%eax
     c7e:	8b 40 08             	mov    0x8(%eax),%eax
     c81:	83 ec 0c             	sub    $0xc,%esp
     c84:	50                   	push   %eax
     c85:	e8 24 ff ff ff       	call   bae <nulterminate>
     c8a:	83 c4 10             	add    $0x10,%esp
    break;
     c8d:	eb 45                	jmp    cd4 <nulterminate+0x126>

  case LIST:
    lcmd = (struct listcmd*)cmd;
     c8f:	8b 45 08             	mov    0x8(%ebp),%eax
     c92:	89 45 ec             	mov    %eax,-0x14(%ebp)
    nulterminate(lcmd->left);
     c95:	8b 45 ec             	mov    -0x14(%ebp),%eax
     c98:	8b 40 04             	mov    0x4(%eax),%eax
     c9b:	83 ec 0c             	sub    $0xc,%esp
     c9e:	50                   	push   %eax
     c9f:	e8 0a ff ff ff       	call   bae <nulterminate>
     ca4:	83 c4 10             	add    $0x10,%esp
    nulterminate(lcmd->right);
     ca7:	8b 45 ec             	mov    -0x14(%ebp),%eax
     caa:	8b 40 08             	mov    0x8(%eax),%eax
     cad:	83 ec 0c             	sub    $0xc,%esp
     cb0:	50                   	push   %eax
     cb1:	e8 f8 fe ff ff       	call   bae <nulterminate>
     cb6:	83 c4 10             	add    $0x10,%esp
    break;
     cb9:	eb 19                	jmp    cd4 <nulterminate+0x126>

  case BACK:
    bcmd = (struct backcmd*)cmd;
     cbb:	8b 45 08             	mov    0x8(%ebp),%eax
     cbe:	89 45 f0             	mov    %eax,-0x10(%ebp)
    nulterminate(bcmd->cmd);
     cc1:	8b 45 f0             	mov    -0x10(%ebp),%eax
     cc4:	8b 40 04             	mov    0x4(%eax),%eax
     cc7:	83 ec 0c             	sub    $0xc,%esp
     cca:	50                   	push   %eax
     ccb:	e8 de fe ff ff       	call   bae <nulterminate>
     cd0:	83 c4 10             	add    $0x10,%esp
    break;
     cd3:	90                   	nop
  }
  return cmd;
     cd4:	8b 45 08             	mov    0x8(%ebp),%eax
}
     cd7:	c9                   	leave
     cd8:	c3                   	ret

00000cd9 <stosb>:
               "cc");
}

static inline void
stosb(void *addr, int data, int cnt)
{
     cd9:	55                   	push   %ebp
     cda:	89 e5                	mov    %esp,%ebp
     cdc:	57                   	push   %edi
     cdd:	53                   	push   %ebx
  asm volatile("cld; rep stosb" :
     cde:	8b 4d 08             	mov    0x8(%ebp),%ecx
     ce1:	8b 55 10             	mov    0x10(%ebp),%edx
     ce4:	8b 45 0c             	mov    0xc(%ebp),%eax
     ce7:	89 cb                	mov    %ecx,%ebx
     ce9:	89 df                	mov    %ebx,%edi
     ceb:	89 d1                	mov    %edx,%ecx
     ced:	fc                   	cld
     cee:	f3 aa                	rep stos %al,%es:(%edi)
     cf0:	89 ca                	mov    %ecx,%edx
     cf2:	89 fb                	mov    %edi,%ebx
     cf4:	89 5d 08             	mov    %ebx,0x8(%ebp)
     cf7:	89 55 10             	mov    %edx,0x10(%ebp)
               "=D" (addr), "=c" (cnt) :
               "0" (addr), "1" (cnt), "a" (data) :
               "memory", "cc");
}
     cfa:	90                   	nop
     cfb:	5b                   	pop    %ebx
     cfc:	5f                   	pop    %edi
     cfd:	5d                   	pop    %ebp
     cfe:	c3                   	ret

00000cff <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
     cff:	55                   	push   %ebp
     d00:	89 e5                	mov    %esp,%ebp
     d02:	83 ec 10             	sub    $0x10,%esp
  char *os;

  os = s;
     d05:	8b 45 08             	mov    0x8(%ebp),%eax
     d08:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while((*s++ = *t++) != 0)
     d0b:	90                   	nop
     d0c:	8b 55 0c             	mov    0xc(%ebp),%edx
     d0f:	8d 42 01             	lea    0x1(%edx),%eax
     d12:	89 45 0c             	mov    %eax,0xc(%ebp)
     d15:	8b 45 08             	mov    0x8(%ebp),%eax
     d18:	8d 48 01             	lea    0x1(%eax),%ecx
     d1b:	89 4d 08             	mov    %ecx,0x8(%ebp)
     d1e:	0f b6 12             	movzbl (%edx),%edx
     d21:	88 10                	mov    %dl,(%eax)
     d23:	0f b6 00             	movzbl (%eax),%eax
     d26:	84 c0                	test   %al,%al
     d28:	75 e2                	jne    d0c <strcpy+0xd>
    ;
  return os;
     d2a:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
     d2d:	c9                   	leave
     d2e:	c3                   	ret

00000d2f <strcmp>:

int
strcmp(const char *p, const char *q)
{
     d2f:	55                   	push   %ebp
     d30:	89 e5                	mov    %esp,%ebp
  while(*p && *p == *q)
     d32:	eb 08                	jmp    d3c <strcmp+0xd>
    p++, q++;
     d34:	83 45 08 01          	addl   $0x1,0x8(%ebp)
     d38:	83 45 0c 01          	addl   $0x1,0xc(%ebp)
  while(*p && *p == *q)
     d3c:	8b 45 08             	mov    0x8(%ebp),%eax
     d3f:	0f b6 00             	movzbl (%eax),%eax
     d42:	84 c0                	test   %al,%al
     d44:	74 10                	je     d56 <strcmp+0x27>
     d46:	8b 45 08             	mov    0x8(%ebp),%eax
     d49:	0f b6 10             	movzbl (%eax),%edx
     d4c:	8b 45 0c             	mov    0xc(%ebp),%eax
     d4f:	0f b6 00             	movzbl (%eax),%eax
     d52:	38 c2                	cmp    %al,%dl
     d54:	74 de                	je     d34 <strcmp+0x5>
  return (uchar)*p - (uchar)*q;
     d56:	8b 45 08             	mov    0x8(%ebp),%eax
     d59:	0f b6 00             	movzbl (%eax),%eax
     d5c:	0f b6 d0             	movzbl %al,%edx
     d5f:	8b 45 0c             	mov    0xc(%ebp),%eax
     d62:	0f b6 00             	movzbl (%eax),%eax
     d65:	0f b6 c0             	movzbl %al,%eax
     d68:	29 c2                	sub    %eax,%edx
     d6a:	89 d0                	mov    %edx,%eax
}
     d6c:	5d                   	pop    %ebp
     d6d:	c3                   	ret

00000d6e <strlen>:

uint
strlen(const char *s)
{
     d6e:	55                   	push   %ebp
     d6f:	89 e5                	mov    %esp,%ebp
     d71:	83 ec 10             	sub    $0x10,%esp
  int n;

  for(n = 0; s[n]; n++)
     d74:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
     d7b:	eb 04                	jmp    d81 <strlen+0x13>
     d7d:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
     d81:	8b 55 fc             	mov    -0x4(%ebp),%edx
     d84:	8b 45 08             	mov    0x8(%ebp),%eax
     d87:	01 d0                	add    %edx,%eax
     d89:	0f b6 00             	movzbl (%eax),%eax
     d8c:	84 c0                	test   %al,%al
     d8e:	75 ed                	jne    d7d <strlen+0xf>
    ;
  return n;
     d90:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
     d93:	c9                   	leave
     d94:	c3                   	ret

00000d95 <memset>:

void*
memset(void *dst, int c, uint n)
{
     d95:	55                   	push   %ebp
     d96:	89 e5                	mov    %esp,%ebp
  stosb(dst, c, n);
     d98:	8b 45 10             	mov    0x10(%ebp),%eax
     d9b:	50                   	push   %eax
     d9c:	ff 75 0c             	push   0xc(%ebp)
     d9f:	ff 75 08             	push   0x8(%ebp)
     da2:	e8 32 ff ff ff       	call   cd9 <stosb>
     da7:	83 c4 0c             	add    $0xc,%esp
  return dst;
     daa:	8b 45 08             	mov    0x8(%ebp),%eax
}
     dad:	c9                   	leave
     dae:	c3                   	ret

00000daf <strchr>:

char*
strchr(const char *s, char c)
{
     daf:	55                   	push   %ebp
     db0:	89 e5                	mov    %esp,%ebp
     db2:	83 ec 04             	sub    $0x4,%esp
     db5:	8b 45 0c             	mov    0xc(%ebp),%eax
     db8:	88 45 fc             	mov    %al,-0x4(%ebp)
  for(; *s; s++)
     dbb:	eb 14                	jmp    dd1 <strchr+0x22>
    if(*s == c)
     dbd:	8b 45 08             	mov    0x8(%ebp),%eax
     dc0:	0f b6 00             	movzbl (%eax),%eax
     dc3:	38 45 fc             	cmp    %al,-0x4(%ebp)
     dc6:	75 05                	jne    dcd <strchr+0x1e>
      return (char*)s;
     dc8:	8b 45 08             	mov    0x8(%ebp),%eax
     dcb:	eb 13                	jmp    de0 <strchr+0x31>
  for(; *s; s++)
     dcd:	83 45 08 01          	addl   $0x1,0x8(%ebp)
     dd1:	8b 45 08             	mov    0x8(%ebp),%eax
     dd4:	0f b6 00             	movzbl (%eax),%eax
     dd7:	84 c0                	test   %al,%al
     dd9:	75 e2                	jne    dbd <strchr+0xe>
  return 0;
     ddb:	b8 00 00 00 00       	mov    $0x0,%eax
}
     de0:	c9                   	leave
     de1:	c3                   	ret

00000de2 <gets>:

char*
gets(char *buf, int max)
{
     de2:	55                   	push   %ebp
     de3:	89 e5                	mov    %esp,%ebp
     de5:	83 ec 18             	sub    $0x18,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     de8:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
     def:	eb 42                	jmp    e33 <gets+0x51>
    cc = read(0, &c, 1);
     df1:	83 ec 04             	sub    $0x4,%esp
     df4:	6a 01                	push   $0x1
     df6:	8d 45 ef             	lea    -0x11(%ebp),%eax
     df9:	50                   	push   %eax
     dfa:	6a 00                	push   $0x0
     dfc:	e8 47 01 00 00       	call   f48 <read>
     e01:	83 c4 10             	add    $0x10,%esp
     e04:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(cc < 1)
     e07:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
     e0b:	7e 33                	jle    e40 <gets+0x5e>
      break;
    buf[i++] = c;
     e0d:	8b 45 f4             	mov    -0xc(%ebp),%eax
     e10:	8d 50 01             	lea    0x1(%eax),%edx
     e13:	89 55 f4             	mov    %edx,-0xc(%ebp)
     e16:	89 c2                	mov    %eax,%edx
     e18:	8b 45 08             	mov    0x8(%ebp),%eax
     e1b:	01 c2                	add    %eax,%edx
     e1d:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
     e21:	88 02                	mov    %al,(%edx)
    if(c == '\n' || c == '\r')
     e23:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
     e27:	3c 0a                	cmp    $0xa,%al
     e29:	74 16                	je     e41 <gets+0x5f>
     e2b:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
     e2f:	3c 0d                	cmp    $0xd,%al
     e31:	74 0e                	je     e41 <gets+0x5f>
  for(i=0; i+1 < max; ){
     e33:	8b 45 f4             	mov    -0xc(%ebp),%eax
     e36:	83 c0 01             	add    $0x1,%eax
     e39:	39 45 0c             	cmp    %eax,0xc(%ebp)
     e3c:	7f b3                	jg     df1 <gets+0xf>
     e3e:	eb 01                	jmp    e41 <gets+0x5f>
      break;
     e40:	90                   	nop
      break;
  }
  buf[i] = '\0';
     e41:	8b 55 f4             	mov    -0xc(%ebp),%edx
     e44:	8b 45 08             	mov    0x8(%ebp),%eax
     e47:	01 d0                	add    %edx,%eax
     e49:	c6 00 00             	movb   $0x0,(%eax)
  return buf;
     e4c:	8b 45 08             	mov    0x8(%ebp),%eax
}
     e4f:	c9                   	leave
     e50:	c3                   	ret

00000e51 <stat>:

int
stat(const char *n, struct stat *st)
{
     e51:	55                   	push   %ebp
     e52:	89 e5                	mov    %esp,%ebp
     e54:	83 ec 18             	sub    $0x18,%esp
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     e57:	83 ec 08             	sub    $0x8,%esp
     e5a:	6a 00                	push   $0x0
     e5c:	ff 75 08             	push   0x8(%ebp)
     e5f:	e8 0c 01 00 00       	call   f70 <open>
     e64:	83 c4 10             	add    $0x10,%esp
     e67:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0)
     e6a:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     e6e:	79 07                	jns    e77 <stat+0x26>
    return -1;
     e70:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     e75:	eb 25                	jmp    e9c <stat+0x4b>
  r = fstat(fd, st);
     e77:	83 ec 08             	sub    $0x8,%esp
     e7a:	ff 75 0c             	push   0xc(%ebp)
     e7d:	ff 75 f4             	push   -0xc(%ebp)
     e80:	e8 03 01 00 00       	call   f88 <fstat>
     e85:	83 c4 10             	add    $0x10,%esp
     e88:	89 45 f0             	mov    %eax,-0x10(%ebp)
  close(fd);
     e8b:	83 ec 0c             	sub    $0xc,%esp
     e8e:	ff 75 f4             	push   -0xc(%ebp)
     e91:	e8 c2 00 00 00       	call   f58 <close>
     e96:	83 c4 10             	add    $0x10,%esp
  return r;
     e99:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
     e9c:	c9                   	leave
     e9d:	c3                   	ret

00000e9e <atoi>:

int
atoi(const char *s)
{
     e9e:	55                   	push   %ebp
     e9f:	89 e5                	mov    %esp,%ebp
     ea1:	83 ec 10             	sub    $0x10,%esp
  int n;

  n = 0;
     ea4:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
  while('0' <= *s && *s <= '9')
     eab:	eb 25                	jmp    ed2 <atoi+0x34>
    n = n*10 + *s++ - '0';
     ead:	8b 55 fc             	mov    -0x4(%ebp),%edx
     eb0:	89 d0                	mov    %edx,%eax
     eb2:	c1 e0 02             	shl    $0x2,%eax
     eb5:	01 d0                	add    %edx,%eax
     eb7:	01 c0                	add    %eax,%eax
     eb9:	89 c1                	mov    %eax,%ecx
     ebb:	8b 45 08             	mov    0x8(%ebp),%eax
     ebe:	8d 50 01             	lea    0x1(%eax),%edx
     ec1:	89 55 08             	mov    %edx,0x8(%ebp)
     ec4:	0f b6 00             	movzbl (%eax),%eax
     ec7:	0f be c0             	movsbl %al,%eax
     eca:	01 c8                	add    %ecx,%eax
     ecc:	83 e8 30             	sub    $0x30,%eax
     ecf:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while('0' <= *s && *s <= '9')
     ed2:	8b 45 08             	mov    0x8(%ebp),%eax
     ed5:	0f b6 00             	movzbl (%eax),%eax
     ed8:	3c 2f                	cmp    $0x2f,%al
     eda:	7e 0a                	jle    ee6 <atoi+0x48>
     edc:	8b 45 08             	mov    0x8(%ebp),%eax
     edf:	0f b6 00             	movzbl (%eax),%eax
     ee2:	3c 39                	cmp    $0x39,%al
     ee4:	7e c7                	jle    ead <atoi+0xf>
  return n;
     ee6:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
     ee9:	c9                   	leave
     eea:	c3                   	ret

00000eeb <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
     eeb:	55                   	push   %ebp
     eec:	89 e5                	mov    %esp,%ebp
     eee:	83 ec 10             	sub    $0x10,%esp
  char *dst;
  const char *src;

  dst = vdst;
     ef1:	8b 45 08             	mov    0x8(%ebp),%eax
     ef4:	89 45 fc             	mov    %eax,-0x4(%ebp)
  src = vsrc;
     ef7:	8b 45 0c             	mov    0xc(%ebp),%eax
     efa:	89 45 f8             	mov    %eax,-0x8(%ebp)
  while(n-- > 0)
     efd:	eb 17                	jmp    f16 <memmove+0x2b>
    *dst++ = *src++;
     eff:	8b 55 f8             	mov    -0x8(%ebp),%edx
     f02:	8d 42 01             	lea    0x1(%edx),%eax
     f05:	89 45 f8             	mov    %eax,-0x8(%ebp)
     f08:	8b 45 fc             	mov    -0x4(%ebp),%eax
     f0b:	8d 48 01             	lea    0x1(%eax),%ecx
     f0e:	89 4d fc             	mov    %ecx,-0x4(%ebp)
     f11:	0f b6 12             	movzbl (%edx),%edx
     f14:	88 10                	mov    %dl,(%eax)
  while(n-- > 0)
     f16:	8b 45 10             	mov    0x10(%ebp),%eax
     f19:	8d 50 ff             	lea    -0x1(%eax),%edx
     f1c:	89 55 10             	mov    %edx,0x10(%ebp)
     f1f:	85 c0                	test   %eax,%eax
     f21:	7f dc                	jg     eff <memmove+0x14>
  return vdst;
     f23:	8b 45 08             	mov    0x8(%ebp),%eax
}
     f26:	c9                   	leave
     f27:	c3                   	ret

00000f28 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
     f28:	b8 01 00 00 00       	mov    $0x1,%eax
     f2d:	cd 40                	int    $0x40
     f2f:	c3                   	ret

00000f30 <exit>:
SYSCALL(exit)
     f30:	b8 02 00 00 00       	mov    $0x2,%eax
     f35:	cd 40                	int    $0x40
     f37:	c3                   	ret

00000f38 <wait>:
SYSCALL(wait)
     f38:	b8 03 00 00 00       	mov    $0x3,%eax
     f3d:	cd 40                	int    $0x40
     f3f:	c3                   	ret

00000f40 <pipe>:
SYSCALL(pipe)
     f40:	b8 04 00 00 00       	mov    $0x4,%eax
     f45:	cd 40                	int    $0x40
     f47:	c3                   	ret

00000f48 <read>:
SYSCALL(read)
     f48:	b8 05 00 00 00       	mov    $0x5,%eax
     f4d:	cd 40                	int    $0x40
     f4f:	c3                   	ret

00000f50 <write>:
SYSCALL(write)
     f50:	b8 10 00 00 00       	mov    $0x10,%eax
     f55:	cd 40                	int    $0x40
     f57:	c3                   	ret

00000f58 <close>:
SYSCALL(close)
     f58:	b8 15 00 00 00       	mov    $0x15,%eax
     f5d:	cd 40                	int    $0x40
     f5f:	c3                   	ret

00000f60 <kill>:
SYSCALL(kill)
     f60:	b8 06 00 00 00       	mov    $0x6,%eax
     f65:	cd 40                	int    $0x40
     f67:	c3                   	ret

00000f68 <exec>:
SYSCALL(exec)
     f68:	b8 07 00 00 00       	mov    $0x7,%eax
     f6d:	cd 40                	int    $0x40
     f6f:	c3                   	ret

00000f70 <open>:
SYSCALL(open)
     f70:	b8 0f 00 00 00       	mov    $0xf,%eax
     f75:	cd 40                	int    $0x40
     f77:	c3                   	ret

00000f78 <mknod>:
SYSCALL(mknod)
     f78:	b8 11 00 00 00       	mov    $0x11,%eax
     f7d:	cd 40                	int    $0x40
     f7f:	c3                   	ret

00000f80 <unlink>:
SYSCALL(unlink)
     f80:	b8 12 00 00 00       	mov    $0x12,%eax
     f85:	cd 40                	int    $0x40
     f87:	c3                   	ret

00000f88 <fstat>:
SYSCALL(fstat)
     f88:	b8 08 00 00 00       	mov    $0x8,%eax
     f8d:	cd 40                	int    $0x40
     f8f:	c3                   	ret

00000f90 <link>:
SYSCALL(link)
     f90:	b8 13 00 00 00       	mov    $0x13,%eax
     f95:	cd 40                	int    $0x40
     f97:	c3                   	ret

00000f98 <mkdir>:
SYSCALL(mkdir)
     f98:	b8 14 00 00 00       	mov    $0x14,%eax
     f9d:	cd 40                	int    $0x40
     f9f:	c3                   	ret

00000fa0 <chdir>:
SYSCALL(chdir)
     fa0:	b8 09 00 00 00       	mov    $0x9,%eax
     fa5:	cd 40                	int    $0x40
     fa7:	c3                   	ret

00000fa8 <dup>:
SYSCALL(dup)
     fa8:	b8 0a 00 00 00       	mov    $0xa,%eax
     fad:	cd 40                	int    $0x40
     faf:	c3                   	ret

00000fb0 <getpid>:
SYSCALL(getpid)
     fb0:	b8 0b 00 00 00       	mov    $0xb,%eax
     fb5:	cd 40                	int    $0x40
     fb7:	c3                   	ret

00000fb8 <sbrk>:
SYSCALL(sbrk)
     fb8:	b8 0c 00 00 00       	mov    $0xc,%eax
     fbd:	cd 40                	int    $0x40
     fbf:	c3                   	ret

00000fc0 <sleep>:
SYSCALL(sleep)
     fc0:	b8 0d 00 00 00       	mov    $0xd,%eax
     fc5:	cd 40                	int    $0x40
     fc7:	c3                   	ret

00000fc8 <uptime>:
SYSCALL(uptime)
     fc8:	b8 0e 00 00 00       	mov    $0xe,%eax
     fcd:	cd 40                	int    $0x40
     fcf:	c3                   	ret

00000fd0 <getparentname>:
SYSCALL(getparentname)
     fd0:	b8 16 00 00 00       	mov    $0x16,%eax
     fd5:	cd 40                	int    $0x40
     fd7:	c3                   	ret

00000fd8 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
     fd8:	55                   	push   %ebp
     fd9:	89 e5                	mov    %esp,%ebp
     fdb:	83 ec 18             	sub    $0x18,%esp
     fde:	8b 45 0c             	mov    0xc(%ebp),%eax
     fe1:	88 45 f4             	mov    %al,-0xc(%ebp)
  write(fd, &c, 1);
     fe4:	83 ec 04             	sub    $0x4,%esp
     fe7:	6a 01                	push   $0x1
     fe9:	8d 45 f4             	lea    -0xc(%ebp),%eax
     fec:	50                   	push   %eax
     fed:	ff 75 08             	push   0x8(%ebp)
     ff0:	e8 5b ff ff ff       	call   f50 <write>
     ff5:	83 c4 10             	add    $0x10,%esp
}
     ff8:	90                   	nop
     ff9:	c9                   	leave
     ffa:	c3                   	ret

00000ffb <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
     ffb:	55                   	push   %ebp
     ffc:	89 e5                	mov    %esp,%ebp
     ffe:	83 ec 28             	sub    $0x28,%esp
  static char digits[] = "0123456789ABCDEF";
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
    1001:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  if(sgn && xx < 0){
    1008:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
    100c:	74 17                	je     1025 <printint+0x2a>
    100e:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
    1012:	79 11                	jns    1025 <printint+0x2a>
    neg = 1;
    1014:	c7 45 f0 01 00 00 00 	movl   $0x1,-0x10(%ebp)
    x = -xx;
    101b:	8b 45 0c             	mov    0xc(%ebp),%eax
    101e:	f7 d8                	neg    %eax
    1020:	89 45 ec             	mov    %eax,-0x14(%ebp)
    1023:	eb 06                	jmp    102b <printint+0x30>
  } else {
    x = xx;
    1025:	8b 45 0c             	mov    0xc(%ebp),%eax
    1028:	89 45 ec             	mov    %eax,-0x14(%ebp)
  }

  i = 0;
    102b:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  do{
    buf[i++] = digits[x % base];
    1032:	8b 4d 10             	mov    0x10(%ebp),%ecx
    1035:	8b 45 ec             	mov    -0x14(%ebp),%eax
    1038:	ba 00 00 00 00       	mov    $0x0,%edx
    103d:	f7 f1                	div    %ecx
    103f:	89 d1                	mov    %edx,%ecx
    1041:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1044:	8d 50 01             	lea    0x1(%eax),%edx
    1047:	89 55 f4             	mov    %edx,-0xc(%ebp)
    104a:	0f b6 91 e4 19 00 00 	movzbl 0x19e4(%ecx),%edx
    1051:	88 54 05 dc          	mov    %dl,-0x24(%ebp,%eax,1)
  }while((x /= base) != 0);
    1055:	8b 4d 10             	mov    0x10(%ebp),%ecx
    1058:	8b 45 ec             	mov    -0x14(%ebp),%eax
    105b:	ba 00 00 00 00       	mov    $0x0,%edx
    1060:	f7 f1                	div    %ecx
    1062:	89 45 ec             	mov    %eax,-0x14(%ebp)
    1065:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    1069:	75 c7                	jne    1032 <printint+0x37>
  if(neg)
    106b:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    106f:	74 2d                	je     109e <printint+0xa3>
    buf[i++] = '-';
    1071:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1074:	8d 50 01             	lea    0x1(%eax),%edx
    1077:	89 55 f4             	mov    %edx,-0xc(%ebp)
    107a:	c6 44 05 dc 2d       	movb   $0x2d,-0x24(%ebp,%eax,1)

  while(--i >= 0)
    107f:	eb 1d                	jmp    109e <printint+0xa3>
    putc(fd, buf[i]);
    1081:	8d 55 dc             	lea    -0x24(%ebp),%edx
    1084:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1087:	01 d0                	add    %edx,%eax
    1089:	0f b6 00             	movzbl (%eax),%eax
    108c:	0f be c0             	movsbl %al,%eax
    108f:	83 ec 08             	sub    $0x8,%esp
    1092:	50                   	push   %eax
    1093:	ff 75 08             	push   0x8(%ebp)
    1096:	e8 3d ff ff ff       	call   fd8 <putc>
    109b:	83 c4 10             	add    $0x10,%esp
  while(--i >= 0)
    109e:	83 6d f4 01          	subl   $0x1,-0xc(%ebp)
    10a2:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    10a6:	79 d9                	jns    1081 <printint+0x86>
}
    10a8:	90                   	nop
    10a9:	90                   	nop
    10aa:	c9                   	leave
    10ab:	c3                   	ret

000010ac <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
    10ac:	55                   	push   %ebp
    10ad:	89 e5                	mov    %esp,%ebp
    10af:	83 ec 28             	sub    $0x28,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
    10b2:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  ap = (uint*)(void*)&fmt + 1;
    10b9:	8d 45 0c             	lea    0xc(%ebp),%eax
    10bc:	83 c0 04             	add    $0x4,%eax
    10bf:	89 45 e8             	mov    %eax,-0x18(%ebp)
  for(i = 0; fmt[i]; i++){
    10c2:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    10c9:	e9 59 01 00 00       	jmp    1227 <printf+0x17b>
    c = fmt[i] & 0xff;
    10ce:	8b 55 0c             	mov    0xc(%ebp),%edx
    10d1:	8b 45 f0             	mov    -0x10(%ebp),%eax
    10d4:	01 d0                	add    %edx,%eax
    10d6:	0f b6 00             	movzbl (%eax),%eax
    10d9:	0f be c0             	movsbl %al,%eax
    10dc:	25 ff 00 00 00       	and    $0xff,%eax
    10e1:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(state == 0){
    10e4:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    10e8:	75 2c                	jne    1116 <printf+0x6a>
      if(c == '%'){
    10ea:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
    10ee:	75 0c                	jne    10fc <printf+0x50>
        state = '%';
    10f0:	c7 45 ec 25 00 00 00 	movl   $0x25,-0x14(%ebp)
    10f7:	e9 27 01 00 00       	jmp    1223 <printf+0x177>
      } else {
        putc(fd, c);
    10fc:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    10ff:	0f be c0             	movsbl %al,%eax
    1102:	83 ec 08             	sub    $0x8,%esp
    1105:	50                   	push   %eax
    1106:	ff 75 08             	push   0x8(%ebp)
    1109:	e8 ca fe ff ff       	call   fd8 <putc>
    110e:	83 c4 10             	add    $0x10,%esp
    1111:	e9 0d 01 00 00       	jmp    1223 <printf+0x177>
      }
    } else if(state == '%'){
    1116:	83 7d ec 25          	cmpl   $0x25,-0x14(%ebp)
    111a:	0f 85 03 01 00 00    	jne    1223 <printf+0x177>
      if(c == 'd'){
    1120:	83 7d e4 64          	cmpl   $0x64,-0x1c(%ebp)
    1124:	75 1e                	jne    1144 <printf+0x98>
        printint(fd, *ap, 10, 1);
    1126:	8b 45 e8             	mov    -0x18(%ebp),%eax
    1129:	8b 00                	mov    (%eax),%eax
    112b:	6a 01                	push   $0x1
    112d:	6a 0a                	push   $0xa
    112f:	50                   	push   %eax
    1130:	ff 75 08             	push   0x8(%ebp)
    1133:	e8 c3 fe ff ff       	call   ffb <printint>
    1138:	83 c4 10             	add    $0x10,%esp
        ap++;
    113b:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
    113f:	e9 d8 00 00 00       	jmp    121c <printf+0x170>
      } else if(c == 'x' || c == 'p'){
    1144:	83 7d e4 78          	cmpl   $0x78,-0x1c(%ebp)
    1148:	74 06                	je     1150 <printf+0xa4>
    114a:	83 7d e4 70          	cmpl   $0x70,-0x1c(%ebp)
    114e:	75 1e                	jne    116e <printf+0xc2>
        printint(fd, *ap, 16, 0);
    1150:	8b 45 e8             	mov    -0x18(%ebp),%eax
    1153:	8b 00                	mov    (%eax),%eax
    1155:	6a 00                	push   $0x0
    1157:	6a 10                	push   $0x10
    1159:	50                   	push   %eax
    115a:	ff 75 08             	push   0x8(%ebp)
    115d:	e8 99 fe ff ff       	call   ffb <printint>
    1162:	83 c4 10             	add    $0x10,%esp
        ap++;
    1165:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
    1169:	e9 ae 00 00 00       	jmp    121c <printf+0x170>
      } else if(c == 's'){
    116e:	83 7d e4 73          	cmpl   $0x73,-0x1c(%ebp)
    1172:	75 43                	jne    11b7 <printf+0x10b>
        s = (char*)*ap;
    1174:	8b 45 e8             	mov    -0x18(%ebp),%eax
    1177:	8b 00                	mov    (%eax),%eax
    1179:	89 45 f4             	mov    %eax,-0xc(%ebp)
        ap++;
    117c:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
        if(s == 0)
    1180:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    1184:	75 25                	jne    11ab <printf+0xff>
          s = "(null)";
    1186:	c7 45 f4 23 15 00 00 	movl   $0x1523,-0xc(%ebp)
        while(*s != 0){
    118d:	eb 1c                	jmp    11ab <printf+0xff>
          putc(fd, *s);
    118f:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1192:	0f b6 00             	movzbl (%eax),%eax
    1195:	0f be c0             	movsbl %al,%eax
    1198:	83 ec 08             	sub    $0x8,%esp
    119b:	50                   	push   %eax
    119c:	ff 75 08             	push   0x8(%ebp)
    119f:	e8 34 fe ff ff       	call   fd8 <putc>
    11a4:	83 c4 10             	add    $0x10,%esp
          s++;
    11a7:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
        while(*s != 0){
    11ab:	8b 45 f4             	mov    -0xc(%ebp),%eax
    11ae:	0f b6 00             	movzbl (%eax),%eax
    11b1:	84 c0                	test   %al,%al
    11b3:	75 da                	jne    118f <printf+0xe3>
    11b5:	eb 65                	jmp    121c <printf+0x170>
        }
      } else if(c == 'c'){
    11b7:	83 7d e4 63          	cmpl   $0x63,-0x1c(%ebp)
    11bb:	75 1d                	jne    11da <printf+0x12e>
        putc(fd, *ap);
    11bd:	8b 45 e8             	mov    -0x18(%ebp),%eax
    11c0:	8b 00                	mov    (%eax),%eax
    11c2:	0f be c0             	movsbl %al,%eax
    11c5:	83 ec 08             	sub    $0x8,%esp
    11c8:	50                   	push   %eax
    11c9:	ff 75 08             	push   0x8(%ebp)
    11cc:	e8 07 fe ff ff       	call   fd8 <putc>
    11d1:	83 c4 10             	add    $0x10,%esp
        ap++;
    11d4:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
    11d8:	eb 42                	jmp    121c <printf+0x170>
      } else if(c == '%'){
    11da:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
    11de:	75 17                	jne    11f7 <printf+0x14b>
        putc(fd, c);
    11e0:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    11e3:	0f be c0             	movsbl %al,%eax
    11e6:	83 ec 08             	sub    $0x8,%esp
    11e9:	50                   	push   %eax
    11ea:	ff 75 08             	push   0x8(%ebp)
    11ed:	e8 e6 fd ff ff       	call   fd8 <putc>
    11f2:	83 c4 10             	add    $0x10,%esp
    11f5:	eb 25                	jmp    121c <printf+0x170>
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
    11f7:	83 ec 08             	sub    $0x8,%esp
    11fa:	6a 25                	push   $0x25
    11fc:	ff 75 08             	push   0x8(%ebp)
    11ff:	e8 d4 fd ff ff       	call   fd8 <putc>
    1204:	83 c4 10             	add    $0x10,%esp
        putc(fd, c);
    1207:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    120a:	0f be c0             	movsbl %al,%eax
    120d:	83 ec 08             	sub    $0x8,%esp
    1210:	50                   	push   %eax
    1211:	ff 75 08             	push   0x8(%ebp)
    1214:	e8 bf fd ff ff       	call   fd8 <putc>
    1219:	83 c4 10             	add    $0x10,%esp
      }
      state = 0;
    121c:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  for(i = 0; fmt[i]; i++){
    1223:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    1227:	8b 55 0c             	mov    0xc(%ebp),%edx
    122a:	8b 45 f0             	mov    -0x10(%ebp),%eax
    122d:	01 d0                	add    %edx,%eax
    122f:	0f b6 00             	movzbl (%eax),%eax
    1232:	84 c0                	test   %al,%al
    1234:	0f 85 94 fe ff ff    	jne    10ce <printf+0x22>
    }
  }
}
    123a:	90                   	nop
    123b:	90                   	nop
    123c:	c9                   	leave
    123d:	c3                   	ret

0000123e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    123e:	55                   	push   %ebp
    123f:	89 e5                	mov    %esp,%ebp
    1241:	83 ec 10             	sub    $0x10,%esp
  Header *bp, *p;

  bp = (Header*)ap - 1;
    1244:	8b 45 08             	mov    0x8(%ebp),%eax
    1247:	83 e8 08             	sub    $0x8,%eax
    124a:	89 45 f8             	mov    %eax,-0x8(%ebp)
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    124d:	a1 6c 1a 00 00       	mov    0x1a6c,%eax
    1252:	89 45 fc             	mov    %eax,-0x4(%ebp)
    1255:	eb 24                	jmp    127b <free+0x3d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1257:	8b 45 fc             	mov    -0x4(%ebp),%eax
    125a:	8b 00                	mov    (%eax),%eax
    125c:	39 45 fc             	cmp    %eax,-0x4(%ebp)
    125f:	72 12                	jb     1273 <free+0x35>
    1261:	8b 45 f8             	mov    -0x8(%ebp),%eax
    1264:	39 45 fc             	cmp    %eax,-0x4(%ebp)
    1267:	72 24                	jb     128d <free+0x4f>
    1269:	8b 45 fc             	mov    -0x4(%ebp),%eax
    126c:	8b 00                	mov    (%eax),%eax
    126e:	39 45 f8             	cmp    %eax,-0x8(%ebp)
    1271:	72 1a                	jb     128d <free+0x4f>
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1273:	8b 45 fc             	mov    -0x4(%ebp),%eax
    1276:	8b 00                	mov    (%eax),%eax
    1278:	89 45 fc             	mov    %eax,-0x4(%ebp)
    127b:	8b 45 f8             	mov    -0x8(%ebp),%eax
    127e:	39 45 fc             	cmp    %eax,-0x4(%ebp)
    1281:	73 d4                	jae    1257 <free+0x19>
    1283:	8b 45 fc             	mov    -0x4(%ebp),%eax
    1286:	8b 00                	mov    (%eax),%eax
    1288:	39 45 f8             	cmp    %eax,-0x8(%ebp)
    128b:	73 ca                	jae    1257 <free+0x19>
      break;
  if(bp + bp->s.size == p->s.ptr){
    128d:	8b 45 f8             	mov    -0x8(%ebp),%eax
    1290:	8b 40 04             	mov    0x4(%eax),%eax
    1293:	8d 14 c5 00 00 00 00 	lea    0x0(,%eax,8),%edx
    129a:	8b 45 f8             	mov    -0x8(%ebp),%eax
    129d:	01 c2                	add    %eax,%edx
    129f:	8b 45 fc             	mov    -0x4(%ebp),%eax
    12a2:	8b 00                	mov    (%eax),%eax
    12a4:	39 c2                	cmp    %eax,%edx
    12a6:	75 24                	jne    12cc <free+0x8e>
    bp->s.size += p->s.ptr->s.size;
    12a8:	8b 45 f8             	mov    -0x8(%ebp),%eax
    12ab:	8b 50 04             	mov    0x4(%eax),%edx
    12ae:	8b 45 fc             	mov    -0x4(%ebp),%eax
    12b1:	8b 00                	mov    (%eax),%eax
    12b3:	8b 40 04             	mov    0x4(%eax),%eax
    12b6:	01 c2                	add    %eax,%edx
    12b8:	8b 45 f8             	mov    -0x8(%ebp),%eax
    12bb:	89 50 04             	mov    %edx,0x4(%eax)
    bp->s.ptr = p->s.ptr->s.ptr;
    12be:	8b 45 fc             	mov    -0x4(%ebp),%eax
    12c1:	8b 00                	mov    (%eax),%eax
    12c3:	8b 10                	mov    (%eax),%edx
    12c5:	8b 45 f8             	mov    -0x8(%ebp),%eax
    12c8:	89 10                	mov    %edx,(%eax)
    12ca:	eb 0a                	jmp    12d6 <free+0x98>
  } else
    bp->s.ptr = p->s.ptr;
    12cc:	8b 45 fc             	mov    -0x4(%ebp),%eax
    12cf:	8b 10                	mov    (%eax),%edx
    12d1:	8b 45 f8             	mov    -0x8(%ebp),%eax
    12d4:	89 10                	mov    %edx,(%eax)
  if(p + p->s.size == bp){
    12d6:	8b 45 fc             	mov    -0x4(%ebp),%eax
    12d9:	8b 40 04             	mov    0x4(%eax),%eax
    12dc:	8d 14 c5 00 00 00 00 	lea    0x0(,%eax,8),%edx
    12e3:	8b 45 fc             	mov    -0x4(%ebp),%eax
    12e6:	01 d0                	add    %edx,%eax
    12e8:	39 45 f8             	cmp    %eax,-0x8(%ebp)
    12eb:	75 20                	jne    130d <free+0xcf>
    p->s.size += bp->s.size;
    12ed:	8b 45 fc             	mov    -0x4(%ebp),%eax
    12f0:	8b 50 04             	mov    0x4(%eax),%edx
    12f3:	8b 45 f8             	mov    -0x8(%ebp),%eax
    12f6:	8b 40 04             	mov    0x4(%eax),%eax
    12f9:	01 c2                	add    %eax,%edx
    12fb:	8b 45 fc             	mov    -0x4(%ebp),%eax
    12fe:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
    1301:	8b 45 f8             	mov    -0x8(%ebp),%eax
    1304:	8b 10                	mov    (%eax),%edx
    1306:	8b 45 fc             	mov    -0x4(%ebp),%eax
    1309:	89 10                	mov    %edx,(%eax)
    130b:	eb 08                	jmp    1315 <free+0xd7>
  } else
    p->s.ptr = bp;
    130d:	8b 45 fc             	mov    -0x4(%ebp),%eax
    1310:	8b 55 f8             	mov    -0x8(%ebp),%edx
    1313:	89 10                	mov    %edx,(%eax)
  freep = p;
    1315:	8b 45 fc             	mov    -0x4(%ebp),%eax
    1318:	a3 6c 1a 00 00       	mov    %eax,0x1a6c
}
    131d:	90                   	nop
    131e:	c9                   	leave
    131f:	c3                   	ret

00001320 <morecore>:

static Header*
morecore(uint nu)
{
    1320:	55                   	push   %ebp
    1321:	89 e5                	mov    %esp,%ebp
    1323:	83 ec 18             	sub    $0x18,%esp
  char *p;
  Header *hp;

  if(nu < 4096)
    1326:	81 7d 08 ff 0f 00 00 	cmpl   $0xfff,0x8(%ebp)
    132d:	77 07                	ja     1336 <morecore+0x16>
    nu = 4096;
    132f:	c7 45 08 00 10 00 00 	movl   $0x1000,0x8(%ebp)
  p = sbrk(nu * sizeof(Header));
    1336:	8b 45 08             	mov    0x8(%ebp),%eax
    1339:	c1 e0 03             	shl    $0x3,%eax
    133c:	83 ec 0c             	sub    $0xc,%esp
    133f:	50                   	push   %eax
    1340:	e8 73 fc ff ff       	call   fb8 <sbrk>
    1345:	83 c4 10             	add    $0x10,%esp
    1348:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(p == (char*)-1)
    134b:	83 7d f4 ff          	cmpl   $0xffffffff,-0xc(%ebp)
    134f:	75 07                	jne    1358 <morecore+0x38>
    return 0;
    1351:	b8 00 00 00 00       	mov    $0x0,%eax
    1356:	eb 26                	jmp    137e <morecore+0x5e>
  hp = (Header*)p;
    1358:	8b 45 f4             	mov    -0xc(%ebp),%eax
    135b:	89 45 f0             	mov    %eax,-0x10(%ebp)
  hp->s.size = nu;
    135e:	8b 45 f0             	mov    -0x10(%ebp),%eax
    1361:	8b 55 08             	mov    0x8(%ebp),%edx
    1364:	89 50 04             	mov    %edx,0x4(%eax)
  free((void*)(hp + 1));
    1367:	8b 45 f0             	mov    -0x10(%ebp),%eax
    136a:	83 c0 08             	add    $0x8,%eax
    136d:	83 ec 0c             	sub    $0xc,%esp
    1370:	50                   	push   %eax
    1371:	e8 c8 fe ff ff       	call   123e <free>
    1376:	83 c4 10             	add    $0x10,%esp
  return freep;
    1379:	a1 6c 1a 00 00       	mov    0x1a6c,%eax
}
    137e:	c9                   	leave
    137f:	c3                   	ret

00001380 <malloc>:

void*
malloc(uint nbytes)
{
    1380:	55                   	push   %ebp
    1381:	89 e5                	mov    %esp,%ebp
    1383:	83 ec 18             	sub    $0x18,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1386:	8b 45 08             	mov    0x8(%ebp),%eax
    1389:	83 c0 07             	add    $0x7,%eax
    138c:	c1 e8 03             	shr    $0x3,%eax
    138f:	83 c0 01             	add    $0x1,%eax
    1392:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if((prevp = freep) == 0){
    1395:	a1 6c 1a 00 00       	mov    0x1a6c,%eax
    139a:	89 45 f0             	mov    %eax,-0x10(%ebp)
    139d:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    13a1:	75 23                	jne    13c6 <malloc+0x46>
    base.s.ptr = freep = prevp = &base;
    13a3:	c7 45 f0 64 1a 00 00 	movl   $0x1a64,-0x10(%ebp)
    13aa:	8b 45 f0             	mov    -0x10(%ebp),%eax
    13ad:	a3 6c 1a 00 00       	mov    %eax,0x1a6c
    13b2:	a1 6c 1a 00 00       	mov    0x1a6c,%eax
    13b7:	a3 64 1a 00 00       	mov    %eax,0x1a64
    base.s.size = 0;
    13bc:	c7 05 68 1a 00 00 00 	movl   $0x0,0x1a68
    13c3:	00 00 00 
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    13c6:	8b 45 f0             	mov    -0x10(%ebp),%eax
    13c9:	8b 00                	mov    (%eax),%eax
    13cb:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(p->s.size >= nunits){
    13ce:	8b 45 f4             	mov    -0xc(%ebp),%eax
    13d1:	8b 40 04             	mov    0x4(%eax),%eax
    13d4:	3b 45 ec             	cmp    -0x14(%ebp),%eax
    13d7:	72 4d                	jb     1426 <malloc+0xa6>
      if(p->s.size == nunits)
    13d9:	8b 45 f4             	mov    -0xc(%ebp),%eax
    13dc:	8b 40 04             	mov    0x4(%eax),%eax
    13df:	39 45 ec             	cmp    %eax,-0x14(%ebp)
    13e2:	75 0c                	jne    13f0 <malloc+0x70>
        prevp->s.ptr = p->s.ptr;
    13e4:	8b 45 f4             	mov    -0xc(%ebp),%eax
    13e7:	8b 10                	mov    (%eax),%edx
    13e9:	8b 45 f0             	mov    -0x10(%ebp),%eax
    13ec:	89 10                	mov    %edx,(%eax)
    13ee:	eb 26                	jmp    1416 <malloc+0x96>
      else {
        p->s.size -= nunits;
    13f0:	8b 45 f4             	mov    -0xc(%ebp),%eax
    13f3:	8b 40 04             	mov    0x4(%eax),%eax
    13f6:	2b 45 ec             	sub    -0x14(%ebp),%eax
    13f9:	89 c2                	mov    %eax,%edx
    13fb:	8b 45 f4             	mov    -0xc(%ebp),%eax
    13fe:	89 50 04             	mov    %edx,0x4(%eax)
        p += p->s.size;
    1401:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1404:	8b 40 04             	mov    0x4(%eax),%eax
    1407:	c1 e0 03             	shl    $0x3,%eax
    140a:	01 45 f4             	add    %eax,-0xc(%ebp)
        p->s.size = nunits;
    140d:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1410:	8b 55 ec             	mov    -0x14(%ebp),%edx
    1413:	89 50 04             	mov    %edx,0x4(%eax)
      }
      freep = prevp;
    1416:	8b 45 f0             	mov    -0x10(%ebp),%eax
    1419:	a3 6c 1a 00 00       	mov    %eax,0x1a6c
      return (void*)(p + 1);
    141e:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1421:	83 c0 08             	add    $0x8,%eax
    1424:	eb 3b                	jmp    1461 <malloc+0xe1>
    }
    if(p == freep)
    1426:	a1 6c 1a 00 00       	mov    0x1a6c,%eax
    142b:	39 45 f4             	cmp    %eax,-0xc(%ebp)
    142e:	75 1e                	jne    144e <malloc+0xce>
      if((p = morecore(nunits)) == 0)
    1430:	83 ec 0c             	sub    $0xc,%esp
    1433:	ff 75 ec             	push   -0x14(%ebp)
    1436:	e8 e5 fe ff ff       	call   1320 <morecore>
    143b:	83 c4 10             	add    $0x10,%esp
    143e:	89 45 f4             	mov    %eax,-0xc(%ebp)
    1441:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    1445:	75 07                	jne    144e <malloc+0xce>
        return 0;
    1447:	b8 00 00 00 00       	mov    $0x0,%eax
    144c:	eb 13                	jmp    1461 <malloc+0xe1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    144e:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1451:	89 45 f0             	mov    %eax,-0x10(%ebp)
    1454:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1457:	8b 00                	mov    (%eax),%eax
    1459:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(p->s.size >= nunits){
    145c:	e9 6d ff ff ff       	jmp    13ce <malloc+0x4e>
  }
}
    1461:	c9                   	leave
    1462:	c3                   	ret
