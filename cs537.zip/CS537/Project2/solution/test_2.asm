
_test_2:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

#define MAX_NAME_LEN 256

int main(int argc, char* argv[]) {
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	51                   	push   %ecx
   e:	81 ec 04 02 00 00    	sub    $0x204,%esp
  char parent_name[MAX_NAME_LEN];
  char child_name[MAX_NAME_LEN];

  if (getparentname((char*)0, child_name, MAX_NAME_LEN, MAX_NAME_LEN) < 0 &&
  14:	68 00 01 00 00       	push   $0x100
  19:	68 00 01 00 00       	push   $0x100
  1e:	8d 85 f8 fd ff ff    	lea    -0x208(%ebp),%eax
  24:	50                   	push   %eax
  25:	6a 00                	push   $0x0
  27:	e8 4b 03 00 00       	call   377 <getparentname>
  2c:	83 c4 10             	add    $0x10,%esp
  2f:	85 c0                	test   %eax,%eax
  31:	79 36                	jns    69 <main+0x69>
    getparentname(parent_name, (char*)0, MAX_NAME_LEN, MAX_NAME_LEN) < 0) {
  33:	68 00 01 00 00       	push   $0x100
  38:	68 00 01 00 00       	push   $0x100
  3d:	6a 00                	push   $0x0
  3f:	8d 85 f8 fe ff ff    	lea    -0x108(%ebp),%eax
  45:	50                   	push   %eax
  46:	e8 2c 03 00 00       	call   377 <getparentname>
  4b:	83 c4 10             	add    $0x10,%esp
  if (getparentname((char*)0, child_name, MAX_NAME_LEN, MAX_NAME_LEN) < 0 &&
  4e:	85 c0                	test   %eax,%eax
  50:	79 17                	jns    69 <main+0x69>
    printf(1, "XV6_TEST_OUTPUT Null pointers handled correctly.\n");
  52:	83 ec 08             	sub    $0x8,%esp
  55:	68 0c 08 00 00       	push   $0x80c
  5a:	6a 01                	push   $0x1
  5c:	e8 f2 03 00 00       	call   453 <printf>
  61:	83 c4 10             	add    $0x10,%esp
    exit();
  64:	e8 6e 02 00 00       	call   2d7 <exit>
  }

  printf(2, "XV6_TEST_ERROR Test failed! Null pointers not handled correctly.\n");
  69:	83 ec 08             	sub    $0x8,%esp
  6c:	68 40 08 00 00       	push   $0x840
  71:	6a 02                	push   $0x2
  73:	e8 db 03 00 00       	call   453 <printf>
  78:	83 c4 10             	add    $0x10,%esp
  exit();
  7b:	e8 57 02 00 00       	call   2d7 <exit>

00000080 <stosb>:
               "cc");
}

static inline void
stosb(void *addr, int data, int cnt)
{
  80:	55                   	push   %ebp
  81:	89 e5                	mov    %esp,%ebp
  83:	57                   	push   %edi
  84:	53                   	push   %ebx
  asm volatile("cld; rep stosb" :
  85:	8b 4d 08             	mov    0x8(%ebp),%ecx
  88:	8b 55 10             	mov    0x10(%ebp),%edx
  8b:	8b 45 0c             	mov    0xc(%ebp),%eax
  8e:	89 cb                	mov    %ecx,%ebx
  90:	89 df                	mov    %ebx,%edi
  92:	89 d1                	mov    %edx,%ecx
  94:	fc                   	cld
  95:	f3 aa                	rep stos %al,%es:(%edi)
  97:	89 ca                	mov    %ecx,%edx
  99:	89 fb                	mov    %edi,%ebx
  9b:	89 5d 08             	mov    %ebx,0x8(%ebp)
  9e:	89 55 10             	mov    %edx,0x10(%ebp)
               "=D" (addr), "=c" (cnt) :
               "0" (addr), "1" (cnt), "a" (data) :
               "memory", "cc");
}
  a1:	90                   	nop
  a2:	5b                   	pop    %ebx
  a3:	5f                   	pop    %edi
  a4:	5d                   	pop    %ebp
  a5:	c3                   	ret

000000a6 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
  a6:	55                   	push   %ebp
  a7:	89 e5                	mov    %esp,%ebp
  a9:	83 ec 10             	sub    $0x10,%esp
  char *os;

  os = s;
  ac:	8b 45 08             	mov    0x8(%ebp),%eax
  af:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while((*s++ = *t++) != 0)
  b2:	90                   	nop
  b3:	8b 55 0c             	mov    0xc(%ebp),%edx
  b6:	8d 42 01             	lea    0x1(%edx),%eax
  b9:	89 45 0c             	mov    %eax,0xc(%ebp)
  bc:	8b 45 08             	mov    0x8(%ebp),%eax
  bf:	8d 48 01             	lea    0x1(%eax),%ecx
  c2:	89 4d 08             	mov    %ecx,0x8(%ebp)
  c5:	0f b6 12             	movzbl (%edx),%edx
  c8:	88 10                	mov    %dl,(%eax)
  ca:	0f b6 00             	movzbl (%eax),%eax
  cd:	84 c0                	test   %al,%al
  cf:	75 e2                	jne    b3 <strcpy+0xd>
    ;
  return os;
  d1:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
  d4:	c9                   	leave
  d5:	c3                   	ret

000000d6 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  d6:	55                   	push   %ebp
  d7:	89 e5                	mov    %esp,%ebp
  while(*p && *p == *q)
  d9:	eb 08                	jmp    e3 <strcmp+0xd>
    p++, q++;
  db:	83 45 08 01          	addl   $0x1,0x8(%ebp)
  df:	83 45 0c 01          	addl   $0x1,0xc(%ebp)
  while(*p && *p == *q)
  e3:	8b 45 08             	mov    0x8(%ebp),%eax
  e6:	0f b6 00             	movzbl (%eax),%eax
  e9:	84 c0                	test   %al,%al
  eb:	74 10                	je     fd <strcmp+0x27>
  ed:	8b 45 08             	mov    0x8(%ebp),%eax
  f0:	0f b6 10             	movzbl (%eax),%edx
  f3:	8b 45 0c             	mov    0xc(%ebp),%eax
  f6:	0f b6 00             	movzbl (%eax),%eax
  f9:	38 c2                	cmp    %al,%dl
  fb:	74 de                	je     db <strcmp+0x5>
  return (uchar)*p - (uchar)*q;
  fd:	8b 45 08             	mov    0x8(%ebp),%eax
 100:	0f b6 00             	movzbl (%eax),%eax
 103:	0f b6 d0             	movzbl %al,%edx
 106:	8b 45 0c             	mov    0xc(%ebp),%eax
 109:	0f b6 00             	movzbl (%eax),%eax
 10c:	0f b6 c0             	movzbl %al,%eax
 10f:	29 c2                	sub    %eax,%edx
 111:	89 d0                	mov    %edx,%eax
}
 113:	5d                   	pop    %ebp
 114:	c3                   	ret

00000115 <strlen>:

uint
strlen(const char *s)
{
 115:	55                   	push   %ebp
 116:	89 e5                	mov    %esp,%ebp
 118:	83 ec 10             	sub    $0x10,%esp
  int n;

  for(n = 0; s[n]; n++)
 11b:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
 122:	eb 04                	jmp    128 <strlen+0x13>
 124:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
 128:	8b 55 fc             	mov    -0x4(%ebp),%edx
 12b:	8b 45 08             	mov    0x8(%ebp),%eax
 12e:	01 d0                	add    %edx,%eax
 130:	0f b6 00             	movzbl (%eax),%eax
 133:	84 c0                	test   %al,%al
 135:	75 ed                	jne    124 <strlen+0xf>
    ;
  return n;
 137:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
 13a:	c9                   	leave
 13b:	c3                   	ret

0000013c <memset>:

void*
memset(void *dst, int c, uint n)
{
 13c:	55                   	push   %ebp
 13d:	89 e5                	mov    %esp,%ebp
  stosb(dst, c, n);
 13f:	8b 45 10             	mov    0x10(%ebp),%eax
 142:	50                   	push   %eax
 143:	ff 75 0c             	push   0xc(%ebp)
 146:	ff 75 08             	push   0x8(%ebp)
 149:	e8 32 ff ff ff       	call   80 <stosb>
 14e:	83 c4 0c             	add    $0xc,%esp
  return dst;
 151:	8b 45 08             	mov    0x8(%ebp),%eax
}
 154:	c9                   	leave
 155:	c3                   	ret

00000156 <strchr>:

char*
strchr(const char *s, char c)
{
 156:	55                   	push   %ebp
 157:	89 e5                	mov    %esp,%ebp
 159:	83 ec 04             	sub    $0x4,%esp
 15c:	8b 45 0c             	mov    0xc(%ebp),%eax
 15f:	88 45 fc             	mov    %al,-0x4(%ebp)
  for(; *s; s++)
 162:	eb 14                	jmp    178 <strchr+0x22>
    if(*s == c)
 164:	8b 45 08             	mov    0x8(%ebp),%eax
 167:	0f b6 00             	movzbl (%eax),%eax
 16a:	38 45 fc             	cmp    %al,-0x4(%ebp)
 16d:	75 05                	jne    174 <strchr+0x1e>
      return (char*)s;
 16f:	8b 45 08             	mov    0x8(%ebp),%eax
 172:	eb 13                	jmp    187 <strchr+0x31>
  for(; *s; s++)
 174:	83 45 08 01          	addl   $0x1,0x8(%ebp)
 178:	8b 45 08             	mov    0x8(%ebp),%eax
 17b:	0f b6 00             	movzbl (%eax),%eax
 17e:	84 c0                	test   %al,%al
 180:	75 e2                	jne    164 <strchr+0xe>
  return 0;
 182:	b8 00 00 00 00       	mov    $0x0,%eax
}
 187:	c9                   	leave
 188:	c3                   	ret

00000189 <gets>:

char*
gets(char *buf, int max)
{
 189:	55                   	push   %ebp
 18a:	89 e5                	mov    %esp,%ebp
 18c:	83 ec 18             	sub    $0x18,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 18f:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
 196:	eb 42                	jmp    1da <gets+0x51>
    cc = read(0, &c, 1);
 198:	83 ec 04             	sub    $0x4,%esp
 19b:	6a 01                	push   $0x1
 19d:	8d 45 ef             	lea    -0x11(%ebp),%eax
 1a0:	50                   	push   %eax
 1a1:	6a 00                	push   $0x0
 1a3:	e8 47 01 00 00       	call   2ef <read>
 1a8:	83 c4 10             	add    $0x10,%esp
 1ab:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(cc < 1)
 1ae:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
 1b2:	7e 33                	jle    1e7 <gets+0x5e>
      break;
    buf[i++] = c;
 1b4:	8b 45 f4             	mov    -0xc(%ebp),%eax
 1b7:	8d 50 01             	lea    0x1(%eax),%edx
 1ba:	89 55 f4             	mov    %edx,-0xc(%ebp)
 1bd:	89 c2                	mov    %eax,%edx
 1bf:	8b 45 08             	mov    0x8(%ebp),%eax
 1c2:	01 c2                	add    %eax,%edx
 1c4:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
 1c8:	88 02                	mov    %al,(%edx)
    if(c == '\n' || c == '\r')
 1ca:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
 1ce:	3c 0a                	cmp    $0xa,%al
 1d0:	74 16                	je     1e8 <gets+0x5f>
 1d2:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
 1d6:	3c 0d                	cmp    $0xd,%al
 1d8:	74 0e                	je     1e8 <gets+0x5f>
  for(i=0; i+1 < max; ){
 1da:	8b 45 f4             	mov    -0xc(%ebp),%eax
 1dd:	83 c0 01             	add    $0x1,%eax
 1e0:	39 45 0c             	cmp    %eax,0xc(%ebp)
 1e3:	7f b3                	jg     198 <gets+0xf>
 1e5:	eb 01                	jmp    1e8 <gets+0x5f>
      break;
 1e7:	90                   	nop
      break;
  }
  buf[i] = '\0';
 1e8:	8b 55 f4             	mov    -0xc(%ebp),%edx
 1eb:	8b 45 08             	mov    0x8(%ebp),%eax
 1ee:	01 d0                	add    %edx,%eax
 1f0:	c6 00 00             	movb   $0x0,(%eax)
  return buf;
 1f3:	8b 45 08             	mov    0x8(%ebp),%eax
}
 1f6:	c9                   	leave
 1f7:	c3                   	ret

000001f8 <stat>:

int
stat(const char *n, struct stat *st)
{
 1f8:	55                   	push   %ebp
 1f9:	89 e5                	mov    %esp,%ebp
 1fb:	83 ec 18             	sub    $0x18,%esp
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1fe:	83 ec 08             	sub    $0x8,%esp
 201:	6a 00                	push   $0x0
 203:	ff 75 08             	push   0x8(%ebp)
 206:	e8 0c 01 00 00       	call   317 <open>
 20b:	83 c4 10             	add    $0x10,%esp
 20e:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0)
 211:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 215:	79 07                	jns    21e <stat+0x26>
    return -1;
 217:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 21c:	eb 25                	jmp    243 <stat+0x4b>
  r = fstat(fd, st);
 21e:	83 ec 08             	sub    $0x8,%esp
 221:	ff 75 0c             	push   0xc(%ebp)
 224:	ff 75 f4             	push   -0xc(%ebp)
 227:	e8 03 01 00 00       	call   32f <fstat>
 22c:	83 c4 10             	add    $0x10,%esp
 22f:	89 45 f0             	mov    %eax,-0x10(%ebp)
  close(fd);
 232:	83 ec 0c             	sub    $0xc,%esp
 235:	ff 75 f4             	push   -0xc(%ebp)
 238:	e8 c2 00 00 00       	call   2ff <close>
 23d:	83 c4 10             	add    $0x10,%esp
  return r;
 240:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
 243:	c9                   	leave
 244:	c3                   	ret

00000245 <atoi>:

int
atoi(const char *s)
{
 245:	55                   	push   %ebp
 246:	89 e5                	mov    %esp,%ebp
 248:	83 ec 10             	sub    $0x10,%esp
  int n;

  n = 0;
 24b:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
  while('0' <= *s && *s <= '9')
 252:	eb 25                	jmp    279 <atoi+0x34>
    n = n*10 + *s++ - '0';
 254:	8b 55 fc             	mov    -0x4(%ebp),%edx
 257:	89 d0                	mov    %edx,%eax
 259:	c1 e0 02             	shl    $0x2,%eax
 25c:	01 d0                	add    %edx,%eax
 25e:	01 c0                	add    %eax,%eax
 260:	89 c1                	mov    %eax,%ecx
 262:	8b 45 08             	mov    0x8(%ebp),%eax
 265:	8d 50 01             	lea    0x1(%eax),%edx
 268:	89 55 08             	mov    %edx,0x8(%ebp)
 26b:	0f b6 00             	movzbl (%eax),%eax
 26e:	0f be c0             	movsbl %al,%eax
 271:	01 c8                	add    %ecx,%eax
 273:	83 e8 30             	sub    $0x30,%eax
 276:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while('0' <= *s && *s <= '9')
 279:	8b 45 08             	mov    0x8(%ebp),%eax
 27c:	0f b6 00             	movzbl (%eax),%eax
 27f:	3c 2f                	cmp    $0x2f,%al
 281:	7e 0a                	jle    28d <atoi+0x48>
 283:	8b 45 08             	mov    0x8(%ebp),%eax
 286:	0f b6 00             	movzbl (%eax),%eax
 289:	3c 39                	cmp    $0x39,%al
 28b:	7e c7                	jle    254 <atoi+0xf>
  return n;
 28d:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
 290:	c9                   	leave
 291:	c3                   	ret

00000292 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 292:	55                   	push   %ebp
 293:	89 e5                	mov    %esp,%ebp
 295:	83 ec 10             	sub    $0x10,%esp
  char *dst;
  const char *src;

  dst = vdst;
 298:	8b 45 08             	mov    0x8(%ebp),%eax
 29b:	89 45 fc             	mov    %eax,-0x4(%ebp)
  src = vsrc;
 29e:	8b 45 0c             	mov    0xc(%ebp),%eax
 2a1:	89 45 f8             	mov    %eax,-0x8(%ebp)
  while(n-- > 0)
 2a4:	eb 17                	jmp    2bd <memmove+0x2b>
    *dst++ = *src++;
 2a6:	8b 55 f8             	mov    -0x8(%ebp),%edx
 2a9:	8d 42 01             	lea    0x1(%edx),%eax
 2ac:	89 45 f8             	mov    %eax,-0x8(%ebp)
 2af:	8b 45 fc             	mov    -0x4(%ebp),%eax
 2b2:	8d 48 01             	lea    0x1(%eax),%ecx
 2b5:	89 4d fc             	mov    %ecx,-0x4(%ebp)
 2b8:	0f b6 12             	movzbl (%edx),%edx
 2bb:	88 10                	mov    %dl,(%eax)
  while(n-- > 0)
 2bd:	8b 45 10             	mov    0x10(%ebp),%eax
 2c0:	8d 50 ff             	lea    -0x1(%eax),%edx
 2c3:	89 55 10             	mov    %edx,0x10(%ebp)
 2c6:	85 c0                	test   %eax,%eax
 2c8:	7f dc                	jg     2a6 <memmove+0x14>
  return vdst;
 2ca:	8b 45 08             	mov    0x8(%ebp),%eax
}
 2cd:	c9                   	leave
 2ce:	c3                   	ret

000002cf <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 2cf:	b8 01 00 00 00       	mov    $0x1,%eax
 2d4:	cd 40                	int    $0x40
 2d6:	c3                   	ret

000002d7 <exit>:
SYSCALL(exit)
 2d7:	b8 02 00 00 00       	mov    $0x2,%eax
 2dc:	cd 40                	int    $0x40
 2de:	c3                   	ret

000002df <wait>:
SYSCALL(wait)
 2df:	b8 03 00 00 00       	mov    $0x3,%eax
 2e4:	cd 40                	int    $0x40
 2e6:	c3                   	ret

000002e7 <pipe>:
SYSCALL(pipe)
 2e7:	b8 04 00 00 00       	mov    $0x4,%eax
 2ec:	cd 40                	int    $0x40
 2ee:	c3                   	ret

000002ef <read>:
SYSCALL(read)
 2ef:	b8 05 00 00 00       	mov    $0x5,%eax
 2f4:	cd 40                	int    $0x40
 2f6:	c3                   	ret

000002f7 <write>:
SYSCALL(write)
 2f7:	b8 10 00 00 00       	mov    $0x10,%eax
 2fc:	cd 40                	int    $0x40
 2fe:	c3                   	ret

000002ff <close>:
SYSCALL(close)
 2ff:	b8 15 00 00 00       	mov    $0x15,%eax
 304:	cd 40                	int    $0x40
 306:	c3                   	ret

00000307 <kill>:
SYSCALL(kill)
 307:	b8 06 00 00 00       	mov    $0x6,%eax
 30c:	cd 40                	int    $0x40
 30e:	c3                   	ret

0000030f <exec>:
SYSCALL(exec)
 30f:	b8 07 00 00 00       	mov    $0x7,%eax
 314:	cd 40                	int    $0x40
 316:	c3                   	ret

00000317 <open>:
SYSCALL(open)
 317:	b8 0f 00 00 00       	mov    $0xf,%eax
 31c:	cd 40                	int    $0x40
 31e:	c3                   	ret

0000031f <mknod>:
SYSCALL(mknod)
 31f:	b8 11 00 00 00       	mov    $0x11,%eax
 324:	cd 40                	int    $0x40
 326:	c3                   	ret

00000327 <unlink>:
SYSCALL(unlink)
 327:	b8 12 00 00 00       	mov    $0x12,%eax
 32c:	cd 40                	int    $0x40
 32e:	c3                   	ret

0000032f <fstat>:
SYSCALL(fstat)
 32f:	b8 08 00 00 00       	mov    $0x8,%eax
 334:	cd 40                	int    $0x40
 336:	c3                   	ret

00000337 <link>:
SYSCALL(link)
 337:	b8 13 00 00 00       	mov    $0x13,%eax
 33c:	cd 40                	int    $0x40
 33e:	c3                   	ret

0000033f <mkdir>:
SYSCALL(mkdir)
 33f:	b8 14 00 00 00       	mov    $0x14,%eax
 344:	cd 40                	int    $0x40
 346:	c3                   	ret

00000347 <chdir>:
SYSCALL(chdir)
 347:	b8 09 00 00 00       	mov    $0x9,%eax
 34c:	cd 40                	int    $0x40
 34e:	c3                   	ret

0000034f <dup>:
SYSCALL(dup)
 34f:	b8 0a 00 00 00       	mov    $0xa,%eax
 354:	cd 40                	int    $0x40
 356:	c3                   	ret

00000357 <getpid>:
SYSCALL(getpid)
 357:	b8 0b 00 00 00       	mov    $0xb,%eax
 35c:	cd 40                	int    $0x40
 35e:	c3                   	ret

0000035f <sbrk>:
SYSCALL(sbrk)
 35f:	b8 0c 00 00 00       	mov    $0xc,%eax
 364:	cd 40                	int    $0x40
 366:	c3                   	ret

00000367 <sleep>:
SYSCALL(sleep)
 367:	b8 0d 00 00 00       	mov    $0xd,%eax
 36c:	cd 40                	int    $0x40
 36e:	c3                   	ret

0000036f <uptime>:
SYSCALL(uptime)
 36f:	b8 0e 00 00 00       	mov    $0xe,%eax
 374:	cd 40                	int    $0x40
 376:	c3                   	ret

00000377 <getparentname>:
SYSCALL(getparentname)
 377:	b8 16 00 00 00       	mov    $0x16,%eax
 37c:	cd 40                	int    $0x40
 37e:	c3                   	ret

0000037f <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 37f:	55                   	push   %ebp
 380:	89 e5                	mov    %esp,%ebp
 382:	83 ec 18             	sub    $0x18,%esp
 385:	8b 45 0c             	mov    0xc(%ebp),%eax
 388:	88 45 f4             	mov    %al,-0xc(%ebp)
  write(fd, &c, 1);
 38b:	83 ec 04             	sub    $0x4,%esp
 38e:	6a 01                	push   $0x1
 390:	8d 45 f4             	lea    -0xc(%ebp),%eax
 393:	50                   	push   %eax
 394:	ff 75 08             	push   0x8(%ebp)
 397:	e8 5b ff ff ff       	call   2f7 <write>
 39c:	83 c4 10             	add    $0x10,%esp
}
 39f:	90                   	nop
 3a0:	c9                   	leave
 3a1:	c3                   	ret

000003a2 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 3a2:	55                   	push   %ebp
 3a3:	89 e5                	mov    %esp,%ebp
 3a5:	83 ec 28             	sub    $0x28,%esp
  static char digits[] = "0123456789ABCDEF";
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
 3a8:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  if(sgn && xx < 0){
 3af:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
 3b3:	74 17                	je     3cc <printint+0x2a>
 3b5:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
 3b9:	79 11                	jns    3cc <printint+0x2a>
    neg = 1;
 3bb:	c7 45 f0 01 00 00 00 	movl   $0x1,-0x10(%ebp)
    x = -xx;
 3c2:	8b 45 0c             	mov    0xc(%ebp),%eax
 3c5:	f7 d8                	neg    %eax
 3c7:	89 45 ec             	mov    %eax,-0x14(%ebp)
 3ca:	eb 06                	jmp    3d2 <printint+0x30>
  } else {
    x = xx;
 3cc:	8b 45 0c             	mov    0xc(%ebp),%eax
 3cf:	89 45 ec             	mov    %eax,-0x14(%ebp)
  }

  i = 0;
 3d2:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  do{
    buf[i++] = digits[x % base];
 3d9:	8b 4d 10             	mov    0x10(%ebp),%ecx
 3dc:	8b 45 ec             	mov    -0x14(%ebp),%eax
 3df:	ba 00 00 00 00       	mov    $0x0,%edx
 3e4:	f7 f1                	div    %ecx
 3e6:	89 d1                	mov    %edx,%ecx
 3e8:	8b 45 f4             	mov    -0xc(%ebp),%eax
 3eb:	8d 50 01             	lea    0x1(%eax),%edx
 3ee:	89 55 f4             	mov    %edx,-0xc(%ebp)
 3f1:	0f b6 91 f8 0a 00 00 	movzbl 0xaf8(%ecx),%edx
 3f8:	88 54 05 dc          	mov    %dl,-0x24(%ebp,%eax,1)
  }while((x /= base) != 0);
 3fc:	8b 4d 10             	mov    0x10(%ebp),%ecx
 3ff:	8b 45 ec             	mov    -0x14(%ebp),%eax
 402:	ba 00 00 00 00       	mov    $0x0,%edx
 407:	f7 f1                	div    %ecx
 409:	89 45 ec             	mov    %eax,-0x14(%ebp)
 40c:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
 410:	75 c7                	jne    3d9 <printint+0x37>
  if(neg)
 412:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
 416:	74 2d                	je     445 <printint+0xa3>
    buf[i++] = '-';
 418:	8b 45 f4             	mov    -0xc(%ebp),%eax
 41b:	8d 50 01             	lea    0x1(%eax),%edx
 41e:	89 55 f4             	mov    %edx,-0xc(%ebp)
 421:	c6 44 05 dc 2d       	movb   $0x2d,-0x24(%ebp,%eax,1)

  while(--i >= 0)
 426:	eb 1d                	jmp    445 <printint+0xa3>
    putc(fd, buf[i]);
 428:	8d 55 dc             	lea    -0x24(%ebp),%edx
 42b:	8b 45 f4             	mov    -0xc(%ebp),%eax
 42e:	01 d0                	add    %edx,%eax
 430:	0f b6 00             	movzbl (%eax),%eax
 433:	0f be c0             	movsbl %al,%eax
 436:	83 ec 08             	sub    $0x8,%esp
 439:	50                   	push   %eax
 43a:	ff 75 08             	push   0x8(%ebp)
 43d:	e8 3d ff ff ff       	call   37f <putc>
 442:	83 c4 10             	add    $0x10,%esp
  while(--i >= 0)
 445:	83 6d f4 01          	subl   $0x1,-0xc(%ebp)
 449:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 44d:	79 d9                	jns    428 <printint+0x86>
}
 44f:	90                   	nop
 450:	90                   	nop
 451:	c9                   	leave
 452:	c3                   	ret

00000453 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 453:	55                   	push   %ebp
 454:	89 e5                	mov    %esp,%ebp
 456:	83 ec 28             	sub    $0x28,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
 459:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  ap = (uint*)(void*)&fmt + 1;
 460:	8d 45 0c             	lea    0xc(%ebp),%eax
 463:	83 c0 04             	add    $0x4,%eax
 466:	89 45 e8             	mov    %eax,-0x18(%ebp)
  for(i = 0; fmt[i]; i++){
 469:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
 470:	e9 59 01 00 00       	jmp    5ce <printf+0x17b>
    c = fmt[i] & 0xff;
 475:	8b 55 0c             	mov    0xc(%ebp),%edx
 478:	8b 45 f0             	mov    -0x10(%ebp),%eax
 47b:	01 d0                	add    %edx,%eax
 47d:	0f b6 00             	movzbl (%eax),%eax
 480:	0f be c0             	movsbl %al,%eax
 483:	25 ff 00 00 00       	and    $0xff,%eax
 488:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(state == 0){
 48b:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
 48f:	75 2c                	jne    4bd <printf+0x6a>
      if(c == '%'){
 491:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
 495:	75 0c                	jne    4a3 <printf+0x50>
        state = '%';
 497:	c7 45 ec 25 00 00 00 	movl   $0x25,-0x14(%ebp)
 49e:	e9 27 01 00 00       	jmp    5ca <printf+0x177>
      } else {
        putc(fd, c);
 4a3:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 4a6:	0f be c0             	movsbl %al,%eax
 4a9:	83 ec 08             	sub    $0x8,%esp
 4ac:	50                   	push   %eax
 4ad:	ff 75 08             	push   0x8(%ebp)
 4b0:	e8 ca fe ff ff       	call   37f <putc>
 4b5:	83 c4 10             	add    $0x10,%esp
 4b8:	e9 0d 01 00 00       	jmp    5ca <printf+0x177>
      }
    } else if(state == '%'){
 4bd:	83 7d ec 25          	cmpl   $0x25,-0x14(%ebp)
 4c1:	0f 85 03 01 00 00    	jne    5ca <printf+0x177>
      if(c == 'd'){
 4c7:	83 7d e4 64          	cmpl   $0x64,-0x1c(%ebp)
 4cb:	75 1e                	jne    4eb <printf+0x98>
        printint(fd, *ap, 10, 1);
 4cd:	8b 45 e8             	mov    -0x18(%ebp),%eax
 4d0:	8b 00                	mov    (%eax),%eax
 4d2:	6a 01                	push   $0x1
 4d4:	6a 0a                	push   $0xa
 4d6:	50                   	push   %eax
 4d7:	ff 75 08             	push   0x8(%ebp)
 4da:	e8 c3 fe ff ff       	call   3a2 <printint>
 4df:	83 c4 10             	add    $0x10,%esp
        ap++;
 4e2:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
 4e6:	e9 d8 00 00 00       	jmp    5c3 <printf+0x170>
      } else if(c == 'x' || c == 'p'){
 4eb:	83 7d e4 78          	cmpl   $0x78,-0x1c(%ebp)
 4ef:	74 06                	je     4f7 <printf+0xa4>
 4f1:	83 7d e4 70          	cmpl   $0x70,-0x1c(%ebp)
 4f5:	75 1e                	jne    515 <printf+0xc2>
        printint(fd, *ap, 16, 0);
 4f7:	8b 45 e8             	mov    -0x18(%ebp),%eax
 4fa:	8b 00                	mov    (%eax),%eax
 4fc:	6a 00                	push   $0x0
 4fe:	6a 10                	push   $0x10
 500:	50                   	push   %eax
 501:	ff 75 08             	push   0x8(%ebp)
 504:	e8 99 fe ff ff       	call   3a2 <printint>
 509:	83 c4 10             	add    $0x10,%esp
        ap++;
 50c:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
 510:	e9 ae 00 00 00       	jmp    5c3 <printf+0x170>
      } else if(c == 's'){
 515:	83 7d e4 73          	cmpl   $0x73,-0x1c(%ebp)
 519:	75 43                	jne    55e <printf+0x10b>
        s = (char*)*ap;
 51b:	8b 45 e8             	mov    -0x18(%ebp),%eax
 51e:	8b 00                	mov    (%eax),%eax
 520:	89 45 f4             	mov    %eax,-0xc(%ebp)
        ap++;
 523:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
        if(s == 0)
 527:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 52b:	75 25                	jne    552 <printf+0xff>
          s = "(null)";
 52d:	c7 45 f4 82 08 00 00 	movl   $0x882,-0xc(%ebp)
        while(*s != 0){
 534:	eb 1c                	jmp    552 <printf+0xff>
          putc(fd, *s);
 536:	8b 45 f4             	mov    -0xc(%ebp),%eax
 539:	0f b6 00             	movzbl (%eax),%eax
 53c:	0f be c0             	movsbl %al,%eax
 53f:	83 ec 08             	sub    $0x8,%esp
 542:	50                   	push   %eax
 543:	ff 75 08             	push   0x8(%ebp)
 546:	e8 34 fe ff ff       	call   37f <putc>
 54b:	83 c4 10             	add    $0x10,%esp
          s++;
 54e:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
        while(*s != 0){
 552:	8b 45 f4             	mov    -0xc(%ebp),%eax
 555:	0f b6 00             	movzbl (%eax),%eax
 558:	84 c0                	test   %al,%al
 55a:	75 da                	jne    536 <printf+0xe3>
 55c:	eb 65                	jmp    5c3 <printf+0x170>
        }
      } else if(c == 'c'){
 55e:	83 7d e4 63          	cmpl   $0x63,-0x1c(%ebp)
 562:	75 1d                	jne    581 <printf+0x12e>
        putc(fd, *ap);
 564:	8b 45 e8             	mov    -0x18(%ebp),%eax
 567:	8b 00                	mov    (%eax),%eax
 569:	0f be c0             	movsbl %al,%eax
 56c:	83 ec 08             	sub    $0x8,%esp
 56f:	50                   	push   %eax
 570:	ff 75 08             	push   0x8(%ebp)
 573:	e8 07 fe ff ff       	call   37f <putc>
 578:	83 c4 10             	add    $0x10,%esp
        ap++;
 57b:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
 57f:	eb 42                	jmp    5c3 <printf+0x170>
      } else if(c == '%'){
 581:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
 585:	75 17                	jne    59e <printf+0x14b>
        putc(fd, c);
 587:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 58a:	0f be c0             	movsbl %al,%eax
 58d:	83 ec 08             	sub    $0x8,%esp
 590:	50                   	push   %eax
 591:	ff 75 08             	push   0x8(%ebp)
 594:	e8 e6 fd ff ff       	call   37f <putc>
 599:	83 c4 10             	add    $0x10,%esp
 59c:	eb 25                	jmp    5c3 <printf+0x170>
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 59e:	83 ec 08             	sub    $0x8,%esp
 5a1:	6a 25                	push   $0x25
 5a3:	ff 75 08             	push   0x8(%ebp)
 5a6:	e8 d4 fd ff ff       	call   37f <putc>
 5ab:	83 c4 10             	add    $0x10,%esp
        putc(fd, c);
 5ae:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 5b1:	0f be c0             	movsbl %al,%eax
 5b4:	83 ec 08             	sub    $0x8,%esp
 5b7:	50                   	push   %eax
 5b8:	ff 75 08             	push   0x8(%ebp)
 5bb:	e8 bf fd ff ff       	call   37f <putc>
 5c0:	83 c4 10             	add    $0x10,%esp
      }
      state = 0;
 5c3:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  for(i = 0; fmt[i]; i++){
 5ca:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
 5ce:	8b 55 0c             	mov    0xc(%ebp),%edx
 5d1:	8b 45 f0             	mov    -0x10(%ebp),%eax
 5d4:	01 d0                	add    %edx,%eax
 5d6:	0f b6 00             	movzbl (%eax),%eax
 5d9:	84 c0                	test   %al,%al
 5db:	0f 85 94 fe ff ff    	jne    475 <printf+0x22>
    }
  }
}
 5e1:	90                   	nop
 5e2:	90                   	nop
 5e3:	c9                   	leave
 5e4:	c3                   	ret

000005e5 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 5e5:	55                   	push   %ebp
 5e6:	89 e5                	mov    %esp,%ebp
 5e8:	83 ec 10             	sub    $0x10,%esp
  Header *bp, *p;

  bp = (Header*)ap - 1;
 5eb:	8b 45 08             	mov    0x8(%ebp),%eax
 5ee:	83 e8 08             	sub    $0x8,%eax
 5f1:	89 45 f8             	mov    %eax,-0x8(%ebp)
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 5f4:	a1 14 0b 00 00       	mov    0xb14,%eax
 5f9:	89 45 fc             	mov    %eax,-0x4(%ebp)
 5fc:	eb 24                	jmp    622 <free+0x3d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 5fe:	8b 45 fc             	mov    -0x4(%ebp),%eax
 601:	8b 00                	mov    (%eax),%eax
 603:	39 45 fc             	cmp    %eax,-0x4(%ebp)
 606:	72 12                	jb     61a <free+0x35>
 608:	8b 45 f8             	mov    -0x8(%ebp),%eax
 60b:	39 45 fc             	cmp    %eax,-0x4(%ebp)
 60e:	72 24                	jb     634 <free+0x4f>
 610:	8b 45 fc             	mov    -0x4(%ebp),%eax
 613:	8b 00                	mov    (%eax),%eax
 615:	39 45 f8             	cmp    %eax,-0x8(%ebp)
 618:	72 1a                	jb     634 <free+0x4f>
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 61a:	8b 45 fc             	mov    -0x4(%ebp),%eax
 61d:	8b 00                	mov    (%eax),%eax
 61f:	89 45 fc             	mov    %eax,-0x4(%ebp)
 622:	8b 45 f8             	mov    -0x8(%ebp),%eax
 625:	39 45 fc             	cmp    %eax,-0x4(%ebp)
 628:	73 d4                	jae    5fe <free+0x19>
 62a:	8b 45 fc             	mov    -0x4(%ebp),%eax
 62d:	8b 00                	mov    (%eax),%eax
 62f:	39 45 f8             	cmp    %eax,-0x8(%ebp)
 632:	73 ca                	jae    5fe <free+0x19>
      break;
  if(bp + bp->s.size == p->s.ptr){
 634:	8b 45 f8             	mov    -0x8(%ebp),%eax
 637:	8b 40 04             	mov    0x4(%eax),%eax
 63a:	8d 14 c5 00 00 00 00 	lea    0x0(,%eax,8),%edx
 641:	8b 45 f8             	mov    -0x8(%ebp),%eax
 644:	01 c2                	add    %eax,%edx
 646:	8b 45 fc             	mov    -0x4(%ebp),%eax
 649:	8b 00                	mov    (%eax),%eax
 64b:	39 c2                	cmp    %eax,%edx
 64d:	75 24                	jne    673 <free+0x8e>
    bp->s.size += p->s.ptr->s.size;
 64f:	8b 45 f8             	mov    -0x8(%ebp),%eax
 652:	8b 50 04             	mov    0x4(%eax),%edx
 655:	8b 45 fc             	mov    -0x4(%ebp),%eax
 658:	8b 00                	mov    (%eax),%eax
 65a:	8b 40 04             	mov    0x4(%eax),%eax
 65d:	01 c2                	add    %eax,%edx
 65f:	8b 45 f8             	mov    -0x8(%ebp),%eax
 662:	89 50 04             	mov    %edx,0x4(%eax)
    bp->s.ptr = p->s.ptr->s.ptr;
 665:	8b 45 fc             	mov    -0x4(%ebp),%eax
 668:	8b 00                	mov    (%eax),%eax
 66a:	8b 10                	mov    (%eax),%edx
 66c:	8b 45 f8             	mov    -0x8(%ebp),%eax
 66f:	89 10                	mov    %edx,(%eax)
 671:	eb 0a                	jmp    67d <free+0x98>
  } else
    bp->s.ptr = p->s.ptr;
 673:	8b 45 fc             	mov    -0x4(%ebp),%eax
 676:	8b 10                	mov    (%eax),%edx
 678:	8b 45 f8             	mov    -0x8(%ebp),%eax
 67b:	89 10                	mov    %edx,(%eax)
  if(p + p->s.size == bp){
 67d:	8b 45 fc             	mov    -0x4(%ebp),%eax
 680:	8b 40 04             	mov    0x4(%eax),%eax
 683:	8d 14 c5 00 00 00 00 	lea    0x0(,%eax,8),%edx
 68a:	8b 45 fc             	mov    -0x4(%ebp),%eax
 68d:	01 d0                	add    %edx,%eax
 68f:	39 45 f8             	cmp    %eax,-0x8(%ebp)
 692:	75 20                	jne    6b4 <free+0xcf>
    p->s.size += bp->s.size;
 694:	8b 45 fc             	mov    -0x4(%ebp),%eax
 697:	8b 50 04             	mov    0x4(%eax),%edx
 69a:	8b 45 f8             	mov    -0x8(%ebp),%eax
 69d:	8b 40 04             	mov    0x4(%eax),%eax
 6a0:	01 c2                	add    %eax,%edx
 6a2:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6a5:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 6a8:	8b 45 f8             	mov    -0x8(%ebp),%eax
 6ab:	8b 10                	mov    (%eax),%edx
 6ad:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6b0:	89 10                	mov    %edx,(%eax)
 6b2:	eb 08                	jmp    6bc <free+0xd7>
  } else
    p->s.ptr = bp;
 6b4:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6b7:	8b 55 f8             	mov    -0x8(%ebp),%edx
 6ba:	89 10                	mov    %edx,(%eax)
  freep = p;
 6bc:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6bf:	a3 14 0b 00 00       	mov    %eax,0xb14
}
 6c4:	90                   	nop
 6c5:	c9                   	leave
 6c6:	c3                   	ret

000006c7 <morecore>:

static Header*
morecore(uint nu)
{
 6c7:	55                   	push   %ebp
 6c8:	89 e5                	mov    %esp,%ebp
 6ca:	83 ec 18             	sub    $0x18,%esp
  char *p;
  Header *hp;

  if(nu < 4096)
 6cd:	81 7d 08 ff 0f 00 00 	cmpl   $0xfff,0x8(%ebp)
 6d4:	77 07                	ja     6dd <morecore+0x16>
    nu = 4096;
 6d6:	c7 45 08 00 10 00 00 	movl   $0x1000,0x8(%ebp)
  p = sbrk(nu * sizeof(Header));
 6dd:	8b 45 08             	mov    0x8(%ebp),%eax
 6e0:	c1 e0 03             	shl    $0x3,%eax
 6e3:	83 ec 0c             	sub    $0xc,%esp
 6e6:	50                   	push   %eax
 6e7:	e8 73 fc ff ff       	call   35f <sbrk>
 6ec:	83 c4 10             	add    $0x10,%esp
 6ef:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(p == (char*)-1)
 6f2:	83 7d f4 ff          	cmpl   $0xffffffff,-0xc(%ebp)
 6f6:	75 07                	jne    6ff <morecore+0x38>
    return 0;
 6f8:	b8 00 00 00 00       	mov    $0x0,%eax
 6fd:	eb 26                	jmp    725 <morecore+0x5e>
  hp = (Header*)p;
 6ff:	8b 45 f4             	mov    -0xc(%ebp),%eax
 702:	89 45 f0             	mov    %eax,-0x10(%ebp)
  hp->s.size = nu;
 705:	8b 45 f0             	mov    -0x10(%ebp),%eax
 708:	8b 55 08             	mov    0x8(%ebp),%edx
 70b:	89 50 04             	mov    %edx,0x4(%eax)
  free((void*)(hp + 1));
 70e:	8b 45 f0             	mov    -0x10(%ebp),%eax
 711:	83 c0 08             	add    $0x8,%eax
 714:	83 ec 0c             	sub    $0xc,%esp
 717:	50                   	push   %eax
 718:	e8 c8 fe ff ff       	call   5e5 <free>
 71d:	83 c4 10             	add    $0x10,%esp
  return freep;
 720:	a1 14 0b 00 00       	mov    0xb14,%eax
}
 725:	c9                   	leave
 726:	c3                   	ret

00000727 <malloc>:

void*
malloc(uint nbytes)
{
 727:	55                   	push   %ebp
 728:	89 e5                	mov    %esp,%ebp
 72a:	83 ec 18             	sub    $0x18,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 72d:	8b 45 08             	mov    0x8(%ebp),%eax
 730:	83 c0 07             	add    $0x7,%eax
 733:	c1 e8 03             	shr    $0x3,%eax
 736:	83 c0 01             	add    $0x1,%eax
 739:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if((prevp = freep) == 0){
 73c:	a1 14 0b 00 00       	mov    0xb14,%eax
 741:	89 45 f0             	mov    %eax,-0x10(%ebp)
 744:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
 748:	75 23                	jne    76d <malloc+0x46>
    base.s.ptr = freep = prevp = &base;
 74a:	c7 45 f0 0c 0b 00 00 	movl   $0xb0c,-0x10(%ebp)
 751:	8b 45 f0             	mov    -0x10(%ebp),%eax
 754:	a3 14 0b 00 00       	mov    %eax,0xb14
 759:	a1 14 0b 00 00       	mov    0xb14,%eax
 75e:	a3 0c 0b 00 00       	mov    %eax,0xb0c
    base.s.size = 0;
 763:	c7 05 10 0b 00 00 00 	movl   $0x0,0xb10
 76a:	00 00 00 
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 76d:	8b 45 f0             	mov    -0x10(%ebp),%eax
 770:	8b 00                	mov    (%eax),%eax
 772:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(p->s.size >= nunits){
 775:	8b 45 f4             	mov    -0xc(%ebp),%eax
 778:	8b 40 04             	mov    0x4(%eax),%eax
 77b:	3b 45 ec             	cmp    -0x14(%ebp),%eax
 77e:	72 4d                	jb     7cd <malloc+0xa6>
      if(p->s.size == nunits)
 780:	8b 45 f4             	mov    -0xc(%ebp),%eax
 783:	8b 40 04             	mov    0x4(%eax),%eax
 786:	39 45 ec             	cmp    %eax,-0x14(%ebp)
 789:	75 0c                	jne    797 <malloc+0x70>
        prevp->s.ptr = p->s.ptr;
 78b:	8b 45 f4             	mov    -0xc(%ebp),%eax
 78e:	8b 10                	mov    (%eax),%edx
 790:	8b 45 f0             	mov    -0x10(%ebp),%eax
 793:	89 10                	mov    %edx,(%eax)
 795:	eb 26                	jmp    7bd <malloc+0x96>
      else {
        p->s.size -= nunits;
 797:	8b 45 f4             	mov    -0xc(%ebp),%eax
 79a:	8b 40 04             	mov    0x4(%eax),%eax
 79d:	2b 45 ec             	sub    -0x14(%ebp),%eax
 7a0:	89 c2                	mov    %eax,%edx
 7a2:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7a5:	89 50 04             	mov    %edx,0x4(%eax)
        p += p->s.size;
 7a8:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7ab:	8b 40 04             	mov    0x4(%eax),%eax
 7ae:	c1 e0 03             	shl    $0x3,%eax
 7b1:	01 45 f4             	add    %eax,-0xc(%ebp)
        p->s.size = nunits;
 7b4:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7b7:	8b 55 ec             	mov    -0x14(%ebp),%edx
 7ba:	89 50 04             	mov    %edx,0x4(%eax)
      }
      freep = prevp;
 7bd:	8b 45 f0             	mov    -0x10(%ebp),%eax
 7c0:	a3 14 0b 00 00       	mov    %eax,0xb14
      return (void*)(p + 1);
 7c5:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7c8:	83 c0 08             	add    $0x8,%eax
 7cb:	eb 3b                	jmp    808 <malloc+0xe1>
    }
    if(p == freep)
 7cd:	a1 14 0b 00 00       	mov    0xb14,%eax
 7d2:	39 45 f4             	cmp    %eax,-0xc(%ebp)
 7d5:	75 1e                	jne    7f5 <malloc+0xce>
      if((p = morecore(nunits)) == 0)
 7d7:	83 ec 0c             	sub    $0xc,%esp
 7da:	ff 75 ec             	push   -0x14(%ebp)
 7dd:	e8 e5 fe ff ff       	call   6c7 <morecore>
 7e2:	83 c4 10             	add    $0x10,%esp
 7e5:	89 45 f4             	mov    %eax,-0xc(%ebp)
 7e8:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 7ec:	75 07                	jne    7f5 <malloc+0xce>
        return 0;
 7ee:	b8 00 00 00 00       	mov    $0x0,%eax
 7f3:	eb 13                	jmp    808 <malloc+0xe1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7f5:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7f8:	89 45 f0             	mov    %eax,-0x10(%ebp)
 7fb:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7fe:	8b 00                	mov    (%eax),%eax
 800:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(p->s.size >= nunits){
 803:	e9 6d ff ff ff       	jmp    775 <malloc+0x4e>
  }
}
 808:	c9                   	leave
 809:	c3                   	ret
