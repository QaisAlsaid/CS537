#include "types.h"
#include "stat.h"
#include "user.h"

int main (void)
{
  char procname[256], procparentname[256];

  int ret = getparentname(procparentname, procname, 256, 256);
  if (ret != 0) {
    printf(2, "getparentname failed, with code: %i.\n", ret);
  }
  printf(1, "XV6_TEST_OUTPUT Parent name: %s Child name: %s\n", procname, procparentname);
  exit();
}