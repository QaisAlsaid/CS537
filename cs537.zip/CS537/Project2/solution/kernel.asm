
kernel:     file format elf32-i386


Disassembly of section .text:

80100000 <multiboot_header>:
80100000:	02 b0 ad 1b 00 00    	add    0x1bad(%eax),%dh
80100006:	00 00                	add    %al,(%eax)
80100008:	fe 4f 52             	decb   0x52(%edi)
8010000b:	e4                   	.byte 0xe4

8010000c <entry>:

# Entering xv6 on boot processor, with paging off.
.globl entry
entry:
  # Turn on page size extension for 4Mbyte pages
  movl    %cr4, %eax
8010000c:	0f 20 e0             	mov    %cr4,%eax
  orl     $(CR4_PSE), %eax
8010000f:	83 c8 10             	or     $0x10,%eax
  movl    %eax, %cr4
80100012:	0f 22 e0             	mov    %eax,%cr4
  # Set page directory
  movl    $(V2P_WO(entrypgdir)), %eax
80100015:	b8 00 a0 10 00       	mov    $0x10a000,%eax
  movl    %eax, %cr3
8010001a:	0f 22 d8             	mov    %eax,%cr3
  # Turn on paging.
  movl    %cr0, %eax
8010001d:	0f 20 c0             	mov    %cr0,%eax
  orl     $(CR0_PG|CR0_WP), %eax
80100020:	0d 00 00 01 80       	or     $0x80010000,%eax
  movl    %eax, %cr0
80100025:	0f 22 c0             	mov    %eax,%cr0

  # Set up the stack pointer.
  movl $(stack + KSTACKSIZE), %esp
80100028:	bc 00 65 11 80       	mov    $0x80116500,%esp

  # Jump to main(), and switch to executing at
  # high addresses. The indirect call is needed because
  # the assembler produces a PC-relative instruction
  # for a direct jump.
  mov $main, %eax
8010002d:	b8 4b 38 10 80       	mov    $0x8010384b,%eax
  jmp *%eax
80100032:	ff e0                	jmp    *%eax

80100034 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
80100034:	55                   	push   %ebp
80100035:	89 e5                	mov    %esp,%ebp
80100037:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  initlock(&bcache.lock, "bcache");
8010003a:	83 ec 08             	sub    $0x8,%esp
8010003d:	68 64 84 10 80       	push   $0x80108464
80100042:	68 a0 b5 10 80       	push   $0x8010b5a0
80100047:	e8 7b 4f 00 00       	call   80104fc7 <initlock>
8010004c:	83 c4 10             	add    $0x10,%esp

//PAGEBREAK!
  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
8010004f:	c7 05 ec fc 10 80 9c 	movl   $0x8010fc9c,0x8010fcec
80100056:	fc 10 80 
  bcache.head.next = &bcache.head;
80100059:	c7 05 f0 fc 10 80 9c 	movl   $0x8010fc9c,0x8010fcf0
80100060:	fc 10 80 
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100063:	c7 45 f4 d4 b5 10 80 	movl   $0x8010b5d4,-0xc(%ebp)
8010006a:	eb 47                	jmp    801000b3 <binit+0x7f>
    b->next = bcache.head.next;
8010006c:	8b 15 f0 fc 10 80    	mov    0x8010fcf0,%edx
80100072:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100075:	89 50 54             	mov    %edx,0x54(%eax)
    b->prev = &bcache.head;
80100078:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010007b:	c7 40 50 9c fc 10 80 	movl   $0x8010fc9c,0x50(%eax)
    initsleeplock(&b->lock, "buffer");
80100082:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100085:	83 c0 0c             	add    $0xc,%eax
80100088:	83 ec 08             	sub    $0x8,%esp
8010008b:	68 6b 84 10 80       	push   $0x8010846b
80100090:	50                   	push   %eax
80100091:	e8 ae 4d 00 00       	call   80104e44 <initsleeplock>
80100096:	83 c4 10             	add    $0x10,%esp
    bcache.head.next->prev = b;
80100099:	a1 f0 fc 10 80       	mov    0x8010fcf0,%eax
8010009e:	8b 55 f4             	mov    -0xc(%ebp),%edx
801000a1:	89 50 50             	mov    %edx,0x50(%eax)
    bcache.head.next = b;
801000a4:	8b 45 f4             	mov    -0xc(%ebp),%eax
801000a7:	a3 f0 fc 10 80       	mov    %eax,0x8010fcf0
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000ac:	81 45 f4 5c 02 00 00 	addl   $0x25c,-0xc(%ebp)
801000b3:	b8 9c fc 10 80       	mov    $0x8010fc9c,%eax
801000b8:	39 45 f4             	cmp    %eax,-0xc(%ebp)
801000bb:	72 af                	jb     8010006c <binit+0x38>
  }
}
801000bd:	90                   	nop
801000be:	90                   	nop
801000bf:	c9                   	leave
801000c0:	c3                   	ret

801000c1 <bget>:
// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{
801000c1:	55                   	push   %ebp
801000c2:	89 e5                	mov    %esp,%ebp
801000c4:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  acquire(&bcache.lock);
801000c7:	83 ec 0c             	sub    $0xc,%esp
801000ca:	68 a0 b5 10 80       	push   $0x8010b5a0
801000cf:	e8 15 4f 00 00       	call   80104fe9 <acquire>
801000d4:	83 c4 10             	add    $0x10,%esp

  // Is the block already cached?
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
801000d7:	a1 f0 fc 10 80       	mov    0x8010fcf0,%eax
801000dc:	89 45 f4             	mov    %eax,-0xc(%ebp)
801000df:	eb 58                	jmp    80100139 <bget+0x78>
    if(b->dev == dev && b->blockno == blockno){
801000e1:	8b 45 f4             	mov    -0xc(%ebp),%eax
801000e4:	8b 40 04             	mov    0x4(%eax),%eax
801000e7:	39 45 08             	cmp    %eax,0x8(%ebp)
801000ea:	75 44                	jne    80100130 <bget+0x6f>
801000ec:	8b 45 f4             	mov    -0xc(%ebp),%eax
801000ef:	8b 40 08             	mov    0x8(%eax),%eax
801000f2:	39 45 0c             	cmp    %eax,0xc(%ebp)
801000f5:	75 39                	jne    80100130 <bget+0x6f>
      b->refcnt++;
801000f7:	8b 45 f4             	mov    -0xc(%ebp),%eax
801000fa:	8b 40 4c             	mov    0x4c(%eax),%eax
801000fd:	8d 50 01             	lea    0x1(%eax),%edx
80100100:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100103:	89 50 4c             	mov    %edx,0x4c(%eax)
      release(&bcache.lock);
80100106:	83 ec 0c             	sub    $0xc,%esp
80100109:	68 a0 b5 10 80       	push   $0x8010b5a0
8010010e:	e8 44 4f 00 00       	call   80105057 <release>
80100113:	83 c4 10             	add    $0x10,%esp
      acquiresleep(&b->lock);
80100116:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100119:	83 c0 0c             	add    $0xc,%eax
8010011c:	83 ec 0c             	sub    $0xc,%esp
8010011f:	50                   	push   %eax
80100120:	e8 5b 4d 00 00       	call   80104e80 <acquiresleep>
80100125:	83 c4 10             	add    $0x10,%esp
      return b;
80100128:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010012b:	e9 9d 00 00 00       	jmp    801001cd <bget+0x10c>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
80100130:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100133:	8b 40 54             	mov    0x54(%eax),%eax
80100136:	89 45 f4             	mov    %eax,-0xc(%ebp)
80100139:	81 7d f4 9c fc 10 80 	cmpl   $0x8010fc9c,-0xc(%ebp)
80100140:	75 9f                	jne    801000e1 <bget+0x20>
  }

  // Not cached; recycle an unused buffer.
  // Even if refcnt==0, B_DIRTY indicates a buffer is in use
  // because log.c has modified it but not yet committed it.
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
80100142:	a1 ec fc 10 80       	mov    0x8010fcec,%eax
80100147:	89 45 f4             	mov    %eax,-0xc(%ebp)
8010014a:	eb 6b                	jmp    801001b7 <bget+0xf6>
    if(b->refcnt == 0 && (b->flags & B_DIRTY) == 0) {
8010014c:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010014f:	8b 40 4c             	mov    0x4c(%eax),%eax
80100152:	85 c0                	test   %eax,%eax
80100154:	75 58                	jne    801001ae <bget+0xed>
80100156:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100159:	8b 00                	mov    (%eax),%eax
8010015b:	83 e0 04             	and    $0x4,%eax
8010015e:	85 c0                	test   %eax,%eax
80100160:	75 4c                	jne    801001ae <bget+0xed>
      b->dev = dev;
80100162:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100165:	8b 55 08             	mov    0x8(%ebp),%edx
80100168:	89 50 04             	mov    %edx,0x4(%eax)
      b->blockno = blockno;
8010016b:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010016e:	8b 55 0c             	mov    0xc(%ebp),%edx
80100171:	89 50 08             	mov    %edx,0x8(%eax)
      b->flags = 0;
80100174:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100177:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
      b->refcnt = 1;
8010017d:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100180:	c7 40 4c 01 00 00 00 	movl   $0x1,0x4c(%eax)
      release(&bcache.lock);
80100187:	83 ec 0c             	sub    $0xc,%esp
8010018a:	68 a0 b5 10 80       	push   $0x8010b5a0
8010018f:	e8 c3 4e 00 00       	call   80105057 <release>
80100194:	83 c4 10             	add    $0x10,%esp
      acquiresleep(&b->lock);
80100197:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010019a:	83 c0 0c             	add    $0xc,%eax
8010019d:	83 ec 0c             	sub    $0xc,%esp
801001a0:	50                   	push   %eax
801001a1:	e8 da 4c 00 00       	call   80104e80 <acquiresleep>
801001a6:	83 c4 10             	add    $0x10,%esp
      return b;
801001a9:	8b 45 f4             	mov    -0xc(%ebp),%eax
801001ac:	eb 1f                	jmp    801001cd <bget+0x10c>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
801001ae:	8b 45 f4             	mov    -0xc(%ebp),%eax
801001b1:	8b 40 50             	mov    0x50(%eax),%eax
801001b4:	89 45 f4             	mov    %eax,-0xc(%ebp)
801001b7:	81 7d f4 9c fc 10 80 	cmpl   $0x8010fc9c,-0xc(%ebp)
801001be:	75 8c                	jne    8010014c <bget+0x8b>
    }
  }
  panic("bget: no buffers");
801001c0:	83 ec 0c             	sub    $0xc,%esp
801001c3:	68 72 84 10 80       	push   $0x80108472
801001c8:	e8 e6 03 00 00       	call   801005b3 <panic>
}
801001cd:	c9                   	leave
801001ce:	c3                   	ret

801001cf <bread>:

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
801001cf:	55                   	push   %ebp
801001d0:	89 e5                	mov    %esp,%ebp
801001d2:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  b = bget(dev, blockno);
801001d5:	83 ec 08             	sub    $0x8,%esp
801001d8:	ff 75 0c             	push   0xc(%ebp)
801001db:	ff 75 08             	push   0x8(%ebp)
801001de:	e8 de fe ff ff       	call   801000c1 <bget>
801001e3:	83 c4 10             	add    $0x10,%esp
801001e6:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if((b->flags & B_VALID) == 0) {
801001e9:	8b 45 f4             	mov    -0xc(%ebp),%eax
801001ec:	8b 00                	mov    (%eax),%eax
801001ee:	83 e0 02             	and    $0x2,%eax
801001f1:	85 c0                	test   %eax,%eax
801001f3:	75 0e                	jne    80100203 <bread+0x34>
    iderw(b);
801001f5:	83 ec 0c             	sub    $0xc,%esp
801001f8:	ff 75 f4             	push   -0xc(%ebp)
801001fb:	e8 57 27 00 00       	call   80102957 <iderw>
80100200:	83 c4 10             	add    $0x10,%esp
  }
  return b;
80100203:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
80100206:	c9                   	leave
80100207:	c3                   	ret

80100208 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
80100208:	55                   	push   %ebp
80100209:	89 e5                	mov    %esp,%ebp
8010020b:	83 ec 08             	sub    $0x8,%esp
  if(!holdingsleep(&b->lock))
8010020e:	8b 45 08             	mov    0x8(%ebp),%eax
80100211:	83 c0 0c             	add    $0xc,%eax
80100214:	83 ec 0c             	sub    $0xc,%esp
80100217:	50                   	push   %eax
80100218:	e8 15 4d 00 00       	call   80104f32 <holdingsleep>
8010021d:	83 c4 10             	add    $0x10,%esp
80100220:	85 c0                	test   %eax,%eax
80100222:	75 0d                	jne    80100231 <bwrite+0x29>
    panic("bwrite");
80100224:	83 ec 0c             	sub    $0xc,%esp
80100227:	68 83 84 10 80       	push   $0x80108483
8010022c:	e8 82 03 00 00       	call   801005b3 <panic>
  b->flags |= B_DIRTY;
80100231:	8b 45 08             	mov    0x8(%ebp),%eax
80100234:	8b 00                	mov    (%eax),%eax
80100236:	83 c8 04             	or     $0x4,%eax
80100239:	89 c2                	mov    %eax,%edx
8010023b:	8b 45 08             	mov    0x8(%ebp),%eax
8010023e:	89 10                	mov    %edx,(%eax)
  iderw(b);
80100240:	83 ec 0c             	sub    $0xc,%esp
80100243:	ff 75 08             	push   0x8(%ebp)
80100246:	e8 0c 27 00 00       	call   80102957 <iderw>
8010024b:	83 c4 10             	add    $0x10,%esp
}
8010024e:	90                   	nop
8010024f:	c9                   	leave
80100250:	c3                   	ret

80100251 <brelse>:

// Release a locked buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
80100251:	55                   	push   %ebp
80100252:	89 e5                	mov    %esp,%ebp
80100254:	83 ec 08             	sub    $0x8,%esp
  if(!holdingsleep(&b->lock))
80100257:	8b 45 08             	mov    0x8(%ebp),%eax
8010025a:	83 c0 0c             	add    $0xc,%eax
8010025d:	83 ec 0c             	sub    $0xc,%esp
80100260:	50                   	push   %eax
80100261:	e8 cc 4c 00 00       	call   80104f32 <holdingsleep>
80100266:	83 c4 10             	add    $0x10,%esp
80100269:	85 c0                	test   %eax,%eax
8010026b:	75 0d                	jne    8010027a <brelse+0x29>
    panic("brelse");
8010026d:	83 ec 0c             	sub    $0xc,%esp
80100270:	68 8a 84 10 80       	push   $0x8010848a
80100275:	e8 39 03 00 00       	call   801005b3 <panic>

  releasesleep(&b->lock);
8010027a:	8b 45 08             	mov    0x8(%ebp),%eax
8010027d:	83 c0 0c             	add    $0xc,%eax
80100280:	83 ec 0c             	sub    $0xc,%esp
80100283:	50                   	push   %eax
80100284:	e8 5b 4c 00 00       	call   80104ee4 <releasesleep>
80100289:	83 c4 10             	add    $0x10,%esp

  acquire(&bcache.lock);
8010028c:	83 ec 0c             	sub    $0xc,%esp
8010028f:	68 a0 b5 10 80       	push   $0x8010b5a0
80100294:	e8 50 4d 00 00       	call   80104fe9 <acquire>
80100299:	83 c4 10             	add    $0x10,%esp
  b->refcnt--;
8010029c:	8b 45 08             	mov    0x8(%ebp),%eax
8010029f:	8b 40 4c             	mov    0x4c(%eax),%eax
801002a2:	8d 50 ff             	lea    -0x1(%eax),%edx
801002a5:	8b 45 08             	mov    0x8(%ebp),%eax
801002a8:	89 50 4c             	mov    %edx,0x4c(%eax)
  if (b->refcnt == 0) {
801002ab:	8b 45 08             	mov    0x8(%ebp),%eax
801002ae:	8b 40 4c             	mov    0x4c(%eax),%eax
801002b1:	85 c0                	test   %eax,%eax
801002b3:	75 47                	jne    801002fc <brelse+0xab>
    // no one is waiting for it.
    b->next->prev = b->prev;
801002b5:	8b 45 08             	mov    0x8(%ebp),%eax
801002b8:	8b 40 54             	mov    0x54(%eax),%eax
801002bb:	8b 55 08             	mov    0x8(%ebp),%edx
801002be:	8b 52 50             	mov    0x50(%edx),%edx
801002c1:	89 50 50             	mov    %edx,0x50(%eax)
    b->prev->next = b->next;
801002c4:	8b 45 08             	mov    0x8(%ebp),%eax
801002c7:	8b 40 50             	mov    0x50(%eax),%eax
801002ca:	8b 55 08             	mov    0x8(%ebp),%edx
801002cd:	8b 52 54             	mov    0x54(%edx),%edx
801002d0:	89 50 54             	mov    %edx,0x54(%eax)
    b->next = bcache.head.next;
801002d3:	8b 15 f0 fc 10 80    	mov    0x8010fcf0,%edx
801002d9:	8b 45 08             	mov    0x8(%ebp),%eax
801002dc:	89 50 54             	mov    %edx,0x54(%eax)
    b->prev = &bcache.head;
801002df:	8b 45 08             	mov    0x8(%ebp),%eax
801002e2:	c7 40 50 9c fc 10 80 	movl   $0x8010fc9c,0x50(%eax)
    bcache.head.next->prev = b;
801002e9:	a1 f0 fc 10 80       	mov    0x8010fcf0,%eax
801002ee:	8b 55 08             	mov    0x8(%ebp),%edx
801002f1:	89 50 50             	mov    %edx,0x50(%eax)
    bcache.head.next = b;
801002f4:	8b 45 08             	mov    0x8(%ebp),%eax
801002f7:	a3 f0 fc 10 80       	mov    %eax,0x8010fcf0
  }
  
  release(&bcache.lock);
801002fc:	83 ec 0c             	sub    $0xc,%esp
801002ff:	68 a0 b5 10 80       	push   $0x8010b5a0
80100304:	e8 4e 4d 00 00       	call   80105057 <release>
80100309:	83 c4 10             	add    $0x10,%esp
}
8010030c:	90                   	nop
8010030d:	c9                   	leave
8010030e:	c3                   	ret

8010030f <inb>:
// Routines to let C code use special x86 instructions.

static inline uchar
inb(ushort port)
{
8010030f:	55                   	push   %ebp
80100310:	89 e5                	mov    %esp,%ebp
80100312:	83 ec 14             	sub    $0x14,%esp
80100315:	8b 45 08             	mov    0x8(%ebp),%eax
80100318:	66 89 45 ec          	mov    %ax,-0x14(%ebp)
  uchar data;

  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010031c:	0f b7 45 ec          	movzwl -0x14(%ebp),%eax
80100320:	89 c2                	mov    %eax,%edx
80100322:	ec                   	in     (%dx),%al
80100323:	88 45 ff             	mov    %al,-0x1(%ebp)
  return data;
80100326:	0f b6 45 ff          	movzbl -0x1(%ebp),%eax
}
8010032a:	c9                   	leave
8010032b:	c3                   	ret

8010032c <outb>:
               "memory", "cc");
}

static inline void
outb(ushort port, uchar data)
{
8010032c:	55                   	push   %ebp
8010032d:	89 e5                	mov    %esp,%ebp
8010032f:	83 ec 08             	sub    $0x8,%esp
80100332:	8b 55 08             	mov    0x8(%ebp),%edx
80100335:	8b 45 0c             	mov    0xc(%ebp),%eax
80100338:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
8010033c:	88 45 f8             	mov    %al,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010033f:	0f b6 45 f8          	movzbl -0x8(%ebp),%eax
80100343:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
80100347:	ee                   	out    %al,(%dx)
}
80100348:	90                   	nop
80100349:	c9                   	leave
8010034a:	c3                   	ret

8010034b <cli>:
  asm volatile("movw %0, %%gs" : : "r" (v));
}

static inline void
cli(void)
{
8010034b:	55                   	push   %ebp
8010034c:	89 e5                	mov    %esp,%ebp
  asm volatile("cli");
8010034e:	fa                   	cli
}
8010034f:	90                   	nop
80100350:	5d                   	pop    %ebp
80100351:	c3                   	ret

80100352 <printint>:
  int locking;
} cons;

static void
printint(int xx, int base, int sign)
{
80100352:	55                   	push   %ebp
80100353:	89 e5                	mov    %esp,%ebp
80100355:	83 ec 28             	sub    $0x28,%esp
  static char digits[] = "0123456789abcdef";
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))
80100358:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
8010035c:	74 1c                	je     8010037a <printint+0x28>
8010035e:	8b 45 08             	mov    0x8(%ebp),%eax
80100361:	c1 e8 1f             	shr    $0x1f,%eax
80100364:	0f b6 c0             	movzbl %al,%eax
80100367:	89 45 10             	mov    %eax,0x10(%ebp)
8010036a:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
8010036e:	74 0a                	je     8010037a <printint+0x28>
    x = -xx;
80100370:	8b 45 08             	mov    0x8(%ebp),%eax
80100373:	f7 d8                	neg    %eax
80100375:	89 45 f0             	mov    %eax,-0x10(%ebp)
80100378:	eb 06                	jmp    80100380 <printint+0x2e>
  else
    x = xx;
8010037a:	8b 45 08             	mov    0x8(%ebp),%eax
8010037d:	89 45 f0             	mov    %eax,-0x10(%ebp)

  i = 0;
80100380:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  do{
    buf[i++] = digits[x % base];
80100387:	8b 4d 0c             	mov    0xc(%ebp),%ecx
8010038a:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010038d:	ba 00 00 00 00       	mov    $0x0,%edx
80100392:	f7 f1                	div    %ecx
80100394:	89 d1                	mov    %edx,%ecx
80100396:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100399:	8d 50 01             	lea    0x1(%eax),%edx
8010039c:	89 55 f4             	mov    %edx,-0xc(%ebp)
8010039f:	0f b6 91 04 90 10 80 	movzbl -0x7fef6ffc(%ecx),%edx
801003a6:	88 54 05 e0          	mov    %dl,-0x20(%ebp,%eax,1)
  }while((x /= base) != 0);
801003aa:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801003ad:	8b 45 f0             	mov    -0x10(%ebp),%eax
801003b0:	ba 00 00 00 00       	mov    $0x0,%edx
801003b5:	f7 f1                	div    %ecx
801003b7:	89 45 f0             	mov    %eax,-0x10(%ebp)
801003ba:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
801003be:	75 c7                	jne    80100387 <printint+0x35>

  if(sign)
801003c0:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
801003c4:	74 2a                	je     801003f0 <printint+0x9e>
    buf[i++] = '-';
801003c6:	8b 45 f4             	mov    -0xc(%ebp),%eax
801003c9:	8d 50 01             	lea    0x1(%eax),%edx
801003cc:	89 55 f4             	mov    %edx,-0xc(%ebp)
801003cf:	c6 44 05 e0 2d       	movb   $0x2d,-0x20(%ebp,%eax,1)

  while(--i >= 0)
801003d4:	eb 1a                	jmp    801003f0 <printint+0x9e>
    consputc(buf[i]);
801003d6:	8d 55 e0             	lea    -0x20(%ebp),%edx
801003d9:	8b 45 f4             	mov    -0xc(%ebp),%eax
801003dc:	01 d0                	add    %edx,%eax
801003de:	0f b6 00             	movzbl (%eax),%eax
801003e1:	0f be c0             	movsbl %al,%eax
801003e4:	83 ec 0c             	sub    $0xc,%esp
801003e7:	50                   	push   %eax
801003e8:	e8 f4 03 00 00       	call   801007e1 <consputc>
801003ed:	83 c4 10             	add    $0x10,%esp
  while(--i >= 0)
801003f0:	83 6d f4 01          	subl   $0x1,-0xc(%ebp)
801003f4:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
801003f8:	79 dc                	jns    801003d6 <printint+0x84>
}
801003fa:	90                   	nop
801003fb:	90                   	nop
801003fc:	c9                   	leave
801003fd:	c3                   	ret

801003fe <cprintf>:
//PAGEBREAK: 50

// Print to the console. only understands %d, %x, %p, %s.
void
cprintf(char *fmt, ...)
{
801003fe:	55                   	push   %ebp
801003ff:	89 e5                	mov    %esp,%ebp
80100401:	83 ec 28             	sub    $0x28,%esp
  int i, c, locking;
  uint *argp;
  char *s;

  locking = cons.locking;
80100404:	a1 d4 ff 10 80       	mov    0x8010ffd4,%eax
80100409:	89 45 e8             	mov    %eax,-0x18(%ebp)
  if(locking)
8010040c:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
80100410:	74 10                	je     80100422 <cprintf+0x24>
    acquire(&cons.lock);
80100412:	83 ec 0c             	sub    $0xc,%esp
80100415:	68 a0 ff 10 80       	push   $0x8010ffa0
8010041a:	e8 ca 4b 00 00       	call   80104fe9 <acquire>
8010041f:	83 c4 10             	add    $0x10,%esp

  if (fmt == 0)
80100422:	8b 45 08             	mov    0x8(%ebp),%eax
80100425:	85 c0                	test   %eax,%eax
80100427:	75 0d                	jne    80100436 <cprintf+0x38>
    panic("null fmt");
80100429:	83 ec 0c             	sub    $0xc,%esp
8010042c:	68 91 84 10 80       	push   $0x80108491
80100431:	e8 7d 01 00 00       	call   801005b3 <panic>

  argp = (uint*)(void*)(&fmt + 1);
80100436:	8d 45 0c             	lea    0xc(%ebp),%eax
80100439:	89 45 f0             	mov    %eax,-0x10(%ebp)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
8010043c:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80100443:	e9 2f 01 00 00       	jmp    80100577 <cprintf+0x179>
    if(c != '%'){
80100448:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
8010044c:	74 13                	je     80100461 <cprintf+0x63>
      consputc(c);
8010044e:	83 ec 0c             	sub    $0xc,%esp
80100451:	ff 75 e4             	push   -0x1c(%ebp)
80100454:	e8 88 03 00 00       	call   801007e1 <consputc>
80100459:	83 c4 10             	add    $0x10,%esp
      continue;
8010045c:	e9 12 01 00 00       	jmp    80100573 <cprintf+0x175>
    }
    c = fmt[++i] & 0xff;
80100461:	8b 55 08             	mov    0x8(%ebp),%edx
80100464:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80100468:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010046b:	01 d0                	add    %edx,%eax
8010046d:	0f b6 00             	movzbl (%eax),%eax
80100470:	0f be c0             	movsbl %al,%eax
80100473:	25 ff 00 00 00       	and    $0xff,%eax
80100478:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(c == 0)
8010047b:	83 7d e4 00          	cmpl   $0x0,-0x1c(%ebp)
8010047f:	0f 84 14 01 00 00    	je     80100599 <cprintf+0x19b>
      break;
    switch(c){
80100485:	83 7d e4 78          	cmpl   $0x78,-0x1c(%ebp)
80100489:	74 5e                	je     801004e9 <cprintf+0xeb>
8010048b:	83 7d e4 78          	cmpl   $0x78,-0x1c(%ebp)
8010048f:	0f 8f c2 00 00 00    	jg     80100557 <cprintf+0x159>
80100495:	83 7d e4 73          	cmpl   $0x73,-0x1c(%ebp)
80100499:	74 6b                	je     80100506 <cprintf+0x108>
8010049b:	83 7d e4 73          	cmpl   $0x73,-0x1c(%ebp)
8010049f:	0f 8f b2 00 00 00    	jg     80100557 <cprintf+0x159>
801004a5:	83 7d e4 70          	cmpl   $0x70,-0x1c(%ebp)
801004a9:	74 3e                	je     801004e9 <cprintf+0xeb>
801004ab:	83 7d e4 70          	cmpl   $0x70,-0x1c(%ebp)
801004af:	0f 8f a2 00 00 00    	jg     80100557 <cprintf+0x159>
801004b5:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
801004b9:	0f 84 89 00 00 00    	je     80100548 <cprintf+0x14a>
801004bf:	83 7d e4 64          	cmpl   $0x64,-0x1c(%ebp)
801004c3:	0f 85 8e 00 00 00    	jne    80100557 <cprintf+0x159>
    case 'd':
      printint(*argp++, 10, 1);
801004c9:	8b 45 f0             	mov    -0x10(%ebp),%eax
801004cc:	8d 50 04             	lea    0x4(%eax),%edx
801004cf:	89 55 f0             	mov    %edx,-0x10(%ebp)
801004d2:	8b 00                	mov    (%eax),%eax
801004d4:	83 ec 04             	sub    $0x4,%esp
801004d7:	6a 01                	push   $0x1
801004d9:	6a 0a                	push   $0xa
801004db:	50                   	push   %eax
801004dc:	e8 71 fe ff ff       	call   80100352 <printint>
801004e1:	83 c4 10             	add    $0x10,%esp
      break;
801004e4:	e9 8a 00 00 00       	jmp    80100573 <cprintf+0x175>
    case 'x':
    case 'p':
      printint(*argp++, 16, 0);
801004e9:	8b 45 f0             	mov    -0x10(%ebp),%eax
801004ec:	8d 50 04             	lea    0x4(%eax),%edx
801004ef:	89 55 f0             	mov    %edx,-0x10(%ebp)
801004f2:	8b 00                	mov    (%eax),%eax
801004f4:	83 ec 04             	sub    $0x4,%esp
801004f7:	6a 00                	push   $0x0
801004f9:	6a 10                	push   $0x10
801004fb:	50                   	push   %eax
801004fc:	e8 51 fe ff ff       	call   80100352 <printint>
80100501:	83 c4 10             	add    $0x10,%esp
      break;
80100504:	eb 6d                	jmp    80100573 <cprintf+0x175>
    case 's':
      if((s = (char*)*argp++) == 0)
80100506:	8b 45 f0             	mov    -0x10(%ebp),%eax
80100509:	8d 50 04             	lea    0x4(%eax),%edx
8010050c:	89 55 f0             	mov    %edx,-0x10(%ebp)
8010050f:	8b 00                	mov    (%eax),%eax
80100511:	89 45 ec             	mov    %eax,-0x14(%ebp)
80100514:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
80100518:	75 22                	jne    8010053c <cprintf+0x13e>
        s = "(null)";
8010051a:	c7 45 ec 9a 84 10 80 	movl   $0x8010849a,-0x14(%ebp)
      for(; *s; s++)
80100521:	eb 19                	jmp    8010053c <cprintf+0x13e>
        consputc(*s);
80100523:	8b 45 ec             	mov    -0x14(%ebp),%eax
80100526:	0f b6 00             	movzbl (%eax),%eax
80100529:	0f be c0             	movsbl %al,%eax
8010052c:	83 ec 0c             	sub    $0xc,%esp
8010052f:	50                   	push   %eax
80100530:	e8 ac 02 00 00       	call   801007e1 <consputc>
80100535:	83 c4 10             	add    $0x10,%esp
      for(; *s; s++)
80100538:	83 45 ec 01          	addl   $0x1,-0x14(%ebp)
8010053c:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010053f:	0f b6 00             	movzbl (%eax),%eax
80100542:	84 c0                	test   %al,%al
80100544:	75 dd                	jne    80100523 <cprintf+0x125>
      break;
80100546:	eb 2b                	jmp    80100573 <cprintf+0x175>
    case '%':
      consputc('%');
80100548:	83 ec 0c             	sub    $0xc,%esp
8010054b:	6a 25                	push   $0x25
8010054d:	e8 8f 02 00 00       	call   801007e1 <consputc>
80100552:	83 c4 10             	add    $0x10,%esp
      break;
80100555:	eb 1c                	jmp    80100573 <cprintf+0x175>
    default:
      // Print unknown % sequence to draw attention.
      consputc('%');
80100557:	83 ec 0c             	sub    $0xc,%esp
8010055a:	6a 25                	push   $0x25
8010055c:	e8 80 02 00 00       	call   801007e1 <consputc>
80100561:	83 c4 10             	add    $0x10,%esp
      consputc(c);
80100564:	83 ec 0c             	sub    $0xc,%esp
80100567:	ff 75 e4             	push   -0x1c(%ebp)
8010056a:	e8 72 02 00 00       	call   801007e1 <consputc>
8010056f:	83 c4 10             	add    $0x10,%esp
      break;
80100572:	90                   	nop
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100573:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80100577:	8b 55 08             	mov    0x8(%ebp),%edx
8010057a:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010057d:	01 d0                	add    %edx,%eax
8010057f:	0f b6 00             	movzbl (%eax),%eax
80100582:	0f be c0             	movsbl %al,%eax
80100585:	25 ff 00 00 00       	and    $0xff,%eax
8010058a:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010058d:	83 7d e4 00          	cmpl   $0x0,-0x1c(%ebp)
80100591:	0f 85 b1 fe ff ff    	jne    80100448 <cprintf+0x4a>
80100597:	eb 01                	jmp    8010059a <cprintf+0x19c>
      break;
80100599:	90                   	nop
    }
  }

  if(locking)
8010059a:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
8010059e:	74 10                	je     801005b0 <cprintf+0x1b2>
    release(&cons.lock);
801005a0:	83 ec 0c             	sub    $0xc,%esp
801005a3:	68 a0 ff 10 80       	push   $0x8010ffa0
801005a8:	e8 aa 4a 00 00       	call   80105057 <release>
801005ad:	83 c4 10             	add    $0x10,%esp
}
801005b0:	90                   	nop
801005b1:	c9                   	leave
801005b2:	c3                   	ret

801005b3 <panic>:

void
panic(char *s)
{
801005b3:	55                   	push   %ebp
801005b4:	89 e5                	mov    %esp,%ebp
801005b6:	83 ec 38             	sub    $0x38,%esp
  int i;
  uint pcs[10];

  cli();
801005b9:	e8 8d fd ff ff       	call   8010034b <cli>
  cons.locking = 0;
801005be:	c7 05 d4 ff 10 80 00 	movl   $0x0,0x8010ffd4
801005c5:	00 00 00 
  // use lapiccpunum so that we can call panic from mycpu()
  cprintf("lapicid %d: panic: ", lapicid());
801005c8:	e8 0f 2a 00 00       	call   80102fdc <lapicid>
801005cd:	83 ec 08             	sub    $0x8,%esp
801005d0:	50                   	push   %eax
801005d1:	68 a1 84 10 80       	push   $0x801084a1
801005d6:	e8 23 fe ff ff       	call   801003fe <cprintf>
801005db:	83 c4 10             	add    $0x10,%esp
  cprintf(s);
801005de:	8b 45 08             	mov    0x8(%ebp),%eax
801005e1:	83 ec 0c             	sub    $0xc,%esp
801005e4:	50                   	push   %eax
801005e5:	e8 14 fe ff ff       	call   801003fe <cprintf>
801005ea:	83 c4 10             	add    $0x10,%esp
  cprintf("\n");
801005ed:	83 ec 0c             	sub    $0xc,%esp
801005f0:	68 b5 84 10 80       	push   $0x801084b5
801005f5:	e8 04 fe ff ff       	call   801003fe <cprintf>
801005fa:	83 c4 10             	add    $0x10,%esp
  getcallerpcs(&s, pcs);
801005fd:	83 ec 08             	sub    $0x8,%esp
80100600:	8d 45 cc             	lea    -0x34(%ebp),%eax
80100603:	50                   	push   %eax
80100604:	8d 45 08             	lea    0x8(%ebp),%eax
80100607:	50                   	push   %eax
80100608:	e8 9c 4a 00 00       	call   801050a9 <getcallerpcs>
8010060d:	83 c4 10             	add    $0x10,%esp
  for(i=0; i<10; i++)
80100610:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80100617:	eb 1c                	jmp    80100635 <panic+0x82>
    cprintf(" %p", pcs[i]);
80100619:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010061c:	8b 44 85 cc          	mov    -0x34(%ebp,%eax,4),%eax
80100620:	83 ec 08             	sub    $0x8,%esp
80100623:	50                   	push   %eax
80100624:	68 b7 84 10 80       	push   $0x801084b7
80100629:	e8 d0 fd ff ff       	call   801003fe <cprintf>
8010062e:	83 c4 10             	add    $0x10,%esp
  for(i=0; i<10; i++)
80100631:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80100635:	83 7d f4 09          	cmpl   $0x9,-0xc(%ebp)
80100639:	7e de                	jle    80100619 <panic+0x66>
  panicked = 1; // freeze other CPU
8010063b:	c7 05 8c ff 10 80 01 	movl   $0x1,0x8010ff8c
80100642:	00 00 00 
  for(;;)
80100645:	90                   	nop
80100646:	eb fd                	jmp    80100645 <panic+0x92>

80100648 <cgaputc>:
#define CRTPORT 0x3d4
static ushort *crt = (ushort*)P2V(0xb8000);  // CGA memory

static void
cgaputc(int c)
{
80100648:	55                   	push   %ebp
80100649:	89 e5                	mov    %esp,%ebp
8010064b:	53                   	push   %ebx
8010064c:	83 ec 14             	sub    $0x14,%esp
  int pos;

  // Cursor position: col + 80*row.
  outb(CRTPORT, 14);
8010064f:	6a 0e                	push   $0xe
80100651:	68 d4 03 00 00       	push   $0x3d4
80100656:	e8 d1 fc ff ff       	call   8010032c <outb>
8010065b:	83 c4 08             	add    $0x8,%esp
  pos = inb(CRTPORT+1) << 8;
8010065e:	68 d5 03 00 00       	push   $0x3d5
80100663:	e8 a7 fc ff ff       	call   8010030f <inb>
80100668:	83 c4 04             	add    $0x4,%esp
8010066b:	0f b6 c0             	movzbl %al,%eax
8010066e:	c1 e0 08             	shl    $0x8,%eax
80100671:	89 45 f4             	mov    %eax,-0xc(%ebp)
  outb(CRTPORT, 15);
80100674:	6a 0f                	push   $0xf
80100676:	68 d4 03 00 00       	push   $0x3d4
8010067b:	e8 ac fc ff ff       	call   8010032c <outb>
80100680:	83 c4 08             	add    $0x8,%esp
  pos |= inb(CRTPORT+1);
80100683:	68 d5 03 00 00       	push   $0x3d5
80100688:	e8 82 fc ff ff       	call   8010030f <inb>
8010068d:	83 c4 04             	add    $0x4,%esp
80100690:	0f b6 c0             	movzbl %al,%eax
80100693:	09 45 f4             	or     %eax,-0xc(%ebp)

  if(c == '\n')
80100696:	83 7d 08 0a          	cmpl   $0xa,0x8(%ebp)
8010069a:	75 30                	jne    801006cc <cgaputc+0x84>
    pos += 80 - pos%80;
8010069c:	8b 4d f4             	mov    -0xc(%ebp),%ecx
8010069f:	ba 67 66 66 66       	mov    $0x66666667,%edx
801006a4:	89 c8                	mov    %ecx,%eax
801006a6:	f7 ea                	imul   %edx
801006a8:	c1 fa 05             	sar    $0x5,%edx
801006ab:	89 c8                	mov    %ecx,%eax
801006ad:	c1 f8 1f             	sar    $0x1f,%eax
801006b0:	29 c2                	sub    %eax,%edx
801006b2:	89 d0                	mov    %edx,%eax
801006b4:	c1 e0 02             	shl    $0x2,%eax
801006b7:	01 d0                	add    %edx,%eax
801006b9:	c1 e0 04             	shl    $0x4,%eax
801006bc:	29 c1                	sub    %eax,%ecx
801006be:	89 ca                	mov    %ecx,%edx
801006c0:	b8 50 00 00 00       	mov    $0x50,%eax
801006c5:	29 d0                	sub    %edx,%eax
801006c7:	01 45 f4             	add    %eax,-0xc(%ebp)
801006ca:	eb 38                	jmp    80100704 <cgaputc+0xbc>
  else if(c == BACKSPACE){
801006cc:	81 7d 08 00 01 00 00 	cmpl   $0x100,0x8(%ebp)
801006d3:	75 0c                	jne    801006e1 <cgaputc+0x99>
    if(pos > 0) --pos;
801006d5:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
801006d9:	7e 29                	jle    80100704 <cgaputc+0xbc>
801006db:	83 6d f4 01          	subl   $0x1,-0xc(%ebp)
801006df:	eb 23                	jmp    80100704 <cgaputc+0xbc>
  } else
    crt[pos++] = (c&0xff) | 0x0700;  // black on white
801006e1:	8b 45 08             	mov    0x8(%ebp),%eax
801006e4:	0f b6 c0             	movzbl %al,%eax
801006e7:	80 cc 07             	or     $0x7,%ah
801006ea:	89 c3                	mov    %eax,%ebx
801006ec:	8b 0d 00 90 10 80    	mov    0x80109000,%ecx
801006f2:	8b 45 f4             	mov    -0xc(%ebp),%eax
801006f5:	8d 50 01             	lea    0x1(%eax),%edx
801006f8:	89 55 f4             	mov    %edx,-0xc(%ebp)
801006fb:	01 c0                	add    %eax,%eax
801006fd:	01 c8                	add    %ecx,%eax
801006ff:	89 da                	mov    %ebx,%edx
80100701:	66 89 10             	mov    %dx,(%eax)

  if(pos < 0 || pos > 25*80)
80100704:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80100708:	78 09                	js     80100713 <cgaputc+0xcb>
8010070a:	81 7d f4 d0 07 00 00 	cmpl   $0x7d0,-0xc(%ebp)
80100711:	7e 0d                	jle    80100720 <cgaputc+0xd8>
    panic("pos under/overflow");
80100713:	83 ec 0c             	sub    $0xc,%esp
80100716:	68 bb 84 10 80       	push   $0x801084bb
8010071b:	e8 93 fe ff ff       	call   801005b3 <panic>

  if((pos/80) >= 24){  // Scroll up.
80100720:	81 7d f4 7f 07 00 00 	cmpl   $0x77f,-0xc(%ebp)
80100727:	7e 4c                	jle    80100775 <cgaputc+0x12d>
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
80100729:	a1 00 90 10 80       	mov    0x80109000,%eax
8010072e:	8d 90 a0 00 00 00    	lea    0xa0(%eax),%edx
80100734:	a1 00 90 10 80       	mov    0x80109000,%eax
80100739:	83 ec 04             	sub    $0x4,%esp
8010073c:	68 60 0e 00 00       	push   $0xe60
80100741:	52                   	push   %edx
80100742:	50                   	push   %eax
80100743:	e8 e6 4b 00 00       	call   8010532e <memmove>
80100748:	83 c4 10             	add    $0x10,%esp
    pos -= 80;
8010074b:	83 6d f4 50          	subl   $0x50,-0xc(%ebp)
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
8010074f:	b8 80 07 00 00       	mov    $0x780,%eax
80100754:	2b 45 f4             	sub    -0xc(%ebp),%eax
80100757:	8d 14 00             	lea    (%eax,%eax,1),%edx
8010075a:	a1 00 90 10 80       	mov    0x80109000,%eax
8010075f:	8b 4d f4             	mov    -0xc(%ebp),%ecx
80100762:	01 c9                	add    %ecx,%ecx
80100764:	01 c8                	add    %ecx,%eax
80100766:	83 ec 04             	sub    $0x4,%esp
80100769:	52                   	push   %edx
8010076a:	6a 00                	push   $0x0
8010076c:	50                   	push   %eax
8010076d:	e8 fd 4a 00 00       	call   8010526f <memset>
80100772:	83 c4 10             	add    $0x10,%esp
  }

  outb(CRTPORT, 14);
80100775:	83 ec 08             	sub    $0x8,%esp
80100778:	6a 0e                	push   $0xe
8010077a:	68 d4 03 00 00       	push   $0x3d4
8010077f:	e8 a8 fb ff ff       	call   8010032c <outb>
80100784:	83 c4 10             	add    $0x10,%esp
  outb(CRTPORT+1, pos>>8);
80100787:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010078a:	c1 f8 08             	sar    $0x8,%eax
8010078d:	0f b6 c0             	movzbl %al,%eax
80100790:	83 ec 08             	sub    $0x8,%esp
80100793:	50                   	push   %eax
80100794:	68 d5 03 00 00       	push   $0x3d5
80100799:	e8 8e fb ff ff       	call   8010032c <outb>
8010079e:	83 c4 10             	add    $0x10,%esp
  outb(CRTPORT, 15);
801007a1:	83 ec 08             	sub    $0x8,%esp
801007a4:	6a 0f                	push   $0xf
801007a6:	68 d4 03 00 00       	push   $0x3d4
801007ab:	e8 7c fb ff ff       	call   8010032c <outb>
801007b0:	83 c4 10             	add    $0x10,%esp
  outb(CRTPORT+1, pos);
801007b3:	8b 45 f4             	mov    -0xc(%ebp),%eax
801007b6:	0f b6 c0             	movzbl %al,%eax
801007b9:	83 ec 08             	sub    $0x8,%esp
801007bc:	50                   	push   %eax
801007bd:	68 d5 03 00 00       	push   $0x3d5
801007c2:	e8 65 fb ff ff       	call   8010032c <outb>
801007c7:	83 c4 10             	add    $0x10,%esp
  crt[pos] = ' ' | 0x0700;
801007ca:	a1 00 90 10 80       	mov    0x80109000,%eax
801007cf:	8b 55 f4             	mov    -0xc(%ebp),%edx
801007d2:	01 d2                	add    %edx,%edx
801007d4:	01 d0                	add    %edx,%eax
801007d6:	66 c7 00 20 07       	movw   $0x720,(%eax)
}
801007db:	90                   	nop
801007dc:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801007df:	c9                   	leave
801007e0:	c3                   	ret

801007e1 <consputc>:

void
consputc(int c)
{
801007e1:	55                   	push   %ebp
801007e2:	89 e5                	mov    %esp,%ebp
801007e4:	83 ec 08             	sub    $0x8,%esp
  if(panicked){
801007e7:	a1 8c ff 10 80       	mov    0x8010ff8c,%eax
801007ec:	85 c0                	test   %eax,%eax
801007ee:	74 08                	je     801007f8 <consputc+0x17>
    cli();
801007f0:	e8 56 fb ff ff       	call   8010034b <cli>
    for(;;)
801007f5:	90                   	nop
801007f6:	eb fd                	jmp    801007f5 <consputc+0x14>
      ;
  }

  if(c == BACKSPACE){
801007f8:	81 7d 08 00 01 00 00 	cmpl   $0x100,0x8(%ebp)
801007ff:	75 29                	jne    8010082a <consputc+0x49>
    uartputc('\b'); uartputc(' '); uartputc('\b');
80100801:	83 ec 0c             	sub    $0xc,%esp
80100804:	6a 08                	push   $0x8
80100806:	e8 0a 64 00 00       	call   80106c15 <uartputc>
8010080b:	83 c4 10             	add    $0x10,%esp
8010080e:	83 ec 0c             	sub    $0xc,%esp
80100811:	6a 20                	push   $0x20
80100813:	e8 fd 63 00 00       	call   80106c15 <uartputc>
80100818:	83 c4 10             	add    $0x10,%esp
8010081b:	83 ec 0c             	sub    $0xc,%esp
8010081e:	6a 08                	push   $0x8
80100820:	e8 f0 63 00 00       	call   80106c15 <uartputc>
80100825:	83 c4 10             	add    $0x10,%esp
80100828:	eb 0e                	jmp    80100838 <consputc+0x57>
  } else
    uartputc(c);
8010082a:	83 ec 0c             	sub    $0xc,%esp
8010082d:	ff 75 08             	push   0x8(%ebp)
80100830:	e8 e0 63 00 00       	call   80106c15 <uartputc>
80100835:	83 c4 10             	add    $0x10,%esp
  cgaputc(c);
80100838:	83 ec 0c             	sub    $0xc,%esp
8010083b:	ff 75 08             	push   0x8(%ebp)
8010083e:	e8 05 fe ff ff       	call   80100648 <cgaputc>
80100843:	83 c4 10             	add    $0x10,%esp
}
80100846:	90                   	nop
80100847:	c9                   	leave
80100848:	c3                   	ret

80100849 <consoleintr>:

#define C(x)  ((x)-'@')  // Control-x

void
consoleintr(int (*getc)(void))
{
80100849:	55                   	push   %ebp
8010084a:	89 e5                	mov    %esp,%ebp
8010084c:	83 ec 18             	sub    $0x18,%esp
  int c, doprocdump = 0;
8010084f:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)

  acquire(&cons.lock);
80100856:	83 ec 0c             	sub    $0xc,%esp
80100859:	68 a0 ff 10 80       	push   $0x8010ffa0
8010085e:	e8 86 47 00 00       	call   80104fe9 <acquire>
80100863:	83 c4 10             	add    $0x10,%esp
  while((c = getc()) >= 0){
80100866:	e9 52 01 00 00       	jmp    801009bd <consoleintr+0x174>
    switch(c){
8010086b:	83 7d f4 7f          	cmpl   $0x7f,-0xc(%ebp)
8010086f:	0f 84 81 00 00 00    	je     801008f6 <consoleintr+0xad>
80100875:	83 7d f4 7f          	cmpl   $0x7f,-0xc(%ebp)
80100879:	0f 8f ac 00 00 00    	jg     8010092b <consoleintr+0xe2>
8010087f:	83 7d f4 15          	cmpl   $0x15,-0xc(%ebp)
80100883:	74 43                	je     801008c8 <consoleintr+0x7f>
80100885:	83 7d f4 15          	cmpl   $0x15,-0xc(%ebp)
80100889:	0f 8f 9c 00 00 00    	jg     8010092b <consoleintr+0xe2>
8010088f:	83 7d f4 08          	cmpl   $0x8,-0xc(%ebp)
80100893:	74 61                	je     801008f6 <consoleintr+0xad>
80100895:	83 7d f4 10          	cmpl   $0x10,-0xc(%ebp)
80100899:	0f 85 8c 00 00 00    	jne    8010092b <consoleintr+0xe2>
    case C('P'):  // Process listing.
      // procdump() locks cons.lock indirectly; invoke later
      doprocdump = 1;
8010089f:	c7 45 f0 01 00 00 00 	movl   $0x1,-0x10(%ebp)
      break;
801008a6:	e9 12 01 00 00       	jmp    801009bd <consoleintr+0x174>
    case C('U'):  // Kill line.
      while(input.e != input.w &&
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
        input.e--;
801008ab:	a1 88 ff 10 80       	mov    0x8010ff88,%eax
801008b0:	83 e8 01             	sub    $0x1,%eax
801008b3:	a3 88 ff 10 80       	mov    %eax,0x8010ff88
        consputc(BACKSPACE);
801008b8:	83 ec 0c             	sub    $0xc,%esp
801008bb:	68 00 01 00 00       	push   $0x100
801008c0:	e8 1c ff ff ff       	call   801007e1 <consputc>
801008c5:	83 c4 10             	add    $0x10,%esp
      while(input.e != input.w &&
801008c8:	8b 15 88 ff 10 80    	mov    0x8010ff88,%edx
801008ce:	a1 84 ff 10 80       	mov    0x8010ff84,%eax
801008d3:	39 c2                	cmp    %eax,%edx
801008d5:	0f 84 db 00 00 00    	je     801009b6 <consoleintr+0x16d>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
801008db:	a1 88 ff 10 80       	mov    0x8010ff88,%eax
801008e0:	83 e8 01             	sub    $0x1,%eax
801008e3:	83 e0 7f             	and    $0x7f,%eax
801008e6:	0f b6 80 00 ff 10 80 	movzbl -0x7fef0100(%eax),%eax
      while(input.e != input.w &&
801008ed:	3c 0a                	cmp    $0xa,%al
801008ef:	75 ba                	jne    801008ab <consoleintr+0x62>
      }
      break;
801008f1:	e9 c0 00 00 00       	jmp    801009b6 <consoleintr+0x16d>
    case C('H'): case '\x7f':  // Backspace
      if(input.e != input.w){
801008f6:	8b 15 88 ff 10 80    	mov    0x8010ff88,%edx
801008fc:	a1 84 ff 10 80       	mov    0x8010ff84,%eax
80100901:	39 c2                	cmp    %eax,%edx
80100903:	0f 84 b0 00 00 00    	je     801009b9 <consoleintr+0x170>
        input.e--;
80100909:	a1 88 ff 10 80       	mov    0x8010ff88,%eax
8010090e:	83 e8 01             	sub    $0x1,%eax
80100911:	a3 88 ff 10 80       	mov    %eax,0x8010ff88
        consputc(BACKSPACE);
80100916:	83 ec 0c             	sub    $0xc,%esp
80100919:	68 00 01 00 00       	push   $0x100
8010091e:	e8 be fe ff ff       	call   801007e1 <consputc>
80100923:	83 c4 10             	add    $0x10,%esp
      }
      break;
80100926:	e9 8e 00 00 00       	jmp    801009b9 <consoleintr+0x170>
    default:
      if(c != 0 && input.e-input.r < INPUT_BUF){
8010092b:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
8010092f:	0f 84 87 00 00 00    	je     801009bc <consoleintr+0x173>
80100935:	8b 15 88 ff 10 80    	mov    0x8010ff88,%edx
8010093b:	a1 80 ff 10 80       	mov    0x8010ff80,%eax
80100940:	29 c2                	sub    %eax,%edx
80100942:	83 fa 7f             	cmp    $0x7f,%edx
80100945:	77 75                	ja     801009bc <consoleintr+0x173>
        c = (c == '\r') ? '\n' : c;
80100947:	83 7d f4 0d          	cmpl   $0xd,-0xc(%ebp)
8010094b:	75 07                	jne    80100954 <consoleintr+0x10b>
8010094d:	c7 45 f4 0a 00 00 00 	movl   $0xa,-0xc(%ebp)
        input.buf[input.e++ % INPUT_BUF] = c;
80100954:	a1 88 ff 10 80       	mov    0x8010ff88,%eax
80100959:	8d 50 01             	lea    0x1(%eax),%edx
8010095c:	89 15 88 ff 10 80    	mov    %edx,0x8010ff88
80100962:	83 e0 7f             	and    $0x7f,%eax
80100965:	8b 55 f4             	mov    -0xc(%ebp),%edx
80100968:	88 90 00 ff 10 80    	mov    %dl,-0x7fef0100(%eax)
        consputc(c);
8010096e:	83 ec 0c             	sub    $0xc,%esp
80100971:	ff 75 f4             	push   -0xc(%ebp)
80100974:	e8 68 fe ff ff       	call   801007e1 <consputc>
80100979:	83 c4 10             	add    $0x10,%esp
        if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
8010097c:	83 7d f4 0a          	cmpl   $0xa,-0xc(%ebp)
80100980:	74 18                	je     8010099a <consoleintr+0x151>
80100982:	83 7d f4 04          	cmpl   $0x4,-0xc(%ebp)
80100986:	74 12                	je     8010099a <consoleintr+0x151>
80100988:	8b 15 88 ff 10 80    	mov    0x8010ff88,%edx
8010098e:	a1 80 ff 10 80       	mov    0x8010ff80,%eax
80100993:	83 e8 80             	sub    $0xffffff80,%eax
80100996:	39 c2                	cmp    %eax,%edx
80100998:	75 22                	jne    801009bc <consoleintr+0x173>
          input.w = input.e;
8010099a:	a1 88 ff 10 80       	mov    0x8010ff88,%eax
8010099f:	a3 84 ff 10 80       	mov    %eax,0x8010ff84
          wakeup(&input.r);
801009a4:	83 ec 0c             	sub    $0xc,%esp
801009a7:	68 80 ff 10 80       	push   $0x8010ff80
801009ac:	e8 de 42 00 00       	call   80104c8f <wakeup>
801009b1:	83 c4 10             	add    $0x10,%esp
        }
      }
      break;
801009b4:	eb 06                	jmp    801009bc <consoleintr+0x173>
      break;
801009b6:	90                   	nop
801009b7:	eb 04                	jmp    801009bd <consoleintr+0x174>
      break;
801009b9:	90                   	nop
801009ba:	eb 01                	jmp    801009bd <consoleintr+0x174>
      break;
801009bc:	90                   	nop
  while((c = getc()) >= 0){
801009bd:	8b 45 08             	mov    0x8(%ebp),%eax
801009c0:	ff d0                	call   *%eax
801009c2:	89 45 f4             	mov    %eax,-0xc(%ebp)
801009c5:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
801009c9:	0f 89 9c fe ff ff    	jns    8010086b <consoleintr+0x22>
    }
  }
  release(&cons.lock);
801009cf:	83 ec 0c             	sub    $0xc,%esp
801009d2:	68 a0 ff 10 80       	push   $0x8010ffa0
801009d7:	e8 7b 46 00 00       	call   80105057 <release>
801009dc:	83 c4 10             	add    $0x10,%esp
  if(doprocdump) {
801009df:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
801009e3:	74 05                	je     801009ea <consoleintr+0x1a1>
    procdump();  // now call procdump() wo. cons.lock held
801009e5:	e8 60 43 00 00       	call   80104d4a <procdump>
  }
}
801009ea:	90                   	nop
801009eb:	c9                   	leave
801009ec:	c3                   	ret

801009ed <consoleread>:

int
consoleread(struct inode *ip, char *dst, int n)
{
801009ed:	55                   	push   %ebp
801009ee:	89 e5                	mov    %esp,%ebp
801009f0:	83 ec 18             	sub    $0x18,%esp
  uint target;
  int c;

  iunlock(ip);
801009f3:	83 ec 0c             	sub    $0xc,%esp
801009f6:	ff 75 08             	push   0x8(%ebp)
801009f9:	e8 2b 11 00 00       	call   80101b29 <iunlock>
801009fe:	83 c4 10             	add    $0x10,%esp
  target = n;
80100a01:	8b 45 10             	mov    0x10(%ebp),%eax
80100a04:	89 45 f4             	mov    %eax,-0xc(%ebp)
  acquire(&cons.lock);
80100a07:	83 ec 0c             	sub    $0xc,%esp
80100a0a:	68 a0 ff 10 80       	push   $0x8010ffa0
80100a0f:	e8 d5 45 00 00       	call   80104fe9 <acquire>
80100a14:	83 c4 10             	add    $0x10,%esp
  while(n > 0){
80100a17:	e9 ab 00 00 00       	jmp    80100ac7 <consoleread+0xda>
    while(input.r == input.w){
      if(myproc()->killed){
80100a1c:	e8 64 38 00 00       	call   80104285 <myproc>
80100a21:	8b 40 24             	mov    0x24(%eax),%eax
80100a24:	85 c0                	test   %eax,%eax
80100a26:	74 28                	je     80100a50 <consoleread+0x63>
        release(&cons.lock);
80100a28:	83 ec 0c             	sub    $0xc,%esp
80100a2b:	68 a0 ff 10 80       	push   $0x8010ffa0
80100a30:	e8 22 46 00 00       	call   80105057 <release>
80100a35:	83 c4 10             	add    $0x10,%esp
        ilock(ip);
80100a38:	83 ec 0c             	sub    $0xc,%esp
80100a3b:	ff 75 08             	push   0x8(%ebp)
80100a3e:	e8 d3 0f 00 00       	call   80101a16 <ilock>
80100a43:	83 c4 10             	add    $0x10,%esp
        return -1;
80100a46:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100a4b:	e9 ab 00 00 00       	jmp    80100afb <consoleread+0x10e>
      }
      sleep(&input.r, &cons.lock);
80100a50:	83 ec 08             	sub    $0x8,%esp
80100a53:	68 a0 ff 10 80       	push   $0x8010ffa0
80100a58:	68 80 ff 10 80       	push   $0x8010ff80
80100a5d:	e8 46 41 00 00       	call   80104ba8 <sleep>
80100a62:	83 c4 10             	add    $0x10,%esp
    while(input.r == input.w){
80100a65:	8b 15 80 ff 10 80    	mov    0x8010ff80,%edx
80100a6b:	a1 84 ff 10 80       	mov    0x8010ff84,%eax
80100a70:	39 c2                	cmp    %eax,%edx
80100a72:	74 a8                	je     80100a1c <consoleread+0x2f>
    }
    c = input.buf[input.r++ % INPUT_BUF];
80100a74:	a1 80 ff 10 80       	mov    0x8010ff80,%eax
80100a79:	8d 50 01             	lea    0x1(%eax),%edx
80100a7c:	89 15 80 ff 10 80    	mov    %edx,0x8010ff80
80100a82:	83 e0 7f             	and    $0x7f,%eax
80100a85:	0f b6 80 00 ff 10 80 	movzbl -0x7fef0100(%eax),%eax
80100a8c:	0f be c0             	movsbl %al,%eax
80100a8f:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(c == C('D')){  // EOF
80100a92:	83 7d f0 04          	cmpl   $0x4,-0x10(%ebp)
80100a96:	75 17                	jne    80100aaf <consoleread+0xc2>
      if(n < target){
80100a98:	8b 45 10             	mov    0x10(%ebp),%eax
80100a9b:	3b 45 f4             	cmp    -0xc(%ebp),%eax
80100a9e:	73 2f                	jae    80100acf <consoleread+0xe2>
        // Save ^D for next time, to make sure
        // caller gets a 0-byte result.
        input.r--;
80100aa0:	a1 80 ff 10 80       	mov    0x8010ff80,%eax
80100aa5:	83 e8 01             	sub    $0x1,%eax
80100aa8:	a3 80 ff 10 80       	mov    %eax,0x8010ff80
      }
      break;
80100aad:	eb 20                	jmp    80100acf <consoleread+0xe2>
    }
    *dst++ = c;
80100aaf:	8b 45 0c             	mov    0xc(%ebp),%eax
80100ab2:	8d 50 01             	lea    0x1(%eax),%edx
80100ab5:	89 55 0c             	mov    %edx,0xc(%ebp)
80100ab8:	8b 55 f0             	mov    -0x10(%ebp),%edx
80100abb:	88 10                	mov    %dl,(%eax)
    --n;
80100abd:	83 6d 10 01          	subl   $0x1,0x10(%ebp)
    if(c == '\n')
80100ac1:	83 7d f0 0a          	cmpl   $0xa,-0x10(%ebp)
80100ac5:	74 0b                	je     80100ad2 <consoleread+0xe5>
  while(n > 0){
80100ac7:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80100acb:	7f 98                	jg     80100a65 <consoleread+0x78>
80100acd:	eb 04                	jmp    80100ad3 <consoleread+0xe6>
      break;
80100acf:	90                   	nop
80100ad0:	eb 01                	jmp    80100ad3 <consoleread+0xe6>
      break;
80100ad2:	90                   	nop
  }
  release(&cons.lock);
80100ad3:	83 ec 0c             	sub    $0xc,%esp
80100ad6:	68 a0 ff 10 80       	push   $0x8010ffa0
80100adb:	e8 77 45 00 00       	call   80105057 <release>
80100ae0:	83 c4 10             	add    $0x10,%esp
  ilock(ip);
80100ae3:	83 ec 0c             	sub    $0xc,%esp
80100ae6:	ff 75 08             	push   0x8(%ebp)
80100ae9:	e8 28 0f 00 00       	call   80101a16 <ilock>
80100aee:	83 c4 10             	add    $0x10,%esp

  return target - n;
80100af1:	8b 45 10             	mov    0x10(%ebp),%eax
80100af4:	8b 55 f4             	mov    -0xc(%ebp),%edx
80100af7:	29 c2                	sub    %eax,%edx
80100af9:	89 d0                	mov    %edx,%eax
}
80100afb:	c9                   	leave
80100afc:	c3                   	ret

80100afd <consolewrite>:

int
consolewrite(struct inode *ip, char *buf, int n)
{
80100afd:	55                   	push   %ebp
80100afe:	89 e5                	mov    %esp,%ebp
80100b00:	83 ec 18             	sub    $0x18,%esp
  int i;

  iunlock(ip);
80100b03:	83 ec 0c             	sub    $0xc,%esp
80100b06:	ff 75 08             	push   0x8(%ebp)
80100b09:	e8 1b 10 00 00       	call   80101b29 <iunlock>
80100b0e:	83 c4 10             	add    $0x10,%esp
  acquire(&cons.lock);
80100b11:	83 ec 0c             	sub    $0xc,%esp
80100b14:	68 a0 ff 10 80       	push   $0x8010ffa0
80100b19:	e8 cb 44 00 00       	call   80104fe9 <acquire>
80100b1e:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < n; i++)
80100b21:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80100b28:	eb 21                	jmp    80100b4b <consolewrite+0x4e>
    consputc(buf[i] & 0xff);
80100b2a:	8b 55 f4             	mov    -0xc(%ebp),%edx
80100b2d:	8b 45 0c             	mov    0xc(%ebp),%eax
80100b30:	01 d0                	add    %edx,%eax
80100b32:	0f b6 00             	movzbl (%eax),%eax
80100b35:	0f be c0             	movsbl %al,%eax
80100b38:	0f b6 c0             	movzbl %al,%eax
80100b3b:	83 ec 0c             	sub    $0xc,%esp
80100b3e:	50                   	push   %eax
80100b3f:	e8 9d fc ff ff       	call   801007e1 <consputc>
80100b44:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < n; i++)
80100b47:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80100b4b:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100b4e:	3b 45 10             	cmp    0x10(%ebp),%eax
80100b51:	7c d7                	jl     80100b2a <consolewrite+0x2d>
  release(&cons.lock);
80100b53:	83 ec 0c             	sub    $0xc,%esp
80100b56:	68 a0 ff 10 80       	push   $0x8010ffa0
80100b5b:	e8 f7 44 00 00       	call   80105057 <release>
80100b60:	83 c4 10             	add    $0x10,%esp
  ilock(ip);
80100b63:	83 ec 0c             	sub    $0xc,%esp
80100b66:	ff 75 08             	push   0x8(%ebp)
80100b69:	e8 a8 0e 00 00       	call   80101a16 <ilock>
80100b6e:	83 c4 10             	add    $0x10,%esp

  return n;
80100b71:	8b 45 10             	mov    0x10(%ebp),%eax
}
80100b74:	c9                   	leave
80100b75:	c3                   	ret

80100b76 <consoleinit>:

void
consoleinit(void)
{
80100b76:	55                   	push   %ebp
80100b77:	89 e5                	mov    %esp,%ebp
80100b79:	83 ec 08             	sub    $0x8,%esp
  initlock(&cons.lock, "console");
80100b7c:	83 ec 08             	sub    $0x8,%esp
80100b7f:	68 ce 84 10 80       	push   $0x801084ce
80100b84:	68 a0 ff 10 80       	push   $0x8010ffa0
80100b89:	e8 39 44 00 00       	call   80104fc7 <initlock>
80100b8e:	83 c4 10             	add    $0x10,%esp

  devsw[CONSOLE].write = consolewrite;
80100b91:	c7 05 ec ff 10 80 fd 	movl   $0x80100afd,0x8010ffec
80100b98:	0a 10 80 
  devsw[CONSOLE].read = consoleread;
80100b9b:	c7 05 e8 ff 10 80 ed 	movl   $0x801009ed,0x8010ffe8
80100ba2:	09 10 80 
  cons.locking = 1;
80100ba5:	c7 05 d4 ff 10 80 01 	movl   $0x1,0x8010ffd4
80100bac:	00 00 00 

  ioapicenable(IRQ_KBD, 0);
80100baf:	83 ec 08             	sub    $0x8,%esp
80100bb2:	6a 00                	push   $0x0
80100bb4:	6a 01                	push   $0x1
80100bb6:	e8 65 1f 00 00       	call   80102b20 <ioapicenable>
80100bbb:	83 c4 10             	add    $0x10,%esp
}
80100bbe:	90                   	nop
80100bbf:	c9                   	leave
80100bc0:	c3                   	ret

80100bc1 <exec>:
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
80100bc1:	55                   	push   %ebp
80100bc2:	89 e5                	mov    %esp,%ebp
80100bc4:	81 ec 18 01 00 00    	sub    $0x118,%esp
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();
80100bca:	e8 b6 36 00 00       	call   80104285 <myproc>
80100bcf:	89 45 d0             	mov    %eax,-0x30(%ebp)

  begin_op();
80100bd2:	e8 4b 29 00 00       	call   80103522 <begin_op>

  if((ip = namei(path)) == 0){
80100bd7:	83 ec 0c             	sub    $0xc,%esp
80100bda:	ff 75 08             	push   0x8(%ebp)
80100bdd:	e8 67 19 00 00       	call   80102549 <namei>
80100be2:	83 c4 10             	add    $0x10,%esp
80100be5:	89 45 d8             	mov    %eax,-0x28(%ebp)
80100be8:	83 7d d8 00          	cmpl   $0x0,-0x28(%ebp)
80100bec:	75 1f                	jne    80100c0d <exec+0x4c>
    end_op();
80100bee:	e8 bb 29 00 00       	call   801035ae <end_op>
    cprintf("exec: fail\n");
80100bf3:	83 ec 0c             	sub    $0xc,%esp
80100bf6:	68 d6 84 10 80       	push   $0x801084d6
80100bfb:	e8 fe f7 ff ff       	call   801003fe <cprintf>
80100c00:	83 c4 10             	add    $0x10,%esp
    return -1;
80100c03:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100c08:	e9 f1 03 00 00       	jmp    80100ffe <exec+0x43d>
  }
  ilock(ip);
80100c0d:	83 ec 0c             	sub    $0xc,%esp
80100c10:	ff 75 d8             	push   -0x28(%ebp)
80100c13:	e8 fe 0d 00 00       	call   80101a16 <ilock>
80100c18:	83 c4 10             	add    $0x10,%esp
  pgdir = 0;
80100c1b:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
80100c22:	6a 34                	push   $0x34
80100c24:	6a 00                	push   $0x0
80100c26:	8d 85 08 ff ff ff    	lea    -0xf8(%ebp),%eax
80100c2c:	50                   	push   %eax
80100c2d:	ff 75 d8             	push   -0x28(%ebp)
80100c30:	e8 cd 12 00 00       	call   80101f02 <readi>
80100c35:	83 c4 10             	add    $0x10,%esp
80100c38:	83 f8 34             	cmp    $0x34,%eax
80100c3b:	0f 85 66 03 00 00    	jne    80100fa7 <exec+0x3e6>
    goto bad;
  if(elf.magic != ELF_MAGIC)
80100c41:	8b 85 08 ff ff ff    	mov    -0xf8(%ebp),%eax
80100c47:	3d 7f 45 4c 46       	cmp    $0x464c457f,%eax
80100c4c:	0f 85 58 03 00 00    	jne    80100faa <exec+0x3e9>
    goto bad;

  if((pgdir = setupkvm()) == 0)
80100c52:	e8 ba 6f 00 00       	call   80107c11 <setupkvm>
80100c57:	89 45 d4             	mov    %eax,-0x2c(%ebp)
80100c5a:	83 7d d4 00          	cmpl   $0x0,-0x2c(%ebp)
80100c5e:	0f 84 49 03 00 00    	je     80100fad <exec+0x3ec>
    goto bad;

  // Load program into memory.
  sz = 0;
80100c64:	c7 45 e0 00 00 00 00 	movl   $0x0,-0x20(%ebp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100c6b:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
80100c72:	8b 85 24 ff ff ff    	mov    -0xdc(%ebp),%eax
80100c78:	89 45 e8             	mov    %eax,-0x18(%ebp)
80100c7b:	e9 de 00 00 00       	jmp    80100d5e <exec+0x19d>
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
80100c80:	8b 45 e8             	mov    -0x18(%ebp),%eax
80100c83:	6a 20                	push   $0x20
80100c85:	50                   	push   %eax
80100c86:	8d 85 e8 fe ff ff    	lea    -0x118(%ebp),%eax
80100c8c:	50                   	push   %eax
80100c8d:	ff 75 d8             	push   -0x28(%ebp)
80100c90:	e8 6d 12 00 00       	call   80101f02 <readi>
80100c95:	83 c4 10             	add    $0x10,%esp
80100c98:	83 f8 20             	cmp    $0x20,%eax
80100c9b:	0f 85 0f 03 00 00    	jne    80100fb0 <exec+0x3ef>
      goto bad;
    if(ph.type != ELF_PROG_LOAD)
80100ca1:	8b 85 e8 fe ff ff    	mov    -0x118(%ebp),%eax
80100ca7:	83 f8 01             	cmp    $0x1,%eax
80100caa:	0f 85 a0 00 00 00    	jne    80100d50 <exec+0x18f>
      continue;
    if(ph.memsz < ph.filesz)
80100cb0:	8b 95 fc fe ff ff    	mov    -0x104(%ebp),%edx
80100cb6:	8b 85 f8 fe ff ff    	mov    -0x108(%ebp),%eax
80100cbc:	39 c2                	cmp    %eax,%edx
80100cbe:	0f 82 ef 02 00 00    	jb     80100fb3 <exec+0x3f2>
      goto bad;
    if(ph.vaddr + ph.memsz < ph.vaddr)
80100cc4:	8b 95 f0 fe ff ff    	mov    -0x110(%ebp),%edx
80100cca:	8b 85 fc fe ff ff    	mov    -0x104(%ebp),%eax
80100cd0:	01 c2                	add    %eax,%edx
80100cd2:	8b 85 f0 fe ff ff    	mov    -0x110(%ebp),%eax
80100cd8:	39 c2                	cmp    %eax,%edx
80100cda:	0f 82 d6 02 00 00    	jb     80100fb6 <exec+0x3f5>
      goto bad;
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
80100ce0:	8b 95 f0 fe ff ff    	mov    -0x110(%ebp),%edx
80100ce6:	8b 85 fc fe ff ff    	mov    -0x104(%ebp),%eax
80100cec:	01 d0                	add    %edx,%eax
80100cee:	83 ec 04             	sub    $0x4,%esp
80100cf1:	50                   	push   %eax
80100cf2:	ff 75 e0             	push   -0x20(%ebp)
80100cf5:	ff 75 d4             	push   -0x2c(%ebp)
80100cf8:	e8 ba 72 00 00       	call   80107fb7 <allocuvm>
80100cfd:	83 c4 10             	add    $0x10,%esp
80100d00:	89 45 e0             	mov    %eax,-0x20(%ebp)
80100d03:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
80100d07:	0f 84 ac 02 00 00    	je     80100fb9 <exec+0x3f8>
      goto bad;
    if(ph.vaddr % PGSIZE != 0)
80100d0d:	8b 85 f0 fe ff ff    	mov    -0x110(%ebp),%eax
80100d13:	25 ff 0f 00 00       	and    $0xfff,%eax
80100d18:	85 c0                	test   %eax,%eax
80100d1a:	0f 85 9c 02 00 00    	jne    80100fbc <exec+0x3fb>
      goto bad;
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
80100d20:	8b 95 f8 fe ff ff    	mov    -0x108(%ebp),%edx
80100d26:	8b 85 ec fe ff ff    	mov    -0x114(%ebp),%eax
80100d2c:	8b 8d f0 fe ff ff    	mov    -0x110(%ebp),%ecx
80100d32:	83 ec 0c             	sub    $0xc,%esp
80100d35:	52                   	push   %edx
80100d36:	50                   	push   %eax
80100d37:	ff 75 d8             	push   -0x28(%ebp)
80100d3a:	51                   	push   %ecx
80100d3b:	ff 75 d4             	push   -0x2c(%ebp)
80100d3e:	e8 a7 71 00 00       	call   80107eea <loaduvm>
80100d43:	83 c4 20             	add    $0x20,%esp
80100d46:	85 c0                	test   %eax,%eax
80100d48:	0f 88 71 02 00 00    	js     80100fbf <exec+0x3fe>
80100d4e:	eb 01                	jmp    80100d51 <exec+0x190>
      continue;
80100d50:	90                   	nop
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100d51:	83 45 ec 01          	addl   $0x1,-0x14(%ebp)
80100d55:	8b 45 e8             	mov    -0x18(%ebp),%eax
80100d58:	83 c0 20             	add    $0x20,%eax
80100d5b:	89 45 e8             	mov    %eax,-0x18(%ebp)
80100d5e:	0f b7 85 34 ff ff ff 	movzwl -0xcc(%ebp),%eax
80100d65:	0f b7 c0             	movzwl %ax,%eax
80100d68:	39 45 ec             	cmp    %eax,-0x14(%ebp)
80100d6b:	0f 8c 0f ff ff ff    	jl     80100c80 <exec+0xbf>
      goto bad;
  }
  iunlockput(ip);
80100d71:	83 ec 0c             	sub    $0xc,%esp
80100d74:	ff 75 d8             	push   -0x28(%ebp)
80100d77:	e8 cb 0e 00 00       	call   80101c47 <iunlockput>
80100d7c:	83 c4 10             	add    $0x10,%esp
  end_op();
80100d7f:	e8 2a 28 00 00       	call   801035ae <end_op>
  ip = 0;
80100d84:	c7 45 d8 00 00 00 00 	movl   $0x0,-0x28(%ebp)

  // Allocate two pages at the next page boundary.
  // Make the first inaccessible.  Use the second as the user stack.
  sz = PGROUNDUP(sz);
80100d8b:	8b 45 e0             	mov    -0x20(%ebp),%eax
80100d8e:	05 ff 0f 00 00       	add    $0xfff,%eax
80100d93:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80100d98:	89 45 e0             	mov    %eax,-0x20(%ebp)
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100d9b:	8b 45 e0             	mov    -0x20(%ebp),%eax
80100d9e:	05 00 20 00 00       	add    $0x2000,%eax
80100da3:	83 ec 04             	sub    $0x4,%esp
80100da6:	50                   	push   %eax
80100da7:	ff 75 e0             	push   -0x20(%ebp)
80100daa:	ff 75 d4             	push   -0x2c(%ebp)
80100dad:	e8 05 72 00 00       	call   80107fb7 <allocuvm>
80100db2:	83 c4 10             	add    $0x10,%esp
80100db5:	89 45 e0             	mov    %eax,-0x20(%ebp)
80100db8:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
80100dbc:	0f 84 00 02 00 00    	je     80100fc2 <exec+0x401>
    goto bad;
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100dc2:	8b 45 e0             	mov    -0x20(%ebp),%eax
80100dc5:	2d 00 20 00 00       	sub    $0x2000,%eax
80100dca:	83 ec 08             	sub    $0x8,%esp
80100dcd:	50                   	push   %eax
80100dce:	ff 75 d4             	push   -0x2c(%ebp)
80100dd1:	e8 43 74 00 00       	call   80108219 <clearpteu>
80100dd6:	83 c4 10             	add    $0x10,%esp
  sp = sz;
80100dd9:	8b 45 e0             	mov    -0x20(%ebp),%eax
80100ddc:	89 45 dc             	mov    %eax,-0x24(%ebp)

  // Push argument strings, prepare rest of stack in ustack.
  for(argc = 0; argv[argc]; argc++) {
80100ddf:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
80100de6:	e9 96 00 00 00       	jmp    80100e81 <exec+0x2c0>
    if(argc >= MAXARG)
80100deb:	83 7d e4 1f          	cmpl   $0x1f,-0x1c(%ebp)
80100def:	0f 87 d0 01 00 00    	ja     80100fc5 <exec+0x404>
      goto bad;
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100df5:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100df8:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80100dff:	8b 45 0c             	mov    0xc(%ebp),%eax
80100e02:	01 d0                	add    %edx,%eax
80100e04:	8b 00                	mov    (%eax),%eax
80100e06:	83 ec 0c             	sub    $0xc,%esp
80100e09:	50                   	push   %eax
80100e0a:	e8 ae 46 00 00       	call   801054bd <strlen>
80100e0f:	83 c4 10             	add    $0x10,%esp
80100e12:	89 c2                	mov    %eax,%edx
80100e14:	8b 45 dc             	mov    -0x24(%ebp),%eax
80100e17:	29 d0                	sub    %edx,%eax
80100e19:	83 e8 01             	sub    $0x1,%eax
80100e1c:	83 e0 fc             	and    $0xfffffffc,%eax
80100e1f:	89 45 dc             	mov    %eax,-0x24(%ebp)
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100e22:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100e25:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80100e2c:	8b 45 0c             	mov    0xc(%ebp),%eax
80100e2f:	01 d0                	add    %edx,%eax
80100e31:	8b 00                	mov    (%eax),%eax
80100e33:	83 ec 0c             	sub    $0xc,%esp
80100e36:	50                   	push   %eax
80100e37:	e8 81 46 00 00       	call   801054bd <strlen>
80100e3c:	83 c4 10             	add    $0x10,%esp
80100e3f:	83 c0 01             	add    $0x1,%eax
80100e42:	89 c1                	mov    %eax,%ecx
80100e44:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100e47:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80100e4e:	8b 45 0c             	mov    0xc(%ebp),%eax
80100e51:	01 d0                	add    %edx,%eax
80100e53:	8b 00                	mov    (%eax),%eax
80100e55:	51                   	push   %ecx
80100e56:	50                   	push   %eax
80100e57:	ff 75 dc             	push   -0x24(%ebp)
80100e5a:	ff 75 d4             	push   -0x2c(%ebp)
80100e5d:	e8 63 75 00 00       	call   801083c5 <copyout>
80100e62:	83 c4 10             	add    $0x10,%esp
80100e65:	85 c0                	test   %eax,%eax
80100e67:	0f 88 5b 01 00 00    	js     80100fc8 <exec+0x407>
      goto bad;
    ustack[3+argc] = sp;
80100e6d:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100e70:	8d 50 03             	lea    0x3(%eax),%edx
80100e73:	8b 45 dc             	mov    -0x24(%ebp),%eax
80100e76:	89 84 95 3c ff ff ff 	mov    %eax,-0xc4(%ebp,%edx,4)
  for(argc = 0; argv[argc]; argc++) {
80100e7d:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
80100e81:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100e84:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80100e8b:	8b 45 0c             	mov    0xc(%ebp),%eax
80100e8e:	01 d0                	add    %edx,%eax
80100e90:	8b 00                	mov    (%eax),%eax
80100e92:	85 c0                	test   %eax,%eax
80100e94:	0f 85 51 ff ff ff    	jne    80100deb <exec+0x22a>
  }
  ustack[3+argc] = 0;
80100e9a:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100e9d:	83 c0 03             	add    $0x3,%eax
80100ea0:	c7 84 85 3c ff ff ff 	movl   $0x0,-0xc4(%ebp,%eax,4)
80100ea7:	00 00 00 00 

  ustack[0] = 0xffffffff;  // fake return PC
80100eab:	c7 85 3c ff ff ff ff 	movl   $0xffffffff,-0xc4(%ebp)
80100eb2:	ff ff ff 
  ustack[1] = argc;
80100eb5:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100eb8:	89 85 40 ff ff ff    	mov    %eax,-0xc0(%ebp)
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100ebe:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100ec1:	83 c0 01             	add    $0x1,%eax
80100ec4:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80100ecb:	8b 45 dc             	mov    -0x24(%ebp),%eax
80100ece:	29 d0                	sub    %edx,%eax
80100ed0:	89 85 44 ff ff ff    	mov    %eax,-0xbc(%ebp)

  sp -= (3+argc+1) * 4;
80100ed6:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100ed9:	83 c0 04             	add    $0x4,%eax
80100edc:	c1 e0 02             	shl    $0x2,%eax
80100edf:	29 45 dc             	sub    %eax,-0x24(%ebp)
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
80100ee2:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100ee5:	83 c0 04             	add    $0x4,%eax
80100ee8:	c1 e0 02             	shl    $0x2,%eax
80100eeb:	50                   	push   %eax
80100eec:	8d 85 3c ff ff ff    	lea    -0xc4(%ebp),%eax
80100ef2:	50                   	push   %eax
80100ef3:	ff 75 dc             	push   -0x24(%ebp)
80100ef6:	ff 75 d4             	push   -0x2c(%ebp)
80100ef9:	e8 c7 74 00 00       	call   801083c5 <copyout>
80100efe:	83 c4 10             	add    $0x10,%esp
80100f01:	85 c0                	test   %eax,%eax
80100f03:	0f 88 c2 00 00 00    	js     80100fcb <exec+0x40a>
    goto bad;

  // Save program name for debugging.
  for(last=s=path; *s; s++)
80100f09:	8b 45 08             	mov    0x8(%ebp),%eax
80100f0c:	89 45 f4             	mov    %eax,-0xc(%ebp)
80100f0f:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100f12:	89 45 f0             	mov    %eax,-0x10(%ebp)
80100f15:	eb 17                	jmp    80100f2e <exec+0x36d>
    if(*s == '/')
80100f17:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100f1a:	0f b6 00             	movzbl (%eax),%eax
80100f1d:	3c 2f                	cmp    $0x2f,%al
80100f1f:	75 09                	jne    80100f2a <exec+0x369>
      last = s+1;
80100f21:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100f24:	83 c0 01             	add    $0x1,%eax
80100f27:	89 45 f0             	mov    %eax,-0x10(%ebp)
  for(last=s=path; *s; s++)
80100f2a:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80100f2e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80100f31:	0f b6 00             	movzbl (%eax),%eax
80100f34:	84 c0                	test   %al,%al
80100f36:	75 df                	jne    80100f17 <exec+0x356>
  safestrcpy(curproc->name, last, sizeof(curproc->name));
80100f38:	8b 45 d0             	mov    -0x30(%ebp),%eax
80100f3b:	83 c0 6c             	add    $0x6c,%eax
80100f3e:	83 ec 04             	sub    $0x4,%esp
80100f41:	6a 10                	push   $0x10
80100f43:	ff 75 f0             	push   -0x10(%ebp)
80100f46:	50                   	push   %eax
80100f47:	e8 26 45 00 00       	call   80105472 <safestrcpy>
80100f4c:	83 c4 10             	add    $0x10,%esp

  // Commit to the user image.
  oldpgdir = curproc->pgdir;
80100f4f:	8b 45 d0             	mov    -0x30(%ebp),%eax
80100f52:	8b 40 04             	mov    0x4(%eax),%eax
80100f55:	89 45 cc             	mov    %eax,-0x34(%ebp)
  curproc->pgdir = pgdir;
80100f58:	8b 45 d0             	mov    -0x30(%ebp),%eax
80100f5b:	8b 55 d4             	mov    -0x2c(%ebp),%edx
80100f5e:	89 50 04             	mov    %edx,0x4(%eax)
  curproc->sz = sz;
80100f61:	8b 45 d0             	mov    -0x30(%ebp),%eax
80100f64:	8b 55 e0             	mov    -0x20(%ebp),%edx
80100f67:	89 10                	mov    %edx,(%eax)
  curproc->tf->eip = elf.entry;  // main
80100f69:	8b 45 d0             	mov    -0x30(%ebp),%eax
80100f6c:	8b 40 18             	mov    0x18(%eax),%eax
80100f6f:	8b 95 20 ff ff ff    	mov    -0xe0(%ebp),%edx
80100f75:	89 50 38             	mov    %edx,0x38(%eax)
  curproc->tf->esp = sp;
80100f78:	8b 45 d0             	mov    -0x30(%ebp),%eax
80100f7b:	8b 40 18             	mov    0x18(%eax),%eax
80100f7e:	8b 55 dc             	mov    -0x24(%ebp),%edx
80100f81:	89 50 44             	mov    %edx,0x44(%eax)
  switchuvm(curproc);
80100f84:	83 ec 0c             	sub    $0xc,%esp
80100f87:	ff 75 d0             	push   -0x30(%ebp)
80100f8a:	e8 4c 6d 00 00       	call   80107cdb <switchuvm>
80100f8f:	83 c4 10             	add    $0x10,%esp
  freevm(oldpgdir);
80100f92:	83 ec 0c             	sub    $0xc,%esp
80100f95:	ff 75 cc             	push   -0x34(%ebp)
80100f98:	e8 e3 71 00 00       	call   80108180 <freevm>
80100f9d:	83 c4 10             	add    $0x10,%esp
  return 0;
80100fa0:	b8 00 00 00 00       	mov    $0x0,%eax
80100fa5:	eb 57                	jmp    80100ffe <exec+0x43d>
    goto bad;
80100fa7:	90                   	nop
80100fa8:	eb 22                	jmp    80100fcc <exec+0x40b>
    goto bad;
80100faa:	90                   	nop
80100fab:	eb 1f                	jmp    80100fcc <exec+0x40b>
    goto bad;
80100fad:	90                   	nop
80100fae:	eb 1c                	jmp    80100fcc <exec+0x40b>
      goto bad;
80100fb0:	90                   	nop
80100fb1:	eb 19                	jmp    80100fcc <exec+0x40b>
      goto bad;
80100fb3:	90                   	nop
80100fb4:	eb 16                	jmp    80100fcc <exec+0x40b>
      goto bad;
80100fb6:	90                   	nop
80100fb7:	eb 13                	jmp    80100fcc <exec+0x40b>
      goto bad;
80100fb9:	90                   	nop
80100fba:	eb 10                	jmp    80100fcc <exec+0x40b>
      goto bad;
80100fbc:	90                   	nop
80100fbd:	eb 0d                	jmp    80100fcc <exec+0x40b>
      goto bad;
80100fbf:	90                   	nop
80100fc0:	eb 0a                	jmp    80100fcc <exec+0x40b>
    goto bad;
80100fc2:	90                   	nop
80100fc3:	eb 07                	jmp    80100fcc <exec+0x40b>
      goto bad;
80100fc5:	90                   	nop
80100fc6:	eb 04                	jmp    80100fcc <exec+0x40b>
      goto bad;
80100fc8:	90                   	nop
80100fc9:	eb 01                	jmp    80100fcc <exec+0x40b>
    goto bad;
80100fcb:	90                   	nop

 bad:
  if(pgdir)
80100fcc:	83 7d d4 00          	cmpl   $0x0,-0x2c(%ebp)
80100fd0:	74 0e                	je     80100fe0 <exec+0x41f>
    freevm(pgdir);
80100fd2:	83 ec 0c             	sub    $0xc,%esp
80100fd5:	ff 75 d4             	push   -0x2c(%ebp)
80100fd8:	e8 a3 71 00 00       	call   80108180 <freevm>
80100fdd:	83 c4 10             	add    $0x10,%esp
  if(ip){
80100fe0:	83 7d d8 00          	cmpl   $0x0,-0x28(%ebp)
80100fe4:	74 13                	je     80100ff9 <exec+0x438>
    iunlockput(ip);
80100fe6:	83 ec 0c             	sub    $0xc,%esp
80100fe9:	ff 75 d8             	push   -0x28(%ebp)
80100fec:	e8 56 0c 00 00       	call   80101c47 <iunlockput>
80100ff1:	83 c4 10             	add    $0x10,%esp
    end_op();
80100ff4:	e8 b5 25 00 00       	call   801035ae <end_op>
  }
  return -1;
80100ff9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80100ffe:	c9                   	leave
80100fff:	c3                   	ret

80101000 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
80101000:	55                   	push   %ebp
80101001:	89 e5                	mov    %esp,%ebp
80101003:	83 ec 08             	sub    $0x8,%esp
  initlock(&ftable.lock, "ftable");
80101006:	83 ec 08             	sub    $0x8,%esp
80101009:	68 e2 84 10 80       	push   $0x801084e2
8010100e:	68 40 00 11 80       	push   $0x80110040
80101013:	e8 af 3f 00 00       	call   80104fc7 <initlock>
80101018:	83 c4 10             	add    $0x10,%esp
}
8010101b:	90                   	nop
8010101c:	c9                   	leave
8010101d:	c3                   	ret

8010101e <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
8010101e:	55                   	push   %ebp
8010101f:	89 e5                	mov    %esp,%ebp
80101021:	83 ec 18             	sub    $0x18,%esp
  struct file *f;

  acquire(&ftable.lock);
80101024:	83 ec 0c             	sub    $0xc,%esp
80101027:	68 40 00 11 80       	push   $0x80110040
8010102c:	e8 b8 3f 00 00       	call   80104fe9 <acquire>
80101031:	83 c4 10             	add    $0x10,%esp
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80101034:	c7 45 f4 74 00 11 80 	movl   $0x80110074,-0xc(%ebp)
8010103b:	eb 2d                	jmp    8010106a <filealloc+0x4c>
    if(f->ref == 0){
8010103d:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101040:	8b 40 04             	mov    0x4(%eax),%eax
80101043:	85 c0                	test   %eax,%eax
80101045:	75 1f                	jne    80101066 <filealloc+0x48>
      f->ref = 1;
80101047:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010104a:	c7 40 04 01 00 00 00 	movl   $0x1,0x4(%eax)
      release(&ftable.lock);
80101051:	83 ec 0c             	sub    $0xc,%esp
80101054:	68 40 00 11 80       	push   $0x80110040
80101059:	e8 f9 3f 00 00       	call   80105057 <release>
8010105e:	83 c4 10             	add    $0x10,%esp
      return f;
80101061:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101064:	eb 23                	jmp    80101089 <filealloc+0x6b>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80101066:	83 45 f4 18          	addl   $0x18,-0xc(%ebp)
8010106a:	b8 d4 09 11 80       	mov    $0x801109d4,%eax
8010106f:	39 45 f4             	cmp    %eax,-0xc(%ebp)
80101072:	72 c9                	jb     8010103d <filealloc+0x1f>
    }
  }
  release(&ftable.lock);
80101074:	83 ec 0c             	sub    $0xc,%esp
80101077:	68 40 00 11 80       	push   $0x80110040
8010107c:	e8 d6 3f 00 00       	call   80105057 <release>
80101081:	83 c4 10             	add    $0x10,%esp
  return 0;
80101084:	b8 00 00 00 00       	mov    $0x0,%eax
}
80101089:	c9                   	leave
8010108a:	c3                   	ret

8010108b <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
8010108b:	55                   	push   %ebp
8010108c:	89 e5                	mov    %esp,%ebp
8010108e:	83 ec 08             	sub    $0x8,%esp
  acquire(&ftable.lock);
80101091:	83 ec 0c             	sub    $0xc,%esp
80101094:	68 40 00 11 80       	push   $0x80110040
80101099:	e8 4b 3f 00 00       	call   80104fe9 <acquire>
8010109e:	83 c4 10             	add    $0x10,%esp
  if(f->ref < 1)
801010a1:	8b 45 08             	mov    0x8(%ebp),%eax
801010a4:	8b 40 04             	mov    0x4(%eax),%eax
801010a7:	85 c0                	test   %eax,%eax
801010a9:	7f 0d                	jg     801010b8 <filedup+0x2d>
    panic("filedup");
801010ab:	83 ec 0c             	sub    $0xc,%esp
801010ae:	68 e9 84 10 80       	push   $0x801084e9
801010b3:	e8 fb f4 ff ff       	call   801005b3 <panic>
  f->ref++;
801010b8:	8b 45 08             	mov    0x8(%ebp),%eax
801010bb:	8b 40 04             	mov    0x4(%eax),%eax
801010be:	8d 50 01             	lea    0x1(%eax),%edx
801010c1:	8b 45 08             	mov    0x8(%ebp),%eax
801010c4:	89 50 04             	mov    %edx,0x4(%eax)
  release(&ftable.lock);
801010c7:	83 ec 0c             	sub    $0xc,%esp
801010ca:	68 40 00 11 80       	push   $0x80110040
801010cf:	e8 83 3f 00 00       	call   80105057 <release>
801010d4:	83 c4 10             	add    $0x10,%esp
  return f;
801010d7:	8b 45 08             	mov    0x8(%ebp),%eax
}
801010da:	c9                   	leave
801010db:	c3                   	ret

801010dc <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
801010dc:	55                   	push   %ebp
801010dd:	89 e5                	mov    %esp,%ebp
801010df:	83 ec 28             	sub    $0x28,%esp
  struct file ff;

  acquire(&ftable.lock);
801010e2:	83 ec 0c             	sub    $0xc,%esp
801010e5:	68 40 00 11 80       	push   $0x80110040
801010ea:	e8 fa 3e 00 00       	call   80104fe9 <acquire>
801010ef:	83 c4 10             	add    $0x10,%esp
  if(f->ref < 1)
801010f2:	8b 45 08             	mov    0x8(%ebp),%eax
801010f5:	8b 40 04             	mov    0x4(%eax),%eax
801010f8:	85 c0                	test   %eax,%eax
801010fa:	7f 0d                	jg     80101109 <fileclose+0x2d>
    panic("fileclose");
801010fc:	83 ec 0c             	sub    $0xc,%esp
801010ff:	68 f1 84 10 80       	push   $0x801084f1
80101104:	e8 aa f4 ff ff       	call   801005b3 <panic>
  if(--f->ref > 0){
80101109:	8b 45 08             	mov    0x8(%ebp),%eax
8010110c:	8b 40 04             	mov    0x4(%eax),%eax
8010110f:	8d 50 ff             	lea    -0x1(%eax),%edx
80101112:	8b 45 08             	mov    0x8(%ebp),%eax
80101115:	89 50 04             	mov    %edx,0x4(%eax)
80101118:	8b 45 08             	mov    0x8(%ebp),%eax
8010111b:	8b 40 04             	mov    0x4(%eax),%eax
8010111e:	85 c0                	test   %eax,%eax
80101120:	7e 15                	jle    80101137 <fileclose+0x5b>
    release(&ftable.lock);
80101122:	83 ec 0c             	sub    $0xc,%esp
80101125:	68 40 00 11 80       	push   $0x80110040
8010112a:	e8 28 3f 00 00       	call   80105057 <release>
8010112f:	83 c4 10             	add    $0x10,%esp
80101132:	e9 8b 00 00 00       	jmp    801011c2 <fileclose+0xe6>
    return;
  }
  ff = *f;
80101137:	8b 45 08             	mov    0x8(%ebp),%eax
8010113a:	8b 10                	mov    (%eax),%edx
8010113c:	89 55 e0             	mov    %edx,-0x20(%ebp)
8010113f:	8b 50 04             	mov    0x4(%eax),%edx
80101142:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80101145:	8b 50 08             	mov    0x8(%eax),%edx
80101148:	89 55 e8             	mov    %edx,-0x18(%ebp)
8010114b:	8b 50 0c             	mov    0xc(%eax),%edx
8010114e:	89 55 ec             	mov    %edx,-0x14(%ebp)
80101151:	8b 50 10             	mov    0x10(%eax),%edx
80101154:	89 55 f0             	mov    %edx,-0x10(%ebp)
80101157:	8b 40 14             	mov    0x14(%eax),%eax
8010115a:	89 45 f4             	mov    %eax,-0xc(%ebp)
  f->ref = 0;
8010115d:	8b 45 08             	mov    0x8(%ebp),%eax
80101160:	c7 40 04 00 00 00 00 	movl   $0x0,0x4(%eax)
  f->type = FD_NONE;
80101167:	8b 45 08             	mov    0x8(%ebp),%eax
8010116a:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  release(&ftable.lock);
80101170:	83 ec 0c             	sub    $0xc,%esp
80101173:	68 40 00 11 80       	push   $0x80110040
80101178:	e8 da 3e 00 00       	call   80105057 <release>
8010117d:	83 c4 10             	add    $0x10,%esp

  if(ff.type == FD_PIPE)
80101180:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101183:	83 f8 01             	cmp    $0x1,%eax
80101186:	75 19                	jne    801011a1 <fileclose+0xc5>
    pipeclose(ff.pipe, ff.writable);
80101188:	0f b6 45 e9          	movzbl -0x17(%ebp),%eax
8010118c:	0f be d0             	movsbl %al,%edx
8010118f:	8b 45 ec             	mov    -0x14(%ebp),%eax
80101192:	83 ec 08             	sub    $0x8,%esp
80101195:	52                   	push   %edx
80101196:	50                   	push   %eax
80101197:	e8 78 2d 00 00       	call   80103f14 <pipeclose>
8010119c:	83 c4 10             	add    $0x10,%esp
8010119f:	eb 21                	jmp    801011c2 <fileclose+0xe6>
  else if(ff.type == FD_INODE){
801011a1:	8b 45 e0             	mov    -0x20(%ebp),%eax
801011a4:	83 f8 02             	cmp    $0x2,%eax
801011a7:	75 19                	jne    801011c2 <fileclose+0xe6>
    begin_op();
801011a9:	e8 74 23 00 00       	call   80103522 <begin_op>
    iput(ff.ip);
801011ae:	8b 45 f0             	mov    -0x10(%ebp),%eax
801011b1:	83 ec 0c             	sub    $0xc,%esp
801011b4:	50                   	push   %eax
801011b5:	e8 bd 09 00 00       	call   80101b77 <iput>
801011ba:	83 c4 10             	add    $0x10,%esp
    end_op();
801011bd:	e8 ec 23 00 00       	call   801035ae <end_op>
  }
}
801011c2:	c9                   	leave
801011c3:	c3                   	ret

801011c4 <filestat>:

// Get metadata about file f.
int
filestat(struct file *f, struct stat *st)
{
801011c4:	55                   	push   %ebp
801011c5:	89 e5                	mov    %esp,%ebp
801011c7:	83 ec 08             	sub    $0x8,%esp
  if(f->type == FD_INODE){
801011ca:	8b 45 08             	mov    0x8(%ebp),%eax
801011cd:	8b 00                	mov    (%eax),%eax
801011cf:	83 f8 02             	cmp    $0x2,%eax
801011d2:	75 40                	jne    80101214 <filestat+0x50>
    ilock(f->ip);
801011d4:	8b 45 08             	mov    0x8(%ebp),%eax
801011d7:	8b 40 10             	mov    0x10(%eax),%eax
801011da:	83 ec 0c             	sub    $0xc,%esp
801011dd:	50                   	push   %eax
801011de:	e8 33 08 00 00       	call   80101a16 <ilock>
801011e3:	83 c4 10             	add    $0x10,%esp
    stati(f->ip, st);
801011e6:	8b 45 08             	mov    0x8(%ebp),%eax
801011e9:	8b 40 10             	mov    0x10(%eax),%eax
801011ec:	83 ec 08             	sub    $0x8,%esp
801011ef:	ff 75 0c             	push   0xc(%ebp)
801011f2:	50                   	push   %eax
801011f3:	e8 c4 0c 00 00       	call   80101ebc <stati>
801011f8:	83 c4 10             	add    $0x10,%esp
    iunlock(f->ip);
801011fb:	8b 45 08             	mov    0x8(%ebp),%eax
801011fe:	8b 40 10             	mov    0x10(%eax),%eax
80101201:	83 ec 0c             	sub    $0xc,%esp
80101204:	50                   	push   %eax
80101205:	e8 1f 09 00 00       	call   80101b29 <iunlock>
8010120a:	83 c4 10             	add    $0x10,%esp
    return 0;
8010120d:	b8 00 00 00 00       	mov    $0x0,%eax
80101212:	eb 05                	jmp    80101219 <filestat+0x55>
  }
  return -1;
80101214:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80101219:	c9                   	leave
8010121a:	c3                   	ret

8010121b <fileread>:

// Read from file f.
int
fileread(struct file *f, char *addr, int n)
{
8010121b:	55                   	push   %ebp
8010121c:	89 e5                	mov    %esp,%ebp
8010121e:	83 ec 18             	sub    $0x18,%esp
  int r;

  if(f->readable == 0)
80101221:	8b 45 08             	mov    0x8(%ebp),%eax
80101224:	0f b6 40 08          	movzbl 0x8(%eax),%eax
80101228:	84 c0                	test   %al,%al
8010122a:	75 0a                	jne    80101236 <fileread+0x1b>
    return -1;
8010122c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101231:	e9 9b 00 00 00       	jmp    801012d1 <fileread+0xb6>
  if(f->type == FD_PIPE)
80101236:	8b 45 08             	mov    0x8(%ebp),%eax
80101239:	8b 00                	mov    (%eax),%eax
8010123b:	83 f8 01             	cmp    $0x1,%eax
8010123e:	75 1a                	jne    8010125a <fileread+0x3f>
    return piperead(f->pipe, addr, n);
80101240:	8b 45 08             	mov    0x8(%ebp),%eax
80101243:	8b 40 0c             	mov    0xc(%eax),%eax
80101246:	83 ec 04             	sub    $0x4,%esp
80101249:	ff 75 10             	push   0x10(%ebp)
8010124c:	ff 75 0c             	push   0xc(%ebp)
8010124f:	50                   	push   %eax
80101250:	e8 6c 2e 00 00       	call   801040c1 <piperead>
80101255:	83 c4 10             	add    $0x10,%esp
80101258:	eb 77                	jmp    801012d1 <fileread+0xb6>
  if(f->type == FD_INODE){
8010125a:	8b 45 08             	mov    0x8(%ebp),%eax
8010125d:	8b 00                	mov    (%eax),%eax
8010125f:	83 f8 02             	cmp    $0x2,%eax
80101262:	75 60                	jne    801012c4 <fileread+0xa9>
    ilock(f->ip);
80101264:	8b 45 08             	mov    0x8(%ebp),%eax
80101267:	8b 40 10             	mov    0x10(%eax),%eax
8010126a:	83 ec 0c             	sub    $0xc,%esp
8010126d:	50                   	push   %eax
8010126e:	e8 a3 07 00 00       	call   80101a16 <ilock>
80101273:	83 c4 10             	add    $0x10,%esp
    if((r = readi(f->ip, addr, f->off, n)) > 0)
80101276:	8b 4d 10             	mov    0x10(%ebp),%ecx
80101279:	8b 45 08             	mov    0x8(%ebp),%eax
8010127c:	8b 50 14             	mov    0x14(%eax),%edx
8010127f:	8b 45 08             	mov    0x8(%ebp),%eax
80101282:	8b 40 10             	mov    0x10(%eax),%eax
80101285:	51                   	push   %ecx
80101286:	52                   	push   %edx
80101287:	ff 75 0c             	push   0xc(%ebp)
8010128a:	50                   	push   %eax
8010128b:	e8 72 0c 00 00       	call   80101f02 <readi>
80101290:	83 c4 10             	add    $0x10,%esp
80101293:	89 45 f4             	mov    %eax,-0xc(%ebp)
80101296:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
8010129a:	7e 11                	jle    801012ad <fileread+0x92>
      f->off += r;
8010129c:	8b 45 08             	mov    0x8(%ebp),%eax
8010129f:	8b 50 14             	mov    0x14(%eax),%edx
801012a2:	8b 45 f4             	mov    -0xc(%ebp),%eax
801012a5:	01 c2                	add    %eax,%edx
801012a7:	8b 45 08             	mov    0x8(%ebp),%eax
801012aa:	89 50 14             	mov    %edx,0x14(%eax)
    iunlock(f->ip);
801012ad:	8b 45 08             	mov    0x8(%ebp),%eax
801012b0:	8b 40 10             	mov    0x10(%eax),%eax
801012b3:	83 ec 0c             	sub    $0xc,%esp
801012b6:	50                   	push   %eax
801012b7:	e8 6d 08 00 00       	call   80101b29 <iunlock>
801012bc:	83 c4 10             	add    $0x10,%esp
    return r;
801012bf:	8b 45 f4             	mov    -0xc(%ebp),%eax
801012c2:	eb 0d                	jmp    801012d1 <fileread+0xb6>
  }
  panic("fileread");
801012c4:	83 ec 0c             	sub    $0xc,%esp
801012c7:	68 fb 84 10 80       	push   $0x801084fb
801012cc:	e8 e2 f2 ff ff       	call   801005b3 <panic>
}
801012d1:	c9                   	leave
801012d2:	c3                   	ret

801012d3 <filewrite>:

//PAGEBREAK!
// Write to file f.
int
filewrite(struct file *f, char *addr, int n)
{
801012d3:	55                   	push   %ebp
801012d4:	89 e5                	mov    %esp,%ebp
801012d6:	53                   	push   %ebx
801012d7:	83 ec 14             	sub    $0x14,%esp
  int r;

  if(f->writable == 0)
801012da:	8b 45 08             	mov    0x8(%ebp),%eax
801012dd:	0f b6 40 09          	movzbl 0x9(%eax),%eax
801012e1:	84 c0                	test   %al,%al
801012e3:	75 0a                	jne    801012ef <filewrite+0x1c>
    return -1;
801012e5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801012ea:	e9 1b 01 00 00       	jmp    8010140a <filewrite+0x137>
  if(f->type == FD_PIPE)
801012ef:	8b 45 08             	mov    0x8(%ebp),%eax
801012f2:	8b 00                	mov    (%eax),%eax
801012f4:	83 f8 01             	cmp    $0x1,%eax
801012f7:	75 1d                	jne    80101316 <filewrite+0x43>
    return pipewrite(f->pipe, addr, n);
801012f9:	8b 45 08             	mov    0x8(%ebp),%eax
801012fc:	8b 40 0c             	mov    0xc(%eax),%eax
801012ff:	83 ec 04             	sub    $0x4,%esp
80101302:	ff 75 10             	push   0x10(%ebp)
80101305:	ff 75 0c             	push   0xc(%ebp)
80101308:	50                   	push   %eax
80101309:	e8 b1 2c 00 00       	call   80103fbf <pipewrite>
8010130e:	83 c4 10             	add    $0x10,%esp
80101311:	e9 f4 00 00 00       	jmp    8010140a <filewrite+0x137>
  if(f->type == FD_INODE){
80101316:	8b 45 08             	mov    0x8(%ebp),%eax
80101319:	8b 00                	mov    (%eax),%eax
8010131b:	83 f8 02             	cmp    $0x2,%eax
8010131e:	0f 85 d9 00 00 00    	jne    801013fd <filewrite+0x12a>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
80101324:	c7 45 ec 00 06 00 00 	movl   $0x600,-0x14(%ebp)
    int i = 0;
8010132b:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    while(i < n){
80101332:	e9 a3 00 00 00       	jmp    801013da <filewrite+0x107>
      int n1 = n - i;
80101337:	8b 45 10             	mov    0x10(%ebp),%eax
8010133a:	2b 45 f4             	sub    -0xc(%ebp),%eax
8010133d:	89 45 f0             	mov    %eax,-0x10(%ebp)
      if(n1 > max)
80101340:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101343:	3b 45 ec             	cmp    -0x14(%ebp),%eax
80101346:	7e 06                	jle    8010134e <filewrite+0x7b>
        n1 = max;
80101348:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010134b:	89 45 f0             	mov    %eax,-0x10(%ebp)

      begin_op();
8010134e:	e8 cf 21 00 00       	call   80103522 <begin_op>
      ilock(f->ip);
80101353:	8b 45 08             	mov    0x8(%ebp),%eax
80101356:	8b 40 10             	mov    0x10(%eax),%eax
80101359:	83 ec 0c             	sub    $0xc,%esp
8010135c:	50                   	push   %eax
8010135d:	e8 b4 06 00 00       	call   80101a16 <ilock>
80101362:	83 c4 10             	add    $0x10,%esp
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
80101365:	8b 4d f0             	mov    -0x10(%ebp),%ecx
80101368:	8b 45 08             	mov    0x8(%ebp),%eax
8010136b:	8b 50 14             	mov    0x14(%eax),%edx
8010136e:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80101371:	8b 45 0c             	mov    0xc(%ebp),%eax
80101374:	01 c3                	add    %eax,%ebx
80101376:	8b 45 08             	mov    0x8(%ebp),%eax
80101379:	8b 40 10             	mov    0x10(%eax),%eax
8010137c:	51                   	push   %ecx
8010137d:	52                   	push   %edx
8010137e:	53                   	push   %ebx
8010137f:	50                   	push   %eax
80101380:	e8 d2 0c 00 00       	call   80102057 <writei>
80101385:	83 c4 10             	add    $0x10,%esp
80101388:	89 45 e8             	mov    %eax,-0x18(%ebp)
8010138b:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
8010138f:	7e 11                	jle    801013a2 <filewrite+0xcf>
        f->off += r;
80101391:	8b 45 08             	mov    0x8(%ebp),%eax
80101394:	8b 50 14             	mov    0x14(%eax),%edx
80101397:	8b 45 e8             	mov    -0x18(%ebp),%eax
8010139a:	01 c2                	add    %eax,%edx
8010139c:	8b 45 08             	mov    0x8(%ebp),%eax
8010139f:	89 50 14             	mov    %edx,0x14(%eax)
      iunlock(f->ip);
801013a2:	8b 45 08             	mov    0x8(%ebp),%eax
801013a5:	8b 40 10             	mov    0x10(%eax),%eax
801013a8:	83 ec 0c             	sub    $0xc,%esp
801013ab:	50                   	push   %eax
801013ac:	e8 78 07 00 00       	call   80101b29 <iunlock>
801013b1:	83 c4 10             	add    $0x10,%esp
      end_op();
801013b4:	e8 f5 21 00 00       	call   801035ae <end_op>

      if(r < 0)
801013b9:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
801013bd:	78 29                	js     801013e8 <filewrite+0x115>
        break;
      if(r != n1)
801013bf:	8b 45 e8             	mov    -0x18(%ebp),%eax
801013c2:	3b 45 f0             	cmp    -0x10(%ebp),%eax
801013c5:	74 0d                	je     801013d4 <filewrite+0x101>
        panic("short filewrite");
801013c7:	83 ec 0c             	sub    $0xc,%esp
801013ca:	68 04 85 10 80       	push   $0x80108504
801013cf:	e8 df f1 ff ff       	call   801005b3 <panic>
      i += r;
801013d4:	8b 45 e8             	mov    -0x18(%ebp),%eax
801013d7:	01 45 f4             	add    %eax,-0xc(%ebp)
    while(i < n){
801013da:	8b 45 f4             	mov    -0xc(%ebp),%eax
801013dd:	3b 45 10             	cmp    0x10(%ebp),%eax
801013e0:	0f 8c 51 ff ff ff    	jl     80101337 <filewrite+0x64>
801013e6:	eb 01                	jmp    801013e9 <filewrite+0x116>
        break;
801013e8:	90                   	nop
    }
    return i == n ? n : -1;
801013e9:	8b 45 f4             	mov    -0xc(%ebp),%eax
801013ec:	3b 45 10             	cmp    0x10(%ebp),%eax
801013ef:	75 05                	jne    801013f6 <filewrite+0x123>
801013f1:	8b 45 10             	mov    0x10(%ebp),%eax
801013f4:	eb 14                	jmp    8010140a <filewrite+0x137>
801013f6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801013fb:	eb 0d                	jmp    8010140a <filewrite+0x137>
  }
  panic("filewrite");
801013fd:	83 ec 0c             	sub    $0xc,%esp
80101400:	68 14 85 10 80       	push   $0x80108514
80101405:	e8 a9 f1 ff ff       	call   801005b3 <panic>
}
8010140a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010140d:	c9                   	leave
8010140e:	c3                   	ret

8010140f <readsb>:
struct superblock sb; 

// Read the super block.
void
readsb(int dev, struct superblock *sb)
{
8010140f:	55                   	push   %ebp
80101410:	89 e5                	mov    %esp,%ebp
80101412:	83 ec 18             	sub    $0x18,%esp
  struct buf *bp;

  bp = bread(dev, 1);
80101415:	8b 45 08             	mov    0x8(%ebp),%eax
80101418:	83 ec 08             	sub    $0x8,%esp
8010141b:	6a 01                	push   $0x1
8010141d:	50                   	push   %eax
8010141e:	e8 ac ed ff ff       	call   801001cf <bread>
80101423:	83 c4 10             	add    $0x10,%esp
80101426:	89 45 f4             	mov    %eax,-0xc(%ebp)
  memmove(sb, bp->data, sizeof(*sb));
80101429:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010142c:	83 c0 5c             	add    $0x5c,%eax
8010142f:	83 ec 04             	sub    $0x4,%esp
80101432:	6a 1c                	push   $0x1c
80101434:	50                   	push   %eax
80101435:	ff 75 0c             	push   0xc(%ebp)
80101438:	e8 f1 3e 00 00       	call   8010532e <memmove>
8010143d:	83 c4 10             	add    $0x10,%esp
  brelse(bp);
80101440:	83 ec 0c             	sub    $0xc,%esp
80101443:	ff 75 f4             	push   -0xc(%ebp)
80101446:	e8 06 ee ff ff       	call   80100251 <brelse>
8010144b:	83 c4 10             	add    $0x10,%esp
}
8010144e:	90                   	nop
8010144f:	c9                   	leave
80101450:	c3                   	ret

80101451 <bzero>:

// Zero a block.
static void
bzero(int dev, int bno)
{
80101451:	55                   	push   %ebp
80101452:	89 e5                	mov    %esp,%ebp
80101454:	83 ec 18             	sub    $0x18,%esp
  struct buf *bp;

  bp = bread(dev, bno);
80101457:	8b 55 0c             	mov    0xc(%ebp),%edx
8010145a:	8b 45 08             	mov    0x8(%ebp),%eax
8010145d:	83 ec 08             	sub    $0x8,%esp
80101460:	52                   	push   %edx
80101461:	50                   	push   %eax
80101462:	e8 68 ed ff ff       	call   801001cf <bread>
80101467:	83 c4 10             	add    $0x10,%esp
8010146a:	89 45 f4             	mov    %eax,-0xc(%ebp)
  memset(bp->data, 0, BSIZE);
8010146d:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101470:	83 c0 5c             	add    $0x5c,%eax
80101473:	83 ec 04             	sub    $0x4,%esp
80101476:	68 00 02 00 00       	push   $0x200
8010147b:	6a 00                	push   $0x0
8010147d:	50                   	push   %eax
8010147e:	e8 ec 3d 00 00       	call   8010526f <memset>
80101483:	83 c4 10             	add    $0x10,%esp
  log_write(bp);
80101486:	83 ec 0c             	sub    $0xc,%esp
80101489:	ff 75 f4             	push   -0xc(%ebp)
8010148c:	e8 ca 22 00 00       	call   8010375b <log_write>
80101491:	83 c4 10             	add    $0x10,%esp
  brelse(bp);
80101494:	83 ec 0c             	sub    $0xc,%esp
80101497:	ff 75 f4             	push   -0xc(%ebp)
8010149a:	e8 b2 ed ff ff       	call   80100251 <brelse>
8010149f:	83 c4 10             	add    $0x10,%esp
}
801014a2:	90                   	nop
801014a3:	c9                   	leave
801014a4:	c3                   	ret

801014a5 <balloc>:
// Blocks.

// Allocate a zeroed disk block.
static uint
balloc(uint dev)
{
801014a5:	55                   	push   %ebp
801014a6:	89 e5                	mov    %esp,%ebp
801014a8:	83 ec 18             	sub    $0x18,%esp
  int b, bi, m;
  struct buf *bp;

  bp = 0;
801014ab:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  for(b = 0; b < sb.size; b += BPB){
801014b2:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
801014b9:	e9 0b 01 00 00       	jmp    801015c9 <balloc+0x124>
    bp = bread(dev, BBLOCK(b, sb));
801014be:	8b 45 f4             	mov    -0xc(%ebp),%eax
801014c1:	8d 90 ff 0f 00 00    	lea    0xfff(%eax),%edx
801014c7:	85 c0                	test   %eax,%eax
801014c9:	0f 48 c2             	cmovs  %edx,%eax
801014cc:	c1 f8 0c             	sar    $0xc,%eax
801014cf:	89 c2                	mov    %eax,%edx
801014d1:	a1 f8 09 11 80       	mov    0x801109f8,%eax
801014d6:	01 d0                	add    %edx,%eax
801014d8:	83 ec 08             	sub    $0x8,%esp
801014db:	50                   	push   %eax
801014dc:	ff 75 08             	push   0x8(%ebp)
801014df:	e8 eb ec ff ff       	call   801001cf <bread>
801014e4:	83 c4 10             	add    $0x10,%esp
801014e7:	89 45 ec             	mov    %eax,-0x14(%ebp)
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
801014ea:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
801014f1:	e9 9e 00 00 00       	jmp    80101594 <balloc+0xef>
      m = 1 << (bi % 8);
801014f6:	8b 45 f0             	mov    -0x10(%ebp),%eax
801014f9:	83 e0 07             	and    $0x7,%eax
801014fc:	ba 01 00 00 00       	mov    $0x1,%edx
80101501:	89 c1                	mov    %eax,%ecx
80101503:	d3 e2                	shl    %cl,%edx
80101505:	89 d0                	mov    %edx,%eax
80101507:	89 45 e8             	mov    %eax,-0x18(%ebp)
      if((bp->data[bi/8] & m) == 0){  // Is block free?
8010150a:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010150d:	8d 50 07             	lea    0x7(%eax),%edx
80101510:	85 c0                	test   %eax,%eax
80101512:	0f 48 c2             	cmovs  %edx,%eax
80101515:	c1 f8 03             	sar    $0x3,%eax
80101518:	89 c2                	mov    %eax,%edx
8010151a:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010151d:	0f b6 44 10 5c       	movzbl 0x5c(%eax,%edx,1),%eax
80101522:	0f b6 c0             	movzbl %al,%eax
80101525:	23 45 e8             	and    -0x18(%ebp),%eax
80101528:	85 c0                	test   %eax,%eax
8010152a:	75 64                	jne    80101590 <balloc+0xeb>
        bp->data[bi/8] |= m;  // Mark block in use.
8010152c:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010152f:	8d 50 07             	lea    0x7(%eax),%edx
80101532:	85 c0                	test   %eax,%eax
80101534:	0f 48 c2             	cmovs  %edx,%eax
80101537:	c1 f8 03             	sar    $0x3,%eax
8010153a:	8b 55 ec             	mov    -0x14(%ebp),%edx
8010153d:	0f b6 54 02 5c       	movzbl 0x5c(%edx,%eax,1),%edx
80101542:	89 d1                	mov    %edx,%ecx
80101544:	8b 55 e8             	mov    -0x18(%ebp),%edx
80101547:	09 ca                	or     %ecx,%edx
80101549:	89 d1                	mov    %edx,%ecx
8010154b:	8b 55 ec             	mov    -0x14(%ebp),%edx
8010154e:	88 4c 02 5c          	mov    %cl,0x5c(%edx,%eax,1)
        log_write(bp);
80101552:	83 ec 0c             	sub    $0xc,%esp
80101555:	ff 75 ec             	push   -0x14(%ebp)
80101558:	e8 fe 21 00 00       	call   8010375b <log_write>
8010155d:	83 c4 10             	add    $0x10,%esp
        brelse(bp);
80101560:	83 ec 0c             	sub    $0xc,%esp
80101563:	ff 75 ec             	push   -0x14(%ebp)
80101566:	e8 e6 ec ff ff       	call   80100251 <brelse>
8010156b:	83 c4 10             	add    $0x10,%esp
        bzero(dev, b + bi);
8010156e:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101571:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101574:	01 c2                	add    %eax,%edx
80101576:	8b 45 08             	mov    0x8(%ebp),%eax
80101579:	83 ec 08             	sub    $0x8,%esp
8010157c:	52                   	push   %edx
8010157d:	50                   	push   %eax
8010157e:	e8 ce fe ff ff       	call   80101451 <bzero>
80101583:	83 c4 10             	add    $0x10,%esp
        return b + bi;
80101586:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101589:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010158c:	01 d0                	add    %edx,%eax
8010158e:	eb 56                	jmp    801015e6 <balloc+0x141>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
80101590:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
80101594:	81 7d f0 ff 0f 00 00 	cmpl   $0xfff,-0x10(%ebp)
8010159b:	7f 17                	jg     801015b4 <balloc+0x10f>
8010159d:	8b 55 f4             	mov    -0xc(%ebp),%edx
801015a0:	8b 45 f0             	mov    -0x10(%ebp),%eax
801015a3:	01 d0                	add    %edx,%eax
801015a5:	89 c2                	mov    %eax,%edx
801015a7:	a1 e0 09 11 80       	mov    0x801109e0,%eax
801015ac:	39 c2                	cmp    %eax,%edx
801015ae:	0f 82 42 ff ff ff    	jb     801014f6 <balloc+0x51>
      }
    }
    brelse(bp);
801015b4:	83 ec 0c             	sub    $0xc,%esp
801015b7:	ff 75 ec             	push   -0x14(%ebp)
801015ba:	e8 92 ec ff ff       	call   80100251 <brelse>
801015bf:	83 c4 10             	add    $0x10,%esp
  for(b = 0; b < sb.size; b += BPB){
801015c2:	81 45 f4 00 10 00 00 	addl   $0x1000,-0xc(%ebp)
801015c9:	a1 e0 09 11 80       	mov    0x801109e0,%eax
801015ce:	8b 55 f4             	mov    -0xc(%ebp),%edx
801015d1:	39 c2                	cmp    %eax,%edx
801015d3:	0f 82 e5 fe ff ff    	jb     801014be <balloc+0x19>
  }
  panic("balloc: out of blocks");
801015d9:	83 ec 0c             	sub    $0xc,%esp
801015dc:	68 20 85 10 80       	push   $0x80108520
801015e1:	e8 cd ef ff ff       	call   801005b3 <panic>
}
801015e6:	c9                   	leave
801015e7:	c3                   	ret

801015e8 <bfree>:

// Free a disk block.
static void
bfree(int dev, uint b)
{
801015e8:	55                   	push   %ebp
801015e9:	89 e5                	mov    %esp,%ebp
801015eb:	83 ec 18             	sub    $0x18,%esp
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
801015ee:	8b 45 0c             	mov    0xc(%ebp),%eax
801015f1:	c1 e8 0c             	shr    $0xc,%eax
801015f4:	89 c2                	mov    %eax,%edx
801015f6:	a1 f8 09 11 80       	mov    0x801109f8,%eax
801015fb:	01 c2                	add    %eax,%edx
801015fd:	8b 45 08             	mov    0x8(%ebp),%eax
80101600:	83 ec 08             	sub    $0x8,%esp
80101603:	52                   	push   %edx
80101604:	50                   	push   %eax
80101605:	e8 c5 eb ff ff       	call   801001cf <bread>
8010160a:	83 c4 10             	add    $0x10,%esp
8010160d:	89 45 f4             	mov    %eax,-0xc(%ebp)
  bi = b % BPB;
80101610:	8b 45 0c             	mov    0xc(%ebp),%eax
80101613:	25 ff 0f 00 00       	and    $0xfff,%eax
80101618:	89 45 f0             	mov    %eax,-0x10(%ebp)
  m = 1 << (bi % 8);
8010161b:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010161e:	83 e0 07             	and    $0x7,%eax
80101621:	ba 01 00 00 00       	mov    $0x1,%edx
80101626:	89 c1                	mov    %eax,%ecx
80101628:	d3 e2                	shl    %cl,%edx
8010162a:	89 d0                	mov    %edx,%eax
8010162c:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if((bp->data[bi/8] & m) == 0)
8010162f:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101632:	8d 50 07             	lea    0x7(%eax),%edx
80101635:	85 c0                	test   %eax,%eax
80101637:	0f 48 c2             	cmovs  %edx,%eax
8010163a:	c1 f8 03             	sar    $0x3,%eax
8010163d:	89 c2                	mov    %eax,%edx
8010163f:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101642:	0f b6 44 10 5c       	movzbl 0x5c(%eax,%edx,1),%eax
80101647:	0f b6 c0             	movzbl %al,%eax
8010164a:	23 45 ec             	and    -0x14(%ebp),%eax
8010164d:	85 c0                	test   %eax,%eax
8010164f:	75 0d                	jne    8010165e <bfree+0x76>
    panic("freeing free block");
80101651:	83 ec 0c             	sub    $0xc,%esp
80101654:	68 36 85 10 80       	push   $0x80108536
80101659:	e8 55 ef ff ff       	call   801005b3 <panic>
  bp->data[bi/8] &= ~m;
8010165e:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101661:	8d 50 07             	lea    0x7(%eax),%edx
80101664:	85 c0                	test   %eax,%eax
80101666:	0f 48 c2             	cmovs  %edx,%eax
80101669:	c1 f8 03             	sar    $0x3,%eax
8010166c:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010166f:	0f b6 54 02 5c       	movzbl 0x5c(%edx,%eax,1),%edx
80101674:	89 d1                	mov    %edx,%ecx
80101676:	8b 55 ec             	mov    -0x14(%ebp),%edx
80101679:	f7 d2                	not    %edx
8010167b:	21 ca                	and    %ecx,%edx
8010167d:	89 d1                	mov    %edx,%ecx
8010167f:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101682:	88 4c 02 5c          	mov    %cl,0x5c(%edx,%eax,1)
  log_write(bp);
80101686:	83 ec 0c             	sub    $0xc,%esp
80101689:	ff 75 f4             	push   -0xc(%ebp)
8010168c:	e8 ca 20 00 00       	call   8010375b <log_write>
80101691:	83 c4 10             	add    $0x10,%esp
  brelse(bp);
80101694:	83 ec 0c             	sub    $0xc,%esp
80101697:	ff 75 f4             	push   -0xc(%ebp)
8010169a:	e8 b2 eb ff ff       	call   80100251 <brelse>
8010169f:	83 c4 10             	add    $0x10,%esp
}
801016a2:	90                   	nop
801016a3:	c9                   	leave
801016a4:	c3                   	ret

801016a5 <iinit>:
  struct inode inode[NINODE];
} icache;

void
iinit(int dev)
{
801016a5:	55                   	push   %ebp
801016a6:	89 e5                	mov    %esp,%ebp
801016a8:	57                   	push   %edi
801016a9:	56                   	push   %esi
801016aa:	53                   	push   %ebx
801016ab:	83 ec 2c             	sub    $0x2c,%esp
  int i = 0;
801016ae:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
  
  initlock(&icache.lock, "icache");
801016b5:	83 ec 08             	sub    $0x8,%esp
801016b8:	68 49 85 10 80       	push   $0x80108549
801016bd:	68 00 0a 11 80       	push   $0x80110a00
801016c2:	e8 00 39 00 00       	call   80104fc7 <initlock>
801016c7:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < NINODE; i++) {
801016ca:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
801016d1:	eb 2d                	jmp    80101700 <iinit+0x5b>
    initsleeplock(&icache.inode[i].lock, "inode");
801016d3:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801016d6:	89 d0                	mov    %edx,%eax
801016d8:	c1 e0 03             	shl    $0x3,%eax
801016db:	01 d0                	add    %edx,%eax
801016dd:	c1 e0 04             	shl    $0x4,%eax
801016e0:	83 c0 30             	add    $0x30,%eax
801016e3:	05 00 0a 11 80       	add    $0x80110a00,%eax
801016e8:	83 c0 10             	add    $0x10,%eax
801016eb:	83 ec 08             	sub    $0x8,%esp
801016ee:	68 50 85 10 80       	push   $0x80108550
801016f3:	50                   	push   %eax
801016f4:	e8 4b 37 00 00       	call   80104e44 <initsleeplock>
801016f9:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < NINODE; i++) {
801016fc:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
80101700:	83 7d e4 31          	cmpl   $0x31,-0x1c(%ebp)
80101704:	7e cd                	jle    801016d3 <iinit+0x2e>
  }

  readsb(dev, &sb);
80101706:	83 ec 08             	sub    $0x8,%esp
80101709:	68 e0 09 11 80       	push   $0x801109e0
8010170e:	ff 75 08             	push   0x8(%ebp)
80101711:	e8 f9 fc ff ff       	call   8010140f <readsb>
80101716:	83 c4 10             	add    $0x10,%esp
  cprintf("sb: size %d nblocks %d ninodes %d nlog %d logstart %d\
80101719:	a1 f8 09 11 80       	mov    0x801109f8,%eax
8010171e:	89 45 d4             	mov    %eax,-0x2c(%ebp)
80101721:	8b 3d f4 09 11 80    	mov    0x801109f4,%edi
80101727:	8b 35 f0 09 11 80    	mov    0x801109f0,%esi
8010172d:	8b 1d ec 09 11 80    	mov    0x801109ec,%ebx
80101733:	8b 0d e8 09 11 80    	mov    0x801109e8,%ecx
80101739:	8b 15 e4 09 11 80    	mov    0x801109e4,%edx
8010173f:	a1 e0 09 11 80       	mov    0x801109e0,%eax
80101744:	ff 75 d4             	push   -0x2c(%ebp)
80101747:	57                   	push   %edi
80101748:	56                   	push   %esi
80101749:	53                   	push   %ebx
8010174a:	51                   	push   %ecx
8010174b:	52                   	push   %edx
8010174c:	50                   	push   %eax
8010174d:	68 58 85 10 80       	push   $0x80108558
80101752:	e8 a7 ec ff ff       	call   801003fe <cprintf>
80101757:	83 c4 20             	add    $0x20,%esp
 inodestart %d bmap start %d\n", sb.size, sb.nblocks,
          sb.ninodes, sb.nlog, sb.logstart, sb.inodestart,
          sb.bmapstart);
}
8010175a:	90                   	nop
8010175b:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010175e:	5b                   	pop    %ebx
8010175f:	5e                   	pop    %esi
80101760:	5f                   	pop    %edi
80101761:	5d                   	pop    %ebp
80101762:	c3                   	ret

80101763 <ialloc>:
// Allocate an inode on device dev.
// Mark it as allocated by  giving it type type.
// Returns an unlocked but allocated and referenced inode.
struct inode*
ialloc(uint dev, short type)
{
80101763:	55                   	push   %ebp
80101764:	89 e5                	mov    %esp,%ebp
80101766:	83 ec 28             	sub    $0x28,%esp
80101769:	8b 45 0c             	mov    0xc(%ebp),%eax
8010176c:	66 89 45 e4          	mov    %ax,-0x1c(%ebp)
  int inum;
  struct buf *bp;
  struct dinode *dip;

  for(inum = 1; inum < sb.ninodes; inum++){
80101770:	c7 45 f4 01 00 00 00 	movl   $0x1,-0xc(%ebp)
80101777:	e9 9e 00 00 00       	jmp    8010181a <ialloc+0xb7>
    bp = bread(dev, IBLOCK(inum, sb));
8010177c:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010177f:	c1 e8 03             	shr    $0x3,%eax
80101782:	89 c2                	mov    %eax,%edx
80101784:	a1 f4 09 11 80       	mov    0x801109f4,%eax
80101789:	01 d0                	add    %edx,%eax
8010178b:	83 ec 08             	sub    $0x8,%esp
8010178e:	50                   	push   %eax
8010178f:	ff 75 08             	push   0x8(%ebp)
80101792:	e8 38 ea ff ff       	call   801001cf <bread>
80101797:	83 c4 10             	add    $0x10,%esp
8010179a:	89 45 f0             	mov    %eax,-0x10(%ebp)
    dip = (struct dinode*)bp->data + inum%IPB;
8010179d:	8b 45 f0             	mov    -0x10(%ebp),%eax
801017a0:	8d 50 5c             	lea    0x5c(%eax),%edx
801017a3:	8b 45 f4             	mov    -0xc(%ebp),%eax
801017a6:	83 e0 07             	and    $0x7,%eax
801017a9:	c1 e0 06             	shl    $0x6,%eax
801017ac:	01 d0                	add    %edx,%eax
801017ae:	89 45 ec             	mov    %eax,-0x14(%ebp)
    if(dip->type == 0){  // a free inode
801017b1:	8b 45 ec             	mov    -0x14(%ebp),%eax
801017b4:	0f b7 00             	movzwl (%eax),%eax
801017b7:	66 85 c0             	test   %ax,%ax
801017ba:	75 4c                	jne    80101808 <ialloc+0xa5>
      memset(dip, 0, sizeof(*dip));
801017bc:	83 ec 04             	sub    $0x4,%esp
801017bf:	6a 40                	push   $0x40
801017c1:	6a 00                	push   $0x0
801017c3:	ff 75 ec             	push   -0x14(%ebp)
801017c6:	e8 a4 3a 00 00       	call   8010526f <memset>
801017cb:	83 c4 10             	add    $0x10,%esp
      dip->type = type;
801017ce:	8b 45 ec             	mov    -0x14(%ebp),%eax
801017d1:	0f b7 55 e4          	movzwl -0x1c(%ebp),%edx
801017d5:	66 89 10             	mov    %dx,(%eax)
      log_write(bp);   // mark it allocated on the disk
801017d8:	83 ec 0c             	sub    $0xc,%esp
801017db:	ff 75 f0             	push   -0x10(%ebp)
801017de:	e8 78 1f 00 00       	call   8010375b <log_write>
801017e3:	83 c4 10             	add    $0x10,%esp
      brelse(bp);
801017e6:	83 ec 0c             	sub    $0xc,%esp
801017e9:	ff 75 f0             	push   -0x10(%ebp)
801017ec:	e8 60 ea ff ff       	call   80100251 <brelse>
801017f1:	83 c4 10             	add    $0x10,%esp
      return iget(dev, inum);
801017f4:	8b 45 f4             	mov    -0xc(%ebp),%eax
801017f7:	83 ec 08             	sub    $0x8,%esp
801017fa:	50                   	push   %eax
801017fb:	ff 75 08             	push   0x8(%ebp)
801017fe:	e8 f7 00 00 00       	call   801018fa <iget>
80101803:	83 c4 10             	add    $0x10,%esp
80101806:	eb 2f                	jmp    80101837 <ialloc+0xd4>
    }
    brelse(bp);
80101808:	83 ec 0c             	sub    $0xc,%esp
8010180b:	ff 75 f0             	push   -0x10(%ebp)
8010180e:	e8 3e ea ff ff       	call   80100251 <brelse>
80101813:	83 c4 10             	add    $0x10,%esp
  for(inum = 1; inum < sb.ninodes; inum++){
80101816:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
8010181a:	a1 e8 09 11 80       	mov    0x801109e8,%eax
8010181f:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101822:	39 c2                	cmp    %eax,%edx
80101824:	0f 82 52 ff ff ff    	jb     8010177c <ialloc+0x19>
  }
  panic("ialloc: no inodes");
8010182a:	83 ec 0c             	sub    $0xc,%esp
8010182d:	68 ab 85 10 80       	push   $0x801085ab
80101832:	e8 7c ed ff ff       	call   801005b3 <panic>
}
80101837:	c9                   	leave
80101838:	c3                   	ret

80101839 <iupdate>:
// Must be called after every change to an ip->xxx field
// that lives on disk, since i-node cache is write-through.
// Caller must hold ip->lock.
void
iupdate(struct inode *ip)
{
80101839:	55                   	push   %ebp
8010183a:	89 e5                	mov    %esp,%ebp
8010183c:	83 ec 18             	sub    $0x18,%esp
  struct buf *bp;
  struct dinode *dip;

  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
8010183f:	8b 45 08             	mov    0x8(%ebp),%eax
80101842:	8b 40 04             	mov    0x4(%eax),%eax
80101845:	c1 e8 03             	shr    $0x3,%eax
80101848:	89 c2                	mov    %eax,%edx
8010184a:	a1 f4 09 11 80       	mov    0x801109f4,%eax
8010184f:	01 c2                	add    %eax,%edx
80101851:	8b 45 08             	mov    0x8(%ebp),%eax
80101854:	8b 00                	mov    (%eax),%eax
80101856:	83 ec 08             	sub    $0x8,%esp
80101859:	52                   	push   %edx
8010185a:	50                   	push   %eax
8010185b:	e8 6f e9 ff ff       	call   801001cf <bread>
80101860:	83 c4 10             	add    $0x10,%esp
80101863:	89 45 f4             	mov    %eax,-0xc(%ebp)
  dip = (struct dinode*)bp->data + ip->inum%IPB;
80101866:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101869:	8d 50 5c             	lea    0x5c(%eax),%edx
8010186c:	8b 45 08             	mov    0x8(%ebp),%eax
8010186f:	8b 40 04             	mov    0x4(%eax),%eax
80101872:	83 e0 07             	and    $0x7,%eax
80101875:	c1 e0 06             	shl    $0x6,%eax
80101878:	01 d0                	add    %edx,%eax
8010187a:	89 45 f0             	mov    %eax,-0x10(%ebp)
  dip->type = ip->type;
8010187d:	8b 45 08             	mov    0x8(%ebp),%eax
80101880:	0f b7 50 50          	movzwl 0x50(%eax),%edx
80101884:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101887:	66 89 10             	mov    %dx,(%eax)
  dip->major = ip->major;
8010188a:	8b 45 08             	mov    0x8(%ebp),%eax
8010188d:	0f b7 50 52          	movzwl 0x52(%eax),%edx
80101891:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101894:	66 89 50 02          	mov    %dx,0x2(%eax)
  dip->minor = ip->minor;
80101898:	8b 45 08             	mov    0x8(%ebp),%eax
8010189b:	0f b7 50 54          	movzwl 0x54(%eax),%edx
8010189f:	8b 45 f0             	mov    -0x10(%ebp),%eax
801018a2:	66 89 50 04          	mov    %dx,0x4(%eax)
  dip->nlink = ip->nlink;
801018a6:	8b 45 08             	mov    0x8(%ebp),%eax
801018a9:	0f b7 50 56          	movzwl 0x56(%eax),%edx
801018ad:	8b 45 f0             	mov    -0x10(%ebp),%eax
801018b0:	66 89 50 06          	mov    %dx,0x6(%eax)
  dip->size = ip->size;
801018b4:	8b 45 08             	mov    0x8(%ebp),%eax
801018b7:	8b 50 58             	mov    0x58(%eax),%edx
801018ba:	8b 45 f0             	mov    -0x10(%ebp),%eax
801018bd:	89 50 08             	mov    %edx,0x8(%eax)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801018c0:	8b 45 08             	mov    0x8(%ebp),%eax
801018c3:	8d 50 5c             	lea    0x5c(%eax),%edx
801018c6:	8b 45 f0             	mov    -0x10(%ebp),%eax
801018c9:	83 c0 0c             	add    $0xc,%eax
801018cc:	83 ec 04             	sub    $0x4,%esp
801018cf:	6a 34                	push   $0x34
801018d1:	52                   	push   %edx
801018d2:	50                   	push   %eax
801018d3:	e8 56 3a 00 00       	call   8010532e <memmove>
801018d8:	83 c4 10             	add    $0x10,%esp
  log_write(bp);
801018db:	83 ec 0c             	sub    $0xc,%esp
801018de:	ff 75 f4             	push   -0xc(%ebp)
801018e1:	e8 75 1e 00 00       	call   8010375b <log_write>
801018e6:	83 c4 10             	add    $0x10,%esp
  brelse(bp);
801018e9:	83 ec 0c             	sub    $0xc,%esp
801018ec:	ff 75 f4             	push   -0xc(%ebp)
801018ef:	e8 5d e9 ff ff       	call   80100251 <brelse>
801018f4:	83 c4 10             	add    $0x10,%esp
}
801018f7:	90                   	nop
801018f8:	c9                   	leave
801018f9:	c3                   	ret

801018fa <iget>:
// Find the inode with number inum on device dev
// and return the in-memory copy. Does not lock
// the inode and does not read it from disk.
static struct inode*
iget(uint dev, uint inum)
{
801018fa:	55                   	push   %ebp
801018fb:	89 e5                	mov    %esp,%ebp
801018fd:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip, *empty;

  acquire(&icache.lock);
80101900:	83 ec 0c             	sub    $0xc,%esp
80101903:	68 00 0a 11 80       	push   $0x80110a00
80101908:	e8 dc 36 00 00       	call   80104fe9 <acquire>
8010190d:	83 c4 10             	add    $0x10,%esp

  // Is the inode already cached?
  empty = 0;
80101910:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101917:	c7 45 f4 34 0a 11 80 	movl   $0x80110a34,-0xc(%ebp)
8010191e:	eb 60                	jmp    80101980 <iget+0x86>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101920:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101923:	8b 40 08             	mov    0x8(%eax),%eax
80101926:	85 c0                	test   %eax,%eax
80101928:	7e 39                	jle    80101963 <iget+0x69>
8010192a:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010192d:	8b 00                	mov    (%eax),%eax
8010192f:	39 45 08             	cmp    %eax,0x8(%ebp)
80101932:	75 2f                	jne    80101963 <iget+0x69>
80101934:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101937:	8b 40 04             	mov    0x4(%eax),%eax
8010193a:	39 45 0c             	cmp    %eax,0xc(%ebp)
8010193d:	75 24                	jne    80101963 <iget+0x69>
      ip->ref++;
8010193f:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101942:	8b 40 08             	mov    0x8(%eax),%eax
80101945:	8d 50 01             	lea    0x1(%eax),%edx
80101948:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010194b:	89 50 08             	mov    %edx,0x8(%eax)
      release(&icache.lock);
8010194e:	83 ec 0c             	sub    $0xc,%esp
80101951:	68 00 0a 11 80       	push   $0x80110a00
80101956:	e8 fc 36 00 00       	call   80105057 <release>
8010195b:	83 c4 10             	add    $0x10,%esp
      return ip;
8010195e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101961:	eb 77                	jmp    801019da <iget+0xe0>
    }
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
80101963:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80101967:	75 10                	jne    80101979 <iget+0x7f>
80101969:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010196c:	8b 40 08             	mov    0x8(%eax),%eax
8010196f:	85 c0                	test   %eax,%eax
80101971:	75 06                	jne    80101979 <iget+0x7f>
      empty = ip;
80101973:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101976:	89 45 f0             	mov    %eax,-0x10(%ebp)
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101979:	81 45 f4 90 00 00 00 	addl   $0x90,-0xc(%ebp)
80101980:	81 7d f4 54 26 11 80 	cmpl   $0x80112654,-0xc(%ebp)
80101987:	72 97                	jb     80101920 <iget+0x26>
  }

  // Recycle an inode cache entry.
  if(empty == 0)
80101989:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
8010198d:	75 0d                	jne    8010199c <iget+0xa2>
    panic("iget: no inodes");
8010198f:	83 ec 0c             	sub    $0xc,%esp
80101992:	68 bd 85 10 80       	push   $0x801085bd
80101997:	e8 17 ec ff ff       	call   801005b3 <panic>

  ip = empty;
8010199c:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010199f:	89 45 f4             	mov    %eax,-0xc(%ebp)
  ip->dev = dev;
801019a2:	8b 45 f4             	mov    -0xc(%ebp),%eax
801019a5:	8b 55 08             	mov    0x8(%ebp),%edx
801019a8:	89 10                	mov    %edx,(%eax)
  ip->inum = inum;
801019aa:	8b 45 f4             	mov    -0xc(%ebp),%eax
801019ad:	8b 55 0c             	mov    0xc(%ebp),%edx
801019b0:	89 50 04             	mov    %edx,0x4(%eax)
  ip->ref = 1;
801019b3:	8b 45 f4             	mov    -0xc(%ebp),%eax
801019b6:	c7 40 08 01 00 00 00 	movl   $0x1,0x8(%eax)
  ip->valid = 0;
801019bd:	8b 45 f4             	mov    -0xc(%ebp),%eax
801019c0:	c7 40 4c 00 00 00 00 	movl   $0x0,0x4c(%eax)
  release(&icache.lock);
801019c7:	83 ec 0c             	sub    $0xc,%esp
801019ca:	68 00 0a 11 80       	push   $0x80110a00
801019cf:	e8 83 36 00 00       	call   80105057 <release>
801019d4:	83 c4 10             	add    $0x10,%esp

  return ip;
801019d7:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
801019da:	c9                   	leave
801019db:	c3                   	ret

801019dc <idup>:

// Increment reference count for ip.
// Returns ip to enable ip = idup(ip1) idiom.
struct inode*
idup(struct inode *ip)
{
801019dc:	55                   	push   %ebp
801019dd:	89 e5                	mov    %esp,%ebp
801019df:	83 ec 08             	sub    $0x8,%esp
  acquire(&icache.lock);
801019e2:	83 ec 0c             	sub    $0xc,%esp
801019e5:	68 00 0a 11 80       	push   $0x80110a00
801019ea:	e8 fa 35 00 00       	call   80104fe9 <acquire>
801019ef:	83 c4 10             	add    $0x10,%esp
  ip->ref++;
801019f2:	8b 45 08             	mov    0x8(%ebp),%eax
801019f5:	8b 40 08             	mov    0x8(%eax),%eax
801019f8:	8d 50 01             	lea    0x1(%eax),%edx
801019fb:	8b 45 08             	mov    0x8(%ebp),%eax
801019fe:	89 50 08             	mov    %edx,0x8(%eax)
  release(&icache.lock);
80101a01:	83 ec 0c             	sub    $0xc,%esp
80101a04:	68 00 0a 11 80       	push   $0x80110a00
80101a09:	e8 49 36 00 00       	call   80105057 <release>
80101a0e:	83 c4 10             	add    $0x10,%esp
  return ip;
80101a11:	8b 45 08             	mov    0x8(%ebp),%eax
}
80101a14:	c9                   	leave
80101a15:	c3                   	ret

80101a16 <ilock>:

// Lock the given inode.
// Reads the inode from disk if necessary.
void
ilock(struct inode *ip)
{
80101a16:	55                   	push   %ebp
80101a17:	89 e5                	mov    %esp,%ebp
80101a19:	83 ec 18             	sub    $0x18,%esp
  struct buf *bp;
  struct dinode *dip;

  if(ip == 0 || ip->ref < 1)
80101a1c:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
80101a20:	74 0a                	je     80101a2c <ilock+0x16>
80101a22:	8b 45 08             	mov    0x8(%ebp),%eax
80101a25:	8b 40 08             	mov    0x8(%eax),%eax
80101a28:	85 c0                	test   %eax,%eax
80101a2a:	7f 0d                	jg     80101a39 <ilock+0x23>
    panic("ilock");
80101a2c:	83 ec 0c             	sub    $0xc,%esp
80101a2f:	68 cd 85 10 80       	push   $0x801085cd
80101a34:	e8 7a eb ff ff       	call   801005b3 <panic>

  acquiresleep(&ip->lock);
80101a39:	8b 45 08             	mov    0x8(%ebp),%eax
80101a3c:	83 c0 0c             	add    $0xc,%eax
80101a3f:	83 ec 0c             	sub    $0xc,%esp
80101a42:	50                   	push   %eax
80101a43:	e8 38 34 00 00       	call   80104e80 <acquiresleep>
80101a48:	83 c4 10             	add    $0x10,%esp

  if(ip->valid == 0){
80101a4b:	8b 45 08             	mov    0x8(%ebp),%eax
80101a4e:	8b 40 4c             	mov    0x4c(%eax),%eax
80101a51:	85 c0                	test   %eax,%eax
80101a53:	0f 85 cd 00 00 00    	jne    80101b26 <ilock+0x110>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
80101a59:	8b 45 08             	mov    0x8(%ebp),%eax
80101a5c:	8b 40 04             	mov    0x4(%eax),%eax
80101a5f:	c1 e8 03             	shr    $0x3,%eax
80101a62:	89 c2                	mov    %eax,%edx
80101a64:	a1 f4 09 11 80       	mov    0x801109f4,%eax
80101a69:	01 c2                	add    %eax,%edx
80101a6b:	8b 45 08             	mov    0x8(%ebp),%eax
80101a6e:	8b 00                	mov    (%eax),%eax
80101a70:	83 ec 08             	sub    $0x8,%esp
80101a73:	52                   	push   %edx
80101a74:	50                   	push   %eax
80101a75:	e8 55 e7 ff ff       	call   801001cf <bread>
80101a7a:	83 c4 10             	add    $0x10,%esp
80101a7d:	89 45 f4             	mov    %eax,-0xc(%ebp)
    dip = (struct dinode*)bp->data + ip->inum%IPB;
80101a80:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101a83:	8d 50 5c             	lea    0x5c(%eax),%edx
80101a86:	8b 45 08             	mov    0x8(%ebp),%eax
80101a89:	8b 40 04             	mov    0x4(%eax),%eax
80101a8c:	83 e0 07             	and    $0x7,%eax
80101a8f:	c1 e0 06             	shl    $0x6,%eax
80101a92:	01 d0                	add    %edx,%eax
80101a94:	89 45 f0             	mov    %eax,-0x10(%ebp)
    ip->type = dip->type;
80101a97:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101a9a:	0f b7 10             	movzwl (%eax),%edx
80101a9d:	8b 45 08             	mov    0x8(%ebp),%eax
80101aa0:	66 89 50 50          	mov    %dx,0x50(%eax)
    ip->major = dip->major;
80101aa4:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101aa7:	0f b7 50 02          	movzwl 0x2(%eax),%edx
80101aab:	8b 45 08             	mov    0x8(%ebp),%eax
80101aae:	66 89 50 52          	mov    %dx,0x52(%eax)
    ip->minor = dip->minor;
80101ab2:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101ab5:	0f b7 50 04          	movzwl 0x4(%eax),%edx
80101ab9:	8b 45 08             	mov    0x8(%ebp),%eax
80101abc:	66 89 50 54          	mov    %dx,0x54(%eax)
    ip->nlink = dip->nlink;
80101ac0:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101ac3:	0f b7 50 06          	movzwl 0x6(%eax),%edx
80101ac7:	8b 45 08             	mov    0x8(%ebp),%eax
80101aca:	66 89 50 56          	mov    %dx,0x56(%eax)
    ip->size = dip->size;
80101ace:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101ad1:	8b 50 08             	mov    0x8(%eax),%edx
80101ad4:	8b 45 08             	mov    0x8(%ebp),%eax
80101ad7:	89 50 58             	mov    %edx,0x58(%eax)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
80101ada:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101add:	8d 50 0c             	lea    0xc(%eax),%edx
80101ae0:	8b 45 08             	mov    0x8(%ebp),%eax
80101ae3:	83 c0 5c             	add    $0x5c,%eax
80101ae6:	83 ec 04             	sub    $0x4,%esp
80101ae9:	6a 34                	push   $0x34
80101aeb:	52                   	push   %edx
80101aec:	50                   	push   %eax
80101aed:	e8 3c 38 00 00       	call   8010532e <memmove>
80101af2:	83 c4 10             	add    $0x10,%esp
    brelse(bp);
80101af5:	83 ec 0c             	sub    $0xc,%esp
80101af8:	ff 75 f4             	push   -0xc(%ebp)
80101afb:	e8 51 e7 ff ff       	call   80100251 <brelse>
80101b00:	83 c4 10             	add    $0x10,%esp
    ip->valid = 1;
80101b03:	8b 45 08             	mov    0x8(%ebp),%eax
80101b06:	c7 40 4c 01 00 00 00 	movl   $0x1,0x4c(%eax)
    if(ip->type == 0)
80101b0d:	8b 45 08             	mov    0x8(%ebp),%eax
80101b10:	0f b7 40 50          	movzwl 0x50(%eax),%eax
80101b14:	66 85 c0             	test   %ax,%ax
80101b17:	75 0d                	jne    80101b26 <ilock+0x110>
      panic("ilock: no type");
80101b19:	83 ec 0c             	sub    $0xc,%esp
80101b1c:	68 d3 85 10 80       	push   $0x801085d3
80101b21:	e8 8d ea ff ff       	call   801005b3 <panic>
  }
}
80101b26:	90                   	nop
80101b27:	c9                   	leave
80101b28:	c3                   	ret

80101b29 <iunlock>:

// Unlock the given inode.
void
iunlock(struct inode *ip)
{
80101b29:	55                   	push   %ebp
80101b2a:	89 e5                	mov    %esp,%ebp
80101b2c:	83 ec 08             	sub    $0x8,%esp
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101b2f:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
80101b33:	74 20                	je     80101b55 <iunlock+0x2c>
80101b35:	8b 45 08             	mov    0x8(%ebp),%eax
80101b38:	83 c0 0c             	add    $0xc,%eax
80101b3b:	83 ec 0c             	sub    $0xc,%esp
80101b3e:	50                   	push   %eax
80101b3f:	e8 ee 33 00 00       	call   80104f32 <holdingsleep>
80101b44:	83 c4 10             	add    $0x10,%esp
80101b47:	85 c0                	test   %eax,%eax
80101b49:	74 0a                	je     80101b55 <iunlock+0x2c>
80101b4b:	8b 45 08             	mov    0x8(%ebp),%eax
80101b4e:	8b 40 08             	mov    0x8(%eax),%eax
80101b51:	85 c0                	test   %eax,%eax
80101b53:	7f 0d                	jg     80101b62 <iunlock+0x39>
    panic("iunlock");
80101b55:	83 ec 0c             	sub    $0xc,%esp
80101b58:	68 e2 85 10 80       	push   $0x801085e2
80101b5d:	e8 51 ea ff ff       	call   801005b3 <panic>

  releasesleep(&ip->lock);
80101b62:	8b 45 08             	mov    0x8(%ebp),%eax
80101b65:	83 c0 0c             	add    $0xc,%eax
80101b68:	83 ec 0c             	sub    $0xc,%esp
80101b6b:	50                   	push   %eax
80101b6c:	e8 73 33 00 00       	call   80104ee4 <releasesleep>
80101b71:	83 c4 10             	add    $0x10,%esp
}
80101b74:	90                   	nop
80101b75:	c9                   	leave
80101b76:	c3                   	ret

80101b77 <iput>:
// to it, free the inode (and its content) on disk.
// All calls to iput() must be inside a transaction in
// case it has to free the inode.
void
iput(struct inode *ip)
{
80101b77:	55                   	push   %ebp
80101b78:	89 e5                	mov    %esp,%ebp
80101b7a:	83 ec 18             	sub    $0x18,%esp
  acquiresleep(&ip->lock);
80101b7d:	8b 45 08             	mov    0x8(%ebp),%eax
80101b80:	83 c0 0c             	add    $0xc,%eax
80101b83:	83 ec 0c             	sub    $0xc,%esp
80101b86:	50                   	push   %eax
80101b87:	e8 f4 32 00 00       	call   80104e80 <acquiresleep>
80101b8c:	83 c4 10             	add    $0x10,%esp
  if(ip->valid && ip->nlink == 0){
80101b8f:	8b 45 08             	mov    0x8(%ebp),%eax
80101b92:	8b 40 4c             	mov    0x4c(%eax),%eax
80101b95:	85 c0                	test   %eax,%eax
80101b97:	74 6a                	je     80101c03 <iput+0x8c>
80101b99:	8b 45 08             	mov    0x8(%ebp),%eax
80101b9c:	0f b7 40 56          	movzwl 0x56(%eax),%eax
80101ba0:	66 85 c0             	test   %ax,%ax
80101ba3:	75 5e                	jne    80101c03 <iput+0x8c>
    acquire(&icache.lock);
80101ba5:	83 ec 0c             	sub    $0xc,%esp
80101ba8:	68 00 0a 11 80       	push   $0x80110a00
80101bad:	e8 37 34 00 00       	call   80104fe9 <acquire>
80101bb2:	83 c4 10             	add    $0x10,%esp
    int r = ip->ref;
80101bb5:	8b 45 08             	mov    0x8(%ebp),%eax
80101bb8:	8b 40 08             	mov    0x8(%eax),%eax
80101bbb:	89 45 f4             	mov    %eax,-0xc(%ebp)
    release(&icache.lock);
80101bbe:	83 ec 0c             	sub    $0xc,%esp
80101bc1:	68 00 0a 11 80       	push   $0x80110a00
80101bc6:	e8 8c 34 00 00       	call   80105057 <release>
80101bcb:	83 c4 10             	add    $0x10,%esp
    if(r == 1){
80101bce:	83 7d f4 01          	cmpl   $0x1,-0xc(%ebp)
80101bd2:	75 2f                	jne    80101c03 <iput+0x8c>
      // inode has no links and no other references: truncate and free.
      itrunc(ip);
80101bd4:	83 ec 0c             	sub    $0xc,%esp
80101bd7:	ff 75 08             	push   0x8(%ebp)
80101bda:	e8 ad 01 00 00       	call   80101d8c <itrunc>
80101bdf:	83 c4 10             	add    $0x10,%esp
      ip->type = 0;
80101be2:	8b 45 08             	mov    0x8(%ebp),%eax
80101be5:	66 c7 40 50 00 00    	movw   $0x0,0x50(%eax)
      iupdate(ip);
80101beb:	83 ec 0c             	sub    $0xc,%esp
80101bee:	ff 75 08             	push   0x8(%ebp)
80101bf1:	e8 43 fc ff ff       	call   80101839 <iupdate>
80101bf6:	83 c4 10             	add    $0x10,%esp
      ip->valid = 0;
80101bf9:	8b 45 08             	mov    0x8(%ebp),%eax
80101bfc:	c7 40 4c 00 00 00 00 	movl   $0x0,0x4c(%eax)
    }
  }
  releasesleep(&ip->lock);
80101c03:	8b 45 08             	mov    0x8(%ebp),%eax
80101c06:	83 c0 0c             	add    $0xc,%eax
80101c09:	83 ec 0c             	sub    $0xc,%esp
80101c0c:	50                   	push   %eax
80101c0d:	e8 d2 32 00 00       	call   80104ee4 <releasesleep>
80101c12:	83 c4 10             	add    $0x10,%esp

  acquire(&icache.lock);
80101c15:	83 ec 0c             	sub    $0xc,%esp
80101c18:	68 00 0a 11 80       	push   $0x80110a00
80101c1d:	e8 c7 33 00 00       	call   80104fe9 <acquire>
80101c22:	83 c4 10             	add    $0x10,%esp
  ip->ref--;
80101c25:	8b 45 08             	mov    0x8(%ebp),%eax
80101c28:	8b 40 08             	mov    0x8(%eax),%eax
80101c2b:	8d 50 ff             	lea    -0x1(%eax),%edx
80101c2e:	8b 45 08             	mov    0x8(%ebp),%eax
80101c31:	89 50 08             	mov    %edx,0x8(%eax)
  release(&icache.lock);
80101c34:	83 ec 0c             	sub    $0xc,%esp
80101c37:	68 00 0a 11 80       	push   $0x80110a00
80101c3c:	e8 16 34 00 00       	call   80105057 <release>
80101c41:	83 c4 10             	add    $0x10,%esp
}
80101c44:	90                   	nop
80101c45:	c9                   	leave
80101c46:	c3                   	ret

80101c47 <iunlockput>:

// Common idiom: unlock, then put.
void
iunlockput(struct inode *ip)
{
80101c47:	55                   	push   %ebp
80101c48:	89 e5                	mov    %esp,%ebp
80101c4a:	83 ec 08             	sub    $0x8,%esp
  iunlock(ip);
80101c4d:	83 ec 0c             	sub    $0xc,%esp
80101c50:	ff 75 08             	push   0x8(%ebp)
80101c53:	e8 d1 fe ff ff       	call   80101b29 <iunlock>
80101c58:	83 c4 10             	add    $0x10,%esp
  iput(ip);
80101c5b:	83 ec 0c             	sub    $0xc,%esp
80101c5e:	ff 75 08             	push   0x8(%ebp)
80101c61:	e8 11 ff ff ff       	call   80101b77 <iput>
80101c66:	83 c4 10             	add    $0x10,%esp
}
80101c69:	90                   	nop
80101c6a:	c9                   	leave
80101c6b:	c3                   	ret

80101c6c <bmap>:

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
80101c6c:	55                   	push   %ebp
80101c6d:	89 e5                	mov    %esp,%ebp
80101c6f:	83 ec 18             	sub    $0x18,%esp
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
80101c72:	83 7d 0c 0b          	cmpl   $0xb,0xc(%ebp)
80101c76:	77 42                	ja     80101cba <bmap+0x4e>
    if((addr = ip->addrs[bn]) == 0)
80101c78:	8b 45 08             	mov    0x8(%ebp),%eax
80101c7b:	8b 55 0c             	mov    0xc(%ebp),%edx
80101c7e:	83 c2 14             	add    $0x14,%edx
80101c81:	8b 44 90 0c          	mov    0xc(%eax,%edx,4),%eax
80101c85:	89 45 f4             	mov    %eax,-0xc(%ebp)
80101c88:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80101c8c:	75 24                	jne    80101cb2 <bmap+0x46>
      ip->addrs[bn] = addr = balloc(ip->dev);
80101c8e:	8b 45 08             	mov    0x8(%ebp),%eax
80101c91:	8b 00                	mov    (%eax),%eax
80101c93:	83 ec 0c             	sub    $0xc,%esp
80101c96:	50                   	push   %eax
80101c97:	e8 09 f8 ff ff       	call   801014a5 <balloc>
80101c9c:	83 c4 10             	add    $0x10,%esp
80101c9f:	89 45 f4             	mov    %eax,-0xc(%ebp)
80101ca2:	8b 45 08             	mov    0x8(%ebp),%eax
80101ca5:	8b 55 0c             	mov    0xc(%ebp),%edx
80101ca8:	8d 4a 14             	lea    0x14(%edx),%ecx
80101cab:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101cae:	89 54 88 0c          	mov    %edx,0xc(%eax,%ecx,4)
    return addr;
80101cb2:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101cb5:	e9 d0 00 00 00       	jmp    80101d8a <bmap+0x11e>
  }
  bn -= NDIRECT;
80101cba:	83 6d 0c 0c          	subl   $0xc,0xc(%ebp)

  if(bn < NINDIRECT){
80101cbe:	83 7d 0c 7f          	cmpl   $0x7f,0xc(%ebp)
80101cc2:	0f 87 b5 00 00 00    	ja     80101d7d <bmap+0x111>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0)
80101cc8:	8b 45 08             	mov    0x8(%ebp),%eax
80101ccb:	8b 80 8c 00 00 00    	mov    0x8c(%eax),%eax
80101cd1:	89 45 f4             	mov    %eax,-0xc(%ebp)
80101cd4:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80101cd8:	75 20                	jne    80101cfa <bmap+0x8e>
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
80101cda:	8b 45 08             	mov    0x8(%ebp),%eax
80101cdd:	8b 00                	mov    (%eax),%eax
80101cdf:	83 ec 0c             	sub    $0xc,%esp
80101ce2:	50                   	push   %eax
80101ce3:	e8 bd f7 ff ff       	call   801014a5 <balloc>
80101ce8:	83 c4 10             	add    $0x10,%esp
80101ceb:	89 45 f4             	mov    %eax,-0xc(%ebp)
80101cee:	8b 45 08             	mov    0x8(%ebp),%eax
80101cf1:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101cf4:	89 90 8c 00 00 00    	mov    %edx,0x8c(%eax)
    bp = bread(ip->dev, addr);
80101cfa:	8b 45 08             	mov    0x8(%ebp),%eax
80101cfd:	8b 00                	mov    (%eax),%eax
80101cff:	83 ec 08             	sub    $0x8,%esp
80101d02:	ff 75 f4             	push   -0xc(%ebp)
80101d05:	50                   	push   %eax
80101d06:	e8 c4 e4 ff ff       	call   801001cf <bread>
80101d0b:	83 c4 10             	add    $0x10,%esp
80101d0e:	89 45 f0             	mov    %eax,-0x10(%ebp)
    a = (uint*)bp->data;
80101d11:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101d14:	83 c0 5c             	add    $0x5c,%eax
80101d17:	89 45 ec             	mov    %eax,-0x14(%ebp)
    if((addr = a[bn]) == 0){
80101d1a:	8b 45 0c             	mov    0xc(%ebp),%eax
80101d1d:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80101d24:	8b 45 ec             	mov    -0x14(%ebp),%eax
80101d27:	01 d0                	add    %edx,%eax
80101d29:	8b 00                	mov    (%eax),%eax
80101d2b:	89 45 f4             	mov    %eax,-0xc(%ebp)
80101d2e:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80101d32:	75 36                	jne    80101d6a <bmap+0xfe>
      a[bn] = addr = balloc(ip->dev);
80101d34:	8b 45 08             	mov    0x8(%ebp),%eax
80101d37:	8b 00                	mov    (%eax),%eax
80101d39:	83 ec 0c             	sub    $0xc,%esp
80101d3c:	50                   	push   %eax
80101d3d:	e8 63 f7 ff ff       	call   801014a5 <balloc>
80101d42:	83 c4 10             	add    $0x10,%esp
80101d45:	89 45 f4             	mov    %eax,-0xc(%ebp)
80101d48:	8b 45 0c             	mov    0xc(%ebp),%eax
80101d4b:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80101d52:	8b 45 ec             	mov    -0x14(%ebp),%eax
80101d55:	01 c2                	add    %eax,%edx
80101d57:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101d5a:	89 02                	mov    %eax,(%edx)
      log_write(bp);
80101d5c:	83 ec 0c             	sub    $0xc,%esp
80101d5f:	ff 75 f0             	push   -0x10(%ebp)
80101d62:	e8 f4 19 00 00       	call   8010375b <log_write>
80101d67:	83 c4 10             	add    $0x10,%esp
    }
    brelse(bp);
80101d6a:	83 ec 0c             	sub    $0xc,%esp
80101d6d:	ff 75 f0             	push   -0x10(%ebp)
80101d70:	e8 dc e4 ff ff       	call   80100251 <brelse>
80101d75:	83 c4 10             	add    $0x10,%esp
    return addr;
80101d78:	8b 45 f4             	mov    -0xc(%ebp),%eax
80101d7b:	eb 0d                	jmp    80101d8a <bmap+0x11e>
  }

  panic("bmap: out of range");
80101d7d:	83 ec 0c             	sub    $0xc,%esp
80101d80:	68 ea 85 10 80       	push   $0x801085ea
80101d85:	e8 29 e8 ff ff       	call   801005b3 <panic>
}
80101d8a:	c9                   	leave
80101d8b:	c3                   	ret

80101d8c <itrunc>:
// to it (no directory entries referring to it)
// and has no in-memory reference to it (is
// not an open file or current directory).
static void
itrunc(struct inode *ip)
{
80101d8c:	55                   	push   %ebp
80101d8d:	89 e5                	mov    %esp,%ebp
80101d8f:	83 ec 18             	sub    $0x18,%esp
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
80101d92:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80101d99:	eb 45                	jmp    80101de0 <itrunc+0x54>
    if(ip->addrs[i]){
80101d9b:	8b 45 08             	mov    0x8(%ebp),%eax
80101d9e:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101da1:	83 c2 14             	add    $0x14,%edx
80101da4:	8b 44 90 0c          	mov    0xc(%eax,%edx,4),%eax
80101da8:	85 c0                	test   %eax,%eax
80101daa:	74 30                	je     80101ddc <itrunc+0x50>
      bfree(ip->dev, ip->addrs[i]);
80101dac:	8b 45 08             	mov    0x8(%ebp),%eax
80101daf:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101db2:	83 c2 14             	add    $0x14,%edx
80101db5:	8b 44 90 0c          	mov    0xc(%eax,%edx,4),%eax
80101db9:	8b 55 08             	mov    0x8(%ebp),%edx
80101dbc:	8b 12                	mov    (%edx),%edx
80101dbe:	83 ec 08             	sub    $0x8,%esp
80101dc1:	50                   	push   %eax
80101dc2:	52                   	push   %edx
80101dc3:	e8 20 f8 ff ff       	call   801015e8 <bfree>
80101dc8:	83 c4 10             	add    $0x10,%esp
      ip->addrs[i] = 0;
80101dcb:	8b 45 08             	mov    0x8(%ebp),%eax
80101dce:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101dd1:	83 c2 14             	add    $0x14,%edx
80101dd4:	c7 44 90 0c 00 00 00 	movl   $0x0,0xc(%eax,%edx,4)
80101ddb:	00 
  for(i = 0; i < NDIRECT; i++){
80101ddc:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80101de0:	83 7d f4 0b          	cmpl   $0xb,-0xc(%ebp)
80101de4:	7e b5                	jle    80101d9b <itrunc+0xf>
    }
  }

  if(ip->addrs[NDIRECT]){
80101de6:	8b 45 08             	mov    0x8(%ebp),%eax
80101de9:	8b 80 8c 00 00 00    	mov    0x8c(%eax),%eax
80101def:	85 c0                	test   %eax,%eax
80101df1:	0f 84 aa 00 00 00    	je     80101ea1 <itrunc+0x115>
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
80101df7:	8b 45 08             	mov    0x8(%ebp),%eax
80101dfa:	8b 90 8c 00 00 00    	mov    0x8c(%eax),%edx
80101e00:	8b 45 08             	mov    0x8(%ebp),%eax
80101e03:	8b 00                	mov    (%eax),%eax
80101e05:	83 ec 08             	sub    $0x8,%esp
80101e08:	52                   	push   %edx
80101e09:	50                   	push   %eax
80101e0a:	e8 c0 e3 ff ff       	call   801001cf <bread>
80101e0f:	83 c4 10             	add    $0x10,%esp
80101e12:	89 45 ec             	mov    %eax,-0x14(%ebp)
    a = (uint*)bp->data;
80101e15:	8b 45 ec             	mov    -0x14(%ebp),%eax
80101e18:	83 c0 5c             	add    $0x5c,%eax
80101e1b:	89 45 e8             	mov    %eax,-0x18(%ebp)
    for(j = 0; j < NINDIRECT; j++){
80101e1e:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
80101e25:	eb 3c                	jmp    80101e63 <itrunc+0xd7>
      if(a[j])
80101e27:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101e2a:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80101e31:	8b 45 e8             	mov    -0x18(%ebp),%eax
80101e34:	01 d0                	add    %edx,%eax
80101e36:	8b 00                	mov    (%eax),%eax
80101e38:	85 c0                	test   %eax,%eax
80101e3a:	74 23                	je     80101e5f <itrunc+0xd3>
        bfree(ip->dev, a[j]);
80101e3c:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101e3f:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80101e46:	8b 45 e8             	mov    -0x18(%ebp),%eax
80101e49:	01 d0                	add    %edx,%eax
80101e4b:	8b 00                	mov    (%eax),%eax
80101e4d:	8b 55 08             	mov    0x8(%ebp),%edx
80101e50:	8b 12                	mov    (%edx),%edx
80101e52:	83 ec 08             	sub    $0x8,%esp
80101e55:	50                   	push   %eax
80101e56:	52                   	push   %edx
80101e57:	e8 8c f7 ff ff       	call   801015e8 <bfree>
80101e5c:	83 c4 10             	add    $0x10,%esp
    for(j = 0; j < NINDIRECT; j++){
80101e5f:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
80101e63:	8b 45 f0             	mov    -0x10(%ebp),%eax
80101e66:	83 f8 7f             	cmp    $0x7f,%eax
80101e69:	76 bc                	jbe    80101e27 <itrunc+0x9b>
    }
    brelse(bp);
80101e6b:	83 ec 0c             	sub    $0xc,%esp
80101e6e:	ff 75 ec             	push   -0x14(%ebp)
80101e71:	e8 db e3 ff ff       	call   80100251 <brelse>
80101e76:	83 c4 10             	add    $0x10,%esp
    bfree(ip->dev, ip->addrs[NDIRECT]);
80101e79:	8b 45 08             	mov    0x8(%ebp),%eax
80101e7c:	8b 80 8c 00 00 00    	mov    0x8c(%eax),%eax
80101e82:	8b 55 08             	mov    0x8(%ebp),%edx
80101e85:	8b 12                	mov    (%edx),%edx
80101e87:	83 ec 08             	sub    $0x8,%esp
80101e8a:	50                   	push   %eax
80101e8b:	52                   	push   %edx
80101e8c:	e8 57 f7 ff ff       	call   801015e8 <bfree>
80101e91:	83 c4 10             	add    $0x10,%esp
    ip->addrs[NDIRECT] = 0;
80101e94:	8b 45 08             	mov    0x8(%ebp),%eax
80101e97:	c7 80 8c 00 00 00 00 	movl   $0x0,0x8c(%eax)
80101e9e:	00 00 00 
  }

  ip->size = 0;
80101ea1:	8b 45 08             	mov    0x8(%ebp),%eax
80101ea4:	c7 40 58 00 00 00 00 	movl   $0x0,0x58(%eax)
  iupdate(ip);
80101eab:	83 ec 0c             	sub    $0xc,%esp
80101eae:	ff 75 08             	push   0x8(%ebp)
80101eb1:	e8 83 f9 ff ff       	call   80101839 <iupdate>
80101eb6:	83 c4 10             	add    $0x10,%esp
}
80101eb9:	90                   	nop
80101eba:	c9                   	leave
80101ebb:	c3                   	ret

80101ebc <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
80101ebc:	55                   	push   %ebp
80101ebd:	89 e5                	mov    %esp,%ebp
  st->dev = ip->dev;
80101ebf:	8b 45 08             	mov    0x8(%ebp),%eax
80101ec2:	8b 00                	mov    (%eax),%eax
80101ec4:	89 c2                	mov    %eax,%edx
80101ec6:	8b 45 0c             	mov    0xc(%ebp),%eax
80101ec9:	89 50 04             	mov    %edx,0x4(%eax)
  st->ino = ip->inum;
80101ecc:	8b 45 08             	mov    0x8(%ebp),%eax
80101ecf:	8b 50 04             	mov    0x4(%eax),%edx
80101ed2:	8b 45 0c             	mov    0xc(%ebp),%eax
80101ed5:	89 50 08             	mov    %edx,0x8(%eax)
  st->type = ip->type;
80101ed8:	8b 45 08             	mov    0x8(%ebp),%eax
80101edb:	0f b7 50 50          	movzwl 0x50(%eax),%edx
80101edf:	8b 45 0c             	mov    0xc(%ebp),%eax
80101ee2:	66 89 10             	mov    %dx,(%eax)
  st->nlink = ip->nlink;
80101ee5:	8b 45 08             	mov    0x8(%ebp),%eax
80101ee8:	0f b7 50 56          	movzwl 0x56(%eax),%edx
80101eec:	8b 45 0c             	mov    0xc(%ebp),%eax
80101eef:	66 89 50 0c          	mov    %dx,0xc(%eax)
  st->size = ip->size;
80101ef3:	8b 45 08             	mov    0x8(%ebp),%eax
80101ef6:	8b 50 58             	mov    0x58(%eax),%edx
80101ef9:	8b 45 0c             	mov    0xc(%ebp),%eax
80101efc:	89 50 10             	mov    %edx,0x10(%eax)
}
80101eff:	90                   	nop
80101f00:	5d                   	pop    %ebp
80101f01:	c3                   	ret

80101f02 <readi>:
//PAGEBREAK!
// Read data from inode.
// Caller must hold ip->lock.
int
readi(struct inode *ip, char *dst, uint off, uint n)
{
80101f02:	55                   	push   %ebp
80101f03:	89 e5                	mov    %esp,%ebp
80101f05:	83 ec 18             	sub    $0x18,%esp
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101f08:	8b 45 08             	mov    0x8(%ebp),%eax
80101f0b:	0f b7 40 50          	movzwl 0x50(%eax),%eax
80101f0f:	66 83 f8 03          	cmp    $0x3,%ax
80101f13:	75 5c                	jne    80101f71 <readi+0x6f>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
80101f15:	8b 45 08             	mov    0x8(%ebp),%eax
80101f18:	0f b7 40 52          	movzwl 0x52(%eax),%eax
80101f1c:	66 85 c0             	test   %ax,%ax
80101f1f:	78 20                	js     80101f41 <readi+0x3f>
80101f21:	8b 45 08             	mov    0x8(%ebp),%eax
80101f24:	0f b7 40 52          	movzwl 0x52(%eax),%eax
80101f28:	66 83 f8 09          	cmp    $0x9,%ax
80101f2c:	7f 13                	jg     80101f41 <readi+0x3f>
80101f2e:	8b 45 08             	mov    0x8(%ebp),%eax
80101f31:	0f b7 40 52          	movzwl 0x52(%eax),%eax
80101f35:	98                   	cwtl
80101f36:	8b 04 c5 e0 ff 10 80 	mov    -0x7fef0020(,%eax,8),%eax
80101f3d:	85 c0                	test   %eax,%eax
80101f3f:	75 0a                	jne    80101f4b <readi+0x49>
      return -1;
80101f41:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101f46:	e9 0a 01 00 00       	jmp    80102055 <readi+0x153>
    return devsw[ip->major].read(ip, dst, n);
80101f4b:	8b 45 08             	mov    0x8(%ebp),%eax
80101f4e:	0f b7 40 52          	movzwl 0x52(%eax),%eax
80101f52:	98                   	cwtl
80101f53:	8b 04 c5 e0 ff 10 80 	mov    -0x7fef0020(,%eax,8),%eax
80101f5a:	8b 55 14             	mov    0x14(%ebp),%edx
80101f5d:	83 ec 04             	sub    $0x4,%esp
80101f60:	52                   	push   %edx
80101f61:	ff 75 0c             	push   0xc(%ebp)
80101f64:	ff 75 08             	push   0x8(%ebp)
80101f67:	ff d0                	call   *%eax
80101f69:	83 c4 10             	add    $0x10,%esp
80101f6c:	e9 e4 00 00 00       	jmp    80102055 <readi+0x153>
  }

  if(off > ip->size || off + n < off)
80101f71:	8b 45 08             	mov    0x8(%ebp),%eax
80101f74:	8b 40 58             	mov    0x58(%eax),%eax
80101f77:	3b 45 10             	cmp    0x10(%ebp),%eax
80101f7a:	72 0d                	jb     80101f89 <readi+0x87>
80101f7c:	8b 55 10             	mov    0x10(%ebp),%edx
80101f7f:	8b 45 14             	mov    0x14(%ebp),%eax
80101f82:	01 d0                	add    %edx,%eax
80101f84:	3b 45 10             	cmp    0x10(%ebp),%eax
80101f87:	73 0a                	jae    80101f93 <readi+0x91>
    return -1;
80101f89:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101f8e:	e9 c2 00 00 00       	jmp    80102055 <readi+0x153>
  if(off + n > ip->size)
80101f93:	8b 55 10             	mov    0x10(%ebp),%edx
80101f96:	8b 45 14             	mov    0x14(%ebp),%eax
80101f99:	01 c2                	add    %eax,%edx
80101f9b:	8b 45 08             	mov    0x8(%ebp),%eax
80101f9e:	8b 40 58             	mov    0x58(%eax),%eax
80101fa1:	39 d0                	cmp    %edx,%eax
80101fa3:	73 0c                	jae    80101fb1 <readi+0xaf>
    n = ip->size - off;
80101fa5:	8b 45 08             	mov    0x8(%ebp),%eax
80101fa8:	8b 40 58             	mov    0x58(%eax),%eax
80101fab:	2b 45 10             	sub    0x10(%ebp),%eax
80101fae:	89 45 14             	mov    %eax,0x14(%ebp)

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101fb1:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80101fb8:	e9 89 00 00 00       	jmp    80102046 <readi+0x144>
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101fbd:	8b 45 10             	mov    0x10(%ebp),%eax
80101fc0:	c1 e8 09             	shr    $0x9,%eax
80101fc3:	83 ec 08             	sub    $0x8,%esp
80101fc6:	50                   	push   %eax
80101fc7:	ff 75 08             	push   0x8(%ebp)
80101fca:	e8 9d fc ff ff       	call   80101c6c <bmap>
80101fcf:	83 c4 10             	add    $0x10,%esp
80101fd2:	8b 55 08             	mov    0x8(%ebp),%edx
80101fd5:	8b 12                	mov    (%edx),%edx
80101fd7:	83 ec 08             	sub    $0x8,%esp
80101fda:	50                   	push   %eax
80101fdb:	52                   	push   %edx
80101fdc:	e8 ee e1 ff ff       	call   801001cf <bread>
80101fe1:	83 c4 10             	add    $0x10,%esp
80101fe4:	89 45 f0             	mov    %eax,-0x10(%ebp)
    m = min(n - tot, BSIZE - off%BSIZE);
80101fe7:	8b 45 10             	mov    0x10(%ebp),%eax
80101fea:	25 ff 01 00 00       	and    $0x1ff,%eax
80101fef:	ba 00 02 00 00       	mov    $0x200,%edx
80101ff4:	29 c2                	sub    %eax,%edx
80101ff6:	8b 45 14             	mov    0x14(%ebp),%eax
80101ff9:	2b 45 f4             	sub    -0xc(%ebp),%eax
80101ffc:	39 c2                	cmp    %eax,%edx
80101ffe:	0f 46 c2             	cmovbe %edx,%eax
80102001:	89 45 ec             	mov    %eax,-0x14(%ebp)
    memmove(dst, bp->data + off%BSIZE, m);
80102004:	8b 45 f0             	mov    -0x10(%ebp),%eax
80102007:	8d 50 5c             	lea    0x5c(%eax),%edx
8010200a:	8b 45 10             	mov    0x10(%ebp),%eax
8010200d:	25 ff 01 00 00       	and    $0x1ff,%eax
80102012:	01 d0                	add    %edx,%eax
80102014:	83 ec 04             	sub    $0x4,%esp
80102017:	ff 75 ec             	push   -0x14(%ebp)
8010201a:	50                   	push   %eax
8010201b:	ff 75 0c             	push   0xc(%ebp)
8010201e:	e8 0b 33 00 00       	call   8010532e <memmove>
80102023:	83 c4 10             	add    $0x10,%esp
    brelse(bp);
80102026:	83 ec 0c             	sub    $0xc,%esp
80102029:	ff 75 f0             	push   -0x10(%ebp)
8010202c:	e8 20 e2 ff ff       	call   80100251 <brelse>
80102031:	83 c4 10             	add    $0x10,%esp
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80102034:	8b 45 ec             	mov    -0x14(%ebp),%eax
80102037:	01 45 f4             	add    %eax,-0xc(%ebp)
8010203a:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010203d:	01 45 10             	add    %eax,0x10(%ebp)
80102040:	8b 45 ec             	mov    -0x14(%ebp),%eax
80102043:	01 45 0c             	add    %eax,0xc(%ebp)
80102046:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102049:	3b 45 14             	cmp    0x14(%ebp),%eax
8010204c:	0f 82 6b ff ff ff    	jb     80101fbd <readi+0xbb>
  }
  return n;
80102052:	8b 45 14             	mov    0x14(%ebp),%eax
}
80102055:	c9                   	leave
80102056:	c3                   	ret

80102057 <writei>:
// PAGEBREAK!
// Write data to inode.
// Caller must hold ip->lock.
int
writei(struct inode *ip, char *src, uint off, uint n)
{
80102057:	55                   	push   %ebp
80102058:	89 e5                	mov    %esp,%ebp
8010205a:	83 ec 18             	sub    $0x18,%esp
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
8010205d:	8b 45 08             	mov    0x8(%ebp),%eax
80102060:	0f b7 40 50          	movzwl 0x50(%eax),%eax
80102064:	66 83 f8 03          	cmp    $0x3,%ax
80102068:	75 5c                	jne    801020c6 <writei+0x6f>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
8010206a:	8b 45 08             	mov    0x8(%ebp),%eax
8010206d:	0f b7 40 52          	movzwl 0x52(%eax),%eax
80102071:	66 85 c0             	test   %ax,%ax
80102074:	78 20                	js     80102096 <writei+0x3f>
80102076:	8b 45 08             	mov    0x8(%ebp),%eax
80102079:	0f b7 40 52          	movzwl 0x52(%eax),%eax
8010207d:	66 83 f8 09          	cmp    $0x9,%ax
80102081:	7f 13                	jg     80102096 <writei+0x3f>
80102083:	8b 45 08             	mov    0x8(%ebp),%eax
80102086:	0f b7 40 52          	movzwl 0x52(%eax),%eax
8010208a:	98                   	cwtl
8010208b:	8b 04 c5 e4 ff 10 80 	mov    -0x7fef001c(,%eax,8),%eax
80102092:	85 c0                	test   %eax,%eax
80102094:	75 0a                	jne    801020a0 <writei+0x49>
      return -1;
80102096:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010209b:	e9 3b 01 00 00       	jmp    801021db <writei+0x184>
    return devsw[ip->major].write(ip, src, n);
801020a0:	8b 45 08             	mov    0x8(%ebp),%eax
801020a3:	0f b7 40 52          	movzwl 0x52(%eax),%eax
801020a7:	98                   	cwtl
801020a8:	8b 04 c5 e4 ff 10 80 	mov    -0x7fef001c(,%eax,8),%eax
801020af:	8b 55 14             	mov    0x14(%ebp),%edx
801020b2:	83 ec 04             	sub    $0x4,%esp
801020b5:	52                   	push   %edx
801020b6:	ff 75 0c             	push   0xc(%ebp)
801020b9:	ff 75 08             	push   0x8(%ebp)
801020bc:	ff d0                	call   *%eax
801020be:	83 c4 10             	add    $0x10,%esp
801020c1:	e9 15 01 00 00       	jmp    801021db <writei+0x184>
  }

  if(off > ip->size || off + n < off)
801020c6:	8b 45 08             	mov    0x8(%ebp),%eax
801020c9:	8b 40 58             	mov    0x58(%eax),%eax
801020cc:	3b 45 10             	cmp    0x10(%ebp),%eax
801020cf:	72 0d                	jb     801020de <writei+0x87>
801020d1:	8b 55 10             	mov    0x10(%ebp),%edx
801020d4:	8b 45 14             	mov    0x14(%ebp),%eax
801020d7:	01 d0                	add    %edx,%eax
801020d9:	3b 45 10             	cmp    0x10(%ebp),%eax
801020dc:	73 0a                	jae    801020e8 <writei+0x91>
    return -1;
801020de:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801020e3:	e9 f3 00 00 00       	jmp    801021db <writei+0x184>
  if(off + n > MAXFILE*BSIZE)
801020e8:	8b 55 10             	mov    0x10(%ebp),%edx
801020eb:	8b 45 14             	mov    0x14(%ebp),%eax
801020ee:	01 d0                	add    %edx,%eax
801020f0:	3d 00 18 01 00       	cmp    $0x11800,%eax
801020f5:	76 0a                	jbe    80102101 <writei+0xaa>
    return -1;
801020f7:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801020fc:	e9 da 00 00 00       	jmp    801021db <writei+0x184>

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80102101:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80102108:	e9 97 00 00 00       	jmp    801021a4 <writei+0x14d>
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
8010210d:	8b 45 10             	mov    0x10(%ebp),%eax
80102110:	c1 e8 09             	shr    $0x9,%eax
80102113:	83 ec 08             	sub    $0x8,%esp
80102116:	50                   	push   %eax
80102117:	ff 75 08             	push   0x8(%ebp)
8010211a:	e8 4d fb ff ff       	call   80101c6c <bmap>
8010211f:	83 c4 10             	add    $0x10,%esp
80102122:	8b 55 08             	mov    0x8(%ebp),%edx
80102125:	8b 12                	mov    (%edx),%edx
80102127:	83 ec 08             	sub    $0x8,%esp
8010212a:	50                   	push   %eax
8010212b:	52                   	push   %edx
8010212c:	e8 9e e0 ff ff       	call   801001cf <bread>
80102131:	83 c4 10             	add    $0x10,%esp
80102134:	89 45 f0             	mov    %eax,-0x10(%ebp)
    m = min(n - tot, BSIZE - off%BSIZE);
80102137:	8b 45 10             	mov    0x10(%ebp),%eax
8010213a:	25 ff 01 00 00       	and    $0x1ff,%eax
8010213f:	ba 00 02 00 00       	mov    $0x200,%edx
80102144:	29 c2                	sub    %eax,%edx
80102146:	8b 45 14             	mov    0x14(%ebp),%eax
80102149:	2b 45 f4             	sub    -0xc(%ebp),%eax
8010214c:	39 c2                	cmp    %eax,%edx
8010214e:	0f 46 c2             	cmovbe %edx,%eax
80102151:	89 45 ec             	mov    %eax,-0x14(%ebp)
    memmove(bp->data + off%BSIZE, src, m);
80102154:	8b 45 f0             	mov    -0x10(%ebp),%eax
80102157:	8d 50 5c             	lea    0x5c(%eax),%edx
8010215a:	8b 45 10             	mov    0x10(%ebp),%eax
8010215d:	25 ff 01 00 00       	and    $0x1ff,%eax
80102162:	01 d0                	add    %edx,%eax
80102164:	83 ec 04             	sub    $0x4,%esp
80102167:	ff 75 ec             	push   -0x14(%ebp)
8010216a:	ff 75 0c             	push   0xc(%ebp)
8010216d:	50                   	push   %eax
8010216e:	e8 bb 31 00 00       	call   8010532e <memmove>
80102173:	83 c4 10             	add    $0x10,%esp
    log_write(bp);
80102176:	83 ec 0c             	sub    $0xc,%esp
80102179:	ff 75 f0             	push   -0x10(%ebp)
8010217c:	e8 da 15 00 00       	call   8010375b <log_write>
80102181:	83 c4 10             	add    $0x10,%esp
    brelse(bp);
80102184:	83 ec 0c             	sub    $0xc,%esp
80102187:	ff 75 f0             	push   -0x10(%ebp)
8010218a:	e8 c2 e0 ff ff       	call   80100251 <brelse>
8010218f:	83 c4 10             	add    $0x10,%esp
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80102192:	8b 45 ec             	mov    -0x14(%ebp),%eax
80102195:	01 45 f4             	add    %eax,-0xc(%ebp)
80102198:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010219b:	01 45 10             	add    %eax,0x10(%ebp)
8010219e:	8b 45 ec             	mov    -0x14(%ebp),%eax
801021a1:	01 45 0c             	add    %eax,0xc(%ebp)
801021a4:	8b 45 f4             	mov    -0xc(%ebp),%eax
801021a7:	3b 45 14             	cmp    0x14(%ebp),%eax
801021aa:	0f 82 5d ff ff ff    	jb     8010210d <writei+0xb6>
  }

  if(n > 0 && off > ip->size){
801021b0:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
801021b4:	74 22                	je     801021d8 <writei+0x181>
801021b6:	8b 45 08             	mov    0x8(%ebp),%eax
801021b9:	8b 40 58             	mov    0x58(%eax),%eax
801021bc:	3b 45 10             	cmp    0x10(%ebp),%eax
801021bf:	73 17                	jae    801021d8 <writei+0x181>
    ip->size = off;
801021c1:	8b 45 08             	mov    0x8(%ebp),%eax
801021c4:	8b 55 10             	mov    0x10(%ebp),%edx
801021c7:	89 50 58             	mov    %edx,0x58(%eax)
    iupdate(ip);
801021ca:	83 ec 0c             	sub    $0xc,%esp
801021cd:	ff 75 08             	push   0x8(%ebp)
801021d0:	e8 64 f6 ff ff       	call   80101839 <iupdate>
801021d5:	83 c4 10             	add    $0x10,%esp
  }
  return n;
801021d8:	8b 45 14             	mov    0x14(%ebp),%eax
}
801021db:	c9                   	leave
801021dc:	c3                   	ret

801021dd <namecmp>:
//PAGEBREAK!
// Directories

int
namecmp(const char *s, const char *t)
{
801021dd:	55                   	push   %ebp
801021de:	89 e5                	mov    %esp,%ebp
801021e0:	83 ec 08             	sub    $0x8,%esp
  return strncmp(s, t, DIRSIZ);
801021e3:	83 ec 04             	sub    $0x4,%esp
801021e6:	6a 0e                	push   $0xe
801021e8:	ff 75 0c             	push   0xc(%ebp)
801021eb:	ff 75 08             	push   0x8(%ebp)
801021ee:	e8 d1 31 00 00       	call   801053c4 <strncmp>
801021f3:	83 c4 10             	add    $0x10,%esp
}
801021f6:	c9                   	leave
801021f7:	c3                   	ret

801021f8 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
801021f8:	55                   	push   %ebp
801021f9:	89 e5                	mov    %esp,%ebp
801021fb:	83 ec 28             	sub    $0x28,%esp
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
801021fe:	8b 45 08             	mov    0x8(%ebp),%eax
80102201:	0f b7 40 50          	movzwl 0x50(%eax),%eax
80102205:	66 83 f8 01          	cmp    $0x1,%ax
80102209:	74 0d                	je     80102218 <dirlookup+0x20>
    panic("dirlookup not DIR");
8010220b:	83 ec 0c             	sub    $0xc,%esp
8010220e:	68 fd 85 10 80       	push   $0x801085fd
80102213:	e8 9b e3 ff ff       	call   801005b3 <panic>

  for(off = 0; off < dp->size; off += sizeof(de)){
80102218:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
8010221f:	eb 7b                	jmp    8010229c <dirlookup+0xa4>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80102221:	6a 10                	push   $0x10
80102223:	ff 75 f4             	push   -0xc(%ebp)
80102226:	8d 45 e0             	lea    -0x20(%ebp),%eax
80102229:	50                   	push   %eax
8010222a:	ff 75 08             	push   0x8(%ebp)
8010222d:	e8 d0 fc ff ff       	call   80101f02 <readi>
80102232:	83 c4 10             	add    $0x10,%esp
80102235:	83 f8 10             	cmp    $0x10,%eax
80102238:	74 0d                	je     80102247 <dirlookup+0x4f>
      panic("dirlookup read");
8010223a:	83 ec 0c             	sub    $0xc,%esp
8010223d:	68 0f 86 10 80       	push   $0x8010860f
80102242:	e8 6c e3 ff ff       	call   801005b3 <panic>
    if(de.inum == 0)
80102247:	0f b7 45 e0          	movzwl -0x20(%ebp),%eax
8010224b:	66 85 c0             	test   %ax,%ax
8010224e:	74 47                	je     80102297 <dirlookup+0x9f>
      continue;
    if(namecmp(name, de.name) == 0){
80102250:	83 ec 08             	sub    $0x8,%esp
80102253:	8d 45 e0             	lea    -0x20(%ebp),%eax
80102256:	83 c0 02             	add    $0x2,%eax
80102259:	50                   	push   %eax
8010225a:	ff 75 0c             	push   0xc(%ebp)
8010225d:	e8 7b ff ff ff       	call   801021dd <namecmp>
80102262:	83 c4 10             	add    $0x10,%esp
80102265:	85 c0                	test   %eax,%eax
80102267:	75 2f                	jne    80102298 <dirlookup+0xa0>
      // entry matches path element
      if(poff)
80102269:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
8010226d:	74 08                	je     80102277 <dirlookup+0x7f>
        *poff = off;
8010226f:	8b 45 10             	mov    0x10(%ebp),%eax
80102272:	8b 55 f4             	mov    -0xc(%ebp),%edx
80102275:	89 10                	mov    %edx,(%eax)
      inum = de.inum;
80102277:	0f b7 45 e0          	movzwl -0x20(%ebp),%eax
8010227b:	0f b7 c0             	movzwl %ax,%eax
8010227e:	89 45 f0             	mov    %eax,-0x10(%ebp)
      return iget(dp->dev, inum);
80102281:	8b 45 08             	mov    0x8(%ebp),%eax
80102284:	8b 00                	mov    (%eax),%eax
80102286:	83 ec 08             	sub    $0x8,%esp
80102289:	ff 75 f0             	push   -0x10(%ebp)
8010228c:	50                   	push   %eax
8010228d:	e8 68 f6 ff ff       	call   801018fa <iget>
80102292:	83 c4 10             	add    $0x10,%esp
80102295:	eb 19                	jmp    801022b0 <dirlookup+0xb8>
      continue;
80102297:	90                   	nop
  for(off = 0; off < dp->size; off += sizeof(de)){
80102298:	83 45 f4 10          	addl   $0x10,-0xc(%ebp)
8010229c:	8b 45 08             	mov    0x8(%ebp),%eax
8010229f:	8b 40 58             	mov    0x58(%eax),%eax
801022a2:	39 45 f4             	cmp    %eax,-0xc(%ebp)
801022a5:	0f 82 76 ff ff ff    	jb     80102221 <dirlookup+0x29>
    }
  }

  return 0;
801022ab:	b8 00 00 00 00       	mov    $0x0,%eax
}
801022b0:	c9                   	leave
801022b1:	c3                   	ret

801022b2 <dirlink>:

// Write a new directory entry (name, inum) into the directory dp.
int
dirlink(struct inode *dp, char *name, uint inum)
{
801022b2:	55                   	push   %ebp
801022b3:	89 e5                	mov    %esp,%ebp
801022b5:	83 ec 28             	sub    $0x28,%esp
  int off;
  struct dirent de;
  struct inode *ip;

  // Check that name is not present.
  if((ip = dirlookup(dp, name, 0)) != 0){
801022b8:	83 ec 04             	sub    $0x4,%esp
801022bb:	6a 00                	push   $0x0
801022bd:	ff 75 0c             	push   0xc(%ebp)
801022c0:	ff 75 08             	push   0x8(%ebp)
801022c3:	e8 30 ff ff ff       	call   801021f8 <dirlookup>
801022c8:	83 c4 10             	add    $0x10,%esp
801022cb:	89 45 f0             	mov    %eax,-0x10(%ebp)
801022ce:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
801022d2:	74 18                	je     801022ec <dirlink+0x3a>
    iput(ip);
801022d4:	83 ec 0c             	sub    $0xc,%esp
801022d7:	ff 75 f0             	push   -0x10(%ebp)
801022da:	e8 98 f8 ff ff       	call   80101b77 <iput>
801022df:	83 c4 10             	add    $0x10,%esp
    return -1;
801022e2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801022e7:	e9 9c 00 00 00       	jmp    80102388 <dirlink+0xd6>
  }

  // Look for an empty dirent.
  for(off = 0; off < dp->size; off += sizeof(de)){
801022ec:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
801022f3:	eb 39                	jmp    8010232e <dirlink+0x7c>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801022f5:	8b 45 f4             	mov    -0xc(%ebp),%eax
801022f8:	6a 10                	push   $0x10
801022fa:	50                   	push   %eax
801022fb:	8d 45 e0             	lea    -0x20(%ebp),%eax
801022fe:	50                   	push   %eax
801022ff:	ff 75 08             	push   0x8(%ebp)
80102302:	e8 fb fb ff ff       	call   80101f02 <readi>
80102307:	83 c4 10             	add    $0x10,%esp
8010230a:	83 f8 10             	cmp    $0x10,%eax
8010230d:	74 0d                	je     8010231c <dirlink+0x6a>
      panic("dirlink read");
8010230f:	83 ec 0c             	sub    $0xc,%esp
80102312:	68 1e 86 10 80       	push   $0x8010861e
80102317:	e8 97 e2 ff ff       	call   801005b3 <panic>
    if(de.inum == 0)
8010231c:	0f b7 45 e0          	movzwl -0x20(%ebp),%eax
80102320:	66 85 c0             	test   %ax,%ax
80102323:	74 18                	je     8010233d <dirlink+0x8b>
  for(off = 0; off < dp->size; off += sizeof(de)){
80102325:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102328:	83 c0 10             	add    $0x10,%eax
8010232b:	89 45 f4             	mov    %eax,-0xc(%ebp)
8010232e:	8b 45 08             	mov    0x8(%ebp),%eax
80102331:	8b 40 58             	mov    0x58(%eax),%eax
80102334:	8b 55 f4             	mov    -0xc(%ebp),%edx
80102337:	39 c2                	cmp    %eax,%edx
80102339:	72 ba                	jb     801022f5 <dirlink+0x43>
8010233b:	eb 01                	jmp    8010233e <dirlink+0x8c>
      break;
8010233d:	90                   	nop
  }

  strncpy(de.name, name, DIRSIZ);
8010233e:	83 ec 04             	sub    $0x4,%esp
80102341:	6a 0e                	push   $0xe
80102343:	ff 75 0c             	push   0xc(%ebp)
80102346:	8d 45 e0             	lea    -0x20(%ebp),%eax
80102349:	83 c0 02             	add    $0x2,%eax
8010234c:	50                   	push   %eax
8010234d:	e8 c8 30 00 00       	call   8010541a <strncpy>
80102352:	83 c4 10             	add    $0x10,%esp
  de.inum = inum;
80102355:	8b 45 10             	mov    0x10(%ebp),%eax
80102358:	66 89 45 e0          	mov    %ax,-0x20(%ebp)
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
8010235c:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010235f:	6a 10                	push   $0x10
80102361:	50                   	push   %eax
80102362:	8d 45 e0             	lea    -0x20(%ebp),%eax
80102365:	50                   	push   %eax
80102366:	ff 75 08             	push   0x8(%ebp)
80102369:	e8 e9 fc ff ff       	call   80102057 <writei>
8010236e:	83 c4 10             	add    $0x10,%esp
80102371:	83 f8 10             	cmp    $0x10,%eax
80102374:	74 0d                	je     80102383 <dirlink+0xd1>
    panic("dirlink");
80102376:	83 ec 0c             	sub    $0xc,%esp
80102379:	68 2b 86 10 80       	push   $0x8010862b
8010237e:	e8 30 e2 ff ff       	call   801005b3 <panic>

  return 0;
80102383:	b8 00 00 00 00       	mov    $0x0,%eax
}
80102388:	c9                   	leave
80102389:	c3                   	ret

8010238a <skipelem>:
//   skipelem("a", name) = "", setting name = "a"
//   skipelem("", name) = skipelem("////", name) = 0
//
static char*
skipelem(char *path, char *name)
{
8010238a:	55                   	push   %ebp
8010238b:	89 e5                	mov    %esp,%ebp
8010238d:	83 ec 18             	sub    $0x18,%esp
  char *s;
  int len;

  while(*path == '/')
80102390:	eb 04                	jmp    80102396 <skipelem+0xc>
    path++;
80102392:	83 45 08 01          	addl   $0x1,0x8(%ebp)
  while(*path == '/')
80102396:	8b 45 08             	mov    0x8(%ebp),%eax
80102399:	0f b6 00             	movzbl (%eax),%eax
8010239c:	3c 2f                	cmp    $0x2f,%al
8010239e:	74 f2                	je     80102392 <skipelem+0x8>
  if(*path == 0)
801023a0:	8b 45 08             	mov    0x8(%ebp),%eax
801023a3:	0f b6 00             	movzbl (%eax),%eax
801023a6:	84 c0                	test   %al,%al
801023a8:	75 07                	jne    801023b1 <skipelem+0x27>
    return 0;
801023aa:	b8 00 00 00 00       	mov    $0x0,%eax
801023af:	eb 77                	jmp    80102428 <skipelem+0x9e>
  s = path;
801023b1:	8b 45 08             	mov    0x8(%ebp),%eax
801023b4:	89 45 f4             	mov    %eax,-0xc(%ebp)
  while(*path != '/' && *path != 0)
801023b7:	eb 04                	jmp    801023bd <skipelem+0x33>
    path++;
801023b9:	83 45 08 01          	addl   $0x1,0x8(%ebp)
  while(*path != '/' && *path != 0)
801023bd:	8b 45 08             	mov    0x8(%ebp),%eax
801023c0:	0f b6 00             	movzbl (%eax),%eax
801023c3:	3c 2f                	cmp    $0x2f,%al
801023c5:	74 0a                	je     801023d1 <skipelem+0x47>
801023c7:	8b 45 08             	mov    0x8(%ebp),%eax
801023ca:	0f b6 00             	movzbl (%eax),%eax
801023cd:	84 c0                	test   %al,%al
801023cf:	75 e8                	jne    801023b9 <skipelem+0x2f>
  len = path - s;
801023d1:	8b 45 08             	mov    0x8(%ebp),%eax
801023d4:	2b 45 f4             	sub    -0xc(%ebp),%eax
801023d7:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(len >= DIRSIZ)
801023da:	83 7d f0 0d          	cmpl   $0xd,-0x10(%ebp)
801023de:	7e 15                	jle    801023f5 <skipelem+0x6b>
    memmove(name, s, DIRSIZ);
801023e0:	83 ec 04             	sub    $0x4,%esp
801023e3:	6a 0e                	push   $0xe
801023e5:	ff 75 f4             	push   -0xc(%ebp)
801023e8:	ff 75 0c             	push   0xc(%ebp)
801023eb:	e8 3e 2f 00 00       	call   8010532e <memmove>
801023f0:	83 c4 10             	add    $0x10,%esp
801023f3:	eb 26                	jmp    8010241b <skipelem+0x91>
  else {
    memmove(name, s, len);
801023f5:	8b 45 f0             	mov    -0x10(%ebp),%eax
801023f8:	83 ec 04             	sub    $0x4,%esp
801023fb:	50                   	push   %eax
801023fc:	ff 75 f4             	push   -0xc(%ebp)
801023ff:	ff 75 0c             	push   0xc(%ebp)
80102402:	e8 27 2f 00 00       	call   8010532e <memmove>
80102407:	83 c4 10             	add    $0x10,%esp
    name[len] = 0;
8010240a:	8b 55 f0             	mov    -0x10(%ebp),%edx
8010240d:	8b 45 0c             	mov    0xc(%ebp),%eax
80102410:	01 d0                	add    %edx,%eax
80102412:	c6 00 00             	movb   $0x0,(%eax)
  }
  while(*path == '/')
80102415:	eb 04                	jmp    8010241b <skipelem+0x91>
    path++;
80102417:	83 45 08 01          	addl   $0x1,0x8(%ebp)
  while(*path == '/')
8010241b:	8b 45 08             	mov    0x8(%ebp),%eax
8010241e:	0f b6 00             	movzbl (%eax),%eax
80102421:	3c 2f                	cmp    $0x2f,%al
80102423:	74 f2                	je     80102417 <skipelem+0x8d>
  return path;
80102425:	8b 45 08             	mov    0x8(%ebp),%eax
}
80102428:	c9                   	leave
80102429:	c3                   	ret

8010242a <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
8010242a:	55                   	push   %ebp
8010242b:	89 e5                	mov    %esp,%ebp
8010242d:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip, *next;

  if(*path == '/')
80102430:	8b 45 08             	mov    0x8(%ebp),%eax
80102433:	0f b6 00             	movzbl (%eax),%eax
80102436:	3c 2f                	cmp    $0x2f,%al
80102438:	75 17                	jne    80102451 <namex+0x27>
    ip = iget(ROOTDEV, ROOTINO);
8010243a:	83 ec 08             	sub    $0x8,%esp
8010243d:	6a 01                	push   $0x1
8010243f:	6a 01                	push   $0x1
80102441:	e8 b4 f4 ff ff       	call   801018fa <iget>
80102446:	83 c4 10             	add    $0x10,%esp
80102449:	89 45 f4             	mov    %eax,-0xc(%ebp)
8010244c:	e9 ba 00 00 00       	jmp    8010250b <namex+0xe1>
  else
    ip = idup(myproc()->cwd);
80102451:	e8 2f 1e 00 00       	call   80104285 <myproc>
80102456:	8b 40 68             	mov    0x68(%eax),%eax
80102459:	83 ec 0c             	sub    $0xc,%esp
8010245c:	50                   	push   %eax
8010245d:	e8 7a f5 ff ff       	call   801019dc <idup>
80102462:	83 c4 10             	add    $0x10,%esp
80102465:	89 45 f4             	mov    %eax,-0xc(%ebp)

  while((path = skipelem(path, name)) != 0){
80102468:	e9 9e 00 00 00       	jmp    8010250b <namex+0xe1>
    ilock(ip);
8010246d:	83 ec 0c             	sub    $0xc,%esp
80102470:	ff 75 f4             	push   -0xc(%ebp)
80102473:	e8 9e f5 ff ff       	call   80101a16 <ilock>
80102478:	83 c4 10             	add    $0x10,%esp
    if(ip->type != T_DIR){
8010247b:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010247e:	0f b7 40 50          	movzwl 0x50(%eax),%eax
80102482:	66 83 f8 01          	cmp    $0x1,%ax
80102486:	74 18                	je     801024a0 <namex+0x76>
      iunlockput(ip);
80102488:	83 ec 0c             	sub    $0xc,%esp
8010248b:	ff 75 f4             	push   -0xc(%ebp)
8010248e:	e8 b4 f7 ff ff       	call   80101c47 <iunlockput>
80102493:	83 c4 10             	add    $0x10,%esp
      return 0;
80102496:	b8 00 00 00 00       	mov    $0x0,%eax
8010249b:	e9 a7 00 00 00       	jmp    80102547 <namex+0x11d>
    }
    if(nameiparent && *path == '\0'){
801024a0:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
801024a4:	74 20                	je     801024c6 <namex+0x9c>
801024a6:	8b 45 08             	mov    0x8(%ebp),%eax
801024a9:	0f b6 00             	movzbl (%eax),%eax
801024ac:	84 c0                	test   %al,%al
801024ae:	75 16                	jne    801024c6 <namex+0x9c>
      // Stop one level early.
      iunlock(ip);
801024b0:	83 ec 0c             	sub    $0xc,%esp
801024b3:	ff 75 f4             	push   -0xc(%ebp)
801024b6:	e8 6e f6 ff ff       	call   80101b29 <iunlock>
801024bb:	83 c4 10             	add    $0x10,%esp
      return ip;
801024be:	8b 45 f4             	mov    -0xc(%ebp),%eax
801024c1:	e9 81 00 00 00       	jmp    80102547 <namex+0x11d>
    }
    if((next = dirlookup(ip, name, 0)) == 0){
801024c6:	83 ec 04             	sub    $0x4,%esp
801024c9:	6a 00                	push   $0x0
801024cb:	ff 75 10             	push   0x10(%ebp)
801024ce:	ff 75 f4             	push   -0xc(%ebp)
801024d1:	e8 22 fd ff ff       	call   801021f8 <dirlookup>
801024d6:	83 c4 10             	add    $0x10,%esp
801024d9:	89 45 f0             	mov    %eax,-0x10(%ebp)
801024dc:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
801024e0:	75 15                	jne    801024f7 <namex+0xcd>
      iunlockput(ip);
801024e2:	83 ec 0c             	sub    $0xc,%esp
801024e5:	ff 75 f4             	push   -0xc(%ebp)
801024e8:	e8 5a f7 ff ff       	call   80101c47 <iunlockput>
801024ed:	83 c4 10             	add    $0x10,%esp
      return 0;
801024f0:	b8 00 00 00 00       	mov    $0x0,%eax
801024f5:	eb 50                	jmp    80102547 <namex+0x11d>
    }
    iunlockput(ip);
801024f7:	83 ec 0c             	sub    $0xc,%esp
801024fa:	ff 75 f4             	push   -0xc(%ebp)
801024fd:	e8 45 f7 ff ff       	call   80101c47 <iunlockput>
80102502:	83 c4 10             	add    $0x10,%esp
    ip = next;
80102505:	8b 45 f0             	mov    -0x10(%ebp),%eax
80102508:	89 45 f4             	mov    %eax,-0xc(%ebp)
  while((path = skipelem(path, name)) != 0){
8010250b:	83 ec 08             	sub    $0x8,%esp
8010250e:	ff 75 10             	push   0x10(%ebp)
80102511:	ff 75 08             	push   0x8(%ebp)
80102514:	e8 71 fe ff ff       	call   8010238a <skipelem>
80102519:	83 c4 10             	add    $0x10,%esp
8010251c:	89 45 08             	mov    %eax,0x8(%ebp)
8010251f:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
80102523:	0f 85 44 ff ff ff    	jne    8010246d <namex+0x43>
  }
  if(nameiparent){
80102529:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
8010252d:	74 15                	je     80102544 <namex+0x11a>
    iput(ip);
8010252f:	83 ec 0c             	sub    $0xc,%esp
80102532:	ff 75 f4             	push   -0xc(%ebp)
80102535:	e8 3d f6 ff ff       	call   80101b77 <iput>
8010253a:	83 c4 10             	add    $0x10,%esp
    return 0;
8010253d:	b8 00 00 00 00       	mov    $0x0,%eax
80102542:	eb 03                	jmp    80102547 <namex+0x11d>
  }
  return ip;
80102544:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
80102547:	c9                   	leave
80102548:	c3                   	ret

80102549 <namei>:

struct inode*
namei(char *path)
{
80102549:	55                   	push   %ebp
8010254a:	89 e5                	mov    %esp,%ebp
8010254c:	83 ec 18             	sub    $0x18,%esp
  char name[DIRSIZ];
  return namex(path, 0, name);
8010254f:	83 ec 04             	sub    $0x4,%esp
80102552:	8d 45 ea             	lea    -0x16(%ebp),%eax
80102555:	50                   	push   %eax
80102556:	6a 00                	push   $0x0
80102558:	ff 75 08             	push   0x8(%ebp)
8010255b:	e8 ca fe ff ff       	call   8010242a <namex>
80102560:	83 c4 10             	add    $0x10,%esp
}
80102563:	c9                   	leave
80102564:	c3                   	ret

80102565 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
80102565:	55                   	push   %ebp
80102566:	89 e5                	mov    %esp,%ebp
80102568:	83 ec 08             	sub    $0x8,%esp
  return namex(path, 1, name);
8010256b:	83 ec 04             	sub    $0x4,%esp
8010256e:	ff 75 0c             	push   0xc(%ebp)
80102571:	6a 01                	push   $0x1
80102573:	ff 75 08             	push   0x8(%ebp)
80102576:	e8 af fe ff ff       	call   8010242a <namex>
8010257b:	83 c4 10             	add    $0x10,%esp
}
8010257e:	c9                   	leave
8010257f:	c3                   	ret

80102580 <inb>:
{
80102580:	55                   	push   %ebp
80102581:	89 e5                	mov    %esp,%ebp
80102583:	83 ec 14             	sub    $0x14,%esp
80102586:	8b 45 08             	mov    0x8(%ebp),%eax
80102589:	66 89 45 ec          	mov    %ax,-0x14(%ebp)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010258d:	0f b7 45 ec          	movzwl -0x14(%ebp),%eax
80102591:	89 c2                	mov    %eax,%edx
80102593:	ec                   	in     (%dx),%al
80102594:	88 45 ff             	mov    %al,-0x1(%ebp)
  return data;
80102597:	0f b6 45 ff          	movzbl -0x1(%ebp),%eax
}
8010259b:	c9                   	leave
8010259c:	c3                   	ret

8010259d <insl>:
{
8010259d:	55                   	push   %ebp
8010259e:	89 e5                	mov    %esp,%ebp
801025a0:	57                   	push   %edi
801025a1:	53                   	push   %ebx
  asm volatile("cld; rep insl" :
801025a2:	8b 55 08             	mov    0x8(%ebp),%edx
801025a5:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801025a8:	8b 45 10             	mov    0x10(%ebp),%eax
801025ab:	89 cb                	mov    %ecx,%ebx
801025ad:	89 df                	mov    %ebx,%edi
801025af:	89 c1                	mov    %eax,%ecx
801025b1:	fc                   	cld
801025b2:	f3 6d                	rep insl (%dx),%es:(%edi)
801025b4:	89 c8                	mov    %ecx,%eax
801025b6:	89 fb                	mov    %edi,%ebx
801025b8:	89 5d 0c             	mov    %ebx,0xc(%ebp)
801025bb:	89 45 10             	mov    %eax,0x10(%ebp)
}
801025be:	90                   	nop
801025bf:	5b                   	pop    %ebx
801025c0:	5f                   	pop    %edi
801025c1:	5d                   	pop    %ebp
801025c2:	c3                   	ret

801025c3 <outb>:
{
801025c3:	55                   	push   %ebp
801025c4:	89 e5                	mov    %esp,%ebp
801025c6:	83 ec 08             	sub    $0x8,%esp
801025c9:	8b 55 08             	mov    0x8(%ebp),%edx
801025cc:	8b 45 0c             	mov    0xc(%ebp),%eax
801025cf:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
801025d3:	88 45 f8             	mov    %al,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801025d6:	0f b6 45 f8          	movzbl -0x8(%ebp),%eax
801025da:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
801025de:	ee                   	out    %al,(%dx)
}
801025df:	90                   	nop
801025e0:	c9                   	leave
801025e1:	c3                   	ret

801025e2 <outsl>:
{
801025e2:	55                   	push   %ebp
801025e3:	89 e5                	mov    %esp,%ebp
801025e5:	56                   	push   %esi
801025e6:	53                   	push   %ebx
  asm volatile("cld; rep outsl" :
801025e7:	8b 55 08             	mov    0x8(%ebp),%edx
801025ea:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801025ed:	8b 45 10             	mov    0x10(%ebp),%eax
801025f0:	89 cb                	mov    %ecx,%ebx
801025f2:	89 de                	mov    %ebx,%esi
801025f4:	89 c1                	mov    %eax,%ecx
801025f6:	fc                   	cld
801025f7:	f3 6f                	rep outsl %ds:(%esi),(%dx)
801025f9:	89 c8                	mov    %ecx,%eax
801025fb:	89 f3                	mov    %esi,%ebx
801025fd:	89 5d 0c             	mov    %ebx,0xc(%ebp)
80102600:	89 45 10             	mov    %eax,0x10(%ebp)
}
80102603:	90                   	nop
80102604:	5b                   	pop    %ebx
80102605:	5e                   	pop    %esi
80102606:	5d                   	pop    %ebp
80102607:	c3                   	ret

80102608 <idewait>:
static void idestart(struct buf*);

// Wait for IDE disk to become ready.
static int
idewait(int checkerr)
{
80102608:	55                   	push   %ebp
80102609:	89 e5                	mov    %esp,%ebp
8010260b:	83 ec 10             	sub    $0x10,%esp
  int r;

  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
8010260e:	90                   	nop
8010260f:	68 f7 01 00 00       	push   $0x1f7
80102614:	e8 67 ff ff ff       	call   80102580 <inb>
80102619:	83 c4 04             	add    $0x4,%esp
8010261c:	0f b6 c0             	movzbl %al,%eax
8010261f:	89 45 fc             	mov    %eax,-0x4(%ebp)
80102622:	8b 45 fc             	mov    -0x4(%ebp),%eax
80102625:	25 c0 00 00 00       	and    $0xc0,%eax
8010262a:	83 f8 40             	cmp    $0x40,%eax
8010262d:	75 e0                	jne    8010260f <idewait+0x7>
    ;
  if(checkerr && (r & (IDE_DF|IDE_ERR)) != 0)
8010262f:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
80102633:	74 11                	je     80102646 <idewait+0x3e>
80102635:	8b 45 fc             	mov    -0x4(%ebp),%eax
80102638:	83 e0 21             	and    $0x21,%eax
8010263b:	85 c0                	test   %eax,%eax
8010263d:	74 07                	je     80102646 <idewait+0x3e>
    return -1;
8010263f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102644:	eb 05                	jmp    8010264b <idewait+0x43>
  return 0;
80102646:	b8 00 00 00 00       	mov    $0x0,%eax
}
8010264b:	c9                   	leave
8010264c:	c3                   	ret

8010264d <ideinit>:

void
ideinit(void)
{
8010264d:	55                   	push   %ebp
8010264e:	89 e5                	mov    %esp,%ebp
80102650:	83 ec 18             	sub    $0x18,%esp
  int i;

  initlock(&idelock, "ide");
80102653:	83 ec 08             	sub    $0x8,%esp
80102656:	68 33 86 10 80       	push   $0x80108633
8010265b:	68 60 26 11 80       	push   $0x80112660
80102660:	e8 62 29 00 00       	call   80104fc7 <initlock>
80102665:	83 c4 10             	add    $0x10,%esp
  ioapicenable(IRQ_IDE, ncpu - 1);
80102668:	a1 60 2d 11 80       	mov    0x80112d60,%eax
8010266d:	83 e8 01             	sub    $0x1,%eax
80102670:	83 ec 08             	sub    $0x8,%esp
80102673:	50                   	push   %eax
80102674:	6a 0e                	push   $0xe
80102676:	e8 a5 04 00 00       	call   80102b20 <ioapicenable>
8010267b:	83 c4 10             	add    $0x10,%esp
  idewait(0);
8010267e:	83 ec 0c             	sub    $0xc,%esp
80102681:	6a 00                	push   $0x0
80102683:	e8 80 ff ff ff       	call   80102608 <idewait>
80102688:	83 c4 10             	add    $0x10,%esp

  // Check if disk 1 is present
  outb(0x1f6, 0xe0 | (1<<4));
8010268b:	83 ec 08             	sub    $0x8,%esp
8010268e:	68 f0 00 00 00       	push   $0xf0
80102693:	68 f6 01 00 00       	push   $0x1f6
80102698:	e8 26 ff ff ff       	call   801025c3 <outb>
8010269d:	83 c4 10             	add    $0x10,%esp
  for(i=0; i<1000; i++){
801026a0:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
801026a7:	eb 24                	jmp    801026cd <ideinit+0x80>
    if(inb(0x1f7) != 0){
801026a9:	83 ec 0c             	sub    $0xc,%esp
801026ac:	68 f7 01 00 00       	push   $0x1f7
801026b1:	e8 ca fe ff ff       	call   80102580 <inb>
801026b6:	83 c4 10             	add    $0x10,%esp
801026b9:	84 c0                	test   %al,%al
801026bb:	74 0c                	je     801026c9 <ideinit+0x7c>
      havedisk1 = 1;
801026bd:	c7 05 98 26 11 80 01 	movl   $0x1,0x80112698
801026c4:	00 00 00 
      break;
801026c7:	eb 0d                	jmp    801026d6 <ideinit+0x89>
  for(i=0; i<1000; i++){
801026c9:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
801026cd:	81 7d f4 e7 03 00 00 	cmpl   $0x3e7,-0xc(%ebp)
801026d4:	7e d3                	jle    801026a9 <ideinit+0x5c>
    }
  }

  // Switch back to disk 0.
  outb(0x1f6, 0xe0 | (0<<4));
801026d6:	83 ec 08             	sub    $0x8,%esp
801026d9:	68 e0 00 00 00       	push   $0xe0
801026de:	68 f6 01 00 00       	push   $0x1f6
801026e3:	e8 db fe ff ff       	call   801025c3 <outb>
801026e8:	83 c4 10             	add    $0x10,%esp
}
801026eb:	90                   	nop
801026ec:	c9                   	leave
801026ed:	c3                   	ret

801026ee <idestart>:

// Start the request for b.  Caller must hold idelock.
static void
idestart(struct buf *b)
{
801026ee:	55                   	push   %ebp
801026ef:	89 e5                	mov    %esp,%ebp
801026f1:	83 ec 18             	sub    $0x18,%esp
  if(b == 0)
801026f4:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
801026f8:	75 0d                	jne    80102707 <idestart+0x19>
    panic("idestart");
801026fa:	83 ec 0c             	sub    $0xc,%esp
801026fd:	68 37 86 10 80       	push   $0x80108637
80102702:	e8 ac de ff ff       	call   801005b3 <panic>
  if(b->blockno >= FSSIZE)
80102707:	8b 45 08             	mov    0x8(%ebp),%eax
8010270a:	8b 40 08             	mov    0x8(%eax),%eax
8010270d:	3d e7 03 00 00       	cmp    $0x3e7,%eax
80102712:	76 0d                	jbe    80102721 <idestart+0x33>
    panic("incorrect blockno");
80102714:	83 ec 0c             	sub    $0xc,%esp
80102717:	68 40 86 10 80       	push   $0x80108640
8010271c:	e8 92 de ff ff       	call   801005b3 <panic>
  int sector_per_block =  BSIZE/SECTOR_SIZE;
80102721:	c7 45 ec 01 00 00 00 	movl   $0x1,-0x14(%ebp)
  int sector = b->blockno * sector_per_block;
80102728:	8b 45 08             	mov    0x8(%ebp),%eax
8010272b:	8b 50 08             	mov    0x8(%eax),%edx
8010272e:	8b 45 ec             	mov    -0x14(%ebp),%eax
80102731:	0f af c2             	imul   %edx,%eax
80102734:	89 45 e8             	mov    %eax,-0x18(%ebp)
  int read_cmd = (sector_per_block == 1) ? IDE_CMD_READ :  IDE_CMD_RDMUL;
80102737:	83 7d ec 01          	cmpl   $0x1,-0x14(%ebp)
8010273b:	75 09                	jne    80102746 <idestart+0x58>
8010273d:	c7 45 f4 20 00 00 00 	movl   $0x20,-0xc(%ebp)
80102744:	eb 07                	jmp    8010274d <idestart+0x5f>
80102746:	c7 45 f4 c4 00 00 00 	movl   $0xc4,-0xc(%ebp)
  int write_cmd = (sector_per_block == 1) ? IDE_CMD_WRITE : IDE_CMD_WRMUL;
8010274d:	83 7d ec 01          	cmpl   $0x1,-0x14(%ebp)
80102751:	75 09                	jne    8010275c <idestart+0x6e>
80102753:	c7 45 f0 30 00 00 00 	movl   $0x30,-0x10(%ebp)
8010275a:	eb 07                	jmp    80102763 <idestart+0x75>
8010275c:	c7 45 f0 c5 00 00 00 	movl   $0xc5,-0x10(%ebp)

  if (sector_per_block > 7) panic("idestart");
80102763:	83 7d ec 07          	cmpl   $0x7,-0x14(%ebp)
80102767:	7e 0d                	jle    80102776 <idestart+0x88>
80102769:	83 ec 0c             	sub    $0xc,%esp
8010276c:	68 37 86 10 80       	push   $0x80108637
80102771:	e8 3d de ff ff       	call   801005b3 <panic>

  idewait(0);
80102776:	83 ec 0c             	sub    $0xc,%esp
80102779:	6a 00                	push   $0x0
8010277b:	e8 88 fe ff ff       	call   80102608 <idewait>
80102780:	83 c4 10             	add    $0x10,%esp
  outb(0x3f6, 0);  // generate interrupt
80102783:	83 ec 08             	sub    $0x8,%esp
80102786:	6a 00                	push   $0x0
80102788:	68 f6 03 00 00       	push   $0x3f6
8010278d:	e8 31 fe ff ff       	call   801025c3 <outb>
80102792:	83 c4 10             	add    $0x10,%esp
  outb(0x1f2, sector_per_block);  // number of sectors
80102795:	8b 45 ec             	mov    -0x14(%ebp),%eax
80102798:	0f b6 c0             	movzbl %al,%eax
8010279b:	83 ec 08             	sub    $0x8,%esp
8010279e:	50                   	push   %eax
8010279f:	68 f2 01 00 00       	push   $0x1f2
801027a4:	e8 1a fe ff ff       	call   801025c3 <outb>
801027a9:	83 c4 10             	add    $0x10,%esp
  outb(0x1f3, sector & 0xff);
801027ac:	8b 45 e8             	mov    -0x18(%ebp),%eax
801027af:	0f b6 c0             	movzbl %al,%eax
801027b2:	83 ec 08             	sub    $0x8,%esp
801027b5:	50                   	push   %eax
801027b6:	68 f3 01 00 00       	push   $0x1f3
801027bb:	e8 03 fe ff ff       	call   801025c3 <outb>
801027c0:	83 c4 10             	add    $0x10,%esp
  outb(0x1f4, (sector >> 8) & 0xff);
801027c3:	8b 45 e8             	mov    -0x18(%ebp),%eax
801027c6:	c1 f8 08             	sar    $0x8,%eax
801027c9:	0f b6 c0             	movzbl %al,%eax
801027cc:	83 ec 08             	sub    $0x8,%esp
801027cf:	50                   	push   %eax
801027d0:	68 f4 01 00 00       	push   $0x1f4
801027d5:	e8 e9 fd ff ff       	call   801025c3 <outb>
801027da:	83 c4 10             	add    $0x10,%esp
  outb(0x1f5, (sector >> 16) & 0xff);
801027dd:	8b 45 e8             	mov    -0x18(%ebp),%eax
801027e0:	c1 f8 10             	sar    $0x10,%eax
801027e3:	0f b6 c0             	movzbl %al,%eax
801027e6:	83 ec 08             	sub    $0x8,%esp
801027e9:	50                   	push   %eax
801027ea:	68 f5 01 00 00       	push   $0x1f5
801027ef:	e8 cf fd ff ff       	call   801025c3 <outb>
801027f4:	83 c4 10             	add    $0x10,%esp
  outb(0x1f6, 0xe0 | ((b->dev&1)<<4) | ((sector>>24)&0x0f));
801027f7:	8b 45 08             	mov    0x8(%ebp),%eax
801027fa:	8b 40 04             	mov    0x4(%eax),%eax
801027fd:	c1 e0 04             	shl    $0x4,%eax
80102800:	83 e0 10             	and    $0x10,%eax
80102803:	89 c2                	mov    %eax,%edx
80102805:	8b 45 e8             	mov    -0x18(%ebp),%eax
80102808:	c1 f8 18             	sar    $0x18,%eax
8010280b:	83 e0 0f             	and    $0xf,%eax
8010280e:	09 d0                	or     %edx,%eax
80102810:	83 c8 e0             	or     $0xffffffe0,%eax
80102813:	0f b6 c0             	movzbl %al,%eax
80102816:	83 ec 08             	sub    $0x8,%esp
80102819:	50                   	push   %eax
8010281a:	68 f6 01 00 00       	push   $0x1f6
8010281f:	e8 9f fd ff ff       	call   801025c3 <outb>
80102824:	83 c4 10             	add    $0x10,%esp
  if(b->flags & B_DIRTY){
80102827:	8b 45 08             	mov    0x8(%ebp),%eax
8010282a:	8b 00                	mov    (%eax),%eax
8010282c:	83 e0 04             	and    $0x4,%eax
8010282f:	85 c0                	test   %eax,%eax
80102831:	74 35                	je     80102868 <idestart+0x17a>
    outb(0x1f7, write_cmd);
80102833:	8b 45 f0             	mov    -0x10(%ebp),%eax
80102836:	0f b6 c0             	movzbl %al,%eax
80102839:	83 ec 08             	sub    $0x8,%esp
8010283c:	50                   	push   %eax
8010283d:	68 f7 01 00 00       	push   $0x1f7
80102842:	e8 7c fd ff ff       	call   801025c3 <outb>
80102847:	83 c4 10             	add    $0x10,%esp
    outsl(0x1f0, b->data, BSIZE/4);
8010284a:	8b 45 08             	mov    0x8(%ebp),%eax
8010284d:	83 c0 5c             	add    $0x5c,%eax
80102850:	83 ec 04             	sub    $0x4,%esp
80102853:	68 80 00 00 00       	push   $0x80
80102858:	50                   	push   %eax
80102859:	68 f0 01 00 00       	push   $0x1f0
8010285e:	e8 7f fd ff ff       	call   801025e2 <outsl>
80102863:	83 c4 10             	add    $0x10,%esp
  } else {
    outb(0x1f7, read_cmd);
  }
}
80102866:	eb 17                	jmp    8010287f <idestart+0x191>
    outb(0x1f7, read_cmd);
80102868:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010286b:	0f b6 c0             	movzbl %al,%eax
8010286e:	83 ec 08             	sub    $0x8,%esp
80102871:	50                   	push   %eax
80102872:	68 f7 01 00 00       	push   $0x1f7
80102877:	e8 47 fd ff ff       	call   801025c3 <outb>
8010287c:	83 c4 10             	add    $0x10,%esp
}
8010287f:	90                   	nop
80102880:	c9                   	leave
80102881:	c3                   	ret

80102882 <ideintr>:

// Interrupt handler.
void
ideintr(void)
{
80102882:	55                   	push   %ebp
80102883:	89 e5                	mov    %esp,%ebp
80102885:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  // First queued buffer is the active request.
  acquire(&idelock);
80102888:	83 ec 0c             	sub    $0xc,%esp
8010288b:	68 60 26 11 80       	push   $0x80112660
80102890:	e8 54 27 00 00       	call   80104fe9 <acquire>
80102895:	83 c4 10             	add    $0x10,%esp

  if((b = idequeue) == 0){
80102898:	a1 94 26 11 80       	mov    0x80112694,%eax
8010289d:	89 45 f4             	mov    %eax,-0xc(%ebp)
801028a0:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
801028a4:	75 15                	jne    801028bb <ideintr+0x39>
    release(&idelock);
801028a6:	83 ec 0c             	sub    $0xc,%esp
801028a9:	68 60 26 11 80       	push   $0x80112660
801028ae:	e8 a4 27 00 00       	call   80105057 <release>
801028b3:	83 c4 10             	add    $0x10,%esp
    return;
801028b6:	e9 9a 00 00 00       	jmp    80102955 <ideintr+0xd3>
  }
  idequeue = b->qnext;
801028bb:	8b 45 f4             	mov    -0xc(%ebp),%eax
801028be:	8b 40 58             	mov    0x58(%eax),%eax
801028c1:	a3 94 26 11 80       	mov    %eax,0x80112694

  // Read data if needed.
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
801028c6:	8b 45 f4             	mov    -0xc(%ebp),%eax
801028c9:	8b 00                	mov    (%eax),%eax
801028cb:	83 e0 04             	and    $0x4,%eax
801028ce:	85 c0                	test   %eax,%eax
801028d0:	75 2d                	jne    801028ff <ideintr+0x7d>
801028d2:	83 ec 0c             	sub    $0xc,%esp
801028d5:	6a 01                	push   $0x1
801028d7:	e8 2c fd ff ff       	call   80102608 <idewait>
801028dc:	83 c4 10             	add    $0x10,%esp
801028df:	85 c0                	test   %eax,%eax
801028e1:	78 1c                	js     801028ff <ideintr+0x7d>
    insl(0x1f0, b->data, BSIZE/4);
801028e3:	8b 45 f4             	mov    -0xc(%ebp),%eax
801028e6:	83 c0 5c             	add    $0x5c,%eax
801028e9:	83 ec 04             	sub    $0x4,%esp
801028ec:	68 80 00 00 00       	push   $0x80
801028f1:	50                   	push   %eax
801028f2:	68 f0 01 00 00       	push   $0x1f0
801028f7:	e8 a1 fc ff ff       	call   8010259d <insl>
801028fc:	83 c4 10             	add    $0x10,%esp

  // Wake process waiting for this buf.
  b->flags |= B_VALID;
801028ff:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102902:	8b 00                	mov    (%eax),%eax
80102904:	83 c8 02             	or     $0x2,%eax
80102907:	89 c2                	mov    %eax,%edx
80102909:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010290c:	89 10                	mov    %edx,(%eax)
  b->flags &= ~B_DIRTY;
8010290e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102911:	8b 00                	mov    (%eax),%eax
80102913:	83 e0 fb             	and    $0xfffffffb,%eax
80102916:	89 c2                	mov    %eax,%edx
80102918:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010291b:	89 10                	mov    %edx,(%eax)
  wakeup(b);
8010291d:	83 ec 0c             	sub    $0xc,%esp
80102920:	ff 75 f4             	push   -0xc(%ebp)
80102923:	e8 67 23 00 00       	call   80104c8f <wakeup>
80102928:	83 c4 10             	add    $0x10,%esp

  // Start disk on next buf in queue.
  if(idequeue != 0)
8010292b:	a1 94 26 11 80       	mov    0x80112694,%eax
80102930:	85 c0                	test   %eax,%eax
80102932:	74 11                	je     80102945 <ideintr+0xc3>
    idestart(idequeue);
80102934:	a1 94 26 11 80       	mov    0x80112694,%eax
80102939:	83 ec 0c             	sub    $0xc,%esp
8010293c:	50                   	push   %eax
8010293d:	e8 ac fd ff ff       	call   801026ee <idestart>
80102942:	83 c4 10             	add    $0x10,%esp

  release(&idelock);
80102945:	83 ec 0c             	sub    $0xc,%esp
80102948:	68 60 26 11 80       	push   $0x80112660
8010294d:	e8 05 27 00 00       	call   80105057 <release>
80102952:	83 c4 10             	add    $0x10,%esp
}
80102955:	c9                   	leave
80102956:	c3                   	ret

80102957 <iderw>:
// Sync buf with disk.
// If B_DIRTY is set, write buf to disk, clear B_DIRTY, set B_VALID.
// Else if B_VALID is not set, read buf from disk, set B_VALID.
void
iderw(struct buf *b)
{
80102957:	55                   	push   %ebp
80102958:	89 e5                	mov    %esp,%ebp
8010295a:	83 ec 18             	sub    $0x18,%esp
  struct buf **pp;

  if(!holdingsleep(&b->lock))
8010295d:	8b 45 08             	mov    0x8(%ebp),%eax
80102960:	83 c0 0c             	add    $0xc,%eax
80102963:	83 ec 0c             	sub    $0xc,%esp
80102966:	50                   	push   %eax
80102967:	e8 c6 25 00 00       	call   80104f32 <holdingsleep>
8010296c:	83 c4 10             	add    $0x10,%esp
8010296f:	85 c0                	test   %eax,%eax
80102971:	75 0d                	jne    80102980 <iderw+0x29>
    panic("iderw: buf not locked");
80102973:	83 ec 0c             	sub    $0xc,%esp
80102976:	68 52 86 10 80       	push   $0x80108652
8010297b:	e8 33 dc ff ff       	call   801005b3 <panic>
  if((b->flags & (B_VALID|B_DIRTY)) == B_VALID)
80102980:	8b 45 08             	mov    0x8(%ebp),%eax
80102983:	8b 00                	mov    (%eax),%eax
80102985:	83 e0 06             	and    $0x6,%eax
80102988:	83 f8 02             	cmp    $0x2,%eax
8010298b:	75 0d                	jne    8010299a <iderw+0x43>
    panic("iderw: nothing to do");
8010298d:	83 ec 0c             	sub    $0xc,%esp
80102990:	68 68 86 10 80       	push   $0x80108668
80102995:	e8 19 dc ff ff       	call   801005b3 <panic>
  if(b->dev != 0 && !havedisk1)
8010299a:	8b 45 08             	mov    0x8(%ebp),%eax
8010299d:	8b 40 04             	mov    0x4(%eax),%eax
801029a0:	85 c0                	test   %eax,%eax
801029a2:	74 16                	je     801029ba <iderw+0x63>
801029a4:	a1 98 26 11 80       	mov    0x80112698,%eax
801029a9:	85 c0                	test   %eax,%eax
801029ab:	75 0d                	jne    801029ba <iderw+0x63>
    panic("iderw: ide disk 1 not present");
801029ad:	83 ec 0c             	sub    $0xc,%esp
801029b0:	68 7d 86 10 80       	push   $0x8010867d
801029b5:	e8 f9 db ff ff       	call   801005b3 <panic>

  acquire(&idelock);  //DOC:acquire-lock
801029ba:	83 ec 0c             	sub    $0xc,%esp
801029bd:	68 60 26 11 80       	push   $0x80112660
801029c2:	e8 22 26 00 00       	call   80104fe9 <acquire>
801029c7:	83 c4 10             	add    $0x10,%esp

  // Append b to idequeue.
  b->qnext = 0;
801029ca:	8b 45 08             	mov    0x8(%ebp),%eax
801029cd:	c7 40 58 00 00 00 00 	movl   $0x0,0x58(%eax)
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
801029d4:	c7 45 f4 94 26 11 80 	movl   $0x80112694,-0xc(%ebp)
801029db:	eb 0b                	jmp    801029e8 <iderw+0x91>
801029dd:	8b 45 f4             	mov    -0xc(%ebp),%eax
801029e0:	8b 00                	mov    (%eax),%eax
801029e2:	83 c0 58             	add    $0x58,%eax
801029e5:	89 45 f4             	mov    %eax,-0xc(%ebp)
801029e8:	8b 45 f4             	mov    -0xc(%ebp),%eax
801029eb:	8b 00                	mov    (%eax),%eax
801029ed:	85 c0                	test   %eax,%eax
801029ef:	75 ec                	jne    801029dd <iderw+0x86>
    ;
  *pp = b;
801029f1:	8b 45 f4             	mov    -0xc(%ebp),%eax
801029f4:	8b 55 08             	mov    0x8(%ebp),%edx
801029f7:	89 10                	mov    %edx,(%eax)

  // Start disk if necessary.
  if(idequeue == b)
801029f9:	a1 94 26 11 80       	mov    0x80112694,%eax
801029fe:	39 45 08             	cmp    %eax,0x8(%ebp)
80102a01:	75 23                	jne    80102a26 <iderw+0xcf>
    idestart(b);
80102a03:	83 ec 0c             	sub    $0xc,%esp
80102a06:	ff 75 08             	push   0x8(%ebp)
80102a09:	e8 e0 fc ff ff       	call   801026ee <idestart>
80102a0e:	83 c4 10             	add    $0x10,%esp

  // Wait for request to finish.
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80102a11:	eb 13                	jmp    80102a26 <iderw+0xcf>
    sleep(b, &idelock);
80102a13:	83 ec 08             	sub    $0x8,%esp
80102a16:	68 60 26 11 80       	push   $0x80112660
80102a1b:	ff 75 08             	push   0x8(%ebp)
80102a1e:	e8 85 21 00 00       	call   80104ba8 <sleep>
80102a23:	83 c4 10             	add    $0x10,%esp
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80102a26:	8b 45 08             	mov    0x8(%ebp),%eax
80102a29:	8b 00                	mov    (%eax),%eax
80102a2b:	83 e0 06             	and    $0x6,%eax
80102a2e:	83 f8 02             	cmp    $0x2,%eax
80102a31:	75 e0                	jne    80102a13 <iderw+0xbc>
  }


  release(&idelock);
80102a33:	83 ec 0c             	sub    $0xc,%esp
80102a36:	68 60 26 11 80       	push   $0x80112660
80102a3b:	e8 17 26 00 00       	call   80105057 <release>
80102a40:	83 c4 10             	add    $0x10,%esp
}
80102a43:	90                   	nop
80102a44:	c9                   	leave
80102a45:	c3                   	ret

80102a46 <ioapicread>:
  uint data;
};

static uint
ioapicread(int reg)
{
80102a46:	55                   	push   %ebp
80102a47:	89 e5                	mov    %esp,%ebp
  ioapic->reg = reg;
80102a49:	a1 9c 26 11 80       	mov    0x8011269c,%eax
80102a4e:	8b 55 08             	mov    0x8(%ebp),%edx
80102a51:	89 10                	mov    %edx,(%eax)
  return ioapic->data;
80102a53:	a1 9c 26 11 80       	mov    0x8011269c,%eax
80102a58:	8b 40 10             	mov    0x10(%eax),%eax
}
80102a5b:	5d                   	pop    %ebp
80102a5c:	c3                   	ret

80102a5d <ioapicwrite>:

static void
ioapicwrite(int reg, uint data)
{
80102a5d:	55                   	push   %ebp
80102a5e:	89 e5                	mov    %esp,%ebp
  ioapic->reg = reg;
80102a60:	a1 9c 26 11 80       	mov    0x8011269c,%eax
80102a65:	8b 55 08             	mov    0x8(%ebp),%edx
80102a68:	89 10                	mov    %edx,(%eax)
  ioapic->data = data;
80102a6a:	a1 9c 26 11 80       	mov    0x8011269c,%eax
80102a6f:	8b 55 0c             	mov    0xc(%ebp),%edx
80102a72:	89 50 10             	mov    %edx,0x10(%eax)
}
80102a75:	90                   	nop
80102a76:	5d                   	pop    %ebp
80102a77:	c3                   	ret

80102a78 <ioapicinit>:

void
ioapicinit(void)
{
80102a78:	55                   	push   %ebp
80102a79:	89 e5                	mov    %esp,%ebp
80102a7b:	83 ec 18             	sub    $0x18,%esp
  int i, id, maxintr;

  ioapic = (volatile struct ioapic*)IOAPIC;
80102a7e:	c7 05 9c 26 11 80 00 	movl   $0xfec00000,0x8011269c
80102a85:	00 c0 fe 
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
80102a88:	6a 01                	push   $0x1
80102a8a:	e8 b7 ff ff ff       	call   80102a46 <ioapicread>
80102a8f:	83 c4 04             	add    $0x4,%esp
80102a92:	c1 e8 10             	shr    $0x10,%eax
80102a95:	25 ff 00 00 00       	and    $0xff,%eax
80102a9a:	89 45 f0             	mov    %eax,-0x10(%ebp)
  id = ioapicread(REG_ID) >> 24;
80102a9d:	6a 00                	push   $0x0
80102a9f:	e8 a2 ff ff ff       	call   80102a46 <ioapicread>
80102aa4:	83 c4 04             	add    $0x4,%esp
80102aa7:	c1 e8 18             	shr    $0x18,%eax
80102aaa:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if(id != ioapicid)
80102aad:	0f b6 05 64 2d 11 80 	movzbl 0x80112d64,%eax
80102ab4:	0f b6 c0             	movzbl %al,%eax
80102ab7:	39 45 ec             	cmp    %eax,-0x14(%ebp)
80102aba:	74 10                	je     80102acc <ioapicinit+0x54>
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");
80102abc:	83 ec 0c             	sub    $0xc,%esp
80102abf:	68 9c 86 10 80       	push   $0x8010869c
80102ac4:	e8 35 d9 ff ff       	call   801003fe <cprintf>
80102ac9:	83 c4 10             	add    $0x10,%esp

  // Mark all interrupts edge-triggered, active high, disabled,
  // and not routed to any CPUs.
  for(i = 0; i <= maxintr; i++){
80102acc:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80102ad3:	eb 3f                	jmp    80102b14 <ioapicinit+0x9c>
    ioapicwrite(REG_TABLE+2*i, INT_DISABLED | (T_IRQ0 + i));
80102ad5:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102ad8:	83 c0 20             	add    $0x20,%eax
80102adb:	0d 00 00 01 00       	or     $0x10000,%eax
80102ae0:	89 c2                	mov    %eax,%edx
80102ae2:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102ae5:	83 c0 08             	add    $0x8,%eax
80102ae8:	01 c0                	add    %eax,%eax
80102aea:	83 ec 08             	sub    $0x8,%esp
80102aed:	52                   	push   %edx
80102aee:	50                   	push   %eax
80102aef:	e8 69 ff ff ff       	call   80102a5d <ioapicwrite>
80102af4:	83 c4 10             	add    $0x10,%esp
    ioapicwrite(REG_TABLE+2*i+1, 0);
80102af7:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102afa:	83 c0 08             	add    $0x8,%eax
80102afd:	01 c0                	add    %eax,%eax
80102aff:	83 c0 01             	add    $0x1,%eax
80102b02:	83 ec 08             	sub    $0x8,%esp
80102b05:	6a 00                	push   $0x0
80102b07:	50                   	push   %eax
80102b08:	e8 50 ff ff ff       	call   80102a5d <ioapicwrite>
80102b0d:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i <= maxintr; i++){
80102b10:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80102b14:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102b17:	3b 45 f0             	cmp    -0x10(%ebp),%eax
80102b1a:	7e b9                	jle    80102ad5 <ioapicinit+0x5d>
  }
}
80102b1c:	90                   	nop
80102b1d:	90                   	nop
80102b1e:	c9                   	leave
80102b1f:	c3                   	ret

80102b20 <ioapicenable>:

void
ioapicenable(int irq, int cpunum)
{
80102b20:	55                   	push   %ebp
80102b21:	89 e5                	mov    %esp,%ebp
  // Mark interrupt edge-triggered, active high,
  // enabled, and routed to the given cpunum,
  // which happens to be that cpu's APIC ID.
  ioapicwrite(REG_TABLE+2*irq, T_IRQ0 + irq);
80102b23:	8b 45 08             	mov    0x8(%ebp),%eax
80102b26:	83 c0 20             	add    $0x20,%eax
80102b29:	89 c2                	mov    %eax,%edx
80102b2b:	8b 45 08             	mov    0x8(%ebp),%eax
80102b2e:	83 c0 08             	add    $0x8,%eax
80102b31:	01 c0                	add    %eax,%eax
80102b33:	52                   	push   %edx
80102b34:	50                   	push   %eax
80102b35:	e8 23 ff ff ff       	call   80102a5d <ioapicwrite>
80102b3a:	83 c4 08             	add    $0x8,%esp
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
80102b3d:	8b 45 0c             	mov    0xc(%ebp),%eax
80102b40:	c1 e0 18             	shl    $0x18,%eax
80102b43:	89 c2                	mov    %eax,%edx
80102b45:	8b 45 08             	mov    0x8(%ebp),%eax
80102b48:	83 c0 08             	add    $0x8,%eax
80102b4b:	01 c0                	add    %eax,%eax
80102b4d:	83 c0 01             	add    $0x1,%eax
80102b50:	52                   	push   %edx
80102b51:	50                   	push   %eax
80102b52:	e8 06 ff ff ff       	call   80102a5d <ioapicwrite>
80102b57:	83 c4 08             	add    $0x8,%esp
}
80102b5a:	90                   	nop
80102b5b:	c9                   	leave
80102b5c:	c3                   	ret

80102b5d <kinit1>:
// the pages mapped by entrypgdir on free list.
// 2. main() calls kinit2() with the rest of the physical pages
// after installing a full page table that maps them on all cores.
void
kinit1(void *vstart, void *vend)
{
80102b5d:	55                   	push   %ebp
80102b5e:	89 e5                	mov    %esp,%ebp
80102b60:	83 ec 08             	sub    $0x8,%esp
  initlock(&kmem.lock, "kmem");
80102b63:	83 ec 08             	sub    $0x8,%esp
80102b66:	68 ce 86 10 80       	push   $0x801086ce
80102b6b:	68 a0 26 11 80       	push   $0x801126a0
80102b70:	e8 52 24 00 00       	call   80104fc7 <initlock>
80102b75:	83 c4 10             	add    $0x10,%esp
  kmem.use_lock = 0;
80102b78:	c7 05 d4 26 11 80 00 	movl   $0x0,0x801126d4
80102b7f:	00 00 00 
  freerange(vstart, vend);
80102b82:	83 ec 08             	sub    $0x8,%esp
80102b85:	ff 75 0c             	push   0xc(%ebp)
80102b88:	ff 75 08             	push   0x8(%ebp)
80102b8b:	e8 2a 00 00 00       	call   80102bba <freerange>
80102b90:	83 c4 10             	add    $0x10,%esp
}
80102b93:	90                   	nop
80102b94:	c9                   	leave
80102b95:	c3                   	ret

80102b96 <kinit2>:

void
kinit2(void *vstart, void *vend)
{
80102b96:	55                   	push   %ebp
80102b97:	89 e5                	mov    %esp,%ebp
80102b99:	83 ec 08             	sub    $0x8,%esp
  freerange(vstart, vend);
80102b9c:	83 ec 08             	sub    $0x8,%esp
80102b9f:	ff 75 0c             	push   0xc(%ebp)
80102ba2:	ff 75 08             	push   0x8(%ebp)
80102ba5:	e8 10 00 00 00       	call   80102bba <freerange>
80102baa:	83 c4 10             	add    $0x10,%esp
  kmem.use_lock = 1;
80102bad:	c7 05 d4 26 11 80 01 	movl   $0x1,0x801126d4
80102bb4:	00 00 00 
}
80102bb7:	90                   	nop
80102bb8:	c9                   	leave
80102bb9:	c3                   	ret

80102bba <freerange>:

void
freerange(void *vstart, void *vend)
{
80102bba:	55                   	push   %ebp
80102bbb:	89 e5                	mov    %esp,%ebp
80102bbd:	83 ec 18             	sub    $0x18,%esp
  char *p;
  p = (char*)PGROUNDUP((uint)vstart);
80102bc0:	8b 45 08             	mov    0x8(%ebp),%eax
80102bc3:	05 ff 0f 00 00       	add    $0xfff,%eax
80102bc8:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80102bcd:	89 45 f4             	mov    %eax,-0xc(%ebp)
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102bd0:	eb 15                	jmp    80102be7 <freerange+0x2d>
    kfree(p);
80102bd2:	83 ec 0c             	sub    $0xc,%esp
80102bd5:	ff 75 f4             	push   -0xc(%ebp)
80102bd8:	e8 1b 00 00 00       	call   80102bf8 <kfree>
80102bdd:	83 c4 10             	add    $0x10,%esp
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102be0:	81 45 f4 00 10 00 00 	addl   $0x1000,-0xc(%ebp)
80102be7:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102bea:	05 00 10 00 00       	add    $0x1000,%eax
80102bef:	39 45 0c             	cmp    %eax,0xc(%ebp)
80102bf2:	73 de                	jae    80102bd2 <freerange+0x18>
}
80102bf4:	90                   	nop
80102bf5:	90                   	nop
80102bf6:	c9                   	leave
80102bf7:	c3                   	ret

80102bf8 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
80102bf8:	55                   	push   %ebp
80102bf9:	89 e5                	mov    %esp,%ebp
80102bfb:	83 ec 18             	sub    $0x18,%esp
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
80102bfe:	8b 45 08             	mov    0x8(%ebp),%eax
80102c01:	25 ff 0f 00 00       	and    $0xfff,%eax
80102c06:	85 c0                	test   %eax,%eax
80102c08:	75 18                	jne    80102c22 <kfree+0x2a>
80102c0a:	81 7d 08 00 65 11 80 	cmpl   $0x80116500,0x8(%ebp)
80102c11:	72 0f                	jb     80102c22 <kfree+0x2a>
80102c13:	8b 45 08             	mov    0x8(%ebp),%eax
80102c16:	05 00 00 00 80       	add    $0x80000000,%eax
80102c1b:	3d ff ff ff 0d       	cmp    $0xdffffff,%eax
80102c20:	76 0d                	jbe    80102c2f <kfree+0x37>
    panic("kfree");
80102c22:	83 ec 0c             	sub    $0xc,%esp
80102c25:	68 d3 86 10 80       	push   $0x801086d3
80102c2a:	e8 84 d9 ff ff       	call   801005b3 <panic>

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);
80102c2f:	83 ec 04             	sub    $0x4,%esp
80102c32:	68 00 10 00 00       	push   $0x1000
80102c37:	6a 01                	push   $0x1
80102c39:	ff 75 08             	push   0x8(%ebp)
80102c3c:	e8 2e 26 00 00       	call   8010526f <memset>
80102c41:	83 c4 10             	add    $0x10,%esp

  if(kmem.use_lock)
80102c44:	a1 d4 26 11 80       	mov    0x801126d4,%eax
80102c49:	85 c0                	test   %eax,%eax
80102c4b:	74 10                	je     80102c5d <kfree+0x65>
    acquire(&kmem.lock);
80102c4d:	83 ec 0c             	sub    $0xc,%esp
80102c50:	68 a0 26 11 80       	push   $0x801126a0
80102c55:	e8 8f 23 00 00       	call   80104fe9 <acquire>
80102c5a:	83 c4 10             	add    $0x10,%esp
  r = (struct run*)v;
80102c5d:	8b 45 08             	mov    0x8(%ebp),%eax
80102c60:	89 45 f4             	mov    %eax,-0xc(%ebp)
  r->next = kmem.freelist;
80102c63:	8b 15 d8 26 11 80    	mov    0x801126d8,%edx
80102c69:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102c6c:	89 10                	mov    %edx,(%eax)
  kmem.freelist = r;
80102c6e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102c71:	a3 d8 26 11 80       	mov    %eax,0x801126d8
  if(kmem.use_lock)
80102c76:	a1 d4 26 11 80       	mov    0x801126d4,%eax
80102c7b:	85 c0                	test   %eax,%eax
80102c7d:	74 10                	je     80102c8f <kfree+0x97>
    release(&kmem.lock);
80102c7f:	83 ec 0c             	sub    $0xc,%esp
80102c82:	68 a0 26 11 80       	push   $0x801126a0
80102c87:	e8 cb 23 00 00       	call   80105057 <release>
80102c8c:	83 c4 10             	add    $0x10,%esp
}
80102c8f:	90                   	nop
80102c90:	c9                   	leave
80102c91:	c3                   	ret

80102c92 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
char*
kalloc(void)
{
80102c92:	55                   	push   %ebp
80102c93:	89 e5                	mov    %esp,%ebp
80102c95:	83 ec 18             	sub    $0x18,%esp
  struct run *r;

  if(kmem.use_lock)
80102c98:	a1 d4 26 11 80       	mov    0x801126d4,%eax
80102c9d:	85 c0                	test   %eax,%eax
80102c9f:	74 10                	je     80102cb1 <kalloc+0x1f>
    acquire(&kmem.lock);
80102ca1:	83 ec 0c             	sub    $0xc,%esp
80102ca4:	68 a0 26 11 80       	push   $0x801126a0
80102ca9:	e8 3b 23 00 00       	call   80104fe9 <acquire>
80102cae:	83 c4 10             	add    $0x10,%esp
  r = kmem.freelist;
80102cb1:	a1 d8 26 11 80       	mov    0x801126d8,%eax
80102cb6:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(r)
80102cb9:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80102cbd:	74 0a                	je     80102cc9 <kalloc+0x37>
    kmem.freelist = r->next;
80102cbf:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102cc2:	8b 00                	mov    (%eax),%eax
80102cc4:	a3 d8 26 11 80       	mov    %eax,0x801126d8
  if(kmem.use_lock)
80102cc9:	a1 d4 26 11 80       	mov    0x801126d4,%eax
80102cce:	85 c0                	test   %eax,%eax
80102cd0:	74 10                	je     80102ce2 <kalloc+0x50>
    release(&kmem.lock);
80102cd2:	83 ec 0c             	sub    $0xc,%esp
80102cd5:	68 a0 26 11 80       	push   $0x801126a0
80102cda:	e8 78 23 00 00       	call   80105057 <release>
80102cdf:	83 c4 10             	add    $0x10,%esp
  return (char*)r;
80102ce2:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
80102ce5:	c9                   	leave
80102ce6:	c3                   	ret

80102ce7 <inb>:
{
80102ce7:	55                   	push   %ebp
80102ce8:	89 e5                	mov    %esp,%ebp
80102cea:	83 ec 14             	sub    $0x14,%esp
80102ced:	8b 45 08             	mov    0x8(%ebp),%eax
80102cf0:	66 89 45 ec          	mov    %ax,-0x14(%ebp)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102cf4:	0f b7 45 ec          	movzwl -0x14(%ebp),%eax
80102cf8:	89 c2                	mov    %eax,%edx
80102cfa:	ec                   	in     (%dx),%al
80102cfb:	88 45 ff             	mov    %al,-0x1(%ebp)
  return data;
80102cfe:	0f b6 45 ff          	movzbl -0x1(%ebp),%eax
}
80102d02:	c9                   	leave
80102d03:	c3                   	ret

80102d04 <kbdgetc>:
#include "defs.h"
#include "kbd.h"

int
kbdgetc(void)
{
80102d04:	55                   	push   %ebp
80102d05:	89 e5                	mov    %esp,%ebp
80102d07:	83 ec 10             	sub    $0x10,%esp
  static uchar *charcode[4] = {
    normalmap, shiftmap, ctlmap, ctlmap
  };
  uint st, data, c;

  st = inb(KBSTATP);
80102d0a:	6a 64                	push   $0x64
80102d0c:	e8 d6 ff ff ff       	call   80102ce7 <inb>
80102d11:	83 c4 04             	add    $0x4,%esp
80102d14:	0f b6 c0             	movzbl %al,%eax
80102d17:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if((st & KBS_DIB) == 0)
80102d1a:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102d1d:	83 e0 01             	and    $0x1,%eax
80102d20:	85 c0                	test   %eax,%eax
80102d22:	75 0a                	jne    80102d2e <kbdgetc+0x2a>
    return -1;
80102d24:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102d29:	e9 19 01 00 00       	jmp    80102e47 <kbdgetc+0x143>
  data = inb(KBDATAP);
80102d2e:	6a 60                	push   $0x60
80102d30:	e8 b2 ff ff ff       	call   80102ce7 <inb>
80102d35:	83 c4 04             	add    $0x4,%esp
80102d38:	0f b6 c0             	movzbl %al,%eax
80102d3b:	89 45 fc             	mov    %eax,-0x4(%ebp)

  if(data == 0xE0){
80102d3e:	81 7d fc e0 00 00 00 	cmpl   $0xe0,-0x4(%ebp)
80102d45:	75 17                	jne    80102d5e <kbdgetc+0x5a>
    shift |= E0ESC;
80102d47:	a1 dc 26 11 80       	mov    0x801126dc,%eax
80102d4c:	83 c8 40             	or     $0x40,%eax
80102d4f:	a3 dc 26 11 80       	mov    %eax,0x801126dc
    return 0;
80102d54:	b8 00 00 00 00       	mov    $0x0,%eax
80102d59:	e9 e9 00 00 00       	jmp    80102e47 <kbdgetc+0x143>
  } else if(data & 0x80){
80102d5e:	8b 45 fc             	mov    -0x4(%ebp),%eax
80102d61:	25 80 00 00 00       	and    $0x80,%eax
80102d66:	85 c0                	test   %eax,%eax
80102d68:	74 3b                	je     80102da5 <kbdgetc+0xa1>
    // Key released
    data = (shift & E0ESC ? data : data & 0x7F);
80102d6a:	a1 dc 26 11 80       	mov    0x801126dc,%eax
80102d6f:	83 e0 40             	and    $0x40,%eax
80102d72:	85 c0                	test   %eax,%eax
80102d74:	75 04                	jne    80102d7a <kbdgetc+0x76>
80102d76:	83 65 fc 7f          	andl   $0x7f,-0x4(%ebp)
    shift &= ~(shiftcode[data] | E0ESC);
80102d7a:	8b 45 fc             	mov    -0x4(%ebp),%eax
80102d7d:	05 20 90 10 80       	add    $0x80109020,%eax
80102d82:	0f b6 00             	movzbl (%eax),%eax
80102d85:	83 c8 40             	or     $0x40,%eax
80102d88:	0f b6 c0             	movzbl %al,%eax
80102d8b:	f7 d0                	not    %eax
80102d8d:	89 c2                	mov    %eax,%edx
80102d8f:	a1 dc 26 11 80       	mov    0x801126dc,%eax
80102d94:	21 d0                	and    %edx,%eax
80102d96:	a3 dc 26 11 80       	mov    %eax,0x801126dc
    return 0;
80102d9b:	b8 00 00 00 00       	mov    $0x0,%eax
80102da0:	e9 a2 00 00 00       	jmp    80102e47 <kbdgetc+0x143>
  } else if(shift & E0ESC){
80102da5:	a1 dc 26 11 80       	mov    0x801126dc,%eax
80102daa:	83 e0 40             	and    $0x40,%eax
80102dad:	85 c0                	test   %eax,%eax
80102daf:	74 14                	je     80102dc5 <kbdgetc+0xc1>
    // Last character was an E0 escape; or with 0x80
    data |= 0x80;
80102db1:	81 4d fc 80 00 00 00 	orl    $0x80,-0x4(%ebp)
    shift &= ~E0ESC;
80102db8:	a1 dc 26 11 80       	mov    0x801126dc,%eax
80102dbd:	83 e0 bf             	and    $0xffffffbf,%eax
80102dc0:	a3 dc 26 11 80       	mov    %eax,0x801126dc
  }

  shift |= shiftcode[data];
80102dc5:	8b 45 fc             	mov    -0x4(%ebp),%eax
80102dc8:	05 20 90 10 80       	add    $0x80109020,%eax
80102dcd:	0f b6 00             	movzbl (%eax),%eax
80102dd0:	0f b6 d0             	movzbl %al,%edx
80102dd3:	a1 dc 26 11 80       	mov    0x801126dc,%eax
80102dd8:	09 d0                	or     %edx,%eax
80102dda:	a3 dc 26 11 80       	mov    %eax,0x801126dc
  shift ^= togglecode[data];
80102ddf:	8b 45 fc             	mov    -0x4(%ebp),%eax
80102de2:	05 20 91 10 80       	add    $0x80109120,%eax
80102de7:	0f b6 00             	movzbl (%eax),%eax
80102dea:	0f b6 d0             	movzbl %al,%edx
80102ded:	a1 dc 26 11 80       	mov    0x801126dc,%eax
80102df2:	31 d0                	xor    %edx,%eax
80102df4:	a3 dc 26 11 80       	mov    %eax,0x801126dc
  c = charcode[shift & (CTL | SHIFT)][data];
80102df9:	a1 dc 26 11 80       	mov    0x801126dc,%eax
80102dfe:	83 e0 03             	and    $0x3,%eax
80102e01:	8b 14 85 20 95 10 80 	mov    -0x7fef6ae0(,%eax,4),%edx
80102e08:	8b 45 fc             	mov    -0x4(%ebp),%eax
80102e0b:	01 d0                	add    %edx,%eax
80102e0d:	0f b6 00             	movzbl (%eax),%eax
80102e10:	0f b6 c0             	movzbl %al,%eax
80102e13:	89 45 f8             	mov    %eax,-0x8(%ebp)
  if(shift & CAPSLOCK){
80102e16:	a1 dc 26 11 80       	mov    0x801126dc,%eax
80102e1b:	83 e0 08             	and    $0x8,%eax
80102e1e:	85 c0                	test   %eax,%eax
80102e20:	74 22                	je     80102e44 <kbdgetc+0x140>
    if('a' <= c && c <= 'z')
80102e22:	83 7d f8 60          	cmpl   $0x60,-0x8(%ebp)
80102e26:	76 0c                	jbe    80102e34 <kbdgetc+0x130>
80102e28:	83 7d f8 7a          	cmpl   $0x7a,-0x8(%ebp)
80102e2c:	77 06                	ja     80102e34 <kbdgetc+0x130>
      c += 'A' - 'a';
80102e2e:	83 6d f8 20          	subl   $0x20,-0x8(%ebp)
80102e32:	eb 10                	jmp    80102e44 <kbdgetc+0x140>
    else if('A' <= c && c <= 'Z')
80102e34:	83 7d f8 40          	cmpl   $0x40,-0x8(%ebp)
80102e38:	76 0a                	jbe    80102e44 <kbdgetc+0x140>
80102e3a:	83 7d f8 5a          	cmpl   $0x5a,-0x8(%ebp)
80102e3e:	77 04                	ja     80102e44 <kbdgetc+0x140>
      c += 'a' - 'A';
80102e40:	83 45 f8 20          	addl   $0x20,-0x8(%ebp)
  }
  return c;
80102e44:	8b 45 f8             	mov    -0x8(%ebp),%eax
}
80102e47:	c9                   	leave
80102e48:	c3                   	ret

80102e49 <kbdintr>:

void
kbdintr(void)
{
80102e49:	55                   	push   %ebp
80102e4a:	89 e5                	mov    %esp,%ebp
80102e4c:	83 ec 08             	sub    $0x8,%esp
  consoleintr(kbdgetc);
80102e4f:	83 ec 0c             	sub    $0xc,%esp
80102e52:	68 04 2d 10 80       	push   $0x80102d04
80102e57:	e8 ed d9 ff ff       	call   80100849 <consoleintr>
80102e5c:	83 c4 10             	add    $0x10,%esp
}
80102e5f:	90                   	nop
80102e60:	c9                   	leave
80102e61:	c3                   	ret

80102e62 <inb>:
{
80102e62:	55                   	push   %ebp
80102e63:	89 e5                	mov    %esp,%ebp
80102e65:	83 ec 14             	sub    $0x14,%esp
80102e68:	8b 45 08             	mov    0x8(%ebp),%eax
80102e6b:	66 89 45 ec          	mov    %ax,-0x14(%ebp)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102e6f:	0f b7 45 ec          	movzwl -0x14(%ebp),%eax
80102e73:	89 c2                	mov    %eax,%edx
80102e75:	ec                   	in     (%dx),%al
80102e76:	88 45 ff             	mov    %al,-0x1(%ebp)
  return data;
80102e79:	0f b6 45 ff          	movzbl -0x1(%ebp),%eax
}
80102e7d:	c9                   	leave
80102e7e:	c3                   	ret

80102e7f <outb>:
{
80102e7f:	55                   	push   %ebp
80102e80:	89 e5                	mov    %esp,%ebp
80102e82:	83 ec 08             	sub    $0x8,%esp
80102e85:	8b 55 08             	mov    0x8(%ebp),%edx
80102e88:	8b 45 0c             	mov    0xc(%ebp),%eax
80102e8b:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
80102e8f:	88 45 f8             	mov    %al,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102e92:	0f b6 45 f8          	movzbl -0x8(%ebp),%eax
80102e96:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
80102e9a:	ee                   	out    %al,(%dx)
}
80102e9b:	90                   	nop
80102e9c:	c9                   	leave
80102e9d:	c3                   	ret

80102e9e <lapicw>:
volatile uint *lapic;  // Initialized in mp.c

//PAGEBREAK!
static void
lapicw(int index, int value)
{
80102e9e:	55                   	push   %ebp
80102e9f:	89 e5                	mov    %esp,%ebp
  lapic[index] = value;
80102ea1:	a1 e0 26 11 80       	mov    0x801126e0,%eax
80102ea6:	8b 55 08             	mov    0x8(%ebp),%edx
80102ea9:	c1 e2 02             	shl    $0x2,%edx
80102eac:	01 c2                	add    %eax,%edx
80102eae:	8b 45 0c             	mov    0xc(%ebp),%eax
80102eb1:	89 02                	mov    %eax,(%edx)
  lapic[ID];  // wait for write to finish, by reading
80102eb3:	a1 e0 26 11 80       	mov    0x801126e0,%eax
80102eb8:	83 c0 20             	add    $0x20,%eax
80102ebb:	8b 00                	mov    (%eax),%eax
}
80102ebd:	90                   	nop
80102ebe:	5d                   	pop    %ebp
80102ebf:	c3                   	ret

80102ec0 <lapicinit>:

void
lapicinit(void)
{
80102ec0:	55                   	push   %ebp
80102ec1:	89 e5                	mov    %esp,%ebp
  if(!lapic)
80102ec3:	a1 e0 26 11 80       	mov    0x801126e0,%eax
80102ec8:	85 c0                	test   %eax,%eax
80102eca:	0f 84 09 01 00 00    	je     80102fd9 <lapicinit+0x119>
    return;

  // Enable local APIC; set spurious interrupt vector.
  lapicw(SVR, ENABLE | (T_IRQ0 + IRQ_SPURIOUS));
80102ed0:	68 3f 01 00 00       	push   $0x13f
80102ed5:	6a 3c                	push   $0x3c
80102ed7:	e8 c2 ff ff ff       	call   80102e9e <lapicw>
80102edc:	83 c4 08             	add    $0x8,%esp

  // The timer repeatedly counts down at bus frequency
  // from lapic[TICR] and then issues an interrupt.
  // If xv6 cared more about precise timekeeping,
  // TICR would be calibrated using an external time source.
  lapicw(TDCR, X1);
80102edf:	6a 0b                	push   $0xb
80102ee1:	68 f8 00 00 00       	push   $0xf8
80102ee6:	e8 b3 ff ff ff       	call   80102e9e <lapicw>
80102eeb:	83 c4 08             	add    $0x8,%esp
  lapicw(TIMER, PERIODIC | (T_IRQ0 + IRQ_TIMER));
80102eee:	68 20 00 02 00       	push   $0x20020
80102ef3:	68 c8 00 00 00       	push   $0xc8
80102ef8:	e8 a1 ff ff ff       	call   80102e9e <lapicw>
80102efd:	83 c4 08             	add    $0x8,%esp
  lapicw(TICR, 10000000);
80102f00:	68 80 96 98 00       	push   $0x989680
80102f05:	68 e0 00 00 00       	push   $0xe0
80102f0a:	e8 8f ff ff ff       	call   80102e9e <lapicw>
80102f0f:	83 c4 08             	add    $0x8,%esp

  // Disable logical interrupt lines.
  lapicw(LINT0, MASKED);
80102f12:	68 00 00 01 00       	push   $0x10000
80102f17:	68 d4 00 00 00       	push   $0xd4
80102f1c:	e8 7d ff ff ff       	call   80102e9e <lapicw>
80102f21:	83 c4 08             	add    $0x8,%esp
  lapicw(LINT1, MASKED);
80102f24:	68 00 00 01 00       	push   $0x10000
80102f29:	68 d8 00 00 00       	push   $0xd8
80102f2e:	e8 6b ff ff ff       	call   80102e9e <lapicw>
80102f33:	83 c4 08             	add    $0x8,%esp

  // Disable performance counter overflow interrupts
  // on machines that provide that interrupt entry.
  if(((lapic[VER]>>16) & 0xFF) >= 4)
80102f36:	a1 e0 26 11 80       	mov    0x801126e0,%eax
80102f3b:	83 c0 30             	add    $0x30,%eax
80102f3e:	8b 00                	mov    (%eax),%eax
80102f40:	25 00 00 fc 00       	and    $0xfc0000,%eax
80102f45:	85 c0                	test   %eax,%eax
80102f47:	74 12                	je     80102f5b <lapicinit+0x9b>
    lapicw(PCINT, MASKED);
80102f49:	68 00 00 01 00       	push   $0x10000
80102f4e:	68 d0 00 00 00       	push   $0xd0
80102f53:	e8 46 ff ff ff       	call   80102e9e <lapicw>
80102f58:	83 c4 08             	add    $0x8,%esp

  // Map error interrupt to IRQ_ERROR.
  lapicw(ERROR, T_IRQ0 + IRQ_ERROR);
80102f5b:	6a 33                	push   $0x33
80102f5d:	68 dc 00 00 00       	push   $0xdc
80102f62:	e8 37 ff ff ff       	call   80102e9e <lapicw>
80102f67:	83 c4 08             	add    $0x8,%esp

  // Clear error status register (requires back-to-back writes).
  lapicw(ESR, 0);
80102f6a:	6a 00                	push   $0x0
80102f6c:	68 a0 00 00 00       	push   $0xa0
80102f71:	e8 28 ff ff ff       	call   80102e9e <lapicw>
80102f76:	83 c4 08             	add    $0x8,%esp
  lapicw(ESR, 0);
80102f79:	6a 00                	push   $0x0
80102f7b:	68 a0 00 00 00       	push   $0xa0
80102f80:	e8 19 ff ff ff       	call   80102e9e <lapicw>
80102f85:	83 c4 08             	add    $0x8,%esp

  // Ack any outstanding interrupts.
  lapicw(EOI, 0);
80102f88:	6a 00                	push   $0x0
80102f8a:	6a 2c                	push   $0x2c
80102f8c:	e8 0d ff ff ff       	call   80102e9e <lapicw>
80102f91:	83 c4 08             	add    $0x8,%esp

  // Send an Init Level De-Assert to synchronise arbitration ID's.
  lapicw(ICRHI, 0);
80102f94:	6a 00                	push   $0x0
80102f96:	68 c4 00 00 00       	push   $0xc4
80102f9b:	e8 fe fe ff ff       	call   80102e9e <lapicw>
80102fa0:	83 c4 08             	add    $0x8,%esp
  lapicw(ICRLO, BCAST | INIT | LEVEL);
80102fa3:	68 00 85 08 00       	push   $0x88500
80102fa8:	68 c0 00 00 00       	push   $0xc0
80102fad:	e8 ec fe ff ff       	call   80102e9e <lapicw>
80102fb2:	83 c4 08             	add    $0x8,%esp
  while(lapic[ICRLO] & DELIVS)
80102fb5:	90                   	nop
80102fb6:	a1 e0 26 11 80       	mov    0x801126e0,%eax
80102fbb:	05 00 03 00 00       	add    $0x300,%eax
80102fc0:	8b 00                	mov    (%eax),%eax
80102fc2:	25 00 10 00 00       	and    $0x1000,%eax
80102fc7:	85 c0                	test   %eax,%eax
80102fc9:	75 eb                	jne    80102fb6 <lapicinit+0xf6>
    ;

  // Enable interrupts on the APIC (but not on the processor).
  lapicw(TPR, 0);
80102fcb:	6a 00                	push   $0x0
80102fcd:	6a 20                	push   $0x20
80102fcf:	e8 ca fe ff ff       	call   80102e9e <lapicw>
80102fd4:	83 c4 08             	add    $0x8,%esp
80102fd7:	eb 01                	jmp    80102fda <lapicinit+0x11a>
    return;
80102fd9:	90                   	nop
}
80102fda:	c9                   	leave
80102fdb:	c3                   	ret

80102fdc <lapicid>:

int
lapicid(void)
{
80102fdc:	55                   	push   %ebp
80102fdd:	89 e5                	mov    %esp,%ebp
  if (!lapic)
80102fdf:	a1 e0 26 11 80       	mov    0x801126e0,%eax
80102fe4:	85 c0                	test   %eax,%eax
80102fe6:	75 07                	jne    80102fef <lapicid+0x13>
    return 0;
80102fe8:	b8 00 00 00 00       	mov    $0x0,%eax
80102fed:	eb 0d                	jmp    80102ffc <lapicid+0x20>
  return lapic[ID] >> 24;
80102fef:	a1 e0 26 11 80       	mov    0x801126e0,%eax
80102ff4:	83 c0 20             	add    $0x20,%eax
80102ff7:	8b 00                	mov    (%eax),%eax
80102ff9:	c1 e8 18             	shr    $0x18,%eax
}
80102ffc:	5d                   	pop    %ebp
80102ffd:	c3                   	ret

80102ffe <lapiceoi>:

// Acknowledge interrupt.
void
lapiceoi(void)
{
80102ffe:	55                   	push   %ebp
80102fff:	89 e5                	mov    %esp,%ebp
  if(lapic)
80103001:	a1 e0 26 11 80       	mov    0x801126e0,%eax
80103006:	85 c0                	test   %eax,%eax
80103008:	74 0c                	je     80103016 <lapiceoi+0x18>
    lapicw(EOI, 0);
8010300a:	6a 00                	push   $0x0
8010300c:	6a 2c                	push   $0x2c
8010300e:	e8 8b fe ff ff       	call   80102e9e <lapicw>
80103013:	83 c4 08             	add    $0x8,%esp
}
80103016:	90                   	nop
80103017:	c9                   	leave
80103018:	c3                   	ret

80103019 <microdelay>:

// Spin for a given number of microseconds.
// On real hardware would want to tune this dynamically.
void
microdelay(int us)
{
80103019:	55                   	push   %ebp
8010301a:	89 e5                	mov    %esp,%ebp
}
8010301c:	90                   	nop
8010301d:	5d                   	pop    %ebp
8010301e:	c3                   	ret

8010301f <lapicstartap>:

// Start additional processor running entry code at addr.
// See Appendix B of MultiProcessor Specification.
void
lapicstartap(uchar apicid, uint addr)
{
8010301f:	55                   	push   %ebp
80103020:	89 e5                	mov    %esp,%ebp
80103022:	83 ec 14             	sub    $0x14,%esp
80103025:	8b 45 08             	mov    0x8(%ebp),%eax
80103028:	88 45 ec             	mov    %al,-0x14(%ebp)
  ushort *wrv;

  // "The BSP must initialize CMOS shutdown code to 0AH
  // and the warm reset vector (DWORD based at 40:67) to point at
  // the AP startup code prior to the [universal startup algorithm]."
  outb(CMOS_PORT, 0xF);  // offset 0xF is shutdown code
8010302b:	6a 0f                	push   $0xf
8010302d:	6a 70                	push   $0x70
8010302f:	e8 4b fe ff ff       	call   80102e7f <outb>
80103034:	83 c4 08             	add    $0x8,%esp
  outb(CMOS_PORT+1, 0x0A);
80103037:	6a 0a                	push   $0xa
80103039:	6a 71                	push   $0x71
8010303b:	e8 3f fe ff ff       	call   80102e7f <outb>
80103040:	83 c4 08             	add    $0x8,%esp
  wrv = (ushort*)P2V((0x40<<4 | 0x67));  // Warm reset vector
80103043:	c7 45 f8 67 04 00 80 	movl   $0x80000467,-0x8(%ebp)
  wrv[0] = 0;
8010304a:	8b 45 f8             	mov    -0x8(%ebp),%eax
8010304d:	66 c7 00 00 00       	movw   $0x0,(%eax)
  wrv[1] = addr >> 4;
80103052:	8b 45 0c             	mov    0xc(%ebp),%eax
80103055:	c1 e8 04             	shr    $0x4,%eax
80103058:	89 c2                	mov    %eax,%edx
8010305a:	8b 45 f8             	mov    -0x8(%ebp),%eax
8010305d:	83 c0 02             	add    $0x2,%eax
80103060:	66 89 10             	mov    %dx,(%eax)

  // "Universal startup algorithm."
  // Send INIT (level-triggered) interrupt to reset other CPU.
  lapicw(ICRHI, apicid<<24);
80103063:	0f b6 45 ec          	movzbl -0x14(%ebp),%eax
80103067:	c1 e0 18             	shl    $0x18,%eax
8010306a:	50                   	push   %eax
8010306b:	68 c4 00 00 00       	push   $0xc4
80103070:	e8 29 fe ff ff       	call   80102e9e <lapicw>
80103075:	83 c4 08             	add    $0x8,%esp
  lapicw(ICRLO, INIT | LEVEL | ASSERT);
80103078:	68 00 c5 00 00       	push   $0xc500
8010307d:	68 c0 00 00 00       	push   $0xc0
80103082:	e8 17 fe ff ff       	call   80102e9e <lapicw>
80103087:	83 c4 08             	add    $0x8,%esp
  microdelay(200);
8010308a:	68 c8 00 00 00       	push   $0xc8
8010308f:	e8 85 ff ff ff       	call   80103019 <microdelay>
80103094:	83 c4 04             	add    $0x4,%esp
  lapicw(ICRLO, INIT | LEVEL);
80103097:	68 00 85 00 00       	push   $0x8500
8010309c:	68 c0 00 00 00       	push   $0xc0
801030a1:	e8 f8 fd ff ff       	call   80102e9e <lapicw>
801030a6:	83 c4 08             	add    $0x8,%esp
  microdelay(100);    // should be 10ms, but too slow in Bochs!
801030a9:	6a 64                	push   $0x64
801030ab:	e8 69 ff ff ff       	call   80103019 <microdelay>
801030b0:	83 c4 04             	add    $0x4,%esp
  // Send startup IPI (twice!) to enter code.
  // Regular hardware is supposed to only accept a STARTUP
  // when it is in the halted state due to an INIT.  So the second
  // should be ignored, but it is part of the official Intel algorithm.
  // Bochs complains about the second one.  Too bad for Bochs.
  for(i = 0; i < 2; i++){
801030b3:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
801030ba:	eb 3d                	jmp    801030f9 <lapicstartap+0xda>
    lapicw(ICRHI, apicid<<24);
801030bc:	0f b6 45 ec          	movzbl -0x14(%ebp),%eax
801030c0:	c1 e0 18             	shl    $0x18,%eax
801030c3:	50                   	push   %eax
801030c4:	68 c4 00 00 00       	push   $0xc4
801030c9:	e8 d0 fd ff ff       	call   80102e9e <lapicw>
801030ce:	83 c4 08             	add    $0x8,%esp
    lapicw(ICRLO, STARTUP | (addr>>12));
801030d1:	8b 45 0c             	mov    0xc(%ebp),%eax
801030d4:	c1 e8 0c             	shr    $0xc,%eax
801030d7:	80 cc 06             	or     $0x6,%ah
801030da:	50                   	push   %eax
801030db:	68 c0 00 00 00       	push   $0xc0
801030e0:	e8 b9 fd ff ff       	call   80102e9e <lapicw>
801030e5:	83 c4 08             	add    $0x8,%esp
    microdelay(200);
801030e8:	68 c8 00 00 00       	push   $0xc8
801030ed:	e8 27 ff ff ff       	call   80103019 <microdelay>
801030f2:	83 c4 04             	add    $0x4,%esp
  for(i = 0; i < 2; i++){
801030f5:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
801030f9:	83 7d fc 01          	cmpl   $0x1,-0x4(%ebp)
801030fd:	7e bd                	jle    801030bc <lapicstartap+0x9d>
  }
}
801030ff:	90                   	nop
80103100:	90                   	nop
80103101:	c9                   	leave
80103102:	c3                   	ret

80103103 <cmos_read>:
#define MONTH   0x08
#define YEAR    0x09

static uint
cmos_read(uint reg)
{
80103103:	55                   	push   %ebp
80103104:	89 e5                	mov    %esp,%ebp
  outb(CMOS_PORT,  reg);
80103106:	8b 45 08             	mov    0x8(%ebp),%eax
80103109:	0f b6 c0             	movzbl %al,%eax
8010310c:	50                   	push   %eax
8010310d:	6a 70                	push   $0x70
8010310f:	e8 6b fd ff ff       	call   80102e7f <outb>
80103114:	83 c4 08             	add    $0x8,%esp
  microdelay(200);
80103117:	68 c8 00 00 00       	push   $0xc8
8010311c:	e8 f8 fe ff ff       	call   80103019 <microdelay>
80103121:	83 c4 04             	add    $0x4,%esp

  return inb(CMOS_RETURN);
80103124:	6a 71                	push   $0x71
80103126:	e8 37 fd ff ff       	call   80102e62 <inb>
8010312b:	83 c4 04             	add    $0x4,%esp
8010312e:	0f b6 c0             	movzbl %al,%eax
}
80103131:	c9                   	leave
80103132:	c3                   	ret

80103133 <fill_rtcdate>:

static void
fill_rtcdate(struct rtcdate *r)
{
80103133:	55                   	push   %ebp
80103134:	89 e5                	mov    %esp,%ebp
  r->second = cmos_read(SECS);
80103136:	6a 00                	push   $0x0
80103138:	e8 c6 ff ff ff       	call   80103103 <cmos_read>
8010313d:	83 c4 04             	add    $0x4,%esp
80103140:	8b 55 08             	mov    0x8(%ebp),%edx
80103143:	89 02                	mov    %eax,(%edx)
  r->minute = cmos_read(MINS);
80103145:	6a 02                	push   $0x2
80103147:	e8 b7 ff ff ff       	call   80103103 <cmos_read>
8010314c:	83 c4 04             	add    $0x4,%esp
8010314f:	8b 55 08             	mov    0x8(%ebp),%edx
80103152:	89 42 04             	mov    %eax,0x4(%edx)
  r->hour   = cmos_read(HOURS);
80103155:	6a 04                	push   $0x4
80103157:	e8 a7 ff ff ff       	call   80103103 <cmos_read>
8010315c:	83 c4 04             	add    $0x4,%esp
8010315f:	8b 55 08             	mov    0x8(%ebp),%edx
80103162:	89 42 08             	mov    %eax,0x8(%edx)
  r->day    = cmos_read(DAY);
80103165:	6a 07                	push   $0x7
80103167:	e8 97 ff ff ff       	call   80103103 <cmos_read>
8010316c:	83 c4 04             	add    $0x4,%esp
8010316f:	8b 55 08             	mov    0x8(%ebp),%edx
80103172:	89 42 0c             	mov    %eax,0xc(%edx)
  r->month  = cmos_read(MONTH);
80103175:	6a 08                	push   $0x8
80103177:	e8 87 ff ff ff       	call   80103103 <cmos_read>
8010317c:	83 c4 04             	add    $0x4,%esp
8010317f:	8b 55 08             	mov    0x8(%ebp),%edx
80103182:	89 42 10             	mov    %eax,0x10(%edx)
  r->year   = cmos_read(YEAR);
80103185:	6a 09                	push   $0x9
80103187:	e8 77 ff ff ff       	call   80103103 <cmos_read>
8010318c:	83 c4 04             	add    $0x4,%esp
8010318f:	8b 55 08             	mov    0x8(%ebp),%edx
80103192:	89 42 14             	mov    %eax,0x14(%edx)
}
80103195:	90                   	nop
80103196:	c9                   	leave
80103197:	c3                   	ret

80103198 <cmostime>:

// qemu seems to use 24-hour GWT and the values are BCD encoded
void
cmostime(struct rtcdate *r)
{
80103198:	55                   	push   %ebp
80103199:	89 e5                	mov    %esp,%ebp
8010319b:	83 ec 48             	sub    $0x48,%esp
  struct rtcdate t1, t2;
  int sb, bcd;

  sb = cmos_read(CMOS_STATB);
8010319e:	6a 0b                	push   $0xb
801031a0:	e8 5e ff ff ff       	call   80103103 <cmos_read>
801031a5:	83 c4 04             	add    $0x4,%esp
801031a8:	89 45 f4             	mov    %eax,-0xc(%ebp)

  bcd = (sb & (1 << 2)) == 0;
801031ab:	8b 45 f4             	mov    -0xc(%ebp),%eax
801031ae:	83 e0 04             	and    $0x4,%eax
801031b1:	c1 e8 02             	shr    $0x2,%eax
801031b4:	83 e0 01             	and    $0x1,%eax
801031b7:	83 f0 01             	xor    $0x1,%eax
801031ba:	0f b6 c0             	movzbl %al,%eax
801031bd:	89 45 f0             	mov    %eax,-0x10(%ebp)

  // make sure CMOS doesn't modify time while we read it
  for(;;) {
    fill_rtcdate(&t1);
801031c0:	8d 45 d8             	lea    -0x28(%ebp),%eax
801031c3:	50                   	push   %eax
801031c4:	e8 6a ff ff ff       	call   80103133 <fill_rtcdate>
801031c9:	83 c4 04             	add    $0x4,%esp
    if(cmos_read(CMOS_STATA) & CMOS_UIP)
801031cc:	6a 0a                	push   $0xa
801031ce:	e8 30 ff ff ff       	call   80103103 <cmos_read>
801031d3:	83 c4 04             	add    $0x4,%esp
801031d6:	25 80 00 00 00       	and    $0x80,%eax
801031db:	85 c0                	test   %eax,%eax
801031dd:	75 27                	jne    80103206 <cmostime+0x6e>
        continue;
    fill_rtcdate(&t2);
801031df:	8d 45 c0             	lea    -0x40(%ebp),%eax
801031e2:	50                   	push   %eax
801031e3:	e8 4b ff ff ff       	call   80103133 <fill_rtcdate>
801031e8:	83 c4 04             	add    $0x4,%esp
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
801031eb:	83 ec 04             	sub    $0x4,%esp
801031ee:	6a 18                	push   $0x18
801031f0:	8d 45 c0             	lea    -0x40(%ebp),%eax
801031f3:	50                   	push   %eax
801031f4:	8d 45 d8             	lea    -0x28(%ebp),%eax
801031f7:	50                   	push   %eax
801031f8:	e8 d9 20 00 00       	call   801052d6 <memcmp>
801031fd:	83 c4 10             	add    $0x10,%esp
80103200:	85 c0                	test   %eax,%eax
80103202:	74 05                	je     80103209 <cmostime+0x71>
80103204:	eb ba                	jmp    801031c0 <cmostime+0x28>
        continue;
80103206:	90                   	nop
    fill_rtcdate(&t1);
80103207:	eb b7                	jmp    801031c0 <cmostime+0x28>
      break;
80103209:	90                   	nop
  }

  // convert
  if(bcd) {
8010320a:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
8010320e:	0f 84 b4 00 00 00    	je     801032c8 <cmostime+0x130>
#define    CONV(x)     (t1.x = ((t1.x >> 4) * 10) + (t1.x & 0xf))
    CONV(second);
80103214:	8b 45 d8             	mov    -0x28(%ebp),%eax
80103217:	c1 e8 04             	shr    $0x4,%eax
8010321a:	89 c2                	mov    %eax,%edx
8010321c:	89 d0                	mov    %edx,%eax
8010321e:	c1 e0 02             	shl    $0x2,%eax
80103221:	01 d0                	add    %edx,%eax
80103223:	01 c0                	add    %eax,%eax
80103225:	89 c2                	mov    %eax,%edx
80103227:	8b 45 d8             	mov    -0x28(%ebp),%eax
8010322a:	83 e0 0f             	and    $0xf,%eax
8010322d:	01 d0                	add    %edx,%eax
8010322f:	89 45 d8             	mov    %eax,-0x28(%ebp)
    CONV(minute);
80103232:	8b 45 dc             	mov    -0x24(%ebp),%eax
80103235:	c1 e8 04             	shr    $0x4,%eax
80103238:	89 c2                	mov    %eax,%edx
8010323a:	89 d0                	mov    %edx,%eax
8010323c:	c1 e0 02             	shl    $0x2,%eax
8010323f:	01 d0                	add    %edx,%eax
80103241:	01 c0                	add    %eax,%eax
80103243:	89 c2                	mov    %eax,%edx
80103245:	8b 45 dc             	mov    -0x24(%ebp),%eax
80103248:	83 e0 0f             	and    $0xf,%eax
8010324b:	01 d0                	add    %edx,%eax
8010324d:	89 45 dc             	mov    %eax,-0x24(%ebp)
    CONV(hour  );
80103250:	8b 45 e0             	mov    -0x20(%ebp),%eax
80103253:	c1 e8 04             	shr    $0x4,%eax
80103256:	89 c2                	mov    %eax,%edx
80103258:	89 d0                	mov    %edx,%eax
8010325a:	c1 e0 02             	shl    $0x2,%eax
8010325d:	01 d0                	add    %edx,%eax
8010325f:	01 c0                	add    %eax,%eax
80103261:	89 c2                	mov    %eax,%edx
80103263:	8b 45 e0             	mov    -0x20(%ebp),%eax
80103266:	83 e0 0f             	and    $0xf,%eax
80103269:	01 d0                	add    %edx,%eax
8010326b:	89 45 e0             	mov    %eax,-0x20(%ebp)
    CONV(day   );
8010326e:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80103271:	c1 e8 04             	shr    $0x4,%eax
80103274:	89 c2                	mov    %eax,%edx
80103276:	89 d0                	mov    %edx,%eax
80103278:	c1 e0 02             	shl    $0x2,%eax
8010327b:	01 d0                	add    %edx,%eax
8010327d:	01 c0                	add    %eax,%eax
8010327f:	89 c2                	mov    %eax,%edx
80103281:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80103284:	83 e0 0f             	and    $0xf,%eax
80103287:	01 d0                	add    %edx,%eax
80103289:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    CONV(month );
8010328c:	8b 45 e8             	mov    -0x18(%ebp),%eax
8010328f:	c1 e8 04             	shr    $0x4,%eax
80103292:	89 c2                	mov    %eax,%edx
80103294:	89 d0                	mov    %edx,%eax
80103296:	c1 e0 02             	shl    $0x2,%eax
80103299:	01 d0                	add    %edx,%eax
8010329b:	01 c0                	add    %eax,%eax
8010329d:	89 c2                	mov    %eax,%edx
8010329f:	8b 45 e8             	mov    -0x18(%ebp),%eax
801032a2:	83 e0 0f             	and    $0xf,%eax
801032a5:	01 d0                	add    %edx,%eax
801032a7:	89 45 e8             	mov    %eax,-0x18(%ebp)
    CONV(year  );
801032aa:	8b 45 ec             	mov    -0x14(%ebp),%eax
801032ad:	c1 e8 04             	shr    $0x4,%eax
801032b0:	89 c2                	mov    %eax,%edx
801032b2:	89 d0                	mov    %edx,%eax
801032b4:	c1 e0 02             	shl    $0x2,%eax
801032b7:	01 d0                	add    %edx,%eax
801032b9:	01 c0                	add    %eax,%eax
801032bb:	89 c2                	mov    %eax,%edx
801032bd:	8b 45 ec             	mov    -0x14(%ebp),%eax
801032c0:	83 e0 0f             	and    $0xf,%eax
801032c3:	01 d0                	add    %edx,%eax
801032c5:	89 45 ec             	mov    %eax,-0x14(%ebp)
#undef     CONV
  }

  *r = t1;
801032c8:	8b 45 08             	mov    0x8(%ebp),%eax
801032cb:	8b 55 d8             	mov    -0x28(%ebp),%edx
801032ce:	89 10                	mov    %edx,(%eax)
801032d0:	8b 55 dc             	mov    -0x24(%ebp),%edx
801032d3:	89 50 04             	mov    %edx,0x4(%eax)
801032d6:	8b 55 e0             	mov    -0x20(%ebp),%edx
801032d9:	89 50 08             	mov    %edx,0x8(%eax)
801032dc:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801032df:	89 50 0c             	mov    %edx,0xc(%eax)
801032e2:	8b 55 e8             	mov    -0x18(%ebp),%edx
801032e5:	89 50 10             	mov    %edx,0x10(%eax)
801032e8:	8b 55 ec             	mov    -0x14(%ebp),%edx
801032eb:	89 50 14             	mov    %edx,0x14(%eax)
  r->year += 2000;
801032ee:	8b 45 08             	mov    0x8(%ebp),%eax
801032f1:	8b 40 14             	mov    0x14(%eax),%eax
801032f4:	8d 90 d0 07 00 00    	lea    0x7d0(%eax),%edx
801032fa:	8b 45 08             	mov    0x8(%ebp),%eax
801032fd:	89 50 14             	mov    %edx,0x14(%eax)
}
80103300:	90                   	nop
80103301:	c9                   	leave
80103302:	c3                   	ret

80103303 <initlog>:
static void recover_from_log(void);
static void commit();

void
initlog(int dev)
{
80103303:	55                   	push   %ebp
80103304:	89 e5                	mov    %esp,%ebp
80103306:	83 ec 28             	sub    $0x28,%esp
  if (sizeof(struct logheader) >= BSIZE)
    panic("initlog: too big logheader");

  struct superblock sb;
  initlock(&log.lock, "log");
80103309:	83 ec 08             	sub    $0x8,%esp
8010330c:	68 d9 86 10 80       	push   $0x801086d9
80103311:	68 00 27 11 80       	push   $0x80112700
80103316:	e8 ac 1c 00 00       	call   80104fc7 <initlock>
8010331b:	83 c4 10             	add    $0x10,%esp
  readsb(dev, &sb);
8010331e:	83 ec 08             	sub    $0x8,%esp
80103321:	8d 45 dc             	lea    -0x24(%ebp),%eax
80103324:	50                   	push   %eax
80103325:	ff 75 08             	push   0x8(%ebp)
80103328:	e8 e2 e0 ff ff       	call   8010140f <readsb>
8010332d:	83 c4 10             	add    $0x10,%esp
  log.start = sb.logstart;
80103330:	8b 45 ec             	mov    -0x14(%ebp),%eax
80103333:	a3 34 27 11 80       	mov    %eax,0x80112734
  log.size = sb.nlog;
80103338:	8b 45 e8             	mov    -0x18(%ebp),%eax
8010333b:	a3 38 27 11 80       	mov    %eax,0x80112738
  log.dev = dev;
80103340:	8b 45 08             	mov    0x8(%ebp),%eax
80103343:	a3 44 27 11 80       	mov    %eax,0x80112744
  recover_from_log();
80103348:	e8 b3 01 00 00       	call   80103500 <recover_from_log>
}
8010334d:	90                   	nop
8010334e:	c9                   	leave
8010334f:	c3                   	ret

80103350 <install_trans>:

// Copy committed blocks from log to their home location
static void
install_trans(void)
{
80103350:	55                   	push   %ebp
80103351:	89 e5                	mov    %esp,%ebp
80103353:	83 ec 18             	sub    $0x18,%esp
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
80103356:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
8010335d:	e9 95 00 00 00       	jmp    801033f7 <install_trans+0xa7>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
80103362:	8b 15 34 27 11 80    	mov    0x80112734,%edx
80103368:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010336b:	01 d0                	add    %edx,%eax
8010336d:	83 c0 01             	add    $0x1,%eax
80103370:	89 c2                	mov    %eax,%edx
80103372:	a1 44 27 11 80       	mov    0x80112744,%eax
80103377:	83 ec 08             	sub    $0x8,%esp
8010337a:	52                   	push   %edx
8010337b:	50                   	push   %eax
8010337c:	e8 4e ce ff ff       	call   801001cf <bread>
80103381:	83 c4 10             	add    $0x10,%esp
80103384:	89 45 f0             	mov    %eax,-0x10(%ebp)
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80103387:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010338a:	83 c0 10             	add    $0x10,%eax
8010338d:	8b 04 85 0c 27 11 80 	mov    -0x7feed8f4(,%eax,4),%eax
80103394:	89 c2                	mov    %eax,%edx
80103396:	a1 44 27 11 80       	mov    0x80112744,%eax
8010339b:	83 ec 08             	sub    $0x8,%esp
8010339e:	52                   	push   %edx
8010339f:	50                   	push   %eax
801033a0:	e8 2a ce ff ff       	call   801001cf <bread>
801033a5:	83 c4 10             	add    $0x10,%esp
801033a8:	89 45 ec             	mov    %eax,-0x14(%ebp)
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
801033ab:	8b 45 f0             	mov    -0x10(%ebp),%eax
801033ae:	8d 50 5c             	lea    0x5c(%eax),%edx
801033b1:	8b 45 ec             	mov    -0x14(%ebp),%eax
801033b4:	83 c0 5c             	add    $0x5c,%eax
801033b7:	83 ec 04             	sub    $0x4,%esp
801033ba:	68 00 02 00 00       	push   $0x200
801033bf:	52                   	push   %edx
801033c0:	50                   	push   %eax
801033c1:	e8 68 1f 00 00       	call   8010532e <memmove>
801033c6:	83 c4 10             	add    $0x10,%esp
    bwrite(dbuf);  // write dst to disk
801033c9:	83 ec 0c             	sub    $0xc,%esp
801033cc:	ff 75 ec             	push   -0x14(%ebp)
801033cf:	e8 34 ce ff ff       	call   80100208 <bwrite>
801033d4:	83 c4 10             	add    $0x10,%esp
    brelse(lbuf);
801033d7:	83 ec 0c             	sub    $0xc,%esp
801033da:	ff 75 f0             	push   -0x10(%ebp)
801033dd:	e8 6f ce ff ff       	call   80100251 <brelse>
801033e2:	83 c4 10             	add    $0x10,%esp
    brelse(dbuf);
801033e5:	83 ec 0c             	sub    $0xc,%esp
801033e8:	ff 75 ec             	push   -0x14(%ebp)
801033eb:	e8 61 ce ff ff       	call   80100251 <brelse>
801033f0:	83 c4 10             	add    $0x10,%esp
  for (tail = 0; tail < log.lh.n; tail++) {
801033f3:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
801033f7:	a1 48 27 11 80       	mov    0x80112748,%eax
801033fc:	39 45 f4             	cmp    %eax,-0xc(%ebp)
801033ff:	0f 8c 5d ff ff ff    	jl     80103362 <install_trans+0x12>
  }
}
80103405:	90                   	nop
80103406:	90                   	nop
80103407:	c9                   	leave
80103408:	c3                   	ret

80103409 <read_head>:

// Read the log header from disk into the in-memory log header
static void
read_head(void)
{
80103409:	55                   	push   %ebp
8010340a:	89 e5                	mov    %esp,%ebp
8010340c:	83 ec 18             	sub    $0x18,%esp
  struct buf *buf = bread(log.dev, log.start);
8010340f:	a1 34 27 11 80       	mov    0x80112734,%eax
80103414:	89 c2                	mov    %eax,%edx
80103416:	a1 44 27 11 80       	mov    0x80112744,%eax
8010341b:	83 ec 08             	sub    $0x8,%esp
8010341e:	52                   	push   %edx
8010341f:	50                   	push   %eax
80103420:	e8 aa cd ff ff       	call   801001cf <bread>
80103425:	83 c4 10             	add    $0x10,%esp
80103428:	89 45 f0             	mov    %eax,-0x10(%ebp)
  struct logheader *lh = (struct logheader *) (buf->data);
8010342b:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010342e:	83 c0 5c             	add    $0x5c,%eax
80103431:	89 45 ec             	mov    %eax,-0x14(%ebp)
  int i;
  log.lh.n = lh->n;
80103434:	8b 45 ec             	mov    -0x14(%ebp),%eax
80103437:	8b 00                	mov    (%eax),%eax
80103439:	a3 48 27 11 80       	mov    %eax,0x80112748
  for (i = 0; i < log.lh.n; i++) {
8010343e:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80103445:	eb 1b                	jmp    80103462 <read_head+0x59>
    log.lh.block[i] = lh->block[i];
80103447:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010344a:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010344d:	8b 44 90 04          	mov    0x4(%eax,%edx,4),%eax
80103451:	8b 55 f4             	mov    -0xc(%ebp),%edx
80103454:	83 c2 10             	add    $0x10,%edx
80103457:	89 04 95 0c 27 11 80 	mov    %eax,-0x7feed8f4(,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
8010345e:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80103462:	a1 48 27 11 80       	mov    0x80112748,%eax
80103467:	39 45 f4             	cmp    %eax,-0xc(%ebp)
8010346a:	7c db                	jl     80103447 <read_head+0x3e>
  }
  brelse(buf);
8010346c:	83 ec 0c             	sub    $0xc,%esp
8010346f:	ff 75 f0             	push   -0x10(%ebp)
80103472:	e8 da cd ff ff       	call   80100251 <brelse>
80103477:	83 c4 10             	add    $0x10,%esp
}
8010347a:	90                   	nop
8010347b:	c9                   	leave
8010347c:	c3                   	ret

8010347d <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
8010347d:	55                   	push   %ebp
8010347e:	89 e5                	mov    %esp,%ebp
80103480:	83 ec 18             	sub    $0x18,%esp
  struct buf *buf = bread(log.dev, log.start);
80103483:	a1 34 27 11 80       	mov    0x80112734,%eax
80103488:	89 c2                	mov    %eax,%edx
8010348a:	a1 44 27 11 80       	mov    0x80112744,%eax
8010348f:	83 ec 08             	sub    $0x8,%esp
80103492:	52                   	push   %edx
80103493:	50                   	push   %eax
80103494:	e8 36 cd ff ff       	call   801001cf <bread>
80103499:	83 c4 10             	add    $0x10,%esp
8010349c:	89 45 f0             	mov    %eax,-0x10(%ebp)
  struct logheader *hb = (struct logheader *) (buf->data);
8010349f:	8b 45 f0             	mov    -0x10(%ebp),%eax
801034a2:	83 c0 5c             	add    $0x5c,%eax
801034a5:	89 45 ec             	mov    %eax,-0x14(%ebp)
  int i;
  hb->n = log.lh.n;
801034a8:	8b 15 48 27 11 80    	mov    0x80112748,%edx
801034ae:	8b 45 ec             	mov    -0x14(%ebp),%eax
801034b1:	89 10                	mov    %edx,(%eax)
  for (i = 0; i < log.lh.n; i++) {
801034b3:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
801034ba:	eb 1b                	jmp    801034d7 <write_head+0x5a>
    hb->block[i] = log.lh.block[i];
801034bc:	8b 45 f4             	mov    -0xc(%ebp),%eax
801034bf:	83 c0 10             	add    $0x10,%eax
801034c2:	8b 0c 85 0c 27 11 80 	mov    -0x7feed8f4(,%eax,4),%ecx
801034c9:	8b 45 ec             	mov    -0x14(%ebp),%eax
801034cc:	8b 55 f4             	mov    -0xc(%ebp),%edx
801034cf:	89 4c 90 04          	mov    %ecx,0x4(%eax,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
801034d3:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
801034d7:	a1 48 27 11 80       	mov    0x80112748,%eax
801034dc:	39 45 f4             	cmp    %eax,-0xc(%ebp)
801034df:	7c db                	jl     801034bc <write_head+0x3f>
  }
  bwrite(buf);
801034e1:	83 ec 0c             	sub    $0xc,%esp
801034e4:	ff 75 f0             	push   -0x10(%ebp)
801034e7:	e8 1c cd ff ff       	call   80100208 <bwrite>
801034ec:	83 c4 10             	add    $0x10,%esp
  brelse(buf);
801034ef:	83 ec 0c             	sub    $0xc,%esp
801034f2:	ff 75 f0             	push   -0x10(%ebp)
801034f5:	e8 57 cd ff ff       	call   80100251 <brelse>
801034fa:	83 c4 10             	add    $0x10,%esp
}
801034fd:	90                   	nop
801034fe:	c9                   	leave
801034ff:	c3                   	ret

80103500 <recover_from_log>:

static void
recover_from_log(void)
{
80103500:	55                   	push   %ebp
80103501:	89 e5                	mov    %esp,%ebp
80103503:	83 ec 08             	sub    $0x8,%esp
  read_head();
80103506:	e8 fe fe ff ff       	call   80103409 <read_head>
  install_trans(); // if committed, copy from log to disk
8010350b:	e8 40 fe ff ff       	call   80103350 <install_trans>
  log.lh.n = 0;
80103510:	c7 05 48 27 11 80 00 	movl   $0x0,0x80112748
80103517:	00 00 00 
  write_head(); // clear the log
8010351a:	e8 5e ff ff ff       	call   8010347d <write_head>
}
8010351f:	90                   	nop
80103520:	c9                   	leave
80103521:	c3                   	ret

80103522 <begin_op>:

// called at the start of each FS system call.
void
begin_op(void)
{
80103522:	55                   	push   %ebp
80103523:	89 e5                	mov    %esp,%ebp
80103525:	83 ec 08             	sub    $0x8,%esp
  acquire(&log.lock);
80103528:	83 ec 0c             	sub    $0xc,%esp
8010352b:	68 00 27 11 80       	push   $0x80112700
80103530:	e8 b4 1a 00 00       	call   80104fe9 <acquire>
80103535:	83 c4 10             	add    $0x10,%esp
  while(1){
    if(log.committing){
80103538:	a1 40 27 11 80       	mov    0x80112740,%eax
8010353d:	85 c0                	test   %eax,%eax
8010353f:	74 17                	je     80103558 <begin_op+0x36>
      sleep(&log, &log.lock);
80103541:	83 ec 08             	sub    $0x8,%esp
80103544:	68 00 27 11 80       	push   $0x80112700
80103549:	68 00 27 11 80       	push   $0x80112700
8010354e:	e8 55 16 00 00       	call   80104ba8 <sleep>
80103553:	83 c4 10             	add    $0x10,%esp
80103556:	eb e0                	jmp    80103538 <begin_op+0x16>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
80103558:	8b 0d 48 27 11 80    	mov    0x80112748,%ecx
8010355e:	a1 3c 27 11 80       	mov    0x8011273c,%eax
80103563:	8d 50 01             	lea    0x1(%eax),%edx
80103566:	89 d0                	mov    %edx,%eax
80103568:	c1 e0 02             	shl    $0x2,%eax
8010356b:	01 d0                	add    %edx,%eax
8010356d:	01 c0                	add    %eax,%eax
8010356f:	01 c8                	add    %ecx,%eax
80103571:	83 f8 1e             	cmp    $0x1e,%eax
80103574:	7e 17                	jle    8010358d <begin_op+0x6b>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
80103576:	83 ec 08             	sub    $0x8,%esp
80103579:	68 00 27 11 80       	push   $0x80112700
8010357e:	68 00 27 11 80       	push   $0x80112700
80103583:	e8 20 16 00 00       	call   80104ba8 <sleep>
80103588:	83 c4 10             	add    $0x10,%esp
8010358b:	eb ab                	jmp    80103538 <begin_op+0x16>
    } else {
      log.outstanding += 1;
8010358d:	a1 3c 27 11 80       	mov    0x8011273c,%eax
80103592:	83 c0 01             	add    $0x1,%eax
80103595:	a3 3c 27 11 80       	mov    %eax,0x8011273c
      release(&log.lock);
8010359a:	83 ec 0c             	sub    $0xc,%esp
8010359d:	68 00 27 11 80       	push   $0x80112700
801035a2:	e8 b0 1a 00 00       	call   80105057 <release>
801035a7:	83 c4 10             	add    $0x10,%esp
      break;
801035aa:	90                   	nop
    }
  }
}
801035ab:	90                   	nop
801035ac:	c9                   	leave
801035ad:	c3                   	ret

801035ae <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
801035ae:	55                   	push   %ebp
801035af:	89 e5                	mov    %esp,%ebp
801035b1:	83 ec 18             	sub    $0x18,%esp
  int do_commit = 0;
801035b4:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)

  acquire(&log.lock);
801035bb:	83 ec 0c             	sub    $0xc,%esp
801035be:	68 00 27 11 80       	push   $0x80112700
801035c3:	e8 21 1a 00 00       	call   80104fe9 <acquire>
801035c8:	83 c4 10             	add    $0x10,%esp
  log.outstanding -= 1;
801035cb:	a1 3c 27 11 80       	mov    0x8011273c,%eax
801035d0:	83 e8 01             	sub    $0x1,%eax
801035d3:	a3 3c 27 11 80       	mov    %eax,0x8011273c
  if(log.committing)
801035d8:	a1 40 27 11 80       	mov    0x80112740,%eax
801035dd:	85 c0                	test   %eax,%eax
801035df:	74 0d                	je     801035ee <end_op+0x40>
    panic("log.committing");
801035e1:	83 ec 0c             	sub    $0xc,%esp
801035e4:	68 dd 86 10 80       	push   $0x801086dd
801035e9:	e8 c5 cf ff ff       	call   801005b3 <panic>
  if(log.outstanding == 0){
801035ee:	a1 3c 27 11 80       	mov    0x8011273c,%eax
801035f3:	85 c0                	test   %eax,%eax
801035f5:	75 13                	jne    8010360a <end_op+0x5c>
    do_commit = 1;
801035f7:	c7 45 f4 01 00 00 00 	movl   $0x1,-0xc(%ebp)
    log.committing = 1;
801035fe:	c7 05 40 27 11 80 01 	movl   $0x1,0x80112740
80103605:	00 00 00 
80103608:	eb 10                	jmp    8010361a <end_op+0x6c>
  } else {
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
8010360a:	83 ec 0c             	sub    $0xc,%esp
8010360d:	68 00 27 11 80       	push   $0x80112700
80103612:	e8 78 16 00 00       	call   80104c8f <wakeup>
80103617:	83 c4 10             	add    $0x10,%esp
  }
  release(&log.lock);
8010361a:	83 ec 0c             	sub    $0xc,%esp
8010361d:	68 00 27 11 80       	push   $0x80112700
80103622:	e8 30 1a 00 00       	call   80105057 <release>
80103627:	83 c4 10             	add    $0x10,%esp

  if(do_commit){
8010362a:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
8010362e:	74 3f                	je     8010366f <end_op+0xc1>
    // call commit w/o holding locks, since not allowed
    // to sleep with locks.
    commit();
80103630:	e8 f6 00 00 00       	call   8010372b <commit>
    acquire(&log.lock);
80103635:	83 ec 0c             	sub    $0xc,%esp
80103638:	68 00 27 11 80       	push   $0x80112700
8010363d:	e8 a7 19 00 00       	call   80104fe9 <acquire>
80103642:	83 c4 10             	add    $0x10,%esp
    log.committing = 0;
80103645:	c7 05 40 27 11 80 00 	movl   $0x0,0x80112740
8010364c:	00 00 00 
    wakeup(&log);
8010364f:	83 ec 0c             	sub    $0xc,%esp
80103652:	68 00 27 11 80       	push   $0x80112700
80103657:	e8 33 16 00 00       	call   80104c8f <wakeup>
8010365c:	83 c4 10             	add    $0x10,%esp
    release(&log.lock);
8010365f:	83 ec 0c             	sub    $0xc,%esp
80103662:	68 00 27 11 80       	push   $0x80112700
80103667:	e8 eb 19 00 00       	call   80105057 <release>
8010366c:	83 c4 10             	add    $0x10,%esp
  }
}
8010366f:	90                   	nop
80103670:	c9                   	leave
80103671:	c3                   	ret

80103672 <write_log>:

// Copy modified blocks from cache to log.
static void
write_log(void)
{
80103672:	55                   	push   %ebp
80103673:	89 e5                	mov    %esp,%ebp
80103675:	83 ec 18             	sub    $0x18,%esp
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
80103678:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
8010367f:	e9 95 00 00 00       	jmp    80103719 <write_log+0xa7>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
80103684:	8b 15 34 27 11 80    	mov    0x80112734,%edx
8010368a:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010368d:	01 d0                	add    %edx,%eax
8010368f:	83 c0 01             	add    $0x1,%eax
80103692:	89 c2                	mov    %eax,%edx
80103694:	a1 44 27 11 80       	mov    0x80112744,%eax
80103699:	83 ec 08             	sub    $0x8,%esp
8010369c:	52                   	push   %edx
8010369d:	50                   	push   %eax
8010369e:	e8 2c cb ff ff       	call   801001cf <bread>
801036a3:	83 c4 10             	add    $0x10,%esp
801036a6:	89 45 f0             	mov    %eax,-0x10(%ebp)
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
801036a9:	8b 45 f4             	mov    -0xc(%ebp),%eax
801036ac:	83 c0 10             	add    $0x10,%eax
801036af:	8b 04 85 0c 27 11 80 	mov    -0x7feed8f4(,%eax,4),%eax
801036b6:	89 c2                	mov    %eax,%edx
801036b8:	a1 44 27 11 80       	mov    0x80112744,%eax
801036bd:	83 ec 08             	sub    $0x8,%esp
801036c0:	52                   	push   %edx
801036c1:	50                   	push   %eax
801036c2:	e8 08 cb ff ff       	call   801001cf <bread>
801036c7:	83 c4 10             	add    $0x10,%esp
801036ca:	89 45 ec             	mov    %eax,-0x14(%ebp)
    memmove(to->data, from->data, BSIZE);
801036cd:	8b 45 ec             	mov    -0x14(%ebp),%eax
801036d0:	8d 50 5c             	lea    0x5c(%eax),%edx
801036d3:	8b 45 f0             	mov    -0x10(%ebp),%eax
801036d6:	83 c0 5c             	add    $0x5c,%eax
801036d9:	83 ec 04             	sub    $0x4,%esp
801036dc:	68 00 02 00 00       	push   $0x200
801036e1:	52                   	push   %edx
801036e2:	50                   	push   %eax
801036e3:	e8 46 1c 00 00       	call   8010532e <memmove>
801036e8:	83 c4 10             	add    $0x10,%esp
    bwrite(to);  // write the log
801036eb:	83 ec 0c             	sub    $0xc,%esp
801036ee:	ff 75 f0             	push   -0x10(%ebp)
801036f1:	e8 12 cb ff ff       	call   80100208 <bwrite>
801036f6:	83 c4 10             	add    $0x10,%esp
    brelse(from);
801036f9:	83 ec 0c             	sub    $0xc,%esp
801036fc:	ff 75 ec             	push   -0x14(%ebp)
801036ff:	e8 4d cb ff ff       	call   80100251 <brelse>
80103704:	83 c4 10             	add    $0x10,%esp
    brelse(to);
80103707:	83 ec 0c             	sub    $0xc,%esp
8010370a:	ff 75 f0             	push   -0x10(%ebp)
8010370d:	e8 3f cb ff ff       	call   80100251 <brelse>
80103712:	83 c4 10             	add    $0x10,%esp
  for (tail = 0; tail < log.lh.n; tail++) {
80103715:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80103719:	a1 48 27 11 80       	mov    0x80112748,%eax
8010371e:	39 45 f4             	cmp    %eax,-0xc(%ebp)
80103721:	0f 8c 5d ff ff ff    	jl     80103684 <write_log+0x12>
  }
}
80103727:	90                   	nop
80103728:	90                   	nop
80103729:	c9                   	leave
8010372a:	c3                   	ret

8010372b <commit>:

static void
commit()
{
8010372b:	55                   	push   %ebp
8010372c:	89 e5                	mov    %esp,%ebp
8010372e:	83 ec 08             	sub    $0x8,%esp
  if (log.lh.n > 0) {
80103731:	a1 48 27 11 80       	mov    0x80112748,%eax
80103736:	85 c0                	test   %eax,%eax
80103738:	7e 1e                	jle    80103758 <commit+0x2d>
    write_log();     // Write modified blocks from cache to log
8010373a:	e8 33 ff ff ff       	call   80103672 <write_log>
    write_head();    // Write header to disk -- the real commit
8010373f:	e8 39 fd ff ff       	call   8010347d <write_head>
    install_trans(); // Now install writes to home locations
80103744:	e8 07 fc ff ff       	call   80103350 <install_trans>
    log.lh.n = 0;
80103749:	c7 05 48 27 11 80 00 	movl   $0x0,0x80112748
80103750:	00 00 00 
    write_head();    // Erase the transaction from the log
80103753:	e8 25 fd ff ff       	call   8010347d <write_head>
  }
}
80103758:	90                   	nop
80103759:	c9                   	leave
8010375a:	c3                   	ret

8010375b <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
8010375b:	55                   	push   %ebp
8010375c:	89 e5                	mov    %esp,%ebp
8010375e:	83 ec 18             	sub    $0x18,%esp
  int i;

  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80103761:	a1 48 27 11 80       	mov    0x80112748,%eax
80103766:	83 f8 1d             	cmp    $0x1d,%eax
80103769:	7f 12                	jg     8010377d <log_write+0x22>
8010376b:	8b 15 48 27 11 80    	mov    0x80112748,%edx
80103771:	a1 38 27 11 80       	mov    0x80112738,%eax
80103776:	83 e8 01             	sub    $0x1,%eax
80103779:	39 c2                	cmp    %eax,%edx
8010377b:	7c 0d                	jl     8010378a <log_write+0x2f>
    panic("too big a transaction");
8010377d:	83 ec 0c             	sub    $0xc,%esp
80103780:	68 ec 86 10 80       	push   $0x801086ec
80103785:	e8 29 ce ff ff       	call   801005b3 <panic>
  if (log.outstanding < 1)
8010378a:	a1 3c 27 11 80       	mov    0x8011273c,%eax
8010378f:	85 c0                	test   %eax,%eax
80103791:	7f 0d                	jg     801037a0 <log_write+0x45>
    panic("log_write outside of trans");
80103793:	83 ec 0c             	sub    $0xc,%esp
80103796:	68 02 87 10 80       	push   $0x80108702
8010379b:	e8 13 ce ff ff       	call   801005b3 <panic>

  acquire(&log.lock);
801037a0:	83 ec 0c             	sub    $0xc,%esp
801037a3:	68 00 27 11 80       	push   $0x80112700
801037a8:	e8 3c 18 00 00       	call   80104fe9 <acquire>
801037ad:	83 c4 10             	add    $0x10,%esp
  for (i = 0; i < log.lh.n; i++) {
801037b0:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
801037b7:	eb 1d                	jmp    801037d6 <log_write+0x7b>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
801037b9:	8b 45 f4             	mov    -0xc(%ebp),%eax
801037bc:	83 c0 10             	add    $0x10,%eax
801037bf:	8b 04 85 0c 27 11 80 	mov    -0x7feed8f4(,%eax,4),%eax
801037c6:	89 c2                	mov    %eax,%edx
801037c8:	8b 45 08             	mov    0x8(%ebp),%eax
801037cb:	8b 40 08             	mov    0x8(%eax),%eax
801037ce:	39 c2                	cmp    %eax,%edx
801037d0:	74 10                	je     801037e2 <log_write+0x87>
  for (i = 0; i < log.lh.n; i++) {
801037d2:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
801037d6:	a1 48 27 11 80       	mov    0x80112748,%eax
801037db:	39 45 f4             	cmp    %eax,-0xc(%ebp)
801037de:	7c d9                	jl     801037b9 <log_write+0x5e>
801037e0:	eb 01                	jmp    801037e3 <log_write+0x88>
      break;
801037e2:	90                   	nop
  }
  log.lh.block[i] = b->blockno;
801037e3:	8b 45 08             	mov    0x8(%ebp),%eax
801037e6:	8b 40 08             	mov    0x8(%eax),%eax
801037e9:	89 c2                	mov    %eax,%edx
801037eb:	8b 45 f4             	mov    -0xc(%ebp),%eax
801037ee:	83 c0 10             	add    $0x10,%eax
801037f1:	89 14 85 0c 27 11 80 	mov    %edx,-0x7feed8f4(,%eax,4)
  if (i == log.lh.n)
801037f8:	a1 48 27 11 80       	mov    0x80112748,%eax
801037fd:	39 45 f4             	cmp    %eax,-0xc(%ebp)
80103800:	75 0d                	jne    8010380f <log_write+0xb4>
    log.lh.n++;
80103802:	a1 48 27 11 80       	mov    0x80112748,%eax
80103807:	83 c0 01             	add    $0x1,%eax
8010380a:	a3 48 27 11 80       	mov    %eax,0x80112748
  b->flags |= B_DIRTY; // prevent eviction
8010380f:	8b 45 08             	mov    0x8(%ebp),%eax
80103812:	8b 00                	mov    (%eax),%eax
80103814:	83 c8 04             	or     $0x4,%eax
80103817:	89 c2                	mov    %eax,%edx
80103819:	8b 45 08             	mov    0x8(%ebp),%eax
8010381c:	89 10                	mov    %edx,(%eax)
  release(&log.lock);
8010381e:	83 ec 0c             	sub    $0xc,%esp
80103821:	68 00 27 11 80       	push   $0x80112700
80103826:	e8 2c 18 00 00       	call   80105057 <release>
8010382b:	83 c4 10             	add    $0x10,%esp
}
8010382e:	90                   	nop
8010382f:	c9                   	leave
80103830:	c3                   	ret

80103831 <xchg>:
  asm volatile("sti");
}

static inline uint
xchg(volatile uint *addr, uint newval)
{
80103831:	55                   	push   %ebp
80103832:	89 e5                	mov    %esp,%ebp
80103834:	83 ec 10             	sub    $0x10,%esp
  uint result;

  // The + in "+m" denotes a read-modify-write operand.
  asm volatile("lock; xchgl %0, %1" :
80103837:	8b 55 08             	mov    0x8(%ebp),%edx
8010383a:	8b 45 0c             	mov    0xc(%ebp),%eax
8010383d:	8b 4d 08             	mov    0x8(%ebp),%ecx
80103840:	f0 87 02             	lock xchg %eax,(%edx)
80103843:	89 45 fc             	mov    %eax,-0x4(%ebp)
               "+m" (*addr), "=a" (result) :
               "1" (newval) :
               "cc");
  return result;
80103846:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
80103849:	c9                   	leave
8010384a:	c3                   	ret

8010384b <main>:
// Bootstrap processor starts running C code here.
// Allocate a real stack and switch to it, first
// doing some setup required for memory allocator to work.
int
main(void)
{
8010384b:	8d 4c 24 04          	lea    0x4(%esp),%ecx
8010384f:	83 e4 f0             	and    $0xfffffff0,%esp
80103852:	ff 71 fc             	push   -0x4(%ecx)
80103855:	55                   	push   %ebp
80103856:	89 e5                	mov    %esp,%ebp
80103858:	51                   	push   %ecx
80103859:	83 ec 04             	sub    $0x4,%esp
  kinit1(end, P2V(4*1024*1024)); // phys page allocator
8010385c:	83 ec 08             	sub    $0x8,%esp
8010385f:	68 00 00 40 80       	push   $0x80400000
80103864:	68 00 65 11 80       	push   $0x80116500
80103869:	e8 ef f2 ff ff       	call   80102b5d <kinit1>
8010386e:	83 c4 10             	add    $0x10,%esp
  kvmalloc();      // kernel page table
80103871:	e8 34 44 00 00       	call   80107caa <kvmalloc>
  mpinit();        // detect other processors
80103876:	e8 bb 03 00 00       	call   80103c36 <mpinit>
  lapicinit();     // interrupt controller
8010387b:	e8 40 f6 ff ff       	call   80102ec0 <lapicinit>
  seginit();       // segment descriptors
80103880:	e8 10 3f 00 00       	call   80107795 <seginit>
  picinit();       // disable pic
80103885:	e8 11 05 00 00       	call   80103d9b <picinit>
  ioapicinit();    // another interrupt controller
8010388a:	e8 e9 f1 ff ff       	call   80102a78 <ioapicinit>
  consoleinit();   // console hardware
8010388f:	e8 e2 d2 ff ff       	call   80100b76 <consoleinit>
  uartinit();      // serial port
80103894:	e8 95 32 00 00       	call   80106b2e <uartinit>
  pinit();         // process table
80103899:	e8 36 09 00 00       	call   801041d4 <pinit>
  tvinit();        // trap vectors
8010389e:	e8 19 2e 00 00       	call   801066bc <tvinit>
  binit();         // buffer cache
801038a3:	e8 8c c7 ff ff       	call   80100034 <binit>
  fileinit();      // file table
801038a8:	e8 53 d7 ff ff       	call   80101000 <fileinit>
  ideinit();       // disk 
801038ad:	e8 9b ed ff ff       	call   8010264d <ideinit>
  startothers();   // start other processors
801038b2:	e8 80 00 00 00       	call   80103937 <startothers>
  kinit2(P2V(4*1024*1024), P2V(PHYSTOP)); // must come after startothers()
801038b7:	83 ec 08             	sub    $0x8,%esp
801038ba:	68 00 00 00 8e       	push   $0x8e000000
801038bf:	68 00 00 40 80       	push   $0x80400000
801038c4:	e8 cd f2 ff ff       	call   80102b96 <kinit2>
801038c9:	83 c4 10             	add    $0x10,%esp
  userinit();      // first user process
801038cc:	e8 e1 0a 00 00       	call   801043b2 <userinit>
  mpmain();        // finish this processor's setup
801038d1:	e8 1a 00 00 00       	call   801038f0 <mpmain>

801038d6 <mpenter>:
}

// Other CPUs jump here from entryother.S.
static void
mpenter(void)
{
801038d6:	55                   	push   %ebp
801038d7:	89 e5                	mov    %esp,%ebp
801038d9:	83 ec 08             	sub    $0x8,%esp
  switchkvm();
801038dc:	e8 e1 43 00 00       	call   80107cc2 <switchkvm>
  seginit();
801038e1:	e8 af 3e 00 00       	call   80107795 <seginit>
  lapicinit();
801038e6:	e8 d5 f5 ff ff       	call   80102ec0 <lapicinit>
  mpmain();
801038eb:	e8 00 00 00 00       	call   801038f0 <mpmain>

801038f0 <mpmain>:
}

// Common CPU setup code.
static void
mpmain(void)
{
801038f0:	55                   	push   %ebp
801038f1:	89 e5                	mov    %esp,%ebp
801038f3:	53                   	push   %ebx
801038f4:	83 ec 04             	sub    $0x4,%esp
  cprintf("cpu%d: starting %d\n", cpuid(), cpuid());
801038f7:	e8 f6 08 00 00       	call   801041f2 <cpuid>
801038fc:	89 c3                	mov    %eax,%ebx
801038fe:	e8 ef 08 00 00       	call   801041f2 <cpuid>
80103903:	83 ec 04             	sub    $0x4,%esp
80103906:	53                   	push   %ebx
80103907:	50                   	push   %eax
80103908:	68 1d 87 10 80       	push   $0x8010871d
8010390d:	e8 ec ca ff ff       	call   801003fe <cprintf>
80103912:	83 c4 10             	add    $0x10,%esp
  idtinit();       // load idt register
80103915:	e8 18 2f 00 00       	call   80106832 <idtinit>
  xchg(&(mycpu()->started), 1); // tell startothers() we're up
8010391a:	e8 ee 08 00 00       	call   8010420d <mycpu>
8010391f:	05 a0 00 00 00       	add    $0xa0,%eax
80103924:	83 ec 08             	sub    $0x8,%esp
80103927:	6a 01                	push   $0x1
80103929:	50                   	push   %eax
8010392a:	e8 02 ff ff ff       	call   80103831 <xchg>
8010392f:	83 c4 10             	add    $0x10,%esp
  scheduler();     // start running processes
80103932:	e8 80 10 00 00       	call   801049b7 <scheduler>

80103937 <startothers>:
pde_t entrypgdir[];  // For entry.S

// Start the non-boot (AP) processors.
static void
startothers(void)
{
80103937:	55                   	push   %ebp
80103938:	89 e5                	mov    %esp,%ebp
8010393a:	83 ec 18             	sub    $0x18,%esp
  char *stack;

  // Write entry code to unused memory at 0x7000.
  // The linker has placed the image of entryother.S in
  // _binary_entryother_start.
  code = P2V(0x7000);
8010393d:	c7 45 f0 00 70 00 80 	movl   $0x80007000,-0x10(%ebp)
  memmove(code, _binary_entryother_start, (uint)_binary_entryother_size);
80103944:	b8 8a 00 00 00       	mov    $0x8a,%eax
80103949:	83 ec 04             	sub    $0x4,%esp
8010394c:	50                   	push   %eax
8010394d:	68 14 b5 10 80       	push   $0x8010b514
80103952:	ff 75 f0             	push   -0x10(%ebp)
80103955:	e8 d4 19 00 00       	call   8010532e <memmove>
8010395a:	83 c4 10             	add    $0x10,%esp

  for(c = cpus; c < cpus+ncpu; c++){
8010395d:	c7 45 f4 e0 27 11 80 	movl   $0x801127e0,-0xc(%ebp)
80103964:	eb 79                	jmp    801039df <startothers+0xa8>
    if(c == mycpu())  // We've started already.
80103966:	e8 a2 08 00 00       	call   8010420d <mycpu>
8010396b:	39 45 f4             	cmp    %eax,-0xc(%ebp)
8010396e:	74 67                	je     801039d7 <startothers+0xa0>
      continue;

    // Tell entryother.S what stack to use, where to enter, and what
    // pgdir to use. We cannot use kpgdir yet, because the AP processor
    // is running in low  memory, so we use entrypgdir for the APs too.
    stack = kalloc();
80103970:	e8 1d f3 ff ff       	call   80102c92 <kalloc>
80103975:	89 45 ec             	mov    %eax,-0x14(%ebp)
    *(void**)(code-4) = stack + KSTACKSIZE;
80103978:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010397b:	83 e8 04             	sub    $0x4,%eax
8010397e:	8b 55 ec             	mov    -0x14(%ebp),%edx
80103981:	81 c2 00 10 00 00    	add    $0x1000,%edx
80103987:	89 10                	mov    %edx,(%eax)
    *(void(**)(void))(code-8) = mpenter;
80103989:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010398c:	83 e8 08             	sub    $0x8,%eax
8010398f:	c7 00 d6 38 10 80    	movl   $0x801038d6,(%eax)
    *(int**)(code-12) = (void *) V2P(entrypgdir);
80103995:	b8 00 a0 10 80       	mov    $0x8010a000,%eax
8010399a:	8d 90 00 00 00 80    	lea    -0x80000000(%eax),%edx
801039a0:	8b 45 f0             	mov    -0x10(%ebp),%eax
801039a3:	83 e8 0c             	sub    $0xc,%eax
801039a6:	89 10                	mov    %edx,(%eax)

    lapicstartap(c->apicid, V2P(code));
801039a8:	8b 45 f0             	mov    -0x10(%ebp),%eax
801039ab:	8d 90 00 00 00 80    	lea    -0x80000000(%eax),%edx
801039b1:	8b 45 f4             	mov    -0xc(%ebp),%eax
801039b4:	0f b6 00             	movzbl (%eax),%eax
801039b7:	0f b6 c0             	movzbl %al,%eax
801039ba:	83 ec 08             	sub    $0x8,%esp
801039bd:	52                   	push   %edx
801039be:	50                   	push   %eax
801039bf:	e8 5b f6 ff ff       	call   8010301f <lapicstartap>
801039c4:	83 c4 10             	add    $0x10,%esp

    // wait for cpu to finish mpmain()
    while(c->started == 0)
801039c7:	90                   	nop
801039c8:	8b 45 f4             	mov    -0xc(%ebp),%eax
801039cb:	8b 80 a0 00 00 00    	mov    0xa0(%eax),%eax
801039d1:	85 c0                	test   %eax,%eax
801039d3:	74 f3                	je     801039c8 <startothers+0x91>
801039d5:	eb 01                	jmp    801039d8 <startothers+0xa1>
      continue;
801039d7:	90                   	nop
  for(c = cpus; c < cpus+ncpu; c++){
801039d8:	81 45 f4 b0 00 00 00 	addl   $0xb0,-0xc(%ebp)
801039df:	a1 60 2d 11 80       	mov    0x80112d60,%eax
801039e4:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
801039ea:	05 e0 27 11 80       	add    $0x801127e0,%eax
801039ef:	39 45 f4             	cmp    %eax,-0xc(%ebp)
801039f2:	0f 82 6e ff ff ff    	jb     80103966 <startothers+0x2f>
      ;
  }
}
801039f8:	90                   	nop
801039f9:	90                   	nop
801039fa:	c9                   	leave
801039fb:	c3                   	ret

801039fc <inb>:
{
801039fc:	55                   	push   %ebp
801039fd:	89 e5                	mov    %esp,%ebp
801039ff:	83 ec 14             	sub    $0x14,%esp
80103a02:	8b 45 08             	mov    0x8(%ebp),%eax
80103a05:	66 89 45 ec          	mov    %ax,-0x14(%ebp)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103a09:	0f b7 45 ec          	movzwl -0x14(%ebp),%eax
80103a0d:	89 c2                	mov    %eax,%edx
80103a0f:	ec                   	in     (%dx),%al
80103a10:	88 45 ff             	mov    %al,-0x1(%ebp)
  return data;
80103a13:	0f b6 45 ff          	movzbl -0x1(%ebp),%eax
}
80103a17:	c9                   	leave
80103a18:	c3                   	ret

80103a19 <outb>:
{
80103a19:	55                   	push   %ebp
80103a1a:	89 e5                	mov    %esp,%ebp
80103a1c:	83 ec 08             	sub    $0x8,%esp
80103a1f:	8b 55 08             	mov    0x8(%ebp),%edx
80103a22:	8b 45 0c             	mov    0xc(%ebp),%eax
80103a25:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
80103a29:	88 45 f8             	mov    %al,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103a2c:	0f b6 45 f8          	movzbl -0x8(%ebp),%eax
80103a30:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
80103a34:	ee                   	out    %al,(%dx)
}
80103a35:	90                   	nop
80103a36:	c9                   	leave
80103a37:	c3                   	ret

80103a38 <sum>:
int ncpu;
uchar ioapicid;

static uchar
sum(uchar *addr, int len)
{
80103a38:	55                   	push   %ebp
80103a39:	89 e5                	mov    %esp,%ebp
80103a3b:	83 ec 10             	sub    $0x10,%esp
  int i, sum;

  sum = 0;
80103a3e:	c7 45 f8 00 00 00 00 	movl   $0x0,-0x8(%ebp)
  for(i=0; i<len; i++)
80103a45:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
80103a4c:	eb 15                	jmp    80103a63 <sum+0x2b>
    sum += addr[i];
80103a4e:	8b 55 fc             	mov    -0x4(%ebp),%edx
80103a51:	8b 45 08             	mov    0x8(%ebp),%eax
80103a54:	01 d0                	add    %edx,%eax
80103a56:	0f b6 00             	movzbl (%eax),%eax
80103a59:	0f b6 c0             	movzbl %al,%eax
80103a5c:	01 45 f8             	add    %eax,-0x8(%ebp)
  for(i=0; i<len; i++)
80103a5f:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
80103a63:	8b 45 fc             	mov    -0x4(%ebp),%eax
80103a66:	3b 45 0c             	cmp    0xc(%ebp),%eax
80103a69:	7c e3                	jl     80103a4e <sum+0x16>
  return sum;
80103a6b:	8b 45 f8             	mov    -0x8(%ebp),%eax
}
80103a6e:	c9                   	leave
80103a6f:	c3                   	ret

80103a70 <mpsearch1>:

// Look for an MP structure in the len bytes at addr.
static struct mp*
mpsearch1(uint a, int len)
{
80103a70:	55                   	push   %ebp
80103a71:	89 e5                	mov    %esp,%ebp
80103a73:	83 ec 18             	sub    $0x18,%esp
  uchar *e, *p, *addr;

  addr = P2V(a);
80103a76:	8b 45 08             	mov    0x8(%ebp),%eax
80103a79:	05 00 00 00 80       	add    $0x80000000,%eax
80103a7e:	89 45 f0             	mov    %eax,-0x10(%ebp)
  e = addr+len;
80103a81:	8b 55 0c             	mov    0xc(%ebp),%edx
80103a84:	8b 45 f0             	mov    -0x10(%ebp),%eax
80103a87:	01 d0                	add    %edx,%eax
80103a89:	89 45 ec             	mov    %eax,-0x14(%ebp)
  for(p = addr; p < e; p += sizeof(struct mp))
80103a8c:	8b 45 f0             	mov    -0x10(%ebp),%eax
80103a8f:	89 45 f4             	mov    %eax,-0xc(%ebp)
80103a92:	eb 36                	jmp    80103aca <mpsearch1+0x5a>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80103a94:	83 ec 04             	sub    $0x4,%esp
80103a97:	6a 04                	push   $0x4
80103a99:	68 34 87 10 80       	push   $0x80108734
80103a9e:	ff 75 f4             	push   -0xc(%ebp)
80103aa1:	e8 30 18 00 00       	call   801052d6 <memcmp>
80103aa6:	83 c4 10             	add    $0x10,%esp
80103aa9:	85 c0                	test   %eax,%eax
80103aab:	75 19                	jne    80103ac6 <mpsearch1+0x56>
80103aad:	83 ec 08             	sub    $0x8,%esp
80103ab0:	6a 10                	push   $0x10
80103ab2:	ff 75 f4             	push   -0xc(%ebp)
80103ab5:	e8 7e ff ff ff       	call   80103a38 <sum>
80103aba:	83 c4 10             	add    $0x10,%esp
80103abd:	84 c0                	test   %al,%al
80103abf:	75 05                	jne    80103ac6 <mpsearch1+0x56>
      return (struct mp*)p;
80103ac1:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103ac4:	eb 11                	jmp    80103ad7 <mpsearch1+0x67>
  for(p = addr; p < e; p += sizeof(struct mp))
80103ac6:	83 45 f4 10          	addl   $0x10,-0xc(%ebp)
80103aca:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103acd:	3b 45 ec             	cmp    -0x14(%ebp),%eax
80103ad0:	72 c2                	jb     80103a94 <mpsearch1+0x24>
  return 0;
80103ad2:	b8 00 00 00 00       	mov    $0x0,%eax
}
80103ad7:	c9                   	leave
80103ad8:	c3                   	ret

80103ad9 <mpsearch>:
// 1) in the first KB of the EBDA;
// 2) in the last KB of system base memory;
// 3) in the BIOS ROM between 0xE0000 and 0xFFFFF.
static struct mp*
mpsearch(void)
{
80103ad9:	55                   	push   %ebp
80103ada:	89 e5                	mov    %esp,%ebp
80103adc:	83 ec 18             	sub    $0x18,%esp
  uchar *bda;
  uint p;
  struct mp *mp;

  bda = (uchar *) P2V(0x400);
80103adf:	c7 45 f4 00 04 00 80 	movl   $0x80000400,-0xc(%ebp)
  if((p = ((bda[0x0F]<<8)| bda[0x0E]) << 4)){
80103ae6:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103ae9:	83 c0 0f             	add    $0xf,%eax
80103aec:	0f b6 00             	movzbl (%eax),%eax
80103aef:	0f b6 c0             	movzbl %al,%eax
80103af2:	c1 e0 08             	shl    $0x8,%eax
80103af5:	89 c2                	mov    %eax,%edx
80103af7:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103afa:	83 c0 0e             	add    $0xe,%eax
80103afd:	0f b6 00             	movzbl (%eax),%eax
80103b00:	0f b6 c0             	movzbl %al,%eax
80103b03:	09 d0                	or     %edx,%eax
80103b05:	c1 e0 04             	shl    $0x4,%eax
80103b08:	89 45 f0             	mov    %eax,-0x10(%ebp)
80103b0b:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80103b0f:	74 21                	je     80103b32 <mpsearch+0x59>
    if((mp = mpsearch1(p, 1024)))
80103b11:	83 ec 08             	sub    $0x8,%esp
80103b14:	68 00 04 00 00       	push   $0x400
80103b19:	ff 75 f0             	push   -0x10(%ebp)
80103b1c:	e8 4f ff ff ff       	call   80103a70 <mpsearch1>
80103b21:	83 c4 10             	add    $0x10,%esp
80103b24:	89 45 ec             	mov    %eax,-0x14(%ebp)
80103b27:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
80103b2b:	74 51                	je     80103b7e <mpsearch+0xa5>
      return mp;
80103b2d:	8b 45 ec             	mov    -0x14(%ebp),%eax
80103b30:	eb 61                	jmp    80103b93 <mpsearch+0xba>
  } else {
    p = ((bda[0x14]<<8)|bda[0x13])*1024;
80103b32:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103b35:	83 c0 14             	add    $0x14,%eax
80103b38:	0f b6 00             	movzbl (%eax),%eax
80103b3b:	0f b6 c0             	movzbl %al,%eax
80103b3e:	c1 e0 08             	shl    $0x8,%eax
80103b41:	89 c2                	mov    %eax,%edx
80103b43:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103b46:	83 c0 13             	add    $0x13,%eax
80103b49:	0f b6 00             	movzbl (%eax),%eax
80103b4c:	0f b6 c0             	movzbl %al,%eax
80103b4f:	09 d0                	or     %edx,%eax
80103b51:	c1 e0 0a             	shl    $0xa,%eax
80103b54:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if((mp = mpsearch1(p-1024, 1024)))
80103b57:	8b 45 f0             	mov    -0x10(%ebp),%eax
80103b5a:	2d 00 04 00 00       	sub    $0x400,%eax
80103b5f:	83 ec 08             	sub    $0x8,%esp
80103b62:	68 00 04 00 00       	push   $0x400
80103b67:	50                   	push   %eax
80103b68:	e8 03 ff ff ff       	call   80103a70 <mpsearch1>
80103b6d:	83 c4 10             	add    $0x10,%esp
80103b70:	89 45 ec             	mov    %eax,-0x14(%ebp)
80103b73:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
80103b77:	74 05                	je     80103b7e <mpsearch+0xa5>
      return mp;
80103b79:	8b 45 ec             	mov    -0x14(%ebp),%eax
80103b7c:	eb 15                	jmp    80103b93 <mpsearch+0xba>
  }
  return mpsearch1(0xF0000, 0x10000);
80103b7e:	83 ec 08             	sub    $0x8,%esp
80103b81:	68 00 00 01 00       	push   $0x10000
80103b86:	68 00 00 0f 00       	push   $0xf0000
80103b8b:	e8 e0 fe ff ff       	call   80103a70 <mpsearch1>
80103b90:	83 c4 10             	add    $0x10,%esp
}
80103b93:	c9                   	leave
80103b94:	c3                   	ret

80103b95 <mpconfig>:
// Check for correct signature, calculate the checksum and,
// if correct, check the version.
// To do: check extended table checksum.
static struct mpconf*
mpconfig(struct mp **pmp)
{
80103b95:	55                   	push   %ebp
80103b96:	89 e5                	mov    %esp,%ebp
80103b98:	83 ec 18             	sub    $0x18,%esp
  struct mpconf *conf;
  struct mp *mp;

  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80103b9b:	e8 39 ff ff ff       	call   80103ad9 <mpsearch>
80103ba0:	89 45 f4             	mov    %eax,-0xc(%ebp)
80103ba3:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80103ba7:	74 0a                	je     80103bb3 <mpconfig+0x1e>
80103ba9:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103bac:	8b 40 04             	mov    0x4(%eax),%eax
80103baf:	85 c0                	test   %eax,%eax
80103bb1:	75 07                	jne    80103bba <mpconfig+0x25>
    return 0;
80103bb3:	b8 00 00 00 00       	mov    $0x0,%eax
80103bb8:	eb 7a                	jmp    80103c34 <mpconfig+0x9f>
  conf = (struct mpconf*) P2V((uint) mp->physaddr);
80103bba:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103bbd:	8b 40 04             	mov    0x4(%eax),%eax
80103bc0:	05 00 00 00 80       	add    $0x80000000,%eax
80103bc5:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(memcmp(conf, "PCMP", 4) != 0)
80103bc8:	83 ec 04             	sub    $0x4,%esp
80103bcb:	6a 04                	push   $0x4
80103bcd:	68 39 87 10 80       	push   $0x80108739
80103bd2:	ff 75 f0             	push   -0x10(%ebp)
80103bd5:	e8 fc 16 00 00       	call   801052d6 <memcmp>
80103bda:	83 c4 10             	add    $0x10,%esp
80103bdd:	85 c0                	test   %eax,%eax
80103bdf:	74 07                	je     80103be8 <mpconfig+0x53>
    return 0;
80103be1:	b8 00 00 00 00       	mov    $0x0,%eax
80103be6:	eb 4c                	jmp    80103c34 <mpconfig+0x9f>
  if(conf->version != 1 && conf->version != 4)
80103be8:	8b 45 f0             	mov    -0x10(%ebp),%eax
80103beb:	0f b6 40 06          	movzbl 0x6(%eax),%eax
80103bef:	3c 01                	cmp    $0x1,%al
80103bf1:	74 12                	je     80103c05 <mpconfig+0x70>
80103bf3:	8b 45 f0             	mov    -0x10(%ebp),%eax
80103bf6:	0f b6 40 06          	movzbl 0x6(%eax),%eax
80103bfa:	3c 04                	cmp    $0x4,%al
80103bfc:	74 07                	je     80103c05 <mpconfig+0x70>
    return 0;
80103bfe:	b8 00 00 00 00       	mov    $0x0,%eax
80103c03:	eb 2f                	jmp    80103c34 <mpconfig+0x9f>
  if(sum((uchar*)conf, conf->length) != 0)
80103c05:	8b 45 f0             	mov    -0x10(%ebp),%eax
80103c08:	0f b7 40 04          	movzwl 0x4(%eax),%eax
80103c0c:	0f b7 c0             	movzwl %ax,%eax
80103c0f:	83 ec 08             	sub    $0x8,%esp
80103c12:	50                   	push   %eax
80103c13:	ff 75 f0             	push   -0x10(%ebp)
80103c16:	e8 1d fe ff ff       	call   80103a38 <sum>
80103c1b:	83 c4 10             	add    $0x10,%esp
80103c1e:	84 c0                	test   %al,%al
80103c20:	74 07                	je     80103c29 <mpconfig+0x94>
    return 0;
80103c22:	b8 00 00 00 00       	mov    $0x0,%eax
80103c27:	eb 0b                	jmp    80103c34 <mpconfig+0x9f>
  *pmp = mp;
80103c29:	8b 45 08             	mov    0x8(%ebp),%eax
80103c2c:	8b 55 f4             	mov    -0xc(%ebp),%edx
80103c2f:	89 10                	mov    %edx,(%eax)
  return conf;
80103c31:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
80103c34:	c9                   	leave
80103c35:	c3                   	ret

80103c36 <mpinit>:

void
mpinit(void)
{
80103c36:	55                   	push   %ebp
80103c37:	89 e5                	mov    %esp,%ebp
80103c39:	83 ec 28             	sub    $0x28,%esp
  struct mp *mp;
  struct mpconf *conf;
  struct mpproc *proc;
  struct mpioapic *ioapic;

  if((conf = mpconfig(&mp)) == 0)
80103c3c:	83 ec 0c             	sub    $0xc,%esp
80103c3f:	8d 45 dc             	lea    -0x24(%ebp),%eax
80103c42:	50                   	push   %eax
80103c43:	e8 4d ff ff ff       	call   80103b95 <mpconfig>
80103c48:	83 c4 10             	add    $0x10,%esp
80103c4b:	89 45 ec             	mov    %eax,-0x14(%ebp)
80103c4e:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
80103c52:	75 0d                	jne    80103c61 <mpinit+0x2b>
    panic("Expect to run on an SMP");
80103c54:	83 ec 0c             	sub    $0xc,%esp
80103c57:	68 3e 87 10 80       	push   $0x8010873e
80103c5c:	e8 52 c9 ff ff       	call   801005b3 <panic>
  ismp = 1;
80103c61:	c7 45 f0 01 00 00 00 	movl   $0x1,-0x10(%ebp)
  lapic = (uint*)conf->lapicaddr;
80103c68:	8b 45 ec             	mov    -0x14(%ebp),%eax
80103c6b:	8b 40 24             	mov    0x24(%eax),%eax
80103c6e:	a3 e0 26 11 80       	mov    %eax,0x801126e0
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80103c73:	8b 45 ec             	mov    -0x14(%ebp),%eax
80103c76:	83 c0 2c             	add    $0x2c,%eax
80103c79:	89 45 f4             	mov    %eax,-0xc(%ebp)
80103c7c:	8b 45 ec             	mov    -0x14(%ebp),%eax
80103c7f:	0f b7 40 04          	movzwl 0x4(%eax),%eax
80103c83:	0f b7 d0             	movzwl %ax,%edx
80103c86:	8b 45 ec             	mov    -0x14(%ebp),%eax
80103c89:	01 d0                	add    %edx,%eax
80103c8b:	89 45 e8             	mov    %eax,-0x18(%ebp)
80103c8e:	e9 8c 00 00 00       	jmp    80103d1f <mpinit+0xe9>
    switch(*p){
80103c93:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103c96:	0f b6 00             	movzbl (%eax),%eax
80103c99:	0f b6 c0             	movzbl %al,%eax
80103c9c:	83 f8 04             	cmp    $0x4,%eax
80103c9f:	7f 76                	jg     80103d17 <mpinit+0xe1>
80103ca1:	83 f8 03             	cmp    $0x3,%eax
80103ca4:	7d 6b                	jge    80103d11 <mpinit+0xdb>
80103ca6:	83 f8 02             	cmp    $0x2,%eax
80103ca9:	74 4e                	je     80103cf9 <mpinit+0xc3>
80103cab:	83 f8 02             	cmp    $0x2,%eax
80103cae:	7f 67                	jg     80103d17 <mpinit+0xe1>
80103cb0:	85 c0                	test   %eax,%eax
80103cb2:	74 07                	je     80103cbb <mpinit+0x85>
80103cb4:	83 f8 01             	cmp    $0x1,%eax
80103cb7:	74 58                	je     80103d11 <mpinit+0xdb>
80103cb9:	eb 5c                	jmp    80103d17 <mpinit+0xe1>
    case MPPROC:
      proc = (struct mpproc*)p;
80103cbb:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103cbe:	89 45 e0             	mov    %eax,-0x20(%ebp)
      if(ncpu < NCPU) {
80103cc1:	a1 60 2d 11 80       	mov    0x80112d60,%eax
80103cc6:	83 f8 07             	cmp    $0x7,%eax
80103cc9:	7f 28                	jg     80103cf3 <mpinit+0xbd>
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
80103ccb:	8b 15 60 2d 11 80    	mov    0x80112d60,%edx
80103cd1:	8b 45 e0             	mov    -0x20(%ebp),%eax
80103cd4:	0f b6 40 01          	movzbl 0x1(%eax),%eax
80103cd8:	69 d2 b0 00 00 00    	imul   $0xb0,%edx,%edx
80103cde:	81 c2 e0 27 11 80    	add    $0x801127e0,%edx
80103ce4:	88 02                	mov    %al,(%edx)
        ncpu++;
80103ce6:	a1 60 2d 11 80       	mov    0x80112d60,%eax
80103ceb:	83 c0 01             	add    $0x1,%eax
80103cee:	a3 60 2d 11 80       	mov    %eax,0x80112d60
      }
      p += sizeof(struct mpproc);
80103cf3:	83 45 f4 14          	addl   $0x14,-0xc(%ebp)
      continue;
80103cf7:	eb 26                	jmp    80103d1f <mpinit+0xe9>
    case MPIOAPIC:
      ioapic = (struct mpioapic*)p;
80103cf9:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103cfc:	89 45 e4             	mov    %eax,-0x1c(%ebp)
      ioapicid = ioapic->apicno;
80103cff:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80103d02:	0f b6 40 01          	movzbl 0x1(%eax),%eax
80103d06:	a2 64 2d 11 80       	mov    %al,0x80112d64
      p += sizeof(struct mpioapic);
80103d0b:	83 45 f4 08          	addl   $0x8,-0xc(%ebp)
      continue;
80103d0f:	eb 0e                	jmp    80103d1f <mpinit+0xe9>
    case MPBUS:
    case MPIOINTR:
    case MPLINTR:
      p += 8;
80103d11:	83 45 f4 08          	addl   $0x8,-0xc(%ebp)
      continue;
80103d15:	eb 08                	jmp    80103d1f <mpinit+0xe9>
    default:
      ismp = 0;
80103d17:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
      break;
80103d1e:	90                   	nop
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80103d1f:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103d22:	3b 45 e8             	cmp    -0x18(%ebp),%eax
80103d25:	0f 82 68 ff ff ff    	jb     80103c93 <mpinit+0x5d>
    }
  }
  if(!ismp)
80103d2b:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80103d2f:	75 0d                	jne    80103d3e <mpinit+0x108>
    panic("Didn't find a suitable machine");
80103d31:	83 ec 0c             	sub    $0xc,%esp
80103d34:	68 58 87 10 80       	push   $0x80108758
80103d39:	e8 75 c8 ff ff       	call   801005b3 <panic>

  if(mp->imcrp){
80103d3e:	8b 45 dc             	mov    -0x24(%ebp),%eax
80103d41:	0f b6 40 0c          	movzbl 0xc(%eax),%eax
80103d45:	84 c0                	test   %al,%al
80103d47:	74 30                	je     80103d79 <mpinit+0x143>
    // Bochs doesn't support IMCR, so this doesn't run on Bochs.
    // But it would on real hardware.
    outb(0x22, 0x70);   // Select IMCR
80103d49:	83 ec 08             	sub    $0x8,%esp
80103d4c:	6a 70                	push   $0x70
80103d4e:	6a 22                	push   $0x22
80103d50:	e8 c4 fc ff ff       	call   80103a19 <outb>
80103d55:	83 c4 10             	add    $0x10,%esp
    outb(0x23, inb(0x23) | 1);  // Mask external interrupts.
80103d58:	83 ec 0c             	sub    $0xc,%esp
80103d5b:	6a 23                	push   $0x23
80103d5d:	e8 9a fc ff ff       	call   801039fc <inb>
80103d62:	83 c4 10             	add    $0x10,%esp
80103d65:	83 c8 01             	or     $0x1,%eax
80103d68:	0f b6 c0             	movzbl %al,%eax
80103d6b:	83 ec 08             	sub    $0x8,%esp
80103d6e:	50                   	push   %eax
80103d6f:	6a 23                	push   $0x23
80103d71:	e8 a3 fc ff ff       	call   80103a19 <outb>
80103d76:	83 c4 10             	add    $0x10,%esp
  }
}
80103d79:	90                   	nop
80103d7a:	c9                   	leave
80103d7b:	c3                   	ret

80103d7c <outb>:
{
80103d7c:	55                   	push   %ebp
80103d7d:	89 e5                	mov    %esp,%ebp
80103d7f:	83 ec 08             	sub    $0x8,%esp
80103d82:	8b 55 08             	mov    0x8(%ebp),%edx
80103d85:	8b 45 0c             	mov    0xc(%ebp),%eax
80103d88:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
80103d8c:	88 45 f8             	mov    %al,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103d8f:	0f b6 45 f8          	movzbl -0x8(%ebp),%eax
80103d93:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
80103d97:	ee                   	out    %al,(%dx)
}
80103d98:	90                   	nop
80103d99:	c9                   	leave
80103d9a:	c3                   	ret

80103d9b <picinit>:
#define IO_PIC2         0xA0    // Slave (IRQs 8-15)

// Don't use the 8259A interrupt controllers.  Xv6 assumes SMP hardware.
void
picinit(void)
{
80103d9b:	55                   	push   %ebp
80103d9c:	89 e5                	mov    %esp,%ebp
  // mask all interrupts
  outb(IO_PIC1+1, 0xFF);
80103d9e:	68 ff 00 00 00       	push   $0xff
80103da3:	6a 21                	push   $0x21
80103da5:	e8 d2 ff ff ff       	call   80103d7c <outb>
80103daa:	83 c4 08             	add    $0x8,%esp
  outb(IO_PIC2+1, 0xFF);
80103dad:	68 ff 00 00 00       	push   $0xff
80103db2:	68 a1 00 00 00       	push   $0xa1
80103db7:	e8 c0 ff ff ff       	call   80103d7c <outb>
80103dbc:	83 c4 08             	add    $0x8,%esp
}
80103dbf:	90                   	nop
80103dc0:	c9                   	leave
80103dc1:	c3                   	ret

80103dc2 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
80103dc2:	55                   	push   %ebp
80103dc3:	89 e5                	mov    %esp,%ebp
80103dc5:	83 ec 18             	sub    $0x18,%esp
  struct pipe *p;

  p = 0;
80103dc8:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  *f0 = *f1 = 0;
80103dcf:	8b 45 0c             	mov    0xc(%ebp),%eax
80103dd2:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
80103dd8:	8b 45 0c             	mov    0xc(%ebp),%eax
80103ddb:	8b 10                	mov    (%eax),%edx
80103ddd:	8b 45 08             	mov    0x8(%ebp),%eax
80103de0:	89 10                	mov    %edx,(%eax)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
80103de2:	e8 37 d2 ff ff       	call   8010101e <filealloc>
80103de7:	8b 55 08             	mov    0x8(%ebp),%edx
80103dea:	89 02                	mov    %eax,(%edx)
80103dec:	8b 45 08             	mov    0x8(%ebp),%eax
80103def:	8b 00                	mov    (%eax),%eax
80103df1:	85 c0                	test   %eax,%eax
80103df3:	0f 84 c8 00 00 00    	je     80103ec1 <pipealloc+0xff>
80103df9:	e8 20 d2 ff ff       	call   8010101e <filealloc>
80103dfe:	8b 55 0c             	mov    0xc(%ebp),%edx
80103e01:	89 02                	mov    %eax,(%edx)
80103e03:	8b 45 0c             	mov    0xc(%ebp),%eax
80103e06:	8b 00                	mov    (%eax),%eax
80103e08:	85 c0                	test   %eax,%eax
80103e0a:	0f 84 b1 00 00 00    	je     80103ec1 <pipealloc+0xff>
    goto bad;
  if((p = (struct pipe*)kalloc()) == 0)
80103e10:	e8 7d ee ff ff       	call   80102c92 <kalloc>
80103e15:	89 45 f4             	mov    %eax,-0xc(%ebp)
80103e18:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80103e1c:	0f 84 a2 00 00 00    	je     80103ec4 <pipealloc+0x102>
    goto bad;
  p->readopen = 1;
80103e22:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103e25:	c7 80 3c 02 00 00 01 	movl   $0x1,0x23c(%eax)
80103e2c:	00 00 00 
  p->writeopen = 1;
80103e2f:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103e32:	c7 80 40 02 00 00 01 	movl   $0x1,0x240(%eax)
80103e39:	00 00 00 
  p->nwrite = 0;
80103e3c:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103e3f:	c7 80 38 02 00 00 00 	movl   $0x0,0x238(%eax)
80103e46:	00 00 00 
  p->nread = 0;
80103e49:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103e4c:	c7 80 34 02 00 00 00 	movl   $0x0,0x234(%eax)
80103e53:	00 00 00 
  initlock(&p->lock, "pipe");
80103e56:	8b 45 f4             	mov    -0xc(%ebp),%eax
80103e59:	83 ec 08             	sub    $0x8,%esp
80103e5c:	68 77 87 10 80       	push   $0x80108777
80103e61:	50                   	push   %eax
80103e62:	e8 60 11 00 00       	call   80104fc7 <initlock>
80103e67:	83 c4 10             	add    $0x10,%esp
  (*f0)->type = FD_PIPE;
80103e6a:	8b 45 08             	mov    0x8(%ebp),%eax
80103e6d:	8b 00                	mov    (%eax),%eax
80103e6f:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f0)->readable = 1;
80103e75:	8b 45 08             	mov    0x8(%ebp),%eax
80103e78:	8b 00                	mov    (%eax),%eax
80103e7a:	c6 40 08 01          	movb   $0x1,0x8(%eax)
  (*f0)->writable = 0;
80103e7e:	8b 45 08             	mov    0x8(%ebp),%eax
80103e81:	8b 00                	mov    (%eax),%eax
80103e83:	c6 40 09 00          	movb   $0x0,0x9(%eax)
  (*f0)->pipe = p;
80103e87:	8b 45 08             	mov    0x8(%ebp),%eax
80103e8a:	8b 00                	mov    (%eax),%eax
80103e8c:	8b 55 f4             	mov    -0xc(%ebp),%edx
80103e8f:	89 50 0c             	mov    %edx,0xc(%eax)
  (*f1)->type = FD_PIPE;
80103e92:	8b 45 0c             	mov    0xc(%ebp),%eax
80103e95:	8b 00                	mov    (%eax),%eax
80103e97:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f1)->readable = 0;
80103e9d:	8b 45 0c             	mov    0xc(%ebp),%eax
80103ea0:	8b 00                	mov    (%eax),%eax
80103ea2:	c6 40 08 00          	movb   $0x0,0x8(%eax)
  (*f1)->writable = 1;
80103ea6:	8b 45 0c             	mov    0xc(%ebp),%eax
80103ea9:	8b 00                	mov    (%eax),%eax
80103eab:	c6 40 09 01          	movb   $0x1,0x9(%eax)
  (*f1)->pipe = p;
80103eaf:	8b 45 0c             	mov    0xc(%ebp),%eax
80103eb2:	8b 00                	mov    (%eax),%eax
80103eb4:	8b 55 f4             	mov    -0xc(%ebp),%edx
80103eb7:	89 50 0c             	mov    %edx,0xc(%eax)
  return 0;
80103eba:	b8 00 00 00 00       	mov    $0x0,%eax
80103ebf:	eb 51                	jmp    80103f12 <pipealloc+0x150>
    goto bad;
80103ec1:	90                   	nop
80103ec2:	eb 01                	jmp    80103ec5 <pipealloc+0x103>
    goto bad;
80103ec4:	90                   	nop

//PAGEBREAK: 20
 bad:
  if(p)
80103ec5:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80103ec9:	74 0e                	je     80103ed9 <pipealloc+0x117>
    kfree((char*)p);
80103ecb:	83 ec 0c             	sub    $0xc,%esp
80103ece:	ff 75 f4             	push   -0xc(%ebp)
80103ed1:	e8 22 ed ff ff       	call   80102bf8 <kfree>
80103ed6:	83 c4 10             	add    $0x10,%esp
  if(*f0)
80103ed9:	8b 45 08             	mov    0x8(%ebp),%eax
80103edc:	8b 00                	mov    (%eax),%eax
80103ede:	85 c0                	test   %eax,%eax
80103ee0:	74 11                	je     80103ef3 <pipealloc+0x131>
    fileclose(*f0);
80103ee2:	8b 45 08             	mov    0x8(%ebp),%eax
80103ee5:	8b 00                	mov    (%eax),%eax
80103ee7:	83 ec 0c             	sub    $0xc,%esp
80103eea:	50                   	push   %eax
80103eeb:	e8 ec d1 ff ff       	call   801010dc <fileclose>
80103ef0:	83 c4 10             	add    $0x10,%esp
  if(*f1)
80103ef3:	8b 45 0c             	mov    0xc(%ebp),%eax
80103ef6:	8b 00                	mov    (%eax),%eax
80103ef8:	85 c0                	test   %eax,%eax
80103efa:	74 11                	je     80103f0d <pipealloc+0x14b>
    fileclose(*f1);
80103efc:	8b 45 0c             	mov    0xc(%ebp),%eax
80103eff:	8b 00                	mov    (%eax),%eax
80103f01:	83 ec 0c             	sub    $0xc,%esp
80103f04:	50                   	push   %eax
80103f05:	e8 d2 d1 ff ff       	call   801010dc <fileclose>
80103f0a:	83 c4 10             	add    $0x10,%esp
  return -1;
80103f0d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80103f12:	c9                   	leave
80103f13:	c3                   	ret

80103f14 <pipeclose>:

void
pipeclose(struct pipe *p, int writable)
{
80103f14:	55                   	push   %ebp
80103f15:	89 e5                	mov    %esp,%ebp
80103f17:	83 ec 08             	sub    $0x8,%esp
  acquire(&p->lock);
80103f1a:	8b 45 08             	mov    0x8(%ebp),%eax
80103f1d:	83 ec 0c             	sub    $0xc,%esp
80103f20:	50                   	push   %eax
80103f21:	e8 c3 10 00 00       	call   80104fe9 <acquire>
80103f26:	83 c4 10             	add    $0x10,%esp
  if(writable){
80103f29:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
80103f2d:	74 23                	je     80103f52 <pipeclose+0x3e>
    p->writeopen = 0;
80103f2f:	8b 45 08             	mov    0x8(%ebp),%eax
80103f32:	c7 80 40 02 00 00 00 	movl   $0x0,0x240(%eax)
80103f39:	00 00 00 
    wakeup(&p->nread);
80103f3c:	8b 45 08             	mov    0x8(%ebp),%eax
80103f3f:	05 34 02 00 00       	add    $0x234,%eax
80103f44:	83 ec 0c             	sub    $0xc,%esp
80103f47:	50                   	push   %eax
80103f48:	e8 42 0d 00 00       	call   80104c8f <wakeup>
80103f4d:	83 c4 10             	add    $0x10,%esp
80103f50:	eb 21                	jmp    80103f73 <pipeclose+0x5f>
  } else {
    p->readopen = 0;
80103f52:	8b 45 08             	mov    0x8(%ebp),%eax
80103f55:	c7 80 3c 02 00 00 00 	movl   $0x0,0x23c(%eax)
80103f5c:	00 00 00 
    wakeup(&p->nwrite);
80103f5f:	8b 45 08             	mov    0x8(%ebp),%eax
80103f62:	05 38 02 00 00       	add    $0x238,%eax
80103f67:	83 ec 0c             	sub    $0xc,%esp
80103f6a:	50                   	push   %eax
80103f6b:	e8 1f 0d 00 00       	call   80104c8f <wakeup>
80103f70:	83 c4 10             	add    $0x10,%esp
  }
  if(p->readopen == 0 && p->writeopen == 0){
80103f73:	8b 45 08             	mov    0x8(%ebp),%eax
80103f76:	8b 80 3c 02 00 00    	mov    0x23c(%eax),%eax
80103f7c:	85 c0                	test   %eax,%eax
80103f7e:	75 2c                	jne    80103fac <pipeclose+0x98>
80103f80:	8b 45 08             	mov    0x8(%ebp),%eax
80103f83:	8b 80 40 02 00 00    	mov    0x240(%eax),%eax
80103f89:	85 c0                	test   %eax,%eax
80103f8b:	75 1f                	jne    80103fac <pipeclose+0x98>
    release(&p->lock);
80103f8d:	8b 45 08             	mov    0x8(%ebp),%eax
80103f90:	83 ec 0c             	sub    $0xc,%esp
80103f93:	50                   	push   %eax
80103f94:	e8 be 10 00 00       	call   80105057 <release>
80103f99:	83 c4 10             	add    $0x10,%esp
    kfree((char*)p);
80103f9c:	83 ec 0c             	sub    $0xc,%esp
80103f9f:	ff 75 08             	push   0x8(%ebp)
80103fa2:	e8 51 ec ff ff       	call   80102bf8 <kfree>
80103fa7:	83 c4 10             	add    $0x10,%esp
80103faa:	eb 10                	jmp    80103fbc <pipeclose+0xa8>
  } else
    release(&p->lock);
80103fac:	8b 45 08             	mov    0x8(%ebp),%eax
80103faf:	83 ec 0c             	sub    $0xc,%esp
80103fb2:	50                   	push   %eax
80103fb3:	e8 9f 10 00 00       	call   80105057 <release>
80103fb8:	83 c4 10             	add    $0x10,%esp
}
80103fbb:	90                   	nop
80103fbc:	90                   	nop
80103fbd:	c9                   	leave
80103fbe:	c3                   	ret

80103fbf <pipewrite>:

//PAGEBREAK: 40
int
pipewrite(struct pipe *p, char *addr, int n)
{
80103fbf:	55                   	push   %ebp
80103fc0:	89 e5                	mov    %esp,%ebp
80103fc2:	53                   	push   %ebx
80103fc3:	83 ec 14             	sub    $0x14,%esp
  int i;

  acquire(&p->lock);
80103fc6:	8b 45 08             	mov    0x8(%ebp),%eax
80103fc9:	83 ec 0c             	sub    $0xc,%esp
80103fcc:	50                   	push   %eax
80103fcd:	e8 17 10 00 00       	call   80104fe9 <acquire>
80103fd2:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < n; i++){
80103fd5:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80103fdc:	e9 ad 00 00 00       	jmp    8010408e <pipewrite+0xcf>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
      if(p->readopen == 0 || myproc()->killed){
80103fe1:	8b 45 08             	mov    0x8(%ebp),%eax
80103fe4:	8b 80 3c 02 00 00    	mov    0x23c(%eax),%eax
80103fea:	85 c0                	test   %eax,%eax
80103fec:	74 0c                	je     80103ffa <pipewrite+0x3b>
80103fee:	e8 92 02 00 00       	call   80104285 <myproc>
80103ff3:	8b 40 24             	mov    0x24(%eax),%eax
80103ff6:	85 c0                	test   %eax,%eax
80103ff8:	74 19                	je     80104013 <pipewrite+0x54>
        release(&p->lock);
80103ffa:	8b 45 08             	mov    0x8(%ebp),%eax
80103ffd:	83 ec 0c             	sub    $0xc,%esp
80104000:	50                   	push   %eax
80104001:	e8 51 10 00 00       	call   80105057 <release>
80104006:	83 c4 10             	add    $0x10,%esp
        return -1;
80104009:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010400e:	e9 a9 00 00 00       	jmp    801040bc <pipewrite+0xfd>
      }
      wakeup(&p->nread);
80104013:	8b 45 08             	mov    0x8(%ebp),%eax
80104016:	05 34 02 00 00       	add    $0x234,%eax
8010401b:	83 ec 0c             	sub    $0xc,%esp
8010401e:	50                   	push   %eax
8010401f:	e8 6b 0c 00 00       	call   80104c8f <wakeup>
80104024:	83 c4 10             	add    $0x10,%esp
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80104027:	8b 45 08             	mov    0x8(%ebp),%eax
8010402a:	8b 55 08             	mov    0x8(%ebp),%edx
8010402d:	81 c2 38 02 00 00    	add    $0x238,%edx
80104033:	83 ec 08             	sub    $0x8,%esp
80104036:	50                   	push   %eax
80104037:	52                   	push   %edx
80104038:	e8 6b 0b 00 00       	call   80104ba8 <sleep>
8010403d:	83 c4 10             	add    $0x10,%esp
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80104040:	8b 45 08             	mov    0x8(%ebp),%eax
80104043:	8b 90 38 02 00 00    	mov    0x238(%eax),%edx
80104049:	8b 45 08             	mov    0x8(%ebp),%eax
8010404c:	8b 80 34 02 00 00    	mov    0x234(%eax),%eax
80104052:	05 00 02 00 00       	add    $0x200,%eax
80104057:	39 c2                	cmp    %eax,%edx
80104059:	74 86                	je     80103fe1 <pipewrite+0x22>
    }
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
8010405b:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010405e:	8b 45 0c             	mov    0xc(%ebp),%eax
80104061:	8d 1c 02             	lea    (%edx,%eax,1),%ebx
80104064:	8b 45 08             	mov    0x8(%ebp),%eax
80104067:	8b 80 38 02 00 00    	mov    0x238(%eax),%eax
8010406d:	8d 48 01             	lea    0x1(%eax),%ecx
80104070:	8b 55 08             	mov    0x8(%ebp),%edx
80104073:	89 8a 38 02 00 00    	mov    %ecx,0x238(%edx)
80104079:	25 ff 01 00 00       	and    $0x1ff,%eax
8010407e:	89 c1                	mov    %eax,%ecx
80104080:	0f b6 13             	movzbl (%ebx),%edx
80104083:	8b 45 08             	mov    0x8(%ebp),%eax
80104086:	88 54 08 34          	mov    %dl,0x34(%eax,%ecx,1)
  for(i = 0; i < n; i++){
8010408a:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
8010408e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104091:	3b 45 10             	cmp    0x10(%ebp),%eax
80104094:	7c aa                	jl     80104040 <pipewrite+0x81>
  }
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
80104096:	8b 45 08             	mov    0x8(%ebp),%eax
80104099:	05 34 02 00 00       	add    $0x234,%eax
8010409e:	83 ec 0c             	sub    $0xc,%esp
801040a1:	50                   	push   %eax
801040a2:	e8 e8 0b 00 00       	call   80104c8f <wakeup>
801040a7:	83 c4 10             	add    $0x10,%esp
  release(&p->lock);
801040aa:	8b 45 08             	mov    0x8(%ebp),%eax
801040ad:	83 ec 0c             	sub    $0xc,%esp
801040b0:	50                   	push   %eax
801040b1:	e8 a1 0f 00 00       	call   80105057 <release>
801040b6:	83 c4 10             	add    $0x10,%esp
  return n;
801040b9:	8b 45 10             	mov    0x10(%ebp),%eax
}
801040bc:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801040bf:	c9                   	leave
801040c0:	c3                   	ret

801040c1 <piperead>:

int
piperead(struct pipe *p, char *addr, int n)
{
801040c1:	55                   	push   %ebp
801040c2:	89 e5                	mov    %esp,%ebp
801040c4:	83 ec 18             	sub    $0x18,%esp
  int i;

  acquire(&p->lock);
801040c7:	8b 45 08             	mov    0x8(%ebp),%eax
801040ca:	83 ec 0c             	sub    $0xc,%esp
801040cd:	50                   	push   %eax
801040ce:	e8 16 0f 00 00       	call   80104fe9 <acquire>
801040d3:	83 c4 10             	add    $0x10,%esp
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
801040d6:	eb 3e                	jmp    80104116 <piperead+0x55>
    if(myproc()->killed){
801040d8:	e8 a8 01 00 00       	call   80104285 <myproc>
801040dd:	8b 40 24             	mov    0x24(%eax),%eax
801040e0:	85 c0                	test   %eax,%eax
801040e2:	74 19                	je     801040fd <piperead+0x3c>
      release(&p->lock);
801040e4:	8b 45 08             	mov    0x8(%ebp),%eax
801040e7:	83 ec 0c             	sub    $0xc,%esp
801040ea:	50                   	push   %eax
801040eb:	e8 67 0f 00 00       	call   80105057 <release>
801040f0:	83 c4 10             	add    $0x10,%esp
      return -1;
801040f3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801040f8:	e9 be 00 00 00       	jmp    801041bb <piperead+0xfa>
    }
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
801040fd:	8b 45 08             	mov    0x8(%ebp),%eax
80104100:	8b 55 08             	mov    0x8(%ebp),%edx
80104103:	81 c2 34 02 00 00    	add    $0x234,%edx
80104109:	83 ec 08             	sub    $0x8,%esp
8010410c:	50                   	push   %eax
8010410d:	52                   	push   %edx
8010410e:	e8 95 0a 00 00       	call   80104ba8 <sleep>
80104113:	83 c4 10             	add    $0x10,%esp
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
80104116:	8b 45 08             	mov    0x8(%ebp),%eax
80104119:	8b 90 34 02 00 00    	mov    0x234(%eax),%edx
8010411f:	8b 45 08             	mov    0x8(%ebp),%eax
80104122:	8b 80 38 02 00 00    	mov    0x238(%eax),%eax
80104128:	39 c2                	cmp    %eax,%edx
8010412a:	75 0d                	jne    80104139 <piperead+0x78>
8010412c:	8b 45 08             	mov    0x8(%ebp),%eax
8010412f:	8b 80 40 02 00 00    	mov    0x240(%eax),%eax
80104135:	85 c0                	test   %eax,%eax
80104137:	75 9f                	jne    801040d8 <piperead+0x17>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80104139:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80104140:	eb 48                	jmp    8010418a <piperead+0xc9>
    if(p->nread == p->nwrite)
80104142:	8b 45 08             	mov    0x8(%ebp),%eax
80104145:	8b 90 34 02 00 00    	mov    0x234(%eax),%edx
8010414b:	8b 45 08             	mov    0x8(%ebp),%eax
8010414e:	8b 80 38 02 00 00    	mov    0x238(%eax),%eax
80104154:	39 c2                	cmp    %eax,%edx
80104156:	74 3c                	je     80104194 <piperead+0xd3>
      break;
    addr[i] = p->data[p->nread++ % PIPESIZE];
80104158:	8b 45 08             	mov    0x8(%ebp),%eax
8010415b:	8b 80 34 02 00 00    	mov    0x234(%eax),%eax
80104161:	8d 48 01             	lea    0x1(%eax),%ecx
80104164:	8b 55 08             	mov    0x8(%ebp),%edx
80104167:	89 8a 34 02 00 00    	mov    %ecx,0x234(%edx)
8010416d:	25 ff 01 00 00       	and    $0x1ff,%eax
80104172:	89 c1                	mov    %eax,%ecx
80104174:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104177:	8b 45 0c             	mov    0xc(%ebp),%eax
8010417a:	01 c2                	add    %eax,%edx
8010417c:	8b 45 08             	mov    0x8(%ebp),%eax
8010417f:	0f b6 44 08 34       	movzbl 0x34(%eax,%ecx,1),%eax
80104184:	88 02                	mov    %al,(%edx)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80104186:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
8010418a:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010418d:	3b 45 10             	cmp    0x10(%ebp),%eax
80104190:	7c b0                	jl     80104142 <piperead+0x81>
80104192:	eb 01                	jmp    80104195 <piperead+0xd4>
      break;
80104194:	90                   	nop
  }
  wakeup(&p->nwrite);  //DOC: piperead-wakeup
80104195:	8b 45 08             	mov    0x8(%ebp),%eax
80104198:	05 38 02 00 00       	add    $0x238,%eax
8010419d:	83 ec 0c             	sub    $0xc,%esp
801041a0:	50                   	push   %eax
801041a1:	e8 e9 0a 00 00       	call   80104c8f <wakeup>
801041a6:	83 c4 10             	add    $0x10,%esp
  release(&p->lock);
801041a9:	8b 45 08             	mov    0x8(%ebp),%eax
801041ac:	83 ec 0c             	sub    $0xc,%esp
801041af:	50                   	push   %eax
801041b0:	e8 a2 0e 00 00       	call   80105057 <release>
801041b5:	83 c4 10             	add    $0x10,%esp
  return i;
801041b8:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
801041bb:	c9                   	leave
801041bc:	c3                   	ret

801041bd <readeflags>:
{
801041bd:	55                   	push   %ebp
801041be:	89 e5                	mov    %esp,%ebp
801041c0:	83 ec 10             	sub    $0x10,%esp
  asm volatile("pushfl; popl %0" : "=r" (eflags));
801041c3:	9c                   	pushf
801041c4:	58                   	pop    %eax
801041c5:	89 45 fc             	mov    %eax,-0x4(%ebp)
  return eflags;
801041c8:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
801041cb:	c9                   	leave
801041cc:	c3                   	ret

801041cd <sti>:
{
801041cd:	55                   	push   %ebp
801041ce:	89 e5                	mov    %esp,%ebp
  asm volatile("sti");
801041d0:	fb                   	sti
}
801041d1:	90                   	nop
801041d2:	5d                   	pop    %ebp
801041d3:	c3                   	ret

801041d4 <pinit>:

static void wakeup1(void *chan);

void
pinit(void)
{
801041d4:	55                   	push   %ebp
801041d5:	89 e5                	mov    %esp,%ebp
801041d7:	83 ec 08             	sub    $0x8,%esp
  initlock(&ptable.lock, "ptable");
801041da:	83 ec 08             	sub    $0x8,%esp
801041dd:	68 7c 87 10 80       	push   $0x8010877c
801041e2:	68 80 2d 11 80       	push   $0x80112d80
801041e7:	e8 db 0d 00 00       	call   80104fc7 <initlock>
801041ec:	83 c4 10             	add    $0x10,%esp
}
801041ef:	90                   	nop
801041f0:	c9                   	leave
801041f1:	c3                   	ret

801041f2 <cpuid>:

// Must be called with interrupts disabled
int
cpuid() {
801041f2:	55                   	push   %ebp
801041f3:	89 e5                	mov    %esp,%ebp
801041f5:	83 ec 08             	sub    $0x8,%esp
  return mycpu()-cpus;
801041f8:	e8 10 00 00 00       	call   8010420d <mycpu>
801041fd:	2d e0 27 11 80       	sub    $0x801127e0,%eax
80104202:	c1 f8 04             	sar    $0x4,%eax
80104205:	69 c0 a3 8b 2e ba    	imul   $0xba2e8ba3,%eax,%eax
}
8010420b:	c9                   	leave
8010420c:	c3                   	ret

8010420d <mycpu>:

// Must be called with interrupts disabled to avoid the caller being
// rescheduled between reading lapicid and running through the loop.
struct cpu*
mycpu(void)
{
8010420d:	55                   	push   %ebp
8010420e:	89 e5                	mov    %esp,%ebp
80104210:	83 ec 18             	sub    $0x18,%esp
  int apicid, i;
  
  if(readeflags()&FL_IF)
80104213:	e8 a5 ff ff ff       	call   801041bd <readeflags>
80104218:	25 00 02 00 00       	and    $0x200,%eax
8010421d:	85 c0                	test   %eax,%eax
8010421f:	74 0d                	je     8010422e <mycpu+0x21>
    panic("mycpu called with interrupts enabled\n");
80104221:	83 ec 0c             	sub    $0xc,%esp
80104224:	68 84 87 10 80       	push   $0x80108784
80104229:	e8 85 c3 ff ff       	call   801005b3 <panic>
  
  apicid = lapicid();
8010422e:	e8 a9 ed ff ff       	call   80102fdc <lapicid>
80104233:	89 45 f0             	mov    %eax,-0x10(%ebp)
  // APIC IDs are not guaranteed to be contiguous. Maybe we should have
  // a reverse map, or reserve a register to store &cpus[i].
  for (i = 0; i < ncpu; ++i) {
80104236:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
8010423d:	eb 2d                	jmp    8010426c <mycpu+0x5f>
    if (cpus[i].apicid == apicid)
8010423f:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104242:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
80104248:	05 e0 27 11 80       	add    $0x801127e0,%eax
8010424d:	0f b6 00             	movzbl (%eax),%eax
80104250:	0f b6 c0             	movzbl %al,%eax
80104253:	39 45 f0             	cmp    %eax,-0x10(%ebp)
80104256:	75 10                	jne    80104268 <mycpu+0x5b>
      return &cpus[i];
80104258:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010425b:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
80104261:	05 e0 27 11 80       	add    $0x801127e0,%eax
80104266:	eb 1b                	jmp    80104283 <mycpu+0x76>
  for (i = 0; i < ncpu; ++i) {
80104268:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
8010426c:	a1 60 2d 11 80       	mov    0x80112d60,%eax
80104271:	39 45 f4             	cmp    %eax,-0xc(%ebp)
80104274:	7c c9                	jl     8010423f <mycpu+0x32>
  }
  panic("unknown apicid\n");
80104276:	83 ec 0c             	sub    $0xc,%esp
80104279:	68 aa 87 10 80       	push   $0x801087aa
8010427e:	e8 30 c3 ff ff       	call   801005b3 <panic>
}
80104283:	c9                   	leave
80104284:	c3                   	ret

80104285 <myproc>:

// Disable interrupts so that we are not rescheduled
// while reading proc from the cpu structure
struct proc*
myproc(void) {
80104285:	55                   	push   %ebp
80104286:	89 e5                	mov    %esp,%ebp
80104288:	83 ec 18             	sub    $0x18,%esp
  struct cpu *c;
  struct proc *p;
  pushcli();
8010428b:	e8 d4 0e 00 00       	call   80105164 <pushcli>
  c = mycpu();
80104290:	e8 78 ff ff ff       	call   8010420d <mycpu>
80104295:	89 45 f4             	mov    %eax,-0xc(%ebp)
  p = c->proc;
80104298:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010429b:	8b 80 ac 00 00 00    	mov    0xac(%eax),%eax
801042a1:	89 45 f0             	mov    %eax,-0x10(%ebp)
  popcli();
801042a4:	e8 08 0f 00 00       	call   801051b1 <popcli>
  return p;
801042a9:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
801042ac:	c9                   	leave
801042ad:	c3                   	ret

801042ae <allocproc>:
// If found, change state to EMBRYO and initialize
// state required to run in the kernel.
// Otherwise return 0.
static struct proc*
allocproc(void)
{
801042ae:	55                   	push   %ebp
801042af:	89 e5                	mov    %esp,%ebp
801042b1:	83 ec 18             	sub    $0x18,%esp
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);
801042b4:	83 ec 0c             	sub    $0xc,%esp
801042b7:	68 80 2d 11 80       	push   $0x80112d80
801042bc:	e8 28 0d 00 00       	call   80104fe9 <acquire>
801042c1:	83 c4 10             	add    $0x10,%esp

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801042c4:	c7 45 f4 b4 2d 11 80 	movl   $0x80112db4,-0xc(%ebp)
801042cb:	eb 0e                	jmp    801042db <allocproc+0x2d>
    if(p->state == UNUSED)
801042cd:	8b 45 f4             	mov    -0xc(%ebp),%eax
801042d0:	8b 40 0c             	mov    0xc(%eax),%eax
801042d3:	85 c0                	test   %eax,%eax
801042d5:	74 27                	je     801042fe <allocproc+0x50>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801042d7:	83 45 f4 7c          	addl   $0x7c,-0xc(%ebp)
801042db:	81 7d f4 b4 4c 11 80 	cmpl   $0x80114cb4,-0xc(%ebp)
801042e2:	72 e9                	jb     801042cd <allocproc+0x1f>
      goto found;

  release(&ptable.lock);
801042e4:	83 ec 0c             	sub    $0xc,%esp
801042e7:	68 80 2d 11 80       	push   $0x80112d80
801042ec:	e8 66 0d 00 00       	call   80105057 <release>
801042f1:	83 c4 10             	add    $0x10,%esp
  return 0;
801042f4:	b8 00 00 00 00       	mov    $0x0,%eax
801042f9:	e9 b2 00 00 00       	jmp    801043b0 <allocproc+0x102>
      goto found;
801042fe:	90                   	nop

found:
  p->state = EMBRYO;
801042ff:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104302:	c7 40 0c 01 00 00 00 	movl   $0x1,0xc(%eax)
  p->pid = nextpid++;
80104309:	a1 00 b0 10 80       	mov    0x8010b000,%eax
8010430e:	8d 50 01             	lea    0x1(%eax),%edx
80104311:	89 15 00 b0 10 80    	mov    %edx,0x8010b000
80104317:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010431a:	89 42 10             	mov    %eax,0x10(%edx)

  release(&ptable.lock);
8010431d:	83 ec 0c             	sub    $0xc,%esp
80104320:	68 80 2d 11 80       	push   $0x80112d80
80104325:	e8 2d 0d 00 00       	call   80105057 <release>
8010432a:	83 c4 10             	add    $0x10,%esp

  // Allocate kernel stack.
  if((p->kstack = kalloc()) == 0){
8010432d:	e8 60 e9 ff ff       	call   80102c92 <kalloc>
80104332:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104335:	89 42 08             	mov    %eax,0x8(%edx)
80104338:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010433b:	8b 40 08             	mov    0x8(%eax),%eax
8010433e:	85 c0                	test   %eax,%eax
80104340:	75 11                	jne    80104353 <allocproc+0xa5>
    p->state = UNUSED;
80104342:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104345:	c7 40 0c 00 00 00 00 	movl   $0x0,0xc(%eax)
    return 0;
8010434c:	b8 00 00 00 00       	mov    $0x0,%eax
80104351:	eb 5d                	jmp    801043b0 <allocproc+0x102>
  }
  sp = p->kstack + KSTACKSIZE;
80104353:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104356:	8b 40 08             	mov    0x8(%eax),%eax
80104359:	05 00 10 00 00       	add    $0x1000,%eax
8010435e:	89 45 f0             	mov    %eax,-0x10(%ebp)

  // Leave room for trap frame.
  sp -= sizeof *p->tf;
80104361:	83 6d f0 4c          	subl   $0x4c,-0x10(%ebp)
  p->tf = (struct trapframe*)sp;
80104365:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104368:	8b 55 f0             	mov    -0x10(%ebp),%edx
8010436b:	89 50 18             	mov    %edx,0x18(%eax)

  // Set up new context to start executing at forkret,
  // which returns to trapret.
  sp -= 4;
8010436e:	83 6d f0 04          	subl   $0x4,-0x10(%ebp)
  *(uint*)sp = (uint)trapret;
80104372:	ba 76 66 10 80       	mov    $0x80106676,%edx
80104377:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010437a:	89 10                	mov    %edx,(%eax)

  sp -= sizeof *p->context;
8010437c:	83 6d f0 14          	subl   $0x14,-0x10(%ebp)
  p->context = (struct context*)sp;
80104380:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104383:	8b 55 f0             	mov    -0x10(%ebp),%edx
80104386:	89 50 1c             	mov    %edx,0x1c(%eax)
  memset(p->context, 0, sizeof *p->context);
80104389:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010438c:	8b 40 1c             	mov    0x1c(%eax),%eax
8010438f:	83 ec 04             	sub    $0x4,%esp
80104392:	6a 14                	push   $0x14
80104394:	6a 00                	push   $0x0
80104396:	50                   	push   %eax
80104397:	e8 d3 0e 00 00       	call   8010526f <memset>
8010439c:	83 c4 10             	add    $0x10,%esp
  p->context->eip = (uint)forkret;
8010439f:	8b 45 f4             	mov    -0xc(%ebp),%eax
801043a2:	8b 40 1c             	mov    0x1c(%eax),%eax
801043a5:	ba 62 4b 10 80       	mov    $0x80104b62,%edx
801043aa:	89 50 10             	mov    %edx,0x10(%eax)

  return p;
801043ad:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
801043b0:	c9                   	leave
801043b1:	c3                   	ret

801043b2 <userinit>:

//PAGEBREAK: 32
// Set up first user process.
void
userinit(void)
{
801043b2:	55                   	push   %ebp
801043b3:	89 e5                	mov    %esp,%ebp
801043b5:	83 ec 18             	sub    $0x18,%esp
  struct proc *p;
  extern char _binary_initcode_start[], _binary_initcode_size[];

  p = allocproc();
801043b8:	e8 f1 fe ff ff       	call   801042ae <allocproc>
801043bd:	89 45 f4             	mov    %eax,-0xc(%ebp)
  
  initproc = p;
801043c0:	8b 45 f4             	mov    -0xc(%ebp),%eax
801043c3:	a3 b4 4c 11 80       	mov    %eax,0x80114cb4
  if((p->pgdir = setupkvm()) == 0)
801043c8:	e8 44 38 00 00       	call   80107c11 <setupkvm>
801043cd:	8b 55 f4             	mov    -0xc(%ebp),%edx
801043d0:	89 42 04             	mov    %eax,0x4(%edx)
801043d3:	8b 45 f4             	mov    -0xc(%ebp),%eax
801043d6:	8b 40 04             	mov    0x4(%eax),%eax
801043d9:	85 c0                	test   %eax,%eax
801043db:	75 0d                	jne    801043ea <userinit+0x38>
    panic("userinit: out of memory?");
801043dd:	83 ec 0c             	sub    $0xc,%esp
801043e0:	68 ba 87 10 80       	push   $0x801087ba
801043e5:	e8 c9 c1 ff ff       	call   801005b3 <panic>
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
801043ea:	ba 54 00 00 00       	mov    $0x54,%edx
801043ef:	8b 45 f4             	mov    -0xc(%ebp),%eax
801043f2:	8b 40 04             	mov    0x4(%eax),%eax
801043f5:	83 ec 04             	sub    $0x4,%esp
801043f8:	52                   	push   %edx
801043f9:	68 c0 b4 10 80       	push   $0x8010b4c0
801043fe:	50                   	push   %eax
801043ff:	e8 76 3a 00 00       	call   80107e7a <inituvm>
80104404:	83 c4 10             	add    $0x10,%esp
  p->sz = PGSIZE;
80104407:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010440a:	c7 00 00 10 00 00    	movl   $0x1000,(%eax)
  memset(p->tf, 0, sizeof(*p->tf));
80104410:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104413:	8b 40 18             	mov    0x18(%eax),%eax
80104416:	83 ec 04             	sub    $0x4,%esp
80104419:	6a 4c                	push   $0x4c
8010441b:	6a 00                	push   $0x0
8010441d:	50                   	push   %eax
8010441e:	e8 4c 0e 00 00       	call   8010526f <memset>
80104423:	83 c4 10             	add    $0x10,%esp
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
80104426:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104429:	8b 40 18             	mov    0x18(%eax),%eax
8010442c:	66 c7 40 3c 1b 00    	movw   $0x1b,0x3c(%eax)
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
80104432:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104435:	8b 40 18             	mov    0x18(%eax),%eax
80104438:	66 c7 40 2c 23 00    	movw   $0x23,0x2c(%eax)
  p->tf->es = p->tf->ds;
8010443e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104441:	8b 50 18             	mov    0x18(%eax),%edx
80104444:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104447:	8b 40 18             	mov    0x18(%eax),%eax
8010444a:	0f b7 52 2c          	movzwl 0x2c(%edx),%edx
8010444e:	66 89 50 28          	mov    %dx,0x28(%eax)
  p->tf->ss = p->tf->ds;
80104452:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104455:	8b 50 18             	mov    0x18(%eax),%edx
80104458:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010445b:	8b 40 18             	mov    0x18(%eax),%eax
8010445e:	0f b7 52 2c          	movzwl 0x2c(%edx),%edx
80104462:	66 89 50 48          	mov    %dx,0x48(%eax)
  p->tf->eflags = FL_IF;
80104466:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104469:	8b 40 18             	mov    0x18(%eax),%eax
8010446c:	c7 40 40 00 02 00 00 	movl   $0x200,0x40(%eax)
  p->tf->esp = PGSIZE;
80104473:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104476:	8b 40 18             	mov    0x18(%eax),%eax
80104479:	c7 40 44 00 10 00 00 	movl   $0x1000,0x44(%eax)
  p->tf->eip = 0;  // beginning of initcode.S
80104480:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104483:	8b 40 18             	mov    0x18(%eax),%eax
80104486:	c7 40 38 00 00 00 00 	movl   $0x0,0x38(%eax)

  safestrcpy(p->name, "initcode", sizeof(p->name));
8010448d:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104490:	83 c0 6c             	add    $0x6c,%eax
80104493:	83 ec 04             	sub    $0x4,%esp
80104496:	6a 10                	push   $0x10
80104498:	68 d3 87 10 80       	push   $0x801087d3
8010449d:	50                   	push   %eax
8010449e:	e8 cf 0f 00 00       	call   80105472 <safestrcpy>
801044a3:	83 c4 10             	add    $0x10,%esp
  p->cwd = namei("/");
801044a6:	83 ec 0c             	sub    $0xc,%esp
801044a9:	68 dc 87 10 80       	push   $0x801087dc
801044ae:	e8 96 e0 ff ff       	call   80102549 <namei>
801044b3:	83 c4 10             	add    $0x10,%esp
801044b6:	8b 55 f4             	mov    -0xc(%ebp),%edx
801044b9:	89 42 68             	mov    %eax,0x68(%edx)

  // this assignment to p->state lets other cores
  // run this process. the acquire forces the above
  // writes to be visible, and the lock is also needed
  // because the assignment might not be atomic.
  acquire(&ptable.lock);
801044bc:	83 ec 0c             	sub    $0xc,%esp
801044bf:	68 80 2d 11 80       	push   $0x80112d80
801044c4:	e8 20 0b 00 00       	call   80104fe9 <acquire>
801044c9:	83 c4 10             	add    $0x10,%esp

  p->state = RUNNABLE;
801044cc:	8b 45 f4             	mov    -0xc(%ebp),%eax
801044cf:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)

  release(&ptable.lock);
801044d6:	83 ec 0c             	sub    $0xc,%esp
801044d9:	68 80 2d 11 80       	push   $0x80112d80
801044de:	e8 74 0b 00 00       	call   80105057 <release>
801044e3:	83 c4 10             	add    $0x10,%esp
}
801044e6:	90                   	nop
801044e7:	c9                   	leave
801044e8:	c3                   	ret

801044e9 <growproc>:

// Grow current process's memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
801044e9:	55                   	push   %ebp
801044ea:	89 e5                	mov    %esp,%ebp
801044ec:	83 ec 18             	sub    $0x18,%esp
  uint sz;
  struct proc *curproc = myproc();
801044ef:	e8 91 fd ff ff       	call   80104285 <myproc>
801044f4:	89 45 f0             	mov    %eax,-0x10(%ebp)

  sz = curproc->sz;
801044f7:	8b 45 f0             	mov    -0x10(%ebp),%eax
801044fa:	8b 00                	mov    (%eax),%eax
801044fc:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(n > 0){
801044ff:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
80104503:	7e 2e                	jle    80104533 <growproc+0x4a>
    if((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
80104505:	8b 55 08             	mov    0x8(%ebp),%edx
80104508:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010450b:	01 c2                	add    %eax,%edx
8010450d:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104510:	8b 40 04             	mov    0x4(%eax),%eax
80104513:	83 ec 04             	sub    $0x4,%esp
80104516:	52                   	push   %edx
80104517:	ff 75 f4             	push   -0xc(%ebp)
8010451a:	50                   	push   %eax
8010451b:	e8 97 3a 00 00       	call   80107fb7 <allocuvm>
80104520:	83 c4 10             	add    $0x10,%esp
80104523:	89 45 f4             	mov    %eax,-0xc(%ebp)
80104526:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
8010452a:	75 3b                	jne    80104567 <growproc+0x7e>
      return -1;
8010452c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104531:	eb 4f                	jmp    80104582 <growproc+0x99>
  } else if(n < 0){
80104533:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
80104537:	79 2e                	jns    80104567 <growproc+0x7e>
    if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
80104539:	8b 55 08             	mov    0x8(%ebp),%edx
8010453c:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010453f:	01 c2                	add    %eax,%edx
80104541:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104544:	8b 40 04             	mov    0x4(%eax),%eax
80104547:	83 ec 04             	sub    $0x4,%esp
8010454a:	52                   	push   %edx
8010454b:	ff 75 f4             	push   -0xc(%ebp)
8010454e:	50                   	push   %eax
8010454f:	e8 68 3b 00 00       	call   801080bc <deallocuvm>
80104554:	83 c4 10             	add    $0x10,%esp
80104557:	89 45 f4             	mov    %eax,-0xc(%ebp)
8010455a:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
8010455e:	75 07                	jne    80104567 <growproc+0x7e>
      return -1;
80104560:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104565:	eb 1b                	jmp    80104582 <growproc+0x99>
  }
  curproc->sz = sz;
80104567:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010456a:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010456d:	89 10                	mov    %edx,(%eax)
  switchuvm(curproc);
8010456f:	83 ec 0c             	sub    $0xc,%esp
80104572:	ff 75 f0             	push   -0x10(%ebp)
80104575:	e8 61 37 00 00       	call   80107cdb <switchuvm>
8010457a:	83 c4 10             	add    $0x10,%esp
  return 0;
8010457d:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104582:	c9                   	leave
80104583:	c3                   	ret

80104584 <fork>:
// Create a new process copying p as the parent.
// Sets up stack to return as if from system call.
// Caller must set state of returned proc to RUNNABLE.
int
fork(void)
{
80104584:	55                   	push   %ebp
80104585:	89 e5                	mov    %esp,%ebp
80104587:	57                   	push   %edi
80104588:	56                   	push   %esi
80104589:	53                   	push   %ebx
8010458a:	83 ec 1c             	sub    $0x1c,%esp
  int i, pid;
  struct proc *np;
  struct proc *curproc = myproc();
8010458d:	e8 f3 fc ff ff       	call   80104285 <myproc>
80104592:	89 45 e0             	mov    %eax,-0x20(%ebp)

  // Allocate process.
  if((np = allocproc()) == 0){
80104595:	e8 14 fd ff ff       	call   801042ae <allocproc>
8010459a:	89 45 dc             	mov    %eax,-0x24(%ebp)
8010459d:	83 7d dc 00          	cmpl   $0x0,-0x24(%ebp)
801045a1:	75 0a                	jne    801045ad <fork+0x29>
    return -1;
801045a3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801045a8:	e9 48 01 00 00       	jmp    801046f5 <fork+0x171>
  }

  // Copy process state from proc.
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
801045ad:	8b 45 e0             	mov    -0x20(%ebp),%eax
801045b0:	8b 10                	mov    (%eax),%edx
801045b2:	8b 45 e0             	mov    -0x20(%ebp),%eax
801045b5:	8b 40 04             	mov    0x4(%eax),%eax
801045b8:	83 ec 08             	sub    $0x8,%esp
801045bb:	52                   	push   %edx
801045bc:	50                   	push   %eax
801045bd:	e8 98 3c 00 00       	call   8010825a <copyuvm>
801045c2:	83 c4 10             	add    $0x10,%esp
801045c5:	8b 55 dc             	mov    -0x24(%ebp),%edx
801045c8:	89 42 04             	mov    %eax,0x4(%edx)
801045cb:	8b 45 dc             	mov    -0x24(%ebp),%eax
801045ce:	8b 40 04             	mov    0x4(%eax),%eax
801045d1:	85 c0                	test   %eax,%eax
801045d3:	75 30                	jne    80104605 <fork+0x81>
    kfree(np->kstack);
801045d5:	8b 45 dc             	mov    -0x24(%ebp),%eax
801045d8:	8b 40 08             	mov    0x8(%eax),%eax
801045db:	83 ec 0c             	sub    $0xc,%esp
801045de:	50                   	push   %eax
801045df:	e8 14 e6 ff ff       	call   80102bf8 <kfree>
801045e4:	83 c4 10             	add    $0x10,%esp
    np->kstack = 0;
801045e7:	8b 45 dc             	mov    -0x24(%ebp),%eax
801045ea:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
    np->state = UNUSED;
801045f1:	8b 45 dc             	mov    -0x24(%ebp),%eax
801045f4:	c7 40 0c 00 00 00 00 	movl   $0x0,0xc(%eax)
    return -1;
801045fb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104600:	e9 f0 00 00 00       	jmp    801046f5 <fork+0x171>
  }
  np->sz = curproc->sz;
80104605:	8b 45 e0             	mov    -0x20(%ebp),%eax
80104608:	8b 10                	mov    (%eax),%edx
8010460a:	8b 45 dc             	mov    -0x24(%ebp),%eax
8010460d:	89 10                	mov    %edx,(%eax)
  np->parent = curproc;
8010460f:	8b 45 dc             	mov    -0x24(%ebp),%eax
80104612:	8b 55 e0             	mov    -0x20(%ebp),%edx
80104615:	89 50 14             	mov    %edx,0x14(%eax)
  *np->tf = *curproc->tf;
80104618:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010461b:	8b 48 18             	mov    0x18(%eax),%ecx
8010461e:	8b 45 dc             	mov    -0x24(%ebp),%eax
80104621:	8b 40 18             	mov    0x18(%eax),%eax
80104624:	89 c2                	mov    %eax,%edx
80104626:	89 cb                	mov    %ecx,%ebx
80104628:	b8 13 00 00 00       	mov    $0x13,%eax
8010462d:	89 d7                	mov    %edx,%edi
8010462f:	89 de                	mov    %ebx,%esi
80104631:	89 c1                	mov    %eax,%ecx
80104633:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)

  // Clear %eax so that fork returns 0 in the child.
  np->tf->eax = 0;
80104635:	8b 45 dc             	mov    -0x24(%ebp),%eax
80104638:	8b 40 18             	mov    0x18(%eax),%eax
8010463b:	c7 40 1c 00 00 00 00 	movl   $0x0,0x1c(%eax)

  for(i = 0; i < NOFILE; i++)
80104642:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
80104649:	eb 3b                	jmp    80104686 <fork+0x102>
    if(curproc->ofile[i])
8010464b:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010464e:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80104651:	83 c2 08             	add    $0x8,%edx
80104654:	8b 44 90 08          	mov    0x8(%eax,%edx,4),%eax
80104658:	85 c0                	test   %eax,%eax
8010465a:	74 26                	je     80104682 <fork+0xfe>
      np->ofile[i] = filedup(curproc->ofile[i]);
8010465c:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010465f:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80104662:	83 c2 08             	add    $0x8,%edx
80104665:	8b 44 90 08          	mov    0x8(%eax,%edx,4),%eax
80104669:	83 ec 0c             	sub    $0xc,%esp
8010466c:	50                   	push   %eax
8010466d:	e8 19 ca ff ff       	call   8010108b <filedup>
80104672:	83 c4 10             	add    $0x10,%esp
80104675:	8b 55 dc             	mov    -0x24(%ebp),%edx
80104678:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
8010467b:	83 c1 08             	add    $0x8,%ecx
8010467e:	89 44 8a 08          	mov    %eax,0x8(%edx,%ecx,4)
  for(i = 0; i < NOFILE; i++)
80104682:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
80104686:	83 7d e4 0f          	cmpl   $0xf,-0x1c(%ebp)
8010468a:	7e bf                	jle    8010464b <fork+0xc7>
  np->cwd = idup(curproc->cwd);
8010468c:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010468f:	8b 40 68             	mov    0x68(%eax),%eax
80104692:	83 ec 0c             	sub    $0xc,%esp
80104695:	50                   	push   %eax
80104696:	e8 41 d3 ff ff       	call   801019dc <idup>
8010469b:	83 c4 10             	add    $0x10,%esp
8010469e:	8b 55 dc             	mov    -0x24(%ebp),%edx
801046a1:	89 42 68             	mov    %eax,0x68(%edx)

  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
801046a4:	8b 45 e0             	mov    -0x20(%ebp),%eax
801046a7:	8d 50 6c             	lea    0x6c(%eax),%edx
801046aa:	8b 45 dc             	mov    -0x24(%ebp),%eax
801046ad:	83 c0 6c             	add    $0x6c,%eax
801046b0:	83 ec 04             	sub    $0x4,%esp
801046b3:	6a 10                	push   $0x10
801046b5:	52                   	push   %edx
801046b6:	50                   	push   %eax
801046b7:	e8 b6 0d 00 00       	call   80105472 <safestrcpy>
801046bc:	83 c4 10             	add    $0x10,%esp

  pid = np->pid;
801046bf:	8b 45 dc             	mov    -0x24(%ebp),%eax
801046c2:	8b 40 10             	mov    0x10(%eax),%eax
801046c5:	89 45 d8             	mov    %eax,-0x28(%ebp)

  acquire(&ptable.lock);
801046c8:	83 ec 0c             	sub    $0xc,%esp
801046cb:	68 80 2d 11 80       	push   $0x80112d80
801046d0:	e8 14 09 00 00       	call   80104fe9 <acquire>
801046d5:	83 c4 10             	add    $0x10,%esp

  np->state = RUNNABLE;
801046d8:	8b 45 dc             	mov    -0x24(%ebp),%eax
801046db:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)

  release(&ptable.lock);
801046e2:	83 ec 0c             	sub    $0xc,%esp
801046e5:	68 80 2d 11 80       	push   $0x80112d80
801046ea:	e8 68 09 00 00       	call   80105057 <release>
801046ef:	83 c4 10             	add    $0x10,%esp

  return pid;
801046f2:	8b 45 d8             	mov    -0x28(%ebp),%eax
}
801046f5:	8d 65 f4             	lea    -0xc(%ebp),%esp
801046f8:	5b                   	pop    %ebx
801046f9:	5e                   	pop    %esi
801046fa:	5f                   	pop    %edi
801046fb:	5d                   	pop    %ebp
801046fc:	c3                   	ret

801046fd <exit>:
// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait() to find out it exited.
void
exit(void)
{
801046fd:	55                   	push   %ebp
801046fe:	89 e5                	mov    %esp,%ebp
80104700:	83 ec 18             	sub    $0x18,%esp
  struct proc *curproc = myproc();
80104703:	e8 7d fb ff ff       	call   80104285 <myproc>
80104708:	89 45 ec             	mov    %eax,-0x14(%ebp)
  struct proc *p;
  int fd;

  if(curproc == initproc)
8010470b:	a1 b4 4c 11 80       	mov    0x80114cb4,%eax
80104710:	39 45 ec             	cmp    %eax,-0x14(%ebp)
80104713:	75 0d                	jne    80104722 <exit+0x25>
    panic("init exiting");
80104715:	83 ec 0c             	sub    $0xc,%esp
80104718:	68 de 87 10 80       	push   $0x801087de
8010471d:	e8 91 be ff ff       	call   801005b3 <panic>

  // Close all open files.
  for(fd = 0; fd < NOFILE; fd++){
80104722:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
80104729:	eb 3f                	jmp    8010476a <exit+0x6d>
    if(curproc->ofile[fd]){
8010472b:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010472e:	8b 55 f0             	mov    -0x10(%ebp),%edx
80104731:	83 c2 08             	add    $0x8,%edx
80104734:	8b 44 90 08          	mov    0x8(%eax,%edx,4),%eax
80104738:	85 c0                	test   %eax,%eax
8010473a:	74 2a                	je     80104766 <exit+0x69>
      fileclose(curproc->ofile[fd]);
8010473c:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010473f:	8b 55 f0             	mov    -0x10(%ebp),%edx
80104742:	83 c2 08             	add    $0x8,%edx
80104745:	8b 44 90 08          	mov    0x8(%eax,%edx,4),%eax
80104749:	83 ec 0c             	sub    $0xc,%esp
8010474c:	50                   	push   %eax
8010474d:	e8 8a c9 ff ff       	call   801010dc <fileclose>
80104752:	83 c4 10             	add    $0x10,%esp
      curproc->ofile[fd] = 0;
80104755:	8b 45 ec             	mov    -0x14(%ebp),%eax
80104758:	8b 55 f0             	mov    -0x10(%ebp),%edx
8010475b:	83 c2 08             	add    $0x8,%edx
8010475e:	c7 44 90 08 00 00 00 	movl   $0x0,0x8(%eax,%edx,4)
80104765:	00 
  for(fd = 0; fd < NOFILE; fd++){
80104766:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
8010476a:	83 7d f0 0f          	cmpl   $0xf,-0x10(%ebp)
8010476e:	7e bb                	jle    8010472b <exit+0x2e>
    }
  }

  begin_op();
80104770:	e8 ad ed ff ff       	call   80103522 <begin_op>
  iput(curproc->cwd);
80104775:	8b 45 ec             	mov    -0x14(%ebp),%eax
80104778:	8b 40 68             	mov    0x68(%eax),%eax
8010477b:	83 ec 0c             	sub    $0xc,%esp
8010477e:	50                   	push   %eax
8010477f:	e8 f3 d3 ff ff       	call   80101b77 <iput>
80104784:	83 c4 10             	add    $0x10,%esp
  end_op();
80104787:	e8 22 ee ff ff       	call   801035ae <end_op>
  curproc->cwd = 0;
8010478c:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010478f:	c7 40 68 00 00 00 00 	movl   $0x0,0x68(%eax)

  acquire(&ptable.lock);
80104796:	83 ec 0c             	sub    $0xc,%esp
80104799:	68 80 2d 11 80       	push   $0x80112d80
8010479e:	e8 46 08 00 00       	call   80104fe9 <acquire>
801047a3:	83 c4 10             	add    $0x10,%esp

  // Parent might be sleeping in wait().
  wakeup1(curproc->parent);
801047a6:	8b 45 ec             	mov    -0x14(%ebp),%eax
801047a9:	8b 40 14             	mov    0x14(%eax),%eax
801047ac:	83 ec 0c             	sub    $0xc,%esp
801047af:	50                   	push   %eax
801047b0:	e8 9a 04 00 00       	call   80104c4f <wakeup1>
801047b5:	83 c4 10             	add    $0x10,%esp

  // Pass abandoned children to init.
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801047b8:	c7 45 f4 b4 2d 11 80 	movl   $0x80112db4,-0xc(%ebp)
801047bf:	eb 37                	jmp    801047f8 <exit+0xfb>
    if(p->parent == curproc){
801047c1:	8b 45 f4             	mov    -0xc(%ebp),%eax
801047c4:	8b 40 14             	mov    0x14(%eax),%eax
801047c7:	39 45 ec             	cmp    %eax,-0x14(%ebp)
801047ca:	75 28                	jne    801047f4 <exit+0xf7>
      p->parent = initproc;
801047cc:	8b 15 b4 4c 11 80    	mov    0x80114cb4,%edx
801047d2:	8b 45 f4             	mov    -0xc(%ebp),%eax
801047d5:	89 50 14             	mov    %edx,0x14(%eax)
      if(p->state == ZOMBIE)
801047d8:	8b 45 f4             	mov    -0xc(%ebp),%eax
801047db:	8b 40 0c             	mov    0xc(%eax),%eax
801047de:	83 f8 05             	cmp    $0x5,%eax
801047e1:	75 11                	jne    801047f4 <exit+0xf7>
        wakeup1(initproc);
801047e3:	a1 b4 4c 11 80       	mov    0x80114cb4,%eax
801047e8:	83 ec 0c             	sub    $0xc,%esp
801047eb:	50                   	push   %eax
801047ec:	e8 5e 04 00 00       	call   80104c4f <wakeup1>
801047f1:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801047f4:	83 45 f4 7c          	addl   $0x7c,-0xc(%ebp)
801047f8:	81 7d f4 b4 4c 11 80 	cmpl   $0x80114cb4,-0xc(%ebp)
801047ff:	72 c0                	jb     801047c1 <exit+0xc4>
    }
  }

  // Jump into the scheduler, never to return.
  curproc->state = ZOMBIE;
80104801:	8b 45 ec             	mov    -0x14(%ebp),%eax
80104804:	c7 40 0c 05 00 00 00 	movl   $0x5,0xc(%eax)
  sched();
8010480b:	e8 5f 02 00 00       	call   80104a6f <sched>
  panic("zombie exit");
80104810:	83 ec 0c             	sub    $0xc,%esp
80104813:	68 eb 87 10 80       	push   $0x801087eb
80104818:	e8 96 bd ff ff       	call   801005b3 <panic>

8010481d <getparentname>:
}

int getparentname(char* parentbuf,char* childbuf, int parentbufsize, int childbufsize) {
8010481d:	55                   	push   %ebp
8010481e:	89 e5                	mov    %esp,%ebp
80104820:	83 ec 18             	sub    $0x18,%esp
  struct proc* p = myproc();
80104823:	e8 5d fa ff ff       	call   80104285 <myproc>
80104828:	89 45 f4             	mov    %eax,-0xc(%ebp)
  
  if (parentbuf == 0 || childbuf == 0 || parentbufsize < 1 || childbufsize < 1) {
8010482b:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
8010482f:	74 12                	je     80104843 <getparentname+0x26>
80104831:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
80104835:	74 0c                	je     80104843 <getparentname+0x26>
80104837:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
8010483b:	7e 06                	jle    80104843 <getparentname+0x26>
8010483d:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
80104841:	7f 07                	jg     8010484a <getparentname+0x2d>
    return -1;
80104843:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104848:	eb 4b                	jmp    80104895 <getparentname+0x78>
  }

  if (p == 0) {
8010484a:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
8010484e:	75 0d                	jne    8010485d <getparentname+0x40>
    panic("getparentname");
80104850:	83 ec 0c             	sub    $0xc,%esp
80104853:	68 f7 87 10 80       	push   $0x801087f7
80104858:	e8 56 bd ff ff       	call   801005b3 <panic>
  }

  safestrcpy(parentbuf, p->parent->name, parentbufsize);
8010485d:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104860:	8b 40 14             	mov    0x14(%eax),%eax
80104863:	83 c0 6c             	add    $0x6c,%eax
80104866:	83 ec 04             	sub    $0x4,%esp
80104869:	ff 75 10             	push   0x10(%ebp)
8010486c:	50                   	push   %eax
8010486d:	ff 75 08             	push   0x8(%ebp)
80104870:	e8 fd 0b 00 00       	call   80105472 <safestrcpy>
80104875:	83 c4 10             	add    $0x10,%esp
  safestrcpy(childbuf, p->name, childbufsize);
80104878:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010487b:	83 c0 6c             	add    $0x6c,%eax
8010487e:	83 ec 04             	sub    $0x4,%esp
80104881:	ff 75 14             	push   0x14(%ebp)
80104884:	50                   	push   %eax
80104885:	ff 75 0c             	push   0xc(%ebp)
80104888:	e8 e5 0b 00 00       	call   80105472 <safestrcpy>
8010488d:	83 c4 10             	add    $0x10,%esp

  return 0;
80104890:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104895:	c9                   	leave
80104896:	c3                   	ret

80104897 <wait>:

// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.
int
wait(void)
{
80104897:	55                   	push   %ebp
80104898:	89 e5                	mov    %esp,%ebp
8010489a:	83 ec 18             	sub    $0x18,%esp
  struct proc *p;
  int havekids, pid;
  struct proc *curproc = myproc();
8010489d:	e8 e3 f9 ff ff       	call   80104285 <myproc>
801048a2:	89 45 ec             	mov    %eax,-0x14(%ebp)
  
  acquire(&ptable.lock);
801048a5:	83 ec 0c             	sub    $0xc,%esp
801048a8:	68 80 2d 11 80       	push   $0x80112d80
801048ad:	e8 37 07 00 00       	call   80104fe9 <acquire>
801048b2:	83 c4 10             	add    $0x10,%esp
  for(;;){
    // Scan through table looking for exited children.
    havekids = 0;
801048b5:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801048bc:	c7 45 f4 b4 2d 11 80 	movl   $0x80112db4,-0xc(%ebp)
801048c3:	e9 a1 00 00 00       	jmp    80104969 <wait+0xd2>
      if(p->parent != curproc)
801048c8:	8b 45 f4             	mov    -0xc(%ebp),%eax
801048cb:	8b 40 14             	mov    0x14(%eax),%eax
801048ce:	39 45 ec             	cmp    %eax,-0x14(%ebp)
801048d1:	0f 85 8d 00 00 00    	jne    80104964 <wait+0xcd>
        continue;
      havekids = 1;
801048d7:	c7 45 f0 01 00 00 00 	movl   $0x1,-0x10(%ebp)
      if(p->state == ZOMBIE){
801048de:	8b 45 f4             	mov    -0xc(%ebp),%eax
801048e1:	8b 40 0c             	mov    0xc(%eax),%eax
801048e4:	83 f8 05             	cmp    $0x5,%eax
801048e7:	75 7c                	jne    80104965 <wait+0xce>
        // Found one.
        pid = p->pid;
801048e9:	8b 45 f4             	mov    -0xc(%ebp),%eax
801048ec:	8b 40 10             	mov    0x10(%eax),%eax
801048ef:	89 45 e8             	mov    %eax,-0x18(%ebp)
        kfree(p->kstack);
801048f2:	8b 45 f4             	mov    -0xc(%ebp),%eax
801048f5:	8b 40 08             	mov    0x8(%eax),%eax
801048f8:	83 ec 0c             	sub    $0xc,%esp
801048fb:	50                   	push   %eax
801048fc:	e8 f7 e2 ff ff       	call   80102bf8 <kfree>
80104901:	83 c4 10             	add    $0x10,%esp
        p->kstack = 0;
80104904:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104907:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
        freevm(p->pgdir);
8010490e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104911:	8b 40 04             	mov    0x4(%eax),%eax
80104914:	83 ec 0c             	sub    $0xc,%esp
80104917:	50                   	push   %eax
80104918:	e8 63 38 00 00       	call   80108180 <freevm>
8010491d:	83 c4 10             	add    $0x10,%esp
        p->pid = 0;
80104920:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104923:	c7 40 10 00 00 00 00 	movl   $0x0,0x10(%eax)
        p->parent = 0;
8010492a:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010492d:	c7 40 14 00 00 00 00 	movl   $0x0,0x14(%eax)
        p->name[0] = 0;
80104934:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104937:	c6 40 6c 00          	movb   $0x0,0x6c(%eax)
        p->killed = 0;
8010493b:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010493e:	c7 40 24 00 00 00 00 	movl   $0x0,0x24(%eax)
        p->state = UNUSED;
80104945:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104948:	c7 40 0c 00 00 00 00 	movl   $0x0,0xc(%eax)
        release(&ptable.lock);
8010494f:	83 ec 0c             	sub    $0xc,%esp
80104952:	68 80 2d 11 80       	push   $0x80112d80
80104957:	e8 fb 06 00 00       	call   80105057 <release>
8010495c:	83 c4 10             	add    $0x10,%esp
        return pid;
8010495f:	8b 45 e8             	mov    -0x18(%ebp),%eax
80104962:	eb 51                	jmp    801049b5 <wait+0x11e>
        continue;
80104964:	90                   	nop
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104965:	83 45 f4 7c          	addl   $0x7c,-0xc(%ebp)
80104969:	81 7d f4 b4 4c 11 80 	cmpl   $0x80114cb4,-0xc(%ebp)
80104970:	0f 82 52 ff ff ff    	jb     801048c8 <wait+0x31>
      }
    }

    // No point waiting if we don't have any children.
    if(!havekids || curproc->killed){
80104976:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
8010497a:	74 0a                	je     80104986 <wait+0xef>
8010497c:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010497f:	8b 40 24             	mov    0x24(%eax),%eax
80104982:	85 c0                	test   %eax,%eax
80104984:	74 17                	je     8010499d <wait+0x106>
      release(&ptable.lock);
80104986:	83 ec 0c             	sub    $0xc,%esp
80104989:	68 80 2d 11 80       	push   $0x80112d80
8010498e:	e8 c4 06 00 00       	call   80105057 <release>
80104993:	83 c4 10             	add    $0x10,%esp
      return -1;
80104996:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010499b:	eb 18                	jmp    801049b5 <wait+0x11e>
    }

    // Wait for children to exit.  (See wakeup1 call in proc_exit.)
    sleep(curproc, &ptable.lock);  //DOC: wait-sleep
8010499d:	83 ec 08             	sub    $0x8,%esp
801049a0:	68 80 2d 11 80       	push   $0x80112d80
801049a5:	ff 75 ec             	push   -0x14(%ebp)
801049a8:	e8 fb 01 00 00       	call   80104ba8 <sleep>
801049ad:	83 c4 10             	add    $0x10,%esp
    havekids = 0;
801049b0:	e9 00 ff ff ff       	jmp    801048b5 <wait+0x1e>
  }
}
801049b5:	c9                   	leave
801049b6:	c3                   	ret

801049b7 <scheduler>:
//  - swtch to start running that process
//  - eventually that process transfers control
//      via swtch back to the scheduler.
void
scheduler(void)
{
801049b7:	55                   	push   %ebp
801049b8:	89 e5                	mov    %esp,%ebp
801049ba:	83 ec 18             	sub    $0x18,%esp
  struct proc *p;
  struct cpu *c = mycpu();
801049bd:	e8 4b f8 ff ff       	call   8010420d <mycpu>
801049c2:	89 45 f0             	mov    %eax,-0x10(%ebp)
  c->proc = 0;
801049c5:	8b 45 f0             	mov    -0x10(%ebp),%eax
801049c8:	c7 80 ac 00 00 00 00 	movl   $0x0,0xac(%eax)
801049cf:	00 00 00 
  
  for(;;){
    // Enable interrupts on this processor.
    sti();
801049d2:	e8 f6 f7 ff ff       	call   801041cd <sti>

    // Loop over process table looking for process to run.
    acquire(&ptable.lock);
801049d7:	83 ec 0c             	sub    $0xc,%esp
801049da:	68 80 2d 11 80       	push   $0x80112d80
801049df:	e8 05 06 00 00       	call   80104fe9 <acquire>
801049e4:	83 c4 10             	add    $0x10,%esp
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801049e7:	c7 45 f4 b4 2d 11 80 	movl   $0x80112db4,-0xc(%ebp)
801049ee:	eb 61                	jmp    80104a51 <scheduler+0x9a>
      if(p->state != RUNNABLE)
801049f0:	8b 45 f4             	mov    -0xc(%ebp),%eax
801049f3:	8b 40 0c             	mov    0xc(%eax),%eax
801049f6:	83 f8 03             	cmp    $0x3,%eax
801049f9:	75 51                	jne    80104a4c <scheduler+0x95>
        continue;

      // Switch to chosen process.  It is the process's job
      // to release ptable.lock and then reacquire it
      // before jumping back to us.
      c->proc = p;
801049fb:	8b 45 f0             	mov    -0x10(%ebp),%eax
801049fe:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104a01:	89 90 ac 00 00 00    	mov    %edx,0xac(%eax)
      switchuvm(p);
80104a07:	83 ec 0c             	sub    $0xc,%esp
80104a0a:	ff 75 f4             	push   -0xc(%ebp)
80104a0d:	e8 c9 32 00 00       	call   80107cdb <switchuvm>
80104a12:	83 c4 10             	add    $0x10,%esp
      p->state = RUNNING;
80104a15:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104a18:	c7 40 0c 04 00 00 00 	movl   $0x4,0xc(%eax)

      swtch(&(c->scheduler), p->context);
80104a1f:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104a22:	8b 40 1c             	mov    0x1c(%eax),%eax
80104a25:	8b 55 f0             	mov    -0x10(%ebp),%edx
80104a28:	83 c2 04             	add    $0x4,%edx
80104a2b:	83 ec 08             	sub    $0x8,%esp
80104a2e:	50                   	push   %eax
80104a2f:	52                   	push   %edx
80104a30:	e8 af 0a 00 00       	call   801054e4 <swtch>
80104a35:	83 c4 10             	add    $0x10,%esp
      switchkvm();
80104a38:	e8 85 32 00 00       	call   80107cc2 <switchkvm>

      // Process is done running for now.
      // It should have changed its p->state before coming back.
      c->proc = 0;
80104a3d:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104a40:	c7 80 ac 00 00 00 00 	movl   $0x0,0xac(%eax)
80104a47:	00 00 00 
80104a4a:	eb 01                	jmp    80104a4d <scheduler+0x96>
        continue;
80104a4c:	90                   	nop
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104a4d:	83 45 f4 7c          	addl   $0x7c,-0xc(%ebp)
80104a51:	81 7d f4 b4 4c 11 80 	cmpl   $0x80114cb4,-0xc(%ebp)
80104a58:	72 96                	jb     801049f0 <scheduler+0x39>
    }
    release(&ptable.lock);
80104a5a:	83 ec 0c             	sub    $0xc,%esp
80104a5d:	68 80 2d 11 80       	push   $0x80112d80
80104a62:	e8 f0 05 00 00       	call   80105057 <release>
80104a67:	83 c4 10             	add    $0x10,%esp
    sti();
80104a6a:	e9 63 ff ff ff       	jmp    801049d2 <scheduler+0x1b>

80104a6f <sched>:
// be proc->intena and proc->ncli, but that would
// break in the few places where a lock is held but
// there's no process.
void
sched(void)
{
80104a6f:	55                   	push   %ebp
80104a70:	89 e5                	mov    %esp,%ebp
80104a72:	83 ec 18             	sub    $0x18,%esp
  int intena;
  struct proc *p = myproc();
80104a75:	e8 0b f8 ff ff       	call   80104285 <myproc>
80104a7a:	89 45 f4             	mov    %eax,-0xc(%ebp)

  if(!holding(&ptable.lock))
80104a7d:	83 ec 0c             	sub    $0xc,%esp
80104a80:	68 80 2d 11 80       	push   $0x80112d80
80104a85:	e8 9a 06 00 00       	call   80105124 <holding>
80104a8a:	83 c4 10             	add    $0x10,%esp
80104a8d:	85 c0                	test   %eax,%eax
80104a8f:	75 0d                	jne    80104a9e <sched+0x2f>
    panic("sched ptable.lock");
80104a91:	83 ec 0c             	sub    $0xc,%esp
80104a94:	68 05 88 10 80       	push   $0x80108805
80104a99:	e8 15 bb ff ff       	call   801005b3 <panic>
  if(mycpu()->ncli != 1)
80104a9e:	e8 6a f7 ff ff       	call   8010420d <mycpu>
80104aa3:	8b 80 a4 00 00 00    	mov    0xa4(%eax),%eax
80104aa9:	83 f8 01             	cmp    $0x1,%eax
80104aac:	74 0d                	je     80104abb <sched+0x4c>
    panic("sched locks");
80104aae:	83 ec 0c             	sub    $0xc,%esp
80104ab1:	68 17 88 10 80       	push   $0x80108817
80104ab6:	e8 f8 ba ff ff       	call   801005b3 <panic>
  if(p->state == RUNNING)
80104abb:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104abe:	8b 40 0c             	mov    0xc(%eax),%eax
80104ac1:	83 f8 04             	cmp    $0x4,%eax
80104ac4:	75 0d                	jne    80104ad3 <sched+0x64>
    panic("sched running");
80104ac6:	83 ec 0c             	sub    $0xc,%esp
80104ac9:	68 23 88 10 80       	push   $0x80108823
80104ace:	e8 e0 ba ff ff       	call   801005b3 <panic>
  if(readeflags()&FL_IF)
80104ad3:	e8 e5 f6 ff ff       	call   801041bd <readeflags>
80104ad8:	25 00 02 00 00       	and    $0x200,%eax
80104add:	85 c0                	test   %eax,%eax
80104adf:	74 0d                	je     80104aee <sched+0x7f>
    panic("sched interruptible");
80104ae1:	83 ec 0c             	sub    $0xc,%esp
80104ae4:	68 31 88 10 80       	push   $0x80108831
80104ae9:	e8 c5 ba ff ff       	call   801005b3 <panic>
  intena = mycpu()->intena;
80104aee:	e8 1a f7 ff ff       	call   8010420d <mycpu>
80104af3:	8b 80 a8 00 00 00    	mov    0xa8(%eax),%eax
80104af9:	89 45 f0             	mov    %eax,-0x10(%ebp)
  swtch(&p->context, mycpu()->scheduler);
80104afc:	e8 0c f7 ff ff       	call   8010420d <mycpu>
80104b01:	8b 40 04             	mov    0x4(%eax),%eax
80104b04:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104b07:	83 c2 1c             	add    $0x1c,%edx
80104b0a:	83 ec 08             	sub    $0x8,%esp
80104b0d:	50                   	push   %eax
80104b0e:	52                   	push   %edx
80104b0f:	e8 d0 09 00 00       	call   801054e4 <swtch>
80104b14:	83 c4 10             	add    $0x10,%esp
  mycpu()->intena = intena;
80104b17:	e8 f1 f6 ff ff       	call   8010420d <mycpu>
80104b1c:	8b 55 f0             	mov    -0x10(%ebp),%edx
80104b1f:	89 90 a8 00 00 00    	mov    %edx,0xa8(%eax)
}
80104b25:	90                   	nop
80104b26:	c9                   	leave
80104b27:	c3                   	ret

80104b28 <yield>:

// Give up the CPU for one scheduling round.
void
yield(void)
{
80104b28:	55                   	push   %ebp
80104b29:	89 e5                	mov    %esp,%ebp
80104b2b:	83 ec 08             	sub    $0x8,%esp
  acquire(&ptable.lock);  //DOC: yieldlock
80104b2e:	83 ec 0c             	sub    $0xc,%esp
80104b31:	68 80 2d 11 80       	push   $0x80112d80
80104b36:	e8 ae 04 00 00       	call   80104fe9 <acquire>
80104b3b:	83 c4 10             	add    $0x10,%esp
  myproc()->state = RUNNABLE;
80104b3e:	e8 42 f7 ff ff       	call   80104285 <myproc>
80104b43:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  sched();
80104b4a:	e8 20 ff ff ff       	call   80104a6f <sched>
  release(&ptable.lock);
80104b4f:	83 ec 0c             	sub    $0xc,%esp
80104b52:	68 80 2d 11 80       	push   $0x80112d80
80104b57:	e8 fb 04 00 00       	call   80105057 <release>
80104b5c:	83 c4 10             	add    $0x10,%esp
}
80104b5f:	90                   	nop
80104b60:	c9                   	leave
80104b61:	c3                   	ret

80104b62 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch here.  "Return" to user space.
void
forkret(void)
{
80104b62:	55                   	push   %ebp
80104b63:	89 e5                	mov    %esp,%ebp
80104b65:	83 ec 08             	sub    $0x8,%esp
  static int first = 1;
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);
80104b68:	83 ec 0c             	sub    $0xc,%esp
80104b6b:	68 80 2d 11 80       	push   $0x80112d80
80104b70:	e8 e2 04 00 00       	call   80105057 <release>
80104b75:	83 c4 10             	add    $0x10,%esp

  if (first) {
80104b78:	a1 04 b0 10 80       	mov    0x8010b004,%eax
80104b7d:	85 c0                	test   %eax,%eax
80104b7f:	74 24                	je     80104ba5 <forkret+0x43>
    // Some initialization functions must be run in the context
    // of a regular process (e.g., they call sleep), and thus cannot
    // be run from main().
    first = 0;
80104b81:	c7 05 04 b0 10 80 00 	movl   $0x0,0x8010b004
80104b88:	00 00 00 
    iinit(ROOTDEV);
80104b8b:	83 ec 0c             	sub    $0xc,%esp
80104b8e:	6a 01                	push   $0x1
80104b90:	e8 10 cb ff ff       	call   801016a5 <iinit>
80104b95:	83 c4 10             	add    $0x10,%esp
    initlog(ROOTDEV);
80104b98:	83 ec 0c             	sub    $0xc,%esp
80104b9b:	6a 01                	push   $0x1
80104b9d:	e8 61 e7 ff ff       	call   80103303 <initlog>
80104ba2:	83 c4 10             	add    $0x10,%esp
  }

  // Return to "caller", actually trapret (see allocproc).
}
80104ba5:	90                   	nop
80104ba6:	c9                   	leave
80104ba7:	c3                   	ret

80104ba8 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
80104ba8:	55                   	push   %ebp
80104ba9:	89 e5                	mov    %esp,%ebp
80104bab:	83 ec 18             	sub    $0x18,%esp
  struct proc *p = myproc();
80104bae:	e8 d2 f6 ff ff       	call   80104285 <myproc>
80104bb3:	89 45 f4             	mov    %eax,-0xc(%ebp)
  
  if(p == 0)
80104bb6:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80104bba:	75 0d                	jne    80104bc9 <sleep+0x21>
    panic("sleep");
80104bbc:	83 ec 0c             	sub    $0xc,%esp
80104bbf:	68 45 88 10 80       	push   $0x80108845
80104bc4:	e8 ea b9 ff ff       	call   801005b3 <panic>

  if(lk == 0)
80104bc9:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
80104bcd:	75 0d                	jne    80104bdc <sleep+0x34>
    panic("sleep without lk");
80104bcf:	83 ec 0c             	sub    $0xc,%esp
80104bd2:	68 4b 88 10 80       	push   $0x8010884b
80104bd7:	e8 d7 b9 ff ff       	call   801005b3 <panic>
  // change p->state and then call sched.
  // Once we hold ptable.lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup runs with ptable.lock locked),
  // so it's okay to release lk.
  if(lk != &ptable.lock){  //DOC: sleeplock0
80104bdc:	81 7d 0c 80 2d 11 80 	cmpl   $0x80112d80,0xc(%ebp)
80104be3:	74 1e                	je     80104c03 <sleep+0x5b>
    acquire(&ptable.lock);  //DOC: sleeplock1
80104be5:	83 ec 0c             	sub    $0xc,%esp
80104be8:	68 80 2d 11 80       	push   $0x80112d80
80104bed:	e8 f7 03 00 00       	call   80104fe9 <acquire>
80104bf2:	83 c4 10             	add    $0x10,%esp
    release(lk);
80104bf5:	83 ec 0c             	sub    $0xc,%esp
80104bf8:	ff 75 0c             	push   0xc(%ebp)
80104bfb:	e8 57 04 00 00       	call   80105057 <release>
80104c00:	83 c4 10             	add    $0x10,%esp
  }
  // Go to sleep.
  p->chan = chan;
80104c03:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104c06:	8b 55 08             	mov    0x8(%ebp),%edx
80104c09:	89 50 20             	mov    %edx,0x20(%eax)
  p->state = SLEEPING;
80104c0c:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104c0f:	c7 40 0c 02 00 00 00 	movl   $0x2,0xc(%eax)

  sched();
80104c16:	e8 54 fe ff ff       	call   80104a6f <sched>

  // Tidy up.
  p->chan = 0;
80104c1b:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104c1e:	c7 40 20 00 00 00 00 	movl   $0x0,0x20(%eax)

  // Reacquire original lock.
  if(lk != &ptable.lock){  //DOC: sleeplock2
80104c25:	81 7d 0c 80 2d 11 80 	cmpl   $0x80112d80,0xc(%ebp)
80104c2c:	74 1e                	je     80104c4c <sleep+0xa4>
    release(&ptable.lock);
80104c2e:	83 ec 0c             	sub    $0xc,%esp
80104c31:	68 80 2d 11 80       	push   $0x80112d80
80104c36:	e8 1c 04 00 00       	call   80105057 <release>
80104c3b:	83 c4 10             	add    $0x10,%esp
    acquire(lk);
80104c3e:	83 ec 0c             	sub    $0xc,%esp
80104c41:	ff 75 0c             	push   0xc(%ebp)
80104c44:	e8 a0 03 00 00       	call   80104fe9 <acquire>
80104c49:	83 c4 10             	add    $0x10,%esp
  }
}
80104c4c:	90                   	nop
80104c4d:	c9                   	leave
80104c4e:	c3                   	ret

80104c4f <wakeup1>:
//PAGEBREAK!
// Wake up all processes sleeping on chan.
// The ptable lock must be held.
static void
wakeup1(void *chan)
{
80104c4f:	55                   	push   %ebp
80104c50:	89 e5                	mov    %esp,%ebp
80104c52:	83 ec 10             	sub    $0x10,%esp
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104c55:	c7 45 fc b4 2d 11 80 	movl   $0x80112db4,-0x4(%ebp)
80104c5c:	eb 24                	jmp    80104c82 <wakeup1+0x33>
    if(p->state == SLEEPING && p->chan == chan)
80104c5e:	8b 45 fc             	mov    -0x4(%ebp),%eax
80104c61:	8b 40 0c             	mov    0xc(%eax),%eax
80104c64:	83 f8 02             	cmp    $0x2,%eax
80104c67:	75 15                	jne    80104c7e <wakeup1+0x2f>
80104c69:	8b 45 fc             	mov    -0x4(%ebp),%eax
80104c6c:	8b 40 20             	mov    0x20(%eax),%eax
80104c6f:	39 45 08             	cmp    %eax,0x8(%ebp)
80104c72:	75 0a                	jne    80104c7e <wakeup1+0x2f>
      p->state = RUNNABLE;
80104c74:	8b 45 fc             	mov    -0x4(%ebp),%eax
80104c77:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104c7e:	83 45 fc 7c          	addl   $0x7c,-0x4(%ebp)
80104c82:	81 7d fc b4 4c 11 80 	cmpl   $0x80114cb4,-0x4(%ebp)
80104c89:	72 d3                	jb     80104c5e <wakeup1+0xf>
}
80104c8b:	90                   	nop
80104c8c:	90                   	nop
80104c8d:	c9                   	leave
80104c8e:	c3                   	ret

80104c8f <wakeup>:

// Wake up all processes sleeping on chan.
void
wakeup(void *chan)
{
80104c8f:	55                   	push   %ebp
80104c90:	89 e5                	mov    %esp,%ebp
80104c92:	83 ec 08             	sub    $0x8,%esp
  acquire(&ptable.lock);
80104c95:	83 ec 0c             	sub    $0xc,%esp
80104c98:	68 80 2d 11 80       	push   $0x80112d80
80104c9d:	e8 47 03 00 00       	call   80104fe9 <acquire>
80104ca2:	83 c4 10             	add    $0x10,%esp
  wakeup1(chan);
80104ca5:	83 ec 0c             	sub    $0xc,%esp
80104ca8:	ff 75 08             	push   0x8(%ebp)
80104cab:	e8 9f ff ff ff       	call   80104c4f <wakeup1>
80104cb0:	83 c4 10             	add    $0x10,%esp
  release(&ptable.lock);
80104cb3:	83 ec 0c             	sub    $0xc,%esp
80104cb6:	68 80 2d 11 80       	push   $0x80112d80
80104cbb:	e8 97 03 00 00       	call   80105057 <release>
80104cc0:	83 c4 10             	add    $0x10,%esp
}
80104cc3:	90                   	nop
80104cc4:	c9                   	leave
80104cc5:	c3                   	ret

80104cc6 <kill>:
// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int
kill(int pid)
{
80104cc6:	55                   	push   %ebp
80104cc7:	89 e5                	mov    %esp,%ebp
80104cc9:	83 ec 18             	sub    $0x18,%esp
  struct proc *p;

  acquire(&ptable.lock);
80104ccc:	83 ec 0c             	sub    $0xc,%esp
80104ccf:	68 80 2d 11 80       	push   $0x80112d80
80104cd4:	e8 10 03 00 00       	call   80104fe9 <acquire>
80104cd9:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104cdc:	c7 45 f4 b4 2d 11 80 	movl   $0x80112db4,-0xc(%ebp)
80104ce3:	eb 45                	jmp    80104d2a <kill+0x64>
    if(p->pid == pid){
80104ce5:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104ce8:	8b 40 10             	mov    0x10(%eax),%eax
80104ceb:	39 45 08             	cmp    %eax,0x8(%ebp)
80104cee:	75 36                	jne    80104d26 <kill+0x60>
      p->killed = 1;
80104cf0:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104cf3:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
      // Wake process from sleep if necessary.
      if(p->state == SLEEPING)
80104cfa:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104cfd:	8b 40 0c             	mov    0xc(%eax),%eax
80104d00:	83 f8 02             	cmp    $0x2,%eax
80104d03:	75 0a                	jne    80104d0f <kill+0x49>
        p->state = RUNNABLE;
80104d05:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104d08:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
      release(&ptable.lock);
80104d0f:	83 ec 0c             	sub    $0xc,%esp
80104d12:	68 80 2d 11 80       	push   $0x80112d80
80104d17:	e8 3b 03 00 00       	call   80105057 <release>
80104d1c:	83 c4 10             	add    $0x10,%esp
      return 0;
80104d1f:	b8 00 00 00 00       	mov    $0x0,%eax
80104d24:	eb 22                	jmp    80104d48 <kill+0x82>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104d26:	83 45 f4 7c          	addl   $0x7c,-0xc(%ebp)
80104d2a:	81 7d f4 b4 4c 11 80 	cmpl   $0x80114cb4,-0xc(%ebp)
80104d31:	72 b2                	jb     80104ce5 <kill+0x1f>
    }
  }
  release(&ptable.lock);
80104d33:	83 ec 0c             	sub    $0xc,%esp
80104d36:	68 80 2d 11 80       	push   $0x80112d80
80104d3b:	e8 17 03 00 00       	call   80105057 <release>
80104d40:	83 c4 10             	add    $0x10,%esp
  return -1;
80104d43:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104d48:	c9                   	leave
80104d49:	c3                   	ret

80104d4a <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
80104d4a:	55                   	push   %ebp
80104d4b:	89 e5                	mov    %esp,%ebp
80104d4d:	83 ec 48             	sub    $0x48,%esp
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104d50:	c7 45 f0 b4 2d 11 80 	movl   $0x80112db4,-0x10(%ebp)
80104d57:	e9 d7 00 00 00       	jmp    80104e33 <procdump+0xe9>
    if(p->state == UNUSED)
80104d5c:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104d5f:	8b 40 0c             	mov    0xc(%eax),%eax
80104d62:	85 c0                	test   %eax,%eax
80104d64:	0f 84 c4 00 00 00    	je     80104e2e <procdump+0xe4>
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
80104d6a:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104d6d:	8b 40 0c             	mov    0xc(%eax),%eax
80104d70:	83 f8 05             	cmp    $0x5,%eax
80104d73:	77 23                	ja     80104d98 <procdump+0x4e>
80104d75:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104d78:	8b 40 0c             	mov    0xc(%eax),%eax
80104d7b:	8b 04 85 08 b0 10 80 	mov    -0x7fef4ff8(,%eax,4),%eax
80104d82:	85 c0                	test   %eax,%eax
80104d84:	74 12                	je     80104d98 <procdump+0x4e>
      state = states[p->state];
80104d86:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104d89:	8b 40 0c             	mov    0xc(%eax),%eax
80104d8c:	8b 04 85 08 b0 10 80 	mov    -0x7fef4ff8(,%eax,4),%eax
80104d93:	89 45 ec             	mov    %eax,-0x14(%ebp)
80104d96:	eb 07                	jmp    80104d9f <procdump+0x55>
    else
      state = "???";
80104d98:	c7 45 ec 5c 88 10 80 	movl   $0x8010885c,-0x14(%ebp)
    cprintf("%d %s %s", p->pid, state, p->name);
80104d9f:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104da2:	8d 50 6c             	lea    0x6c(%eax),%edx
80104da5:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104da8:	8b 40 10             	mov    0x10(%eax),%eax
80104dab:	52                   	push   %edx
80104dac:	ff 75 ec             	push   -0x14(%ebp)
80104daf:	50                   	push   %eax
80104db0:	68 60 88 10 80       	push   $0x80108860
80104db5:	e8 44 b6 ff ff       	call   801003fe <cprintf>
80104dba:	83 c4 10             	add    $0x10,%esp
    if(p->state == SLEEPING){
80104dbd:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104dc0:	8b 40 0c             	mov    0xc(%eax),%eax
80104dc3:	83 f8 02             	cmp    $0x2,%eax
80104dc6:	75 54                	jne    80104e1c <procdump+0xd2>
      getcallerpcs((uint*)p->context->ebp+2, pc);
80104dc8:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104dcb:	8b 40 1c             	mov    0x1c(%eax),%eax
80104dce:	8b 40 0c             	mov    0xc(%eax),%eax
80104dd1:	83 c0 08             	add    $0x8,%eax
80104dd4:	89 c2                	mov    %eax,%edx
80104dd6:	83 ec 08             	sub    $0x8,%esp
80104dd9:	8d 45 c4             	lea    -0x3c(%ebp),%eax
80104ddc:	50                   	push   %eax
80104ddd:	52                   	push   %edx
80104dde:	e8 c6 02 00 00       	call   801050a9 <getcallerpcs>
80104de3:	83 c4 10             	add    $0x10,%esp
      for(i=0; i<10 && pc[i] != 0; i++)
80104de6:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80104ded:	eb 1c                	jmp    80104e0b <procdump+0xc1>
        cprintf(" %p", pc[i]);
80104def:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104df2:	8b 44 85 c4          	mov    -0x3c(%ebp,%eax,4),%eax
80104df6:	83 ec 08             	sub    $0x8,%esp
80104df9:	50                   	push   %eax
80104dfa:	68 69 88 10 80       	push   $0x80108869
80104dff:	e8 fa b5 ff ff       	call   801003fe <cprintf>
80104e04:	83 c4 10             	add    $0x10,%esp
      for(i=0; i<10 && pc[i] != 0; i++)
80104e07:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80104e0b:	83 7d f4 09          	cmpl   $0x9,-0xc(%ebp)
80104e0f:	7f 0b                	jg     80104e1c <procdump+0xd2>
80104e11:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104e14:	8b 44 85 c4          	mov    -0x3c(%ebp,%eax,4),%eax
80104e18:	85 c0                	test   %eax,%eax
80104e1a:	75 d3                	jne    80104def <procdump+0xa5>
    }
    cprintf("\n");
80104e1c:	83 ec 0c             	sub    $0xc,%esp
80104e1f:	68 6d 88 10 80       	push   $0x8010886d
80104e24:	e8 d5 b5 ff ff       	call   801003fe <cprintf>
80104e29:	83 c4 10             	add    $0x10,%esp
80104e2c:	eb 01                	jmp    80104e2f <procdump+0xe5>
      continue;
80104e2e:	90                   	nop
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104e2f:	83 45 f0 7c          	addl   $0x7c,-0x10(%ebp)
80104e33:	81 7d f0 b4 4c 11 80 	cmpl   $0x80114cb4,-0x10(%ebp)
80104e3a:	0f 82 1c ff ff ff    	jb     80104d5c <procdump+0x12>
  }
}
80104e40:	90                   	nop
80104e41:	90                   	nop
80104e42:	c9                   	leave
80104e43:	c3                   	ret

80104e44 <initsleeplock>:
#include "spinlock.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
80104e44:	55                   	push   %ebp
80104e45:	89 e5                	mov    %esp,%ebp
80104e47:	83 ec 08             	sub    $0x8,%esp
  initlock(&lk->lk, "sleep lock");
80104e4a:	8b 45 08             	mov    0x8(%ebp),%eax
80104e4d:	83 c0 04             	add    $0x4,%eax
80104e50:	83 ec 08             	sub    $0x8,%esp
80104e53:	68 99 88 10 80       	push   $0x80108899
80104e58:	50                   	push   %eax
80104e59:	e8 69 01 00 00       	call   80104fc7 <initlock>
80104e5e:	83 c4 10             	add    $0x10,%esp
  lk->name = name;
80104e61:	8b 45 08             	mov    0x8(%ebp),%eax
80104e64:	8b 55 0c             	mov    0xc(%ebp),%edx
80104e67:	89 50 38             	mov    %edx,0x38(%eax)
  lk->locked = 0;
80104e6a:	8b 45 08             	mov    0x8(%ebp),%eax
80104e6d:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  lk->pid = 0;
80104e73:	8b 45 08             	mov    0x8(%ebp),%eax
80104e76:	c7 40 3c 00 00 00 00 	movl   $0x0,0x3c(%eax)
}
80104e7d:	90                   	nop
80104e7e:	c9                   	leave
80104e7f:	c3                   	ret

80104e80 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
80104e80:	55                   	push   %ebp
80104e81:	89 e5                	mov    %esp,%ebp
80104e83:	83 ec 08             	sub    $0x8,%esp
  acquire(&lk->lk);
80104e86:	8b 45 08             	mov    0x8(%ebp),%eax
80104e89:	83 c0 04             	add    $0x4,%eax
80104e8c:	83 ec 0c             	sub    $0xc,%esp
80104e8f:	50                   	push   %eax
80104e90:	e8 54 01 00 00       	call   80104fe9 <acquire>
80104e95:	83 c4 10             	add    $0x10,%esp
  while (lk->locked) {
80104e98:	eb 15                	jmp    80104eaf <acquiresleep+0x2f>
    sleep(lk, &lk->lk);
80104e9a:	8b 45 08             	mov    0x8(%ebp),%eax
80104e9d:	83 c0 04             	add    $0x4,%eax
80104ea0:	83 ec 08             	sub    $0x8,%esp
80104ea3:	50                   	push   %eax
80104ea4:	ff 75 08             	push   0x8(%ebp)
80104ea7:	e8 fc fc ff ff       	call   80104ba8 <sleep>
80104eac:	83 c4 10             	add    $0x10,%esp
  while (lk->locked) {
80104eaf:	8b 45 08             	mov    0x8(%ebp),%eax
80104eb2:	8b 00                	mov    (%eax),%eax
80104eb4:	85 c0                	test   %eax,%eax
80104eb6:	75 e2                	jne    80104e9a <acquiresleep+0x1a>
  }
  lk->locked = 1;
80104eb8:	8b 45 08             	mov    0x8(%ebp),%eax
80104ebb:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  lk->pid = myproc()->pid;
80104ec1:	e8 bf f3 ff ff       	call   80104285 <myproc>
80104ec6:	8b 50 10             	mov    0x10(%eax),%edx
80104ec9:	8b 45 08             	mov    0x8(%ebp),%eax
80104ecc:	89 50 3c             	mov    %edx,0x3c(%eax)
  release(&lk->lk);
80104ecf:	8b 45 08             	mov    0x8(%ebp),%eax
80104ed2:	83 c0 04             	add    $0x4,%eax
80104ed5:	83 ec 0c             	sub    $0xc,%esp
80104ed8:	50                   	push   %eax
80104ed9:	e8 79 01 00 00       	call   80105057 <release>
80104ede:	83 c4 10             	add    $0x10,%esp
}
80104ee1:	90                   	nop
80104ee2:	c9                   	leave
80104ee3:	c3                   	ret

80104ee4 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
80104ee4:	55                   	push   %ebp
80104ee5:	89 e5                	mov    %esp,%ebp
80104ee7:	83 ec 08             	sub    $0x8,%esp
  acquire(&lk->lk);
80104eea:	8b 45 08             	mov    0x8(%ebp),%eax
80104eed:	83 c0 04             	add    $0x4,%eax
80104ef0:	83 ec 0c             	sub    $0xc,%esp
80104ef3:	50                   	push   %eax
80104ef4:	e8 f0 00 00 00       	call   80104fe9 <acquire>
80104ef9:	83 c4 10             	add    $0x10,%esp
  lk->locked = 0;
80104efc:	8b 45 08             	mov    0x8(%ebp),%eax
80104eff:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  lk->pid = 0;
80104f05:	8b 45 08             	mov    0x8(%ebp),%eax
80104f08:	c7 40 3c 00 00 00 00 	movl   $0x0,0x3c(%eax)
  wakeup(lk);
80104f0f:	83 ec 0c             	sub    $0xc,%esp
80104f12:	ff 75 08             	push   0x8(%ebp)
80104f15:	e8 75 fd ff ff       	call   80104c8f <wakeup>
80104f1a:	83 c4 10             	add    $0x10,%esp
  release(&lk->lk);
80104f1d:	8b 45 08             	mov    0x8(%ebp),%eax
80104f20:	83 c0 04             	add    $0x4,%eax
80104f23:	83 ec 0c             	sub    $0xc,%esp
80104f26:	50                   	push   %eax
80104f27:	e8 2b 01 00 00       	call   80105057 <release>
80104f2c:	83 c4 10             	add    $0x10,%esp
}
80104f2f:	90                   	nop
80104f30:	c9                   	leave
80104f31:	c3                   	ret

80104f32 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
80104f32:	55                   	push   %ebp
80104f33:	89 e5                	mov    %esp,%ebp
80104f35:	53                   	push   %ebx
80104f36:	83 ec 14             	sub    $0x14,%esp
  int r;
  
  acquire(&lk->lk);
80104f39:	8b 45 08             	mov    0x8(%ebp),%eax
80104f3c:	83 c0 04             	add    $0x4,%eax
80104f3f:	83 ec 0c             	sub    $0xc,%esp
80104f42:	50                   	push   %eax
80104f43:	e8 a1 00 00 00       	call   80104fe9 <acquire>
80104f48:	83 c4 10             	add    $0x10,%esp
  r = lk->locked && (lk->pid == myproc()->pid);
80104f4b:	8b 45 08             	mov    0x8(%ebp),%eax
80104f4e:	8b 00                	mov    (%eax),%eax
80104f50:	85 c0                	test   %eax,%eax
80104f52:	74 19                	je     80104f6d <holdingsleep+0x3b>
80104f54:	8b 45 08             	mov    0x8(%ebp),%eax
80104f57:	8b 58 3c             	mov    0x3c(%eax),%ebx
80104f5a:	e8 26 f3 ff ff       	call   80104285 <myproc>
80104f5f:	8b 40 10             	mov    0x10(%eax),%eax
80104f62:	39 c3                	cmp    %eax,%ebx
80104f64:	75 07                	jne    80104f6d <holdingsleep+0x3b>
80104f66:	b8 01 00 00 00       	mov    $0x1,%eax
80104f6b:	eb 05                	jmp    80104f72 <holdingsleep+0x40>
80104f6d:	b8 00 00 00 00       	mov    $0x0,%eax
80104f72:	89 45 f4             	mov    %eax,-0xc(%ebp)
  release(&lk->lk);
80104f75:	8b 45 08             	mov    0x8(%ebp),%eax
80104f78:	83 c0 04             	add    $0x4,%eax
80104f7b:	83 ec 0c             	sub    $0xc,%esp
80104f7e:	50                   	push   %eax
80104f7f:	e8 d3 00 00 00       	call   80105057 <release>
80104f84:	83 c4 10             	add    $0x10,%esp
  return r;
80104f87:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
80104f8a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104f8d:	c9                   	leave
80104f8e:	c3                   	ret

80104f8f <readeflags>:
{
80104f8f:	55                   	push   %ebp
80104f90:	89 e5                	mov    %esp,%ebp
80104f92:	83 ec 10             	sub    $0x10,%esp
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80104f95:	9c                   	pushf
80104f96:	58                   	pop    %eax
80104f97:	89 45 fc             	mov    %eax,-0x4(%ebp)
  return eflags;
80104f9a:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
80104f9d:	c9                   	leave
80104f9e:	c3                   	ret

80104f9f <cli>:
{
80104f9f:	55                   	push   %ebp
80104fa0:	89 e5                	mov    %esp,%ebp
  asm volatile("cli");
80104fa2:	fa                   	cli
}
80104fa3:	90                   	nop
80104fa4:	5d                   	pop    %ebp
80104fa5:	c3                   	ret

80104fa6 <sti>:
{
80104fa6:	55                   	push   %ebp
80104fa7:	89 e5                	mov    %esp,%ebp
  asm volatile("sti");
80104fa9:	fb                   	sti
}
80104faa:	90                   	nop
80104fab:	5d                   	pop    %ebp
80104fac:	c3                   	ret

80104fad <xchg>:
{
80104fad:	55                   	push   %ebp
80104fae:	89 e5                	mov    %esp,%ebp
80104fb0:	83 ec 10             	sub    $0x10,%esp
  asm volatile("lock; xchgl %0, %1" :
80104fb3:	8b 55 08             	mov    0x8(%ebp),%edx
80104fb6:	8b 45 0c             	mov    0xc(%ebp),%eax
80104fb9:	8b 4d 08             	mov    0x8(%ebp),%ecx
80104fbc:	f0 87 02             	lock xchg %eax,(%edx)
80104fbf:	89 45 fc             	mov    %eax,-0x4(%ebp)
  return result;
80104fc2:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
80104fc5:	c9                   	leave
80104fc6:	c3                   	ret

80104fc7 <initlock>:
#include "proc.h"
#include "spinlock.h"

void
initlock(struct spinlock *lk, char *name)
{
80104fc7:	55                   	push   %ebp
80104fc8:	89 e5                	mov    %esp,%ebp
  lk->name = name;
80104fca:	8b 45 08             	mov    0x8(%ebp),%eax
80104fcd:	8b 55 0c             	mov    0xc(%ebp),%edx
80104fd0:	89 50 04             	mov    %edx,0x4(%eax)
  lk->locked = 0;
80104fd3:	8b 45 08             	mov    0x8(%ebp),%eax
80104fd6:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  lk->cpu = 0;
80104fdc:	8b 45 08             	mov    0x8(%ebp),%eax
80104fdf:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
}
80104fe6:	90                   	nop
80104fe7:	5d                   	pop    %ebp
80104fe8:	c3                   	ret

80104fe9 <acquire>:
// Loops (spins) until the lock is acquired.
// Holding a lock for a long time may cause
// other CPUs to waste time spinning to acquire it.
void
acquire(struct spinlock *lk)
{
80104fe9:	55                   	push   %ebp
80104fea:	89 e5                	mov    %esp,%ebp
80104fec:	53                   	push   %ebx
80104fed:	83 ec 04             	sub    $0x4,%esp
  pushcli(); // disable interrupts to avoid deadlock.
80104ff0:	e8 6f 01 00 00       	call   80105164 <pushcli>
  if(holding(lk))
80104ff5:	8b 45 08             	mov    0x8(%ebp),%eax
80104ff8:	83 ec 0c             	sub    $0xc,%esp
80104ffb:	50                   	push   %eax
80104ffc:	e8 23 01 00 00       	call   80105124 <holding>
80105001:	83 c4 10             	add    $0x10,%esp
80105004:	85 c0                	test   %eax,%eax
80105006:	74 0d                	je     80105015 <acquire+0x2c>
    panic("acquire");
80105008:	83 ec 0c             	sub    $0xc,%esp
8010500b:	68 a4 88 10 80       	push   $0x801088a4
80105010:	e8 9e b5 ff ff       	call   801005b3 <panic>

  // The xchg is atomic.
  while(xchg(&lk->locked, 1) != 0)
80105015:	90                   	nop
80105016:	8b 45 08             	mov    0x8(%ebp),%eax
80105019:	83 ec 08             	sub    $0x8,%esp
8010501c:	6a 01                	push   $0x1
8010501e:	50                   	push   %eax
8010501f:	e8 89 ff ff ff       	call   80104fad <xchg>
80105024:	83 c4 10             	add    $0x10,%esp
80105027:	85 c0                	test   %eax,%eax
80105029:	75 eb                	jne    80105016 <acquire+0x2d>
    ;

  // Tell the C compiler and the processor to not move loads or stores
  // past this point, to ensure that the critical section's memory
  // references happen after the lock is acquired.
  __sync_synchronize();
8010502b:	f0 83 0c 24 00       	lock orl $0x0,(%esp)

  // Record info about lock acquisition for debugging.
  lk->cpu = mycpu();
80105030:	8b 5d 08             	mov    0x8(%ebp),%ebx
80105033:	e8 d5 f1 ff ff       	call   8010420d <mycpu>
80105038:	89 43 08             	mov    %eax,0x8(%ebx)
  getcallerpcs(&lk, lk->pcs);
8010503b:	8b 45 08             	mov    0x8(%ebp),%eax
8010503e:	83 c0 0c             	add    $0xc,%eax
80105041:	83 ec 08             	sub    $0x8,%esp
80105044:	50                   	push   %eax
80105045:	8d 45 08             	lea    0x8(%ebp),%eax
80105048:	50                   	push   %eax
80105049:	e8 5b 00 00 00       	call   801050a9 <getcallerpcs>
8010504e:	83 c4 10             	add    $0x10,%esp
}
80105051:	90                   	nop
80105052:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105055:	c9                   	leave
80105056:	c3                   	ret

80105057 <release>:

// Release the lock.
void
release(struct spinlock *lk)
{
80105057:	55                   	push   %ebp
80105058:	89 e5                	mov    %esp,%ebp
8010505a:	83 ec 08             	sub    $0x8,%esp
  if(!holding(lk))
8010505d:	83 ec 0c             	sub    $0xc,%esp
80105060:	ff 75 08             	push   0x8(%ebp)
80105063:	e8 bc 00 00 00       	call   80105124 <holding>
80105068:	83 c4 10             	add    $0x10,%esp
8010506b:	85 c0                	test   %eax,%eax
8010506d:	75 0d                	jne    8010507c <release+0x25>
    panic("release");
8010506f:	83 ec 0c             	sub    $0xc,%esp
80105072:	68 ac 88 10 80       	push   $0x801088ac
80105077:	e8 37 b5 ff ff       	call   801005b3 <panic>

  lk->pcs[0] = 0;
8010507c:	8b 45 08             	mov    0x8(%ebp),%eax
8010507f:	c7 40 0c 00 00 00 00 	movl   $0x0,0xc(%eax)
  lk->cpu = 0;
80105086:	8b 45 08             	mov    0x8(%ebp),%eax
80105089:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
  // Tell the C compiler and the processor to not move loads or stores
  // past this point, to ensure that all the stores in the critical
  // section are visible to other cores before the lock is released.
  // Both the C compiler and the hardware may re-order loads and
  // stores; __sync_synchronize() tells them both not to.
  __sync_synchronize();
80105090:	f0 83 0c 24 00       	lock orl $0x0,(%esp)

  // Release the lock, equivalent to lk->locked = 0.
  // This code can't use a C assignment, since it might
  // not be atomic. A real OS would use C atomics here.
  asm volatile("movl $0, %0" : "+m" (lk->locked) : );
80105095:	8b 45 08             	mov    0x8(%ebp),%eax
80105098:	8b 55 08             	mov    0x8(%ebp),%edx
8010509b:	c7 00 00 00 00 00    	movl   $0x0,(%eax)

  popcli();
801050a1:	e8 0b 01 00 00       	call   801051b1 <popcli>
}
801050a6:	90                   	nop
801050a7:	c9                   	leave
801050a8:	c3                   	ret

801050a9 <getcallerpcs>:

// Record the current call stack in pcs[] by following the %ebp chain.
void
getcallerpcs(void *v, uint pcs[])
{
801050a9:	55                   	push   %ebp
801050aa:	89 e5                	mov    %esp,%ebp
801050ac:	83 ec 10             	sub    $0x10,%esp
  uint *ebp;
  int i;

  ebp = (uint*)v - 2;
801050af:	8b 45 08             	mov    0x8(%ebp),%eax
801050b2:	83 e8 08             	sub    $0x8,%eax
801050b5:	89 45 fc             	mov    %eax,-0x4(%ebp)
  for(i = 0; i < 10; i++){
801050b8:	c7 45 f8 00 00 00 00 	movl   $0x0,-0x8(%ebp)
801050bf:	eb 38                	jmp    801050f9 <getcallerpcs+0x50>
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
801050c1:	83 7d fc 00          	cmpl   $0x0,-0x4(%ebp)
801050c5:	74 53                	je     8010511a <getcallerpcs+0x71>
801050c7:	81 7d fc ff ff ff 7f 	cmpl   $0x7fffffff,-0x4(%ebp)
801050ce:	76 4a                	jbe    8010511a <getcallerpcs+0x71>
801050d0:	83 7d fc ff          	cmpl   $0xffffffff,-0x4(%ebp)
801050d4:	74 44                	je     8010511a <getcallerpcs+0x71>
      break;
    pcs[i] = ebp[1];     // saved %eip
801050d6:	8b 45 f8             	mov    -0x8(%ebp),%eax
801050d9:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
801050e0:	8b 45 0c             	mov    0xc(%ebp),%eax
801050e3:	01 c2                	add    %eax,%edx
801050e5:	8b 45 fc             	mov    -0x4(%ebp),%eax
801050e8:	8b 40 04             	mov    0x4(%eax),%eax
801050eb:	89 02                	mov    %eax,(%edx)
    ebp = (uint*)ebp[0]; // saved %ebp
801050ed:	8b 45 fc             	mov    -0x4(%ebp),%eax
801050f0:	8b 00                	mov    (%eax),%eax
801050f2:	89 45 fc             	mov    %eax,-0x4(%ebp)
  for(i = 0; i < 10; i++){
801050f5:	83 45 f8 01          	addl   $0x1,-0x8(%ebp)
801050f9:	83 7d f8 09          	cmpl   $0x9,-0x8(%ebp)
801050fd:	7e c2                	jle    801050c1 <getcallerpcs+0x18>
  }
  for(; i < 10; i++)
801050ff:	eb 19                	jmp    8010511a <getcallerpcs+0x71>
    pcs[i] = 0;
80105101:	8b 45 f8             	mov    -0x8(%ebp),%eax
80105104:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
8010510b:	8b 45 0c             	mov    0xc(%ebp),%eax
8010510e:	01 d0                	add    %edx,%eax
80105110:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
80105116:	83 45 f8 01          	addl   $0x1,-0x8(%ebp)
8010511a:	83 7d f8 09          	cmpl   $0x9,-0x8(%ebp)
8010511e:	7e e1                	jle    80105101 <getcallerpcs+0x58>
}
80105120:	90                   	nop
80105121:	90                   	nop
80105122:	c9                   	leave
80105123:	c3                   	ret

80105124 <holding>:

// Check whether this cpu is holding the lock.
int
holding(struct spinlock *lock)
{
80105124:	55                   	push   %ebp
80105125:	89 e5                	mov    %esp,%ebp
80105127:	53                   	push   %ebx
80105128:	83 ec 14             	sub    $0x14,%esp
  int r;
  pushcli();
8010512b:	e8 34 00 00 00       	call   80105164 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
80105130:	8b 45 08             	mov    0x8(%ebp),%eax
80105133:	8b 00                	mov    (%eax),%eax
80105135:	85 c0                	test   %eax,%eax
80105137:	74 16                	je     8010514f <holding+0x2b>
80105139:	8b 45 08             	mov    0x8(%ebp),%eax
8010513c:	8b 58 08             	mov    0x8(%eax),%ebx
8010513f:	e8 c9 f0 ff ff       	call   8010420d <mycpu>
80105144:	39 c3                	cmp    %eax,%ebx
80105146:	75 07                	jne    8010514f <holding+0x2b>
80105148:	b8 01 00 00 00       	mov    $0x1,%eax
8010514d:	eb 05                	jmp    80105154 <holding+0x30>
8010514f:	b8 00 00 00 00       	mov    $0x0,%eax
80105154:	89 45 f4             	mov    %eax,-0xc(%ebp)
  popcli();
80105157:	e8 55 00 00 00       	call   801051b1 <popcli>
  return r;
8010515c:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
8010515f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105162:	c9                   	leave
80105163:	c3                   	ret

80105164 <pushcli>:
// it takes two popcli to undo two pushcli.  Also, if interrupts
// are off, then pushcli, popcli leaves them off.

void
pushcli(void)
{
80105164:	55                   	push   %ebp
80105165:	89 e5                	mov    %esp,%ebp
80105167:	83 ec 18             	sub    $0x18,%esp
  int eflags;

  eflags = readeflags();
8010516a:	e8 20 fe ff ff       	call   80104f8f <readeflags>
8010516f:	89 45 f4             	mov    %eax,-0xc(%ebp)
  cli();
80105172:	e8 28 fe ff ff       	call   80104f9f <cli>
  if(mycpu()->ncli == 0)
80105177:	e8 91 f0 ff ff       	call   8010420d <mycpu>
8010517c:	8b 80 a4 00 00 00    	mov    0xa4(%eax),%eax
80105182:	85 c0                	test   %eax,%eax
80105184:	75 14                	jne    8010519a <pushcli+0x36>
    mycpu()->intena = eflags & FL_IF;
80105186:	e8 82 f0 ff ff       	call   8010420d <mycpu>
8010518b:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010518e:	81 e2 00 02 00 00    	and    $0x200,%edx
80105194:	89 90 a8 00 00 00    	mov    %edx,0xa8(%eax)
  mycpu()->ncli += 1;
8010519a:	e8 6e f0 ff ff       	call   8010420d <mycpu>
8010519f:	8b 90 a4 00 00 00    	mov    0xa4(%eax),%edx
801051a5:	83 c2 01             	add    $0x1,%edx
801051a8:	89 90 a4 00 00 00    	mov    %edx,0xa4(%eax)
}
801051ae:	90                   	nop
801051af:	c9                   	leave
801051b0:	c3                   	ret

801051b1 <popcli>:

void
popcli(void)
{
801051b1:	55                   	push   %ebp
801051b2:	89 e5                	mov    %esp,%ebp
801051b4:	83 ec 08             	sub    $0x8,%esp
  if(readeflags()&FL_IF)
801051b7:	e8 d3 fd ff ff       	call   80104f8f <readeflags>
801051bc:	25 00 02 00 00       	and    $0x200,%eax
801051c1:	85 c0                	test   %eax,%eax
801051c3:	74 0d                	je     801051d2 <popcli+0x21>
    panic("popcli - interruptible");
801051c5:	83 ec 0c             	sub    $0xc,%esp
801051c8:	68 b4 88 10 80       	push   $0x801088b4
801051cd:	e8 e1 b3 ff ff       	call   801005b3 <panic>
  if(--mycpu()->ncli < 0)
801051d2:	e8 36 f0 ff ff       	call   8010420d <mycpu>
801051d7:	8b 90 a4 00 00 00    	mov    0xa4(%eax),%edx
801051dd:	83 ea 01             	sub    $0x1,%edx
801051e0:	89 90 a4 00 00 00    	mov    %edx,0xa4(%eax)
801051e6:	8b 80 a4 00 00 00    	mov    0xa4(%eax),%eax
801051ec:	85 c0                	test   %eax,%eax
801051ee:	79 0d                	jns    801051fd <popcli+0x4c>
    panic("popcli");
801051f0:	83 ec 0c             	sub    $0xc,%esp
801051f3:	68 cb 88 10 80       	push   $0x801088cb
801051f8:	e8 b6 b3 ff ff       	call   801005b3 <panic>
  if(mycpu()->ncli == 0 && mycpu()->intena)
801051fd:	e8 0b f0 ff ff       	call   8010420d <mycpu>
80105202:	8b 80 a4 00 00 00    	mov    0xa4(%eax),%eax
80105208:	85 c0                	test   %eax,%eax
8010520a:	75 14                	jne    80105220 <popcli+0x6f>
8010520c:	e8 fc ef ff ff       	call   8010420d <mycpu>
80105211:	8b 80 a8 00 00 00    	mov    0xa8(%eax),%eax
80105217:	85 c0                	test   %eax,%eax
80105219:	74 05                	je     80105220 <popcli+0x6f>
    sti();
8010521b:	e8 86 fd ff ff       	call   80104fa6 <sti>
}
80105220:	90                   	nop
80105221:	c9                   	leave
80105222:	c3                   	ret

80105223 <stosb>:
{
80105223:	55                   	push   %ebp
80105224:	89 e5                	mov    %esp,%ebp
80105226:	57                   	push   %edi
80105227:	53                   	push   %ebx
  asm volatile("cld; rep stosb" :
80105228:	8b 4d 08             	mov    0x8(%ebp),%ecx
8010522b:	8b 55 10             	mov    0x10(%ebp),%edx
8010522e:	8b 45 0c             	mov    0xc(%ebp),%eax
80105231:	89 cb                	mov    %ecx,%ebx
80105233:	89 df                	mov    %ebx,%edi
80105235:	89 d1                	mov    %edx,%ecx
80105237:	fc                   	cld
80105238:	f3 aa                	rep stos %al,%es:(%edi)
8010523a:	89 ca                	mov    %ecx,%edx
8010523c:	89 fb                	mov    %edi,%ebx
8010523e:	89 5d 08             	mov    %ebx,0x8(%ebp)
80105241:	89 55 10             	mov    %edx,0x10(%ebp)
}
80105244:	90                   	nop
80105245:	5b                   	pop    %ebx
80105246:	5f                   	pop    %edi
80105247:	5d                   	pop    %ebp
80105248:	c3                   	ret

80105249 <stosl>:
{
80105249:	55                   	push   %ebp
8010524a:	89 e5                	mov    %esp,%ebp
8010524c:	57                   	push   %edi
8010524d:	53                   	push   %ebx
  asm volatile("cld; rep stosl" :
8010524e:	8b 4d 08             	mov    0x8(%ebp),%ecx
80105251:	8b 55 10             	mov    0x10(%ebp),%edx
80105254:	8b 45 0c             	mov    0xc(%ebp),%eax
80105257:	89 cb                	mov    %ecx,%ebx
80105259:	89 df                	mov    %ebx,%edi
8010525b:	89 d1                	mov    %edx,%ecx
8010525d:	fc                   	cld
8010525e:	f3 ab                	rep stos %eax,%es:(%edi)
80105260:	89 ca                	mov    %ecx,%edx
80105262:	89 fb                	mov    %edi,%ebx
80105264:	89 5d 08             	mov    %ebx,0x8(%ebp)
80105267:	89 55 10             	mov    %edx,0x10(%ebp)
}
8010526a:	90                   	nop
8010526b:	5b                   	pop    %ebx
8010526c:	5f                   	pop    %edi
8010526d:	5d                   	pop    %ebp
8010526e:	c3                   	ret

8010526f <memset>:
#include "types.h"
#include "x86.h"

void*
memset(void *dst, int c, uint n)
{
8010526f:	55                   	push   %ebp
80105270:	89 e5                	mov    %esp,%ebp
  if ((int)dst%4 == 0 && n%4 == 0){
80105272:	8b 45 08             	mov    0x8(%ebp),%eax
80105275:	83 e0 03             	and    $0x3,%eax
80105278:	85 c0                	test   %eax,%eax
8010527a:	75 43                	jne    801052bf <memset+0x50>
8010527c:	8b 45 10             	mov    0x10(%ebp),%eax
8010527f:	83 e0 03             	and    $0x3,%eax
80105282:	85 c0                	test   %eax,%eax
80105284:	75 39                	jne    801052bf <memset+0x50>
    c &= 0xFF;
80105286:	81 65 0c ff 00 00 00 	andl   $0xff,0xc(%ebp)
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
8010528d:	8b 45 10             	mov    0x10(%ebp),%eax
80105290:	c1 e8 02             	shr    $0x2,%eax
80105293:	89 c1                	mov    %eax,%ecx
80105295:	8b 45 0c             	mov    0xc(%ebp),%eax
80105298:	c1 e0 18             	shl    $0x18,%eax
8010529b:	89 c2                	mov    %eax,%edx
8010529d:	8b 45 0c             	mov    0xc(%ebp),%eax
801052a0:	c1 e0 10             	shl    $0x10,%eax
801052a3:	09 c2                	or     %eax,%edx
801052a5:	8b 45 0c             	mov    0xc(%ebp),%eax
801052a8:	c1 e0 08             	shl    $0x8,%eax
801052ab:	09 d0                	or     %edx,%eax
801052ad:	0b 45 0c             	or     0xc(%ebp),%eax
801052b0:	51                   	push   %ecx
801052b1:	50                   	push   %eax
801052b2:	ff 75 08             	push   0x8(%ebp)
801052b5:	e8 8f ff ff ff       	call   80105249 <stosl>
801052ba:	83 c4 0c             	add    $0xc,%esp
801052bd:	eb 12                	jmp    801052d1 <memset+0x62>
  } else
    stosb(dst, c, n);
801052bf:	8b 45 10             	mov    0x10(%ebp),%eax
801052c2:	50                   	push   %eax
801052c3:	ff 75 0c             	push   0xc(%ebp)
801052c6:	ff 75 08             	push   0x8(%ebp)
801052c9:	e8 55 ff ff ff       	call   80105223 <stosb>
801052ce:	83 c4 0c             	add    $0xc,%esp
  return dst;
801052d1:	8b 45 08             	mov    0x8(%ebp),%eax
}
801052d4:	c9                   	leave
801052d5:	c3                   	ret

801052d6 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
801052d6:	55                   	push   %ebp
801052d7:	89 e5                	mov    %esp,%ebp
801052d9:	83 ec 10             	sub    $0x10,%esp
  const uchar *s1, *s2;

  s1 = v1;
801052dc:	8b 45 08             	mov    0x8(%ebp),%eax
801052df:	89 45 fc             	mov    %eax,-0x4(%ebp)
  s2 = v2;
801052e2:	8b 45 0c             	mov    0xc(%ebp),%eax
801052e5:	89 45 f8             	mov    %eax,-0x8(%ebp)
  while(n-- > 0){
801052e8:	eb 2e                	jmp    80105318 <memcmp+0x42>
    if(*s1 != *s2)
801052ea:	8b 45 fc             	mov    -0x4(%ebp),%eax
801052ed:	0f b6 10             	movzbl (%eax),%edx
801052f0:	8b 45 f8             	mov    -0x8(%ebp),%eax
801052f3:	0f b6 00             	movzbl (%eax),%eax
801052f6:	38 c2                	cmp    %al,%dl
801052f8:	74 16                	je     80105310 <memcmp+0x3a>
      return *s1 - *s2;
801052fa:	8b 45 fc             	mov    -0x4(%ebp),%eax
801052fd:	0f b6 00             	movzbl (%eax),%eax
80105300:	0f b6 d0             	movzbl %al,%edx
80105303:	8b 45 f8             	mov    -0x8(%ebp),%eax
80105306:	0f b6 00             	movzbl (%eax),%eax
80105309:	0f b6 c0             	movzbl %al,%eax
8010530c:	29 c2                	sub    %eax,%edx
8010530e:	eb 1a                	jmp    8010532a <memcmp+0x54>
    s1++, s2++;
80105310:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
80105314:	83 45 f8 01          	addl   $0x1,-0x8(%ebp)
  while(n-- > 0){
80105318:	8b 45 10             	mov    0x10(%ebp),%eax
8010531b:	8d 50 ff             	lea    -0x1(%eax),%edx
8010531e:	89 55 10             	mov    %edx,0x10(%ebp)
80105321:	85 c0                	test   %eax,%eax
80105323:	75 c5                	jne    801052ea <memcmp+0x14>
  }

  return 0;
80105325:	ba 00 00 00 00       	mov    $0x0,%edx
}
8010532a:	89 d0                	mov    %edx,%eax
8010532c:	c9                   	leave
8010532d:	c3                   	ret

8010532e <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
8010532e:	55                   	push   %ebp
8010532f:	89 e5                	mov    %esp,%ebp
80105331:	83 ec 10             	sub    $0x10,%esp
  const char *s;
  char *d;

  s = src;
80105334:	8b 45 0c             	mov    0xc(%ebp),%eax
80105337:	89 45 fc             	mov    %eax,-0x4(%ebp)
  d = dst;
8010533a:	8b 45 08             	mov    0x8(%ebp),%eax
8010533d:	89 45 f8             	mov    %eax,-0x8(%ebp)
  if(s < d && s + n > d){
80105340:	8b 45 fc             	mov    -0x4(%ebp),%eax
80105343:	3b 45 f8             	cmp    -0x8(%ebp),%eax
80105346:	73 54                	jae    8010539c <memmove+0x6e>
80105348:	8b 55 fc             	mov    -0x4(%ebp),%edx
8010534b:	8b 45 10             	mov    0x10(%ebp),%eax
8010534e:	01 d0                	add    %edx,%eax
80105350:	39 45 f8             	cmp    %eax,-0x8(%ebp)
80105353:	73 47                	jae    8010539c <memmove+0x6e>
    s += n;
80105355:	8b 45 10             	mov    0x10(%ebp),%eax
80105358:	01 45 fc             	add    %eax,-0x4(%ebp)
    d += n;
8010535b:	8b 45 10             	mov    0x10(%ebp),%eax
8010535e:	01 45 f8             	add    %eax,-0x8(%ebp)
    while(n-- > 0)
80105361:	eb 13                	jmp    80105376 <memmove+0x48>
      *--d = *--s;
80105363:	83 6d fc 01          	subl   $0x1,-0x4(%ebp)
80105367:	83 6d f8 01          	subl   $0x1,-0x8(%ebp)
8010536b:	8b 45 fc             	mov    -0x4(%ebp),%eax
8010536e:	0f b6 10             	movzbl (%eax),%edx
80105371:	8b 45 f8             	mov    -0x8(%ebp),%eax
80105374:	88 10                	mov    %dl,(%eax)
    while(n-- > 0)
80105376:	8b 45 10             	mov    0x10(%ebp),%eax
80105379:	8d 50 ff             	lea    -0x1(%eax),%edx
8010537c:	89 55 10             	mov    %edx,0x10(%ebp)
8010537f:	85 c0                	test   %eax,%eax
80105381:	75 e0                	jne    80105363 <memmove+0x35>
  if(s < d && s + n > d){
80105383:	eb 24                	jmp    801053a9 <memmove+0x7b>
  } else
    while(n-- > 0)
      *d++ = *s++;
80105385:	8b 55 fc             	mov    -0x4(%ebp),%edx
80105388:	8d 42 01             	lea    0x1(%edx),%eax
8010538b:	89 45 fc             	mov    %eax,-0x4(%ebp)
8010538e:	8b 45 f8             	mov    -0x8(%ebp),%eax
80105391:	8d 48 01             	lea    0x1(%eax),%ecx
80105394:	89 4d f8             	mov    %ecx,-0x8(%ebp)
80105397:	0f b6 12             	movzbl (%edx),%edx
8010539a:	88 10                	mov    %dl,(%eax)
    while(n-- > 0)
8010539c:	8b 45 10             	mov    0x10(%ebp),%eax
8010539f:	8d 50 ff             	lea    -0x1(%eax),%edx
801053a2:	89 55 10             	mov    %edx,0x10(%ebp)
801053a5:	85 c0                	test   %eax,%eax
801053a7:	75 dc                	jne    80105385 <memmove+0x57>

  return dst;
801053a9:	8b 45 08             	mov    0x8(%ebp),%eax
}
801053ac:	c9                   	leave
801053ad:	c3                   	ret

801053ae <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
801053ae:	55                   	push   %ebp
801053af:	89 e5                	mov    %esp,%ebp
  return memmove(dst, src, n);
801053b1:	ff 75 10             	push   0x10(%ebp)
801053b4:	ff 75 0c             	push   0xc(%ebp)
801053b7:	ff 75 08             	push   0x8(%ebp)
801053ba:	e8 6f ff ff ff       	call   8010532e <memmove>
801053bf:	83 c4 0c             	add    $0xc,%esp
}
801053c2:	c9                   	leave
801053c3:	c3                   	ret

801053c4 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
801053c4:	55                   	push   %ebp
801053c5:	89 e5                	mov    %esp,%ebp
  while(n > 0 && *p && *p == *q)
801053c7:	eb 0c                	jmp    801053d5 <strncmp+0x11>
    n--, p++, q++;
801053c9:	83 6d 10 01          	subl   $0x1,0x10(%ebp)
801053cd:	83 45 08 01          	addl   $0x1,0x8(%ebp)
801053d1:	83 45 0c 01          	addl   $0x1,0xc(%ebp)
  while(n > 0 && *p && *p == *q)
801053d5:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
801053d9:	74 1a                	je     801053f5 <strncmp+0x31>
801053db:	8b 45 08             	mov    0x8(%ebp),%eax
801053de:	0f b6 00             	movzbl (%eax),%eax
801053e1:	84 c0                	test   %al,%al
801053e3:	74 10                	je     801053f5 <strncmp+0x31>
801053e5:	8b 45 08             	mov    0x8(%ebp),%eax
801053e8:	0f b6 10             	movzbl (%eax),%edx
801053eb:	8b 45 0c             	mov    0xc(%ebp),%eax
801053ee:	0f b6 00             	movzbl (%eax),%eax
801053f1:	38 c2                	cmp    %al,%dl
801053f3:	74 d4                	je     801053c9 <strncmp+0x5>
  if(n == 0)
801053f5:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
801053f9:	75 07                	jne    80105402 <strncmp+0x3e>
    return 0;
801053fb:	ba 00 00 00 00       	mov    $0x0,%edx
80105400:	eb 14                	jmp    80105416 <strncmp+0x52>
  return (uchar)*p - (uchar)*q;
80105402:	8b 45 08             	mov    0x8(%ebp),%eax
80105405:	0f b6 00             	movzbl (%eax),%eax
80105408:	0f b6 d0             	movzbl %al,%edx
8010540b:	8b 45 0c             	mov    0xc(%ebp),%eax
8010540e:	0f b6 00             	movzbl (%eax),%eax
80105411:	0f b6 c0             	movzbl %al,%eax
80105414:	29 c2                	sub    %eax,%edx
}
80105416:	89 d0                	mov    %edx,%eax
80105418:	5d                   	pop    %ebp
80105419:	c3                   	ret

8010541a <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
8010541a:	55                   	push   %ebp
8010541b:	89 e5                	mov    %esp,%ebp
8010541d:	83 ec 10             	sub    $0x10,%esp
  char *os;

  os = s;
80105420:	8b 45 08             	mov    0x8(%ebp),%eax
80105423:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while(n-- > 0 && (*s++ = *t++) != 0)
80105426:	90                   	nop
80105427:	8b 45 10             	mov    0x10(%ebp),%eax
8010542a:	8d 50 ff             	lea    -0x1(%eax),%edx
8010542d:	89 55 10             	mov    %edx,0x10(%ebp)
80105430:	85 c0                	test   %eax,%eax
80105432:	7e 2c                	jle    80105460 <strncpy+0x46>
80105434:	8b 55 0c             	mov    0xc(%ebp),%edx
80105437:	8d 42 01             	lea    0x1(%edx),%eax
8010543a:	89 45 0c             	mov    %eax,0xc(%ebp)
8010543d:	8b 45 08             	mov    0x8(%ebp),%eax
80105440:	8d 48 01             	lea    0x1(%eax),%ecx
80105443:	89 4d 08             	mov    %ecx,0x8(%ebp)
80105446:	0f b6 12             	movzbl (%edx),%edx
80105449:	88 10                	mov    %dl,(%eax)
8010544b:	0f b6 00             	movzbl (%eax),%eax
8010544e:	84 c0                	test   %al,%al
80105450:	75 d5                	jne    80105427 <strncpy+0xd>
    ;
  while(n-- > 0)
80105452:	eb 0c                	jmp    80105460 <strncpy+0x46>
    *s++ = 0;
80105454:	8b 45 08             	mov    0x8(%ebp),%eax
80105457:	8d 50 01             	lea    0x1(%eax),%edx
8010545a:	89 55 08             	mov    %edx,0x8(%ebp)
8010545d:	c6 00 00             	movb   $0x0,(%eax)
  while(n-- > 0)
80105460:	8b 45 10             	mov    0x10(%ebp),%eax
80105463:	8d 50 ff             	lea    -0x1(%eax),%edx
80105466:	89 55 10             	mov    %edx,0x10(%ebp)
80105469:	85 c0                	test   %eax,%eax
8010546b:	7f e7                	jg     80105454 <strncpy+0x3a>
  return os;
8010546d:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
80105470:	c9                   	leave
80105471:	c3                   	ret

80105472 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
80105472:	55                   	push   %ebp
80105473:	89 e5                	mov    %esp,%ebp
80105475:	83 ec 10             	sub    $0x10,%esp
  char *os;

  os = s;
80105478:	8b 45 08             	mov    0x8(%ebp),%eax
8010547b:	89 45 fc             	mov    %eax,-0x4(%ebp)
  if(n <= 0)
8010547e:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80105482:	7f 05                	jg     80105489 <safestrcpy+0x17>
    return os;
80105484:	8b 45 fc             	mov    -0x4(%ebp),%eax
80105487:	eb 32                	jmp    801054bb <safestrcpy+0x49>
  while(--n > 0 && (*s++ = *t++) != 0)
80105489:	90                   	nop
8010548a:	83 6d 10 01          	subl   $0x1,0x10(%ebp)
8010548e:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80105492:	7e 1e                	jle    801054b2 <safestrcpy+0x40>
80105494:	8b 55 0c             	mov    0xc(%ebp),%edx
80105497:	8d 42 01             	lea    0x1(%edx),%eax
8010549a:	89 45 0c             	mov    %eax,0xc(%ebp)
8010549d:	8b 45 08             	mov    0x8(%ebp),%eax
801054a0:	8d 48 01             	lea    0x1(%eax),%ecx
801054a3:	89 4d 08             	mov    %ecx,0x8(%ebp)
801054a6:	0f b6 12             	movzbl (%edx),%edx
801054a9:	88 10                	mov    %dl,(%eax)
801054ab:	0f b6 00             	movzbl (%eax),%eax
801054ae:	84 c0                	test   %al,%al
801054b0:	75 d8                	jne    8010548a <safestrcpy+0x18>
    ;
  *s = 0;
801054b2:	8b 45 08             	mov    0x8(%ebp),%eax
801054b5:	c6 00 00             	movb   $0x0,(%eax)
  return os;
801054b8:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
801054bb:	c9                   	leave
801054bc:	c3                   	ret

801054bd <strlen>:

int
strlen(const char *s)
{
801054bd:	55                   	push   %ebp
801054be:	89 e5                	mov    %esp,%ebp
801054c0:	83 ec 10             	sub    $0x10,%esp
  int n;

  for(n = 0; s[n]; n++)
801054c3:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
801054ca:	eb 04                	jmp    801054d0 <strlen+0x13>
801054cc:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
801054d0:	8b 55 fc             	mov    -0x4(%ebp),%edx
801054d3:	8b 45 08             	mov    0x8(%ebp),%eax
801054d6:	01 d0                	add    %edx,%eax
801054d8:	0f b6 00             	movzbl (%eax),%eax
801054db:	84 c0                	test   %al,%al
801054dd:	75 ed                	jne    801054cc <strlen+0xf>
    ;
  return n;
801054df:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
801054e2:	c9                   	leave
801054e3:	c3                   	ret

801054e4 <swtch>:
# a struct context, and save its address in *old.
# Switch stacks to new and pop previously-saved registers.

.globl swtch
swtch:
  movl 4(%esp), %eax
801054e4:	8b 44 24 04          	mov    0x4(%esp),%eax
  movl 8(%esp), %edx
801054e8:	8b 54 24 08          	mov    0x8(%esp),%edx

  # Save old callee-saved registers
  pushl %ebp
801054ec:	55                   	push   %ebp
  pushl %ebx
801054ed:	53                   	push   %ebx
  pushl %esi
801054ee:	56                   	push   %esi
  pushl %edi
801054ef:	57                   	push   %edi

  # Switch stacks
  movl %esp, (%eax)
801054f0:	89 20                	mov    %esp,(%eax)
  movl %edx, %esp
801054f2:	89 d4                	mov    %edx,%esp

  # Load new callee-saved registers
  popl %edi
801054f4:	5f                   	pop    %edi
  popl %esi
801054f5:	5e                   	pop    %esi
  popl %ebx
801054f6:	5b                   	pop    %ebx
  popl %ebp
801054f7:	5d                   	pop    %ebp
  ret
801054f8:	c3                   	ret

801054f9 <fetchint>:
// to a saved program counter, and then the first argument.

// Fetch the int at addr from the current process.
int
fetchint(uint addr, int *ip)
{
801054f9:	55                   	push   %ebp
801054fa:	89 e5                	mov    %esp,%ebp
801054fc:	83 ec 18             	sub    $0x18,%esp
  struct proc *curproc = myproc();
801054ff:	e8 81 ed ff ff       	call   80104285 <myproc>
80105504:	89 45 f4             	mov    %eax,-0xc(%ebp)

  if(addr >= curproc->sz || addr+4 > curproc->sz)
80105507:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010550a:	8b 00                	mov    (%eax),%eax
8010550c:	39 45 08             	cmp    %eax,0x8(%ebp)
8010550f:	73 0f                	jae    80105520 <fetchint+0x27>
80105511:	8b 45 08             	mov    0x8(%ebp),%eax
80105514:	8d 50 04             	lea    0x4(%eax),%edx
80105517:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010551a:	8b 00                	mov    (%eax),%eax
8010551c:	39 d0                	cmp    %edx,%eax
8010551e:	73 07                	jae    80105527 <fetchint+0x2e>
    return -1;
80105520:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105525:	eb 0f                	jmp    80105536 <fetchint+0x3d>
  *ip = *(int*)(addr);
80105527:	8b 45 08             	mov    0x8(%ebp),%eax
8010552a:	8b 10                	mov    (%eax),%edx
8010552c:	8b 45 0c             	mov    0xc(%ebp),%eax
8010552f:	89 10                	mov    %edx,(%eax)
  return 0;
80105531:	b8 00 00 00 00       	mov    $0x0,%eax
}
80105536:	c9                   	leave
80105537:	c3                   	ret

80105538 <fetchstr>:
// Fetch the nul-terminated string at addr from the current process.
// Doesn't actually copy the string - just sets *pp to point at it.
// Returns length of string, not including nul.
int
fetchstr(uint addr, char **pp)
{
80105538:	55                   	push   %ebp
80105539:	89 e5                	mov    %esp,%ebp
8010553b:	83 ec 18             	sub    $0x18,%esp
  char *s, *ep;
  struct proc *curproc = myproc();
8010553e:	e8 42 ed ff ff       	call   80104285 <myproc>
80105543:	89 45 f0             	mov    %eax,-0x10(%ebp)

  if(addr >= curproc->sz)
80105546:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105549:	8b 00                	mov    (%eax),%eax
8010554b:	39 45 08             	cmp    %eax,0x8(%ebp)
8010554e:	72 07                	jb     80105557 <fetchstr+0x1f>
    return -1;
80105550:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105555:	eb 41                	jmp    80105598 <fetchstr+0x60>
  *pp = (char*)addr;
80105557:	8b 55 08             	mov    0x8(%ebp),%edx
8010555a:	8b 45 0c             	mov    0xc(%ebp),%eax
8010555d:	89 10                	mov    %edx,(%eax)
  ep = (char*)curproc->sz;
8010555f:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105562:	8b 00                	mov    (%eax),%eax
80105564:	89 45 ec             	mov    %eax,-0x14(%ebp)
  for(s = *pp; s < ep; s++){
80105567:	8b 45 0c             	mov    0xc(%ebp),%eax
8010556a:	8b 00                	mov    (%eax),%eax
8010556c:	89 45 f4             	mov    %eax,-0xc(%ebp)
8010556f:	eb 1a                	jmp    8010558b <fetchstr+0x53>
    if(*s == 0)
80105571:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105574:	0f b6 00             	movzbl (%eax),%eax
80105577:	84 c0                	test   %al,%al
80105579:	75 0c                	jne    80105587 <fetchstr+0x4f>
      return s - *pp;
8010557b:	8b 45 0c             	mov    0xc(%ebp),%eax
8010557e:	8b 10                	mov    (%eax),%edx
80105580:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105583:	29 d0                	sub    %edx,%eax
80105585:	eb 11                	jmp    80105598 <fetchstr+0x60>
  for(s = *pp; s < ep; s++){
80105587:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
8010558b:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010558e:	3b 45 ec             	cmp    -0x14(%ebp),%eax
80105591:	72 de                	jb     80105571 <fetchstr+0x39>
  }
  return -1;
80105593:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105598:	c9                   	leave
80105599:	c3                   	ret

8010559a <argint>:

// Fetch the nth 32-bit system call argument.
int
argint(int n, int *ip)
{
8010559a:	55                   	push   %ebp
8010559b:	89 e5                	mov    %esp,%ebp
8010559d:	83 ec 08             	sub    $0x8,%esp
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
801055a0:	e8 e0 ec ff ff       	call   80104285 <myproc>
801055a5:	8b 40 18             	mov    0x18(%eax),%eax
801055a8:	8b 40 44             	mov    0x44(%eax),%eax
801055ab:	8b 55 08             	mov    0x8(%ebp),%edx
801055ae:	c1 e2 02             	shl    $0x2,%edx
801055b1:	01 d0                	add    %edx,%eax
801055b3:	83 c0 04             	add    $0x4,%eax
801055b6:	83 ec 08             	sub    $0x8,%esp
801055b9:	ff 75 0c             	push   0xc(%ebp)
801055bc:	50                   	push   %eax
801055bd:	e8 37 ff ff ff       	call   801054f9 <fetchint>
801055c2:	83 c4 10             	add    $0x10,%esp
}
801055c5:	c9                   	leave
801055c6:	c3                   	ret

801055c7 <argptr>:
// Fetch the nth word-sized system call argument as a pointer
// to a block of memory of size bytes.  Check that the pointer
// lies within the process address space.
int
argptr(int n, char **pp, int size)
{
801055c7:	55                   	push   %ebp
801055c8:	89 e5                	mov    %esp,%ebp
801055ca:	83 ec 18             	sub    $0x18,%esp
  int i;
  struct proc *curproc = myproc();
801055cd:	e8 b3 ec ff ff       	call   80104285 <myproc>
801055d2:	89 45 f4             	mov    %eax,-0xc(%ebp)
 
  if(argint(n, &i) < 0)
801055d5:	83 ec 08             	sub    $0x8,%esp
801055d8:	8d 45 f0             	lea    -0x10(%ebp),%eax
801055db:	50                   	push   %eax
801055dc:	ff 75 08             	push   0x8(%ebp)
801055df:	e8 b6 ff ff ff       	call   8010559a <argint>
801055e4:	83 c4 10             	add    $0x10,%esp
801055e7:	85 c0                	test   %eax,%eax
801055e9:	79 07                	jns    801055f2 <argptr+0x2b>
    return -1;
801055eb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801055f0:	eb 3b                	jmp    8010562d <argptr+0x66>
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
801055f2:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
801055f6:	78 1f                	js     80105617 <argptr+0x50>
801055f8:	8b 45 f4             	mov    -0xc(%ebp),%eax
801055fb:	8b 00                	mov    (%eax),%eax
801055fd:	8b 55 f0             	mov    -0x10(%ebp),%edx
80105600:	39 c2                	cmp    %eax,%edx
80105602:	73 13                	jae    80105617 <argptr+0x50>
80105604:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105607:	89 c2                	mov    %eax,%edx
80105609:	8b 45 10             	mov    0x10(%ebp),%eax
8010560c:	01 c2                	add    %eax,%edx
8010560e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105611:	8b 00                	mov    (%eax),%eax
80105613:	39 d0                	cmp    %edx,%eax
80105615:	73 07                	jae    8010561e <argptr+0x57>
    return -1;
80105617:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010561c:	eb 0f                	jmp    8010562d <argptr+0x66>
  *pp = (char*)i;
8010561e:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105621:	89 c2                	mov    %eax,%edx
80105623:	8b 45 0c             	mov    0xc(%ebp),%eax
80105626:	89 10                	mov    %edx,(%eax)
  return 0;
80105628:	b8 00 00 00 00       	mov    $0x0,%eax
}
8010562d:	c9                   	leave
8010562e:	c3                   	ret

8010562f <argstr>:
// Check that the pointer is valid and the string is nul-terminated.
// (There is no shared writable memory, so the string can't change
// between this check and being used by the kernel.)
int
argstr(int n, char **pp)
{
8010562f:	55                   	push   %ebp
80105630:	89 e5                	mov    %esp,%ebp
80105632:	83 ec 18             	sub    $0x18,%esp
  int addr;
  if(argint(n, &addr) < 0)
80105635:	83 ec 08             	sub    $0x8,%esp
80105638:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010563b:	50                   	push   %eax
8010563c:	ff 75 08             	push   0x8(%ebp)
8010563f:	e8 56 ff ff ff       	call   8010559a <argint>
80105644:	83 c4 10             	add    $0x10,%esp
80105647:	85 c0                	test   %eax,%eax
80105649:	79 07                	jns    80105652 <argstr+0x23>
    return -1;
8010564b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105650:	eb 12                	jmp    80105664 <argstr+0x35>
  return fetchstr(addr, pp);
80105652:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105655:	83 ec 08             	sub    $0x8,%esp
80105658:	ff 75 0c             	push   0xc(%ebp)
8010565b:	50                   	push   %eax
8010565c:	e8 d7 fe ff ff       	call   80105538 <fetchstr>
80105661:	83 c4 10             	add    $0x10,%esp
}
80105664:	c9                   	leave
80105665:	c3                   	ret

80105666 <syscall>:
[SYS_getparentname] sys_getparentname,
};

void
syscall(void)
{
80105666:	55                   	push   %ebp
80105667:	89 e5                	mov    %esp,%ebp
80105669:	83 ec 18             	sub    $0x18,%esp
  int num;
  struct proc *curproc = myproc();
8010566c:	e8 14 ec ff ff       	call   80104285 <myproc>
80105671:	89 45 f4             	mov    %eax,-0xc(%ebp)

  num = curproc->tf->eax;
80105674:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105677:	8b 40 18             	mov    0x18(%eax),%eax
8010567a:	8b 40 1c             	mov    0x1c(%eax),%eax
8010567d:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
80105680:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80105684:	7e 2f                	jle    801056b5 <syscall+0x4f>
80105686:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105689:	83 f8 16             	cmp    $0x16,%eax
8010568c:	77 27                	ja     801056b5 <syscall+0x4f>
8010568e:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105691:	8b 04 85 20 b0 10 80 	mov    -0x7fef4fe0(,%eax,4),%eax
80105698:	85 c0                	test   %eax,%eax
8010569a:	74 19                	je     801056b5 <syscall+0x4f>
    curproc->tf->eax = syscalls[num]();
8010569c:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010569f:	8b 04 85 20 b0 10 80 	mov    -0x7fef4fe0(,%eax,4),%eax
801056a6:	ff d0                	call   *%eax
801056a8:	89 c2                	mov    %eax,%edx
801056aa:	8b 45 f4             	mov    -0xc(%ebp),%eax
801056ad:	8b 40 18             	mov    0x18(%eax),%eax
801056b0:	89 50 1c             	mov    %edx,0x1c(%eax)
801056b3:	eb 2c                	jmp    801056e1 <syscall+0x7b>
  } else {
    cprintf("%d %s: unknown sys call %d\n",
            curproc->pid, curproc->name, num);
801056b5:	8b 45 f4             	mov    -0xc(%ebp),%eax
801056b8:	8d 50 6c             	lea    0x6c(%eax),%edx
    cprintf("%d %s: unknown sys call %d\n",
801056bb:	8b 45 f4             	mov    -0xc(%ebp),%eax
801056be:	8b 40 10             	mov    0x10(%eax),%eax
801056c1:	ff 75 f0             	push   -0x10(%ebp)
801056c4:	52                   	push   %edx
801056c5:	50                   	push   %eax
801056c6:	68 d2 88 10 80       	push   $0x801088d2
801056cb:	e8 2e ad ff ff       	call   801003fe <cprintf>
801056d0:	83 c4 10             	add    $0x10,%esp
    curproc->tf->eax = -1;
801056d3:	8b 45 f4             	mov    -0xc(%ebp),%eax
801056d6:	8b 40 18             	mov    0x18(%eax),%eax
801056d9:	c7 40 1c ff ff ff ff 	movl   $0xffffffff,0x1c(%eax)
  }
}
801056e0:	90                   	nop
801056e1:	90                   	nop
801056e2:	c9                   	leave
801056e3:	c3                   	ret

801056e4 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
801056e4:	55                   	push   %ebp
801056e5:	89 e5                	mov    %esp,%ebp
801056e7:	83 ec 18             	sub    $0x18,%esp
  int fd;
  struct file *f;

  if(argint(n, &fd) < 0)
801056ea:	83 ec 08             	sub    $0x8,%esp
801056ed:	8d 45 f0             	lea    -0x10(%ebp),%eax
801056f0:	50                   	push   %eax
801056f1:	ff 75 08             	push   0x8(%ebp)
801056f4:	e8 a1 fe ff ff       	call   8010559a <argint>
801056f9:	83 c4 10             	add    $0x10,%esp
801056fc:	85 c0                	test   %eax,%eax
801056fe:	79 07                	jns    80105707 <argfd+0x23>
    return -1;
80105700:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105705:	eb 4f                	jmp    80105756 <argfd+0x72>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80105707:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010570a:	85 c0                	test   %eax,%eax
8010570c:	78 20                	js     8010572e <argfd+0x4a>
8010570e:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105711:	83 f8 0f             	cmp    $0xf,%eax
80105714:	7f 18                	jg     8010572e <argfd+0x4a>
80105716:	e8 6a eb ff ff       	call   80104285 <myproc>
8010571b:	8b 55 f0             	mov    -0x10(%ebp),%edx
8010571e:	83 c2 08             	add    $0x8,%edx
80105721:	8b 44 90 08          	mov    0x8(%eax,%edx,4),%eax
80105725:	89 45 f4             	mov    %eax,-0xc(%ebp)
80105728:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
8010572c:	75 07                	jne    80105735 <argfd+0x51>
    return -1;
8010572e:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105733:	eb 21                	jmp    80105756 <argfd+0x72>
  if(pfd)
80105735:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
80105739:	74 08                	je     80105743 <argfd+0x5f>
    *pfd = fd;
8010573b:	8b 55 f0             	mov    -0x10(%ebp),%edx
8010573e:	8b 45 0c             	mov    0xc(%ebp),%eax
80105741:	89 10                	mov    %edx,(%eax)
  if(pf)
80105743:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80105747:	74 08                	je     80105751 <argfd+0x6d>
    *pf = f;
80105749:	8b 45 10             	mov    0x10(%ebp),%eax
8010574c:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010574f:	89 10                	mov    %edx,(%eax)
  return 0;
80105751:	b8 00 00 00 00       	mov    $0x0,%eax
}
80105756:	c9                   	leave
80105757:	c3                   	ret

80105758 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
80105758:	55                   	push   %ebp
80105759:	89 e5                	mov    %esp,%ebp
8010575b:	83 ec 18             	sub    $0x18,%esp
  int fd;
  struct proc *curproc = myproc();
8010575e:	e8 22 eb ff ff       	call   80104285 <myproc>
80105763:	89 45 f0             	mov    %eax,-0x10(%ebp)

  for(fd = 0; fd < NOFILE; fd++){
80105766:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
8010576d:	eb 2a                	jmp    80105799 <fdalloc+0x41>
    if(curproc->ofile[fd] == 0){
8010576f:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105772:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105775:	83 c2 08             	add    $0x8,%edx
80105778:	8b 44 90 08          	mov    0x8(%eax,%edx,4),%eax
8010577c:	85 c0                	test   %eax,%eax
8010577e:	75 15                	jne    80105795 <fdalloc+0x3d>
      curproc->ofile[fd] = f;
80105780:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105783:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105786:	8d 4a 08             	lea    0x8(%edx),%ecx
80105789:	8b 55 08             	mov    0x8(%ebp),%edx
8010578c:	89 54 88 08          	mov    %edx,0x8(%eax,%ecx,4)
      return fd;
80105790:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105793:	eb 0f                	jmp    801057a4 <fdalloc+0x4c>
  for(fd = 0; fd < NOFILE; fd++){
80105795:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80105799:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
8010579d:	7e d0                	jle    8010576f <fdalloc+0x17>
    }
  }
  return -1;
8010579f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801057a4:	c9                   	leave
801057a5:	c3                   	ret

801057a6 <sys_dup>:

int
sys_dup(void)
{
801057a6:	55                   	push   %ebp
801057a7:	89 e5                	mov    %esp,%ebp
801057a9:	83 ec 18             	sub    $0x18,%esp
  struct file *f;
  int fd;

  if(argfd(0, 0, &f) < 0)
801057ac:	83 ec 04             	sub    $0x4,%esp
801057af:	8d 45 f0             	lea    -0x10(%ebp),%eax
801057b2:	50                   	push   %eax
801057b3:	6a 00                	push   $0x0
801057b5:	6a 00                	push   $0x0
801057b7:	e8 28 ff ff ff       	call   801056e4 <argfd>
801057bc:	83 c4 10             	add    $0x10,%esp
801057bf:	85 c0                	test   %eax,%eax
801057c1:	79 07                	jns    801057ca <sys_dup+0x24>
    return -1;
801057c3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801057c8:	eb 31                	jmp    801057fb <sys_dup+0x55>
  if((fd=fdalloc(f)) < 0)
801057ca:	8b 45 f0             	mov    -0x10(%ebp),%eax
801057cd:	83 ec 0c             	sub    $0xc,%esp
801057d0:	50                   	push   %eax
801057d1:	e8 82 ff ff ff       	call   80105758 <fdalloc>
801057d6:	83 c4 10             	add    $0x10,%esp
801057d9:	89 45 f4             	mov    %eax,-0xc(%ebp)
801057dc:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
801057e0:	79 07                	jns    801057e9 <sys_dup+0x43>
    return -1;
801057e2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801057e7:	eb 12                	jmp    801057fb <sys_dup+0x55>
  filedup(f);
801057e9:	8b 45 f0             	mov    -0x10(%ebp),%eax
801057ec:	83 ec 0c             	sub    $0xc,%esp
801057ef:	50                   	push   %eax
801057f0:	e8 96 b8 ff ff       	call   8010108b <filedup>
801057f5:	83 c4 10             	add    $0x10,%esp
  return fd;
801057f8:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
801057fb:	c9                   	leave
801057fc:	c3                   	ret

801057fd <sys_read>:

int
sys_read(void)
{
801057fd:	55                   	push   %ebp
801057fe:	89 e5                	mov    %esp,%ebp
80105800:	83 ec 18             	sub    $0x18,%esp
  struct file *f;
  int n;
  char *p;

  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
80105803:	83 ec 04             	sub    $0x4,%esp
80105806:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105809:	50                   	push   %eax
8010580a:	6a 00                	push   $0x0
8010580c:	6a 00                	push   $0x0
8010580e:	e8 d1 fe ff ff       	call   801056e4 <argfd>
80105813:	83 c4 10             	add    $0x10,%esp
80105816:	85 c0                	test   %eax,%eax
80105818:	78 2e                	js     80105848 <sys_read+0x4b>
8010581a:	83 ec 08             	sub    $0x8,%esp
8010581d:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105820:	50                   	push   %eax
80105821:	6a 02                	push   $0x2
80105823:	e8 72 fd ff ff       	call   8010559a <argint>
80105828:	83 c4 10             	add    $0x10,%esp
8010582b:	85 c0                	test   %eax,%eax
8010582d:	78 19                	js     80105848 <sys_read+0x4b>
8010582f:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105832:	83 ec 04             	sub    $0x4,%esp
80105835:	50                   	push   %eax
80105836:	8d 45 ec             	lea    -0x14(%ebp),%eax
80105839:	50                   	push   %eax
8010583a:	6a 01                	push   $0x1
8010583c:	e8 86 fd ff ff       	call   801055c7 <argptr>
80105841:	83 c4 10             	add    $0x10,%esp
80105844:	85 c0                	test   %eax,%eax
80105846:	79 07                	jns    8010584f <sys_read+0x52>
    return -1;
80105848:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010584d:	eb 17                	jmp    80105866 <sys_read+0x69>
  return fileread(f, p, n);
8010584f:	8b 4d f0             	mov    -0x10(%ebp),%ecx
80105852:	8b 55 ec             	mov    -0x14(%ebp),%edx
80105855:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105858:	83 ec 04             	sub    $0x4,%esp
8010585b:	51                   	push   %ecx
8010585c:	52                   	push   %edx
8010585d:	50                   	push   %eax
8010585e:	e8 b8 b9 ff ff       	call   8010121b <fileread>
80105863:	83 c4 10             	add    $0x10,%esp
}
80105866:	c9                   	leave
80105867:	c3                   	ret

80105868 <sys_write>:

int
sys_write(void)
{
80105868:	55                   	push   %ebp
80105869:	89 e5                	mov    %esp,%ebp
8010586b:	83 ec 18             	sub    $0x18,%esp
  struct file *f;
  int n;
  char *p;

  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
8010586e:	83 ec 04             	sub    $0x4,%esp
80105871:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105874:	50                   	push   %eax
80105875:	6a 00                	push   $0x0
80105877:	6a 00                	push   $0x0
80105879:	e8 66 fe ff ff       	call   801056e4 <argfd>
8010587e:	83 c4 10             	add    $0x10,%esp
80105881:	85 c0                	test   %eax,%eax
80105883:	78 2e                	js     801058b3 <sys_write+0x4b>
80105885:	83 ec 08             	sub    $0x8,%esp
80105888:	8d 45 f0             	lea    -0x10(%ebp),%eax
8010588b:	50                   	push   %eax
8010588c:	6a 02                	push   $0x2
8010588e:	e8 07 fd ff ff       	call   8010559a <argint>
80105893:	83 c4 10             	add    $0x10,%esp
80105896:	85 c0                	test   %eax,%eax
80105898:	78 19                	js     801058b3 <sys_write+0x4b>
8010589a:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010589d:	83 ec 04             	sub    $0x4,%esp
801058a0:	50                   	push   %eax
801058a1:	8d 45 ec             	lea    -0x14(%ebp),%eax
801058a4:	50                   	push   %eax
801058a5:	6a 01                	push   $0x1
801058a7:	e8 1b fd ff ff       	call   801055c7 <argptr>
801058ac:	83 c4 10             	add    $0x10,%esp
801058af:	85 c0                	test   %eax,%eax
801058b1:	79 07                	jns    801058ba <sys_write+0x52>
    return -1;
801058b3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801058b8:	eb 17                	jmp    801058d1 <sys_write+0x69>
  return filewrite(f, p, n);
801058ba:	8b 4d f0             	mov    -0x10(%ebp),%ecx
801058bd:	8b 55 ec             	mov    -0x14(%ebp),%edx
801058c0:	8b 45 f4             	mov    -0xc(%ebp),%eax
801058c3:	83 ec 04             	sub    $0x4,%esp
801058c6:	51                   	push   %ecx
801058c7:	52                   	push   %edx
801058c8:	50                   	push   %eax
801058c9:	e8 05 ba ff ff       	call   801012d3 <filewrite>
801058ce:	83 c4 10             	add    $0x10,%esp
}
801058d1:	c9                   	leave
801058d2:	c3                   	ret

801058d3 <sys_close>:

int
sys_close(void)
{
801058d3:	55                   	push   %ebp
801058d4:	89 e5                	mov    %esp,%ebp
801058d6:	83 ec 18             	sub    $0x18,%esp
  int fd;
  struct file *f;

  if(argfd(0, &fd, &f) < 0)
801058d9:	83 ec 04             	sub    $0x4,%esp
801058dc:	8d 45 f0             	lea    -0x10(%ebp),%eax
801058df:	50                   	push   %eax
801058e0:	8d 45 f4             	lea    -0xc(%ebp),%eax
801058e3:	50                   	push   %eax
801058e4:	6a 00                	push   $0x0
801058e6:	e8 f9 fd ff ff       	call   801056e4 <argfd>
801058eb:	83 c4 10             	add    $0x10,%esp
801058ee:	85 c0                	test   %eax,%eax
801058f0:	79 07                	jns    801058f9 <sys_close+0x26>
    return -1;
801058f2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801058f7:	eb 27                	jmp    80105920 <sys_close+0x4d>
  myproc()->ofile[fd] = 0;
801058f9:	e8 87 e9 ff ff       	call   80104285 <myproc>
801058fe:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105901:	83 c2 08             	add    $0x8,%edx
80105904:	c7 44 90 08 00 00 00 	movl   $0x0,0x8(%eax,%edx,4)
8010590b:	00 
  fileclose(f);
8010590c:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010590f:	83 ec 0c             	sub    $0xc,%esp
80105912:	50                   	push   %eax
80105913:	e8 c4 b7 ff ff       	call   801010dc <fileclose>
80105918:	83 c4 10             	add    $0x10,%esp
  return 0;
8010591b:	b8 00 00 00 00       	mov    $0x0,%eax
}
80105920:	c9                   	leave
80105921:	c3                   	ret

80105922 <sys_fstat>:

int
sys_fstat(void)
{
80105922:	55                   	push   %ebp
80105923:	89 e5                	mov    %esp,%ebp
80105925:	83 ec 18             	sub    $0x18,%esp
  struct file *f;
  struct stat *st;

  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)
80105928:	83 ec 04             	sub    $0x4,%esp
8010592b:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010592e:	50                   	push   %eax
8010592f:	6a 00                	push   $0x0
80105931:	6a 00                	push   $0x0
80105933:	e8 ac fd ff ff       	call   801056e4 <argfd>
80105938:	83 c4 10             	add    $0x10,%esp
8010593b:	85 c0                	test   %eax,%eax
8010593d:	78 17                	js     80105956 <sys_fstat+0x34>
8010593f:	83 ec 04             	sub    $0x4,%esp
80105942:	6a 14                	push   $0x14
80105944:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105947:	50                   	push   %eax
80105948:	6a 01                	push   $0x1
8010594a:	e8 78 fc ff ff       	call   801055c7 <argptr>
8010594f:	83 c4 10             	add    $0x10,%esp
80105952:	85 c0                	test   %eax,%eax
80105954:	79 07                	jns    8010595d <sys_fstat+0x3b>
    return -1;
80105956:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010595b:	eb 13                	jmp    80105970 <sys_fstat+0x4e>
  return filestat(f, st);
8010595d:	8b 55 f0             	mov    -0x10(%ebp),%edx
80105960:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105963:	83 ec 08             	sub    $0x8,%esp
80105966:	52                   	push   %edx
80105967:	50                   	push   %eax
80105968:	e8 57 b8 ff ff       	call   801011c4 <filestat>
8010596d:	83 c4 10             	add    $0x10,%esp
}
80105970:	c9                   	leave
80105971:	c3                   	ret

80105972 <sys_link>:

// Create the path new as a link to the same inode as old.
int
sys_link(void)
{
80105972:	55                   	push   %ebp
80105973:	89 e5                	mov    %esp,%ebp
80105975:	83 ec 28             	sub    $0x28,%esp
  char name[DIRSIZ], *new, *old;
  struct inode *dp, *ip;

  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
80105978:	83 ec 08             	sub    $0x8,%esp
8010597b:	8d 45 d8             	lea    -0x28(%ebp),%eax
8010597e:	50                   	push   %eax
8010597f:	6a 00                	push   $0x0
80105981:	e8 a9 fc ff ff       	call   8010562f <argstr>
80105986:	83 c4 10             	add    $0x10,%esp
80105989:	85 c0                	test   %eax,%eax
8010598b:	78 15                	js     801059a2 <sys_link+0x30>
8010598d:	83 ec 08             	sub    $0x8,%esp
80105990:	8d 45 dc             	lea    -0x24(%ebp),%eax
80105993:	50                   	push   %eax
80105994:	6a 01                	push   $0x1
80105996:	e8 94 fc ff ff       	call   8010562f <argstr>
8010599b:	83 c4 10             	add    $0x10,%esp
8010599e:	85 c0                	test   %eax,%eax
801059a0:	79 0a                	jns    801059ac <sys_link+0x3a>
    return -1;
801059a2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801059a7:	e9 68 01 00 00       	jmp    80105b14 <sys_link+0x1a2>

  begin_op();
801059ac:	e8 71 db ff ff       	call   80103522 <begin_op>
  if((ip = namei(old)) == 0){
801059b1:	8b 45 d8             	mov    -0x28(%ebp),%eax
801059b4:	83 ec 0c             	sub    $0xc,%esp
801059b7:	50                   	push   %eax
801059b8:	e8 8c cb ff ff       	call   80102549 <namei>
801059bd:	83 c4 10             	add    $0x10,%esp
801059c0:	89 45 f4             	mov    %eax,-0xc(%ebp)
801059c3:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
801059c7:	75 0f                	jne    801059d8 <sys_link+0x66>
    end_op();
801059c9:	e8 e0 db ff ff       	call   801035ae <end_op>
    return -1;
801059ce:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801059d3:	e9 3c 01 00 00       	jmp    80105b14 <sys_link+0x1a2>
  }

  ilock(ip);
801059d8:	83 ec 0c             	sub    $0xc,%esp
801059db:	ff 75 f4             	push   -0xc(%ebp)
801059de:	e8 33 c0 ff ff       	call   80101a16 <ilock>
801059e3:	83 c4 10             	add    $0x10,%esp
  if(ip->type == T_DIR){
801059e6:	8b 45 f4             	mov    -0xc(%ebp),%eax
801059e9:	0f b7 40 50          	movzwl 0x50(%eax),%eax
801059ed:	66 83 f8 01          	cmp    $0x1,%ax
801059f1:	75 1d                	jne    80105a10 <sys_link+0x9e>
    iunlockput(ip);
801059f3:	83 ec 0c             	sub    $0xc,%esp
801059f6:	ff 75 f4             	push   -0xc(%ebp)
801059f9:	e8 49 c2 ff ff       	call   80101c47 <iunlockput>
801059fe:	83 c4 10             	add    $0x10,%esp
    end_op();
80105a01:	e8 a8 db ff ff       	call   801035ae <end_op>
    return -1;
80105a06:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105a0b:	e9 04 01 00 00       	jmp    80105b14 <sys_link+0x1a2>
  }

  ip->nlink++;
80105a10:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105a13:	0f b7 40 56          	movzwl 0x56(%eax),%eax
80105a17:	83 c0 01             	add    $0x1,%eax
80105a1a:	89 c2                	mov    %eax,%edx
80105a1c:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105a1f:	66 89 50 56          	mov    %dx,0x56(%eax)
  iupdate(ip);
80105a23:	83 ec 0c             	sub    $0xc,%esp
80105a26:	ff 75 f4             	push   -0xc(%ebp)
80105a29:	e8 0b be ff ff       	call   80101839 <iupdate>
80105a2e:	83 c4 10             	add    $0x10,%esp
  iunlock(ip);
80105a31:	83 ec 0c             	sub    $0xc,%esp
80105a34:	ff 75 f4             	push   -0xc(%ebp)
80105a37:	e8 ed c0 ff ff       	call   80101b29 <iunlock>
80105a3c:	83 c4 10             	add    $0x10,%esp

  if((dp = nameiparent(new, name)) == 0)
80105a3f:	8b 45 dc             	mov    -0x24(%ebp),%eax
80105a42:	83 ec 08             	sub    $0x8,%esp
80105a45:	8d 55 e2             	lea    -0x1e(%ebp),%edx
80105a48:	52                   	push   %edx
80105a49:	50                   	push   %eax
80105a4a:	e8 16 cb ff ff       	call   80102565 <nameiparent>
80105a4f:	83 c4 10             	add    $0x10,%esp
80105a52:	89 45 f0             	mov    %eax,-0x10(%ebp)
80105a55:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80105a59:	74 71                	je     80105acc <sys_link+0x15a>
    goto bad;
  ilock(dp);
80105a5b:	83 ec 0c             	sub    $0xc,%esp
80105a5e:	ff 75 f0             	push   -0x10(%ebp)
80105a61:	e8 b0 bf ff ff       	call   80101a16 <ilock>
80105a66:	83 c4 10             	add    $0x10,%esp
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
80105a69:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105a6c:	8b 10                	mov    (%eax),%edx
80105a6e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105a71:	8b 00                	mov    (%eax),%eax
80105a73:	39 c2                	cmp    %eax,%edx
80105a75:	75 1d                	jne    80105a94 <sys_link+0x122>
80105a77:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105a7a:	8b 40 04             	mov    0x4(%eax),%eax
80105a7d:	83 ec 04             	sub    $0x4,%esp
80105a80:	50                   	push   %eax
80105a81:	8d 45 e2             	lea    -0x1e(%ebp),%eax
80105a84:	50                   	push   %eax
80105a85:	ff 75 f0             	push   -0x10(%ebp)
80105a88:	e8 25 c8 ff ff       	call   801022b2 <dirlink>
80105a8d:	83 c4 10             	add    $0x10,%esp
80105a90:	85 c0                	test   %eax,%eax
80105a92:	79 10                	jns    80105aa4 <sys_link+0x132>
    iunlockput(dp);
80105a94:	83 ec 0c             	sub    $0xc,%esp
80105a97:	ff 75 f0             	push   -0x10(%ebp)
80105a9a:	e8 a8 c1 ff ff       	call   80101c47 <iunlockput>
80105a9f:	83 c4 10             	add    $0x10,%esp
    goto bad;
80105aa2:	eb 29                	jmp    80105acd <sys_link+0x15b>
  }
  iunlockput(dp);
80105aa4:	83 ec 0c             	sub    $0xc,%esp
80105aa7:	ff 75 f0             	push   -0x10(%ebp)
80105aaa:	e8 98 c1 ff ff       	call   80101c47 <iunlockput>
80105aaf:	83 c4 10             	add    $0x10,%esp
  iput(ip);
80105ab2:	83 ec 0c             	sub    $0xc,%esp
80105ab5:	ff 75 f4             	push   -0xc(%ebp)
80105ab8:	e8 ba c0 ff ff       	call   80101b77 <iput>
80105abd:	83 c4 10             	add    $0x10,%esp

  end_op();
80105ac0:	e8 e9 da ff ff       	call   801035ae <end_op>

  return 0;
80105ac5:	b8 00 00 00 00       	mov    $0x0,%eax
80105aca:	eb 48                	jmp    80105b14 <sys_link+0x1a2>
    goto bad;
80105acc:	90                   	nop

bad:
  ilock(ip);
80105acd:	83 ec 0c             	sub    $0xc,%esp
80105ad0:	ff 75 f4             	push   -0xc(%ebp)
80105ad3:	e8 3e bf ff ff       	call   80101a16 <ilock>
80105ad8:	83 c4 10             	add    $0x10,%esp
  ip->nlink--;
80105adb:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105ade:	0f b7 40 56          	movzwl 0x56(%eax),%eax
80105ae2:	83 e8 01             	sub    $0x1,%eax
80105ae5:	89 c2                	mov    %eax,%edx
80105ae7:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105aea:	66 89 50 56          	mov    %dx,0x56(%eax)
  iupdate(ip);
80105aee:	83 ec 0c             	sub    $0xc,%esp
80105af1:	ff 75 f4             	push   -0xc(%ebp)
80105af4:	e8 40 bd ff ff       	call   80101839 <iupdate>
80105af9:	83 c4 10             	add    $0x10,%esp
  iunlockput(ip);
80105afc:	83 ec 0c             	sub    $0xc,%esp
80105aff:	ff 75 f4             	push   -0xc(%ebp)
80105b02:	e8 40 c1 ff ff       	call   80101c47 <iunlockput>
80105b07:	83 c4 10             	add    $0x10,%esp
  end_op();
80105b0a:	e8 9f da ff ff       	call   801035ae <end_op>
  return -1;
80105b0f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105b14:	c9                   	leave
80105b15:	c3                   	ret

80105b16 <isdirempty>:

// Is the directory dp empty except for "." and ".." ?
static int
isdirempty(struct inode *dp)
{
80105b16:	55                   	push   %ebp
80105b17:	89 e5                	mov    %esp,%ebp
80105b19:	83 ec 28             	sub    $0x28,%esp
  int off;
  struct dirent de;

  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
80105b1c:	c7 45 f4 20 00 00 00 	movl   $0x20,-0xc(%ebp)
80105b23:	eb 40                	jmp    80105b65 <isdirempty+0x4f>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80105b25:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105b28:	6a 10                	push   $0x10
80105b2a:	50                   	push   %eax
80105b2b:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80105b2e:	50                   	push   %eax
80105b2f:	ff 75 08             	push   0x8(%ebp)
80105b32:	e8 cb c3 ff ff       	call   80101f02 <readi>
80105b37:	83 c4 10             	add    $0x10,%esp
80105b3a:	83 f8 10             	cmp    $0x10,%eax
80105b3d:	74 0d                	je     80105b4c <isdirempty+0x36>
      panic("isdirempty: readi");
80105b3f:	83 ec 0c             	sub    $0xc,%esp
80105b42:	68 ee 88 10 80       	push   $0x801088ee
80105b47:	e8 67 aa ff ff       	call   801005b3 <panic>
    if(de.inum != 0)
80105b4c:	0f b7 45 e4          	movzwl -0x1c(%ebp),%eax
80105b50:	66 85 c0             	test   %ax,%ax
80105b53:	74 07                	je     80105b5c <isdirempty+0x46>
      return 0;
80105b55:	b8 00 00 00 00       	mov    $0x0,%eax
80105b5a:	eb 1b                	jmp    80105b77 <isdirempty+0x61>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
80105b5c:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105b5f:	83 c0 10             	add    $0x10,%eax
80105b62:	89 45 f4             	mov    %eax,-0xc(%ebp)
80105b65:	8b 45 08             	mov    0x8(%ebp),%eax
80105b68:	8b 40 58             	mov    0x58(%eax),%eax
80105b6b:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105b6e:	39 c2                	cmp    %eax,%edx
80105b70:	72 b3                	jb     80105b25 <isdirempty+0xf>
  }
  return 1;
80105b72:	b8 01 00 00 00       	mov    $0x1,%eax
}
80105b77:	c9                   	leave
80105b78:	c3                   	ret

80105b79 <sys_unlink>:

//PAGEBREAK!
int
sys_unlink(void)
{
80105b79:	55                   	push   %ebp
80105b7a:	89 e5                	mov    %esp,%ebp
80105b7c:	83 ec 38             	sub    $0x38,%esp
  struct inode *ip, *dp;
  struct dirent de;
  char name[DIRSIZ], *path;
  uint off;

  if(argstr(0, &path) < 0)
80105b7f:	83 ec 08             	sub    $0x8,%esp
80105b82:	8d 45 cc             	lea    -0x34(%ebp),%eax
80105b85:	50                   	push   %eax
80105b86:	6a 00                	push   $0x0
80105b88:	e8 a2 fa ff ff       	call   8010562f <argstr>
80105b8d:	83 c4 10             	add    $0x10,%esp
80105b90:	85 c0                	test   %eax,%eax
80105b92:	79 0a                	jns    80105b9e <sys_unlink+0x25>
    return -1;
80105b94:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105b99:	e9 bf 01 00 00       	jmp    80105d5d <sys_unlink+0x1e4>

  begin_op();
80105b9e:	e8 7f d9 ff ff       	call   80103522 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
80105ba3:	8b 45 cc             	mov    -0x34(%ebp),%eax
80105ba6:	83 ec 08             	sub    $0x8,%esp
80105ba9:	8d 55 d2             	lea    -0x2e(%ebp),%edx
80105bac:	52                   	push   %edx
80105bad:	50                   	push   %eax
80105bae:	e8 b2 c9 ff ff       	call   80102565 <nameiparent>
80105bb3:	83 c4 10             	add    $0x10,%esp
80105bb6:	89 45 f4             	mov    %eax,-0xc(%ebp)
80105bb9:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80105bbd:	75 0f                	jne    80105bce <sys_unlink+0x55>
    end_op();
80105bbf:	e8 ea d9 ff ff       	call   801035ae <end_op>
    return -1;
80105bc4:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105bc9:	e9 8f 01 00 00       	jmp    80105d5d <sys_unlink+0x1e4>
  }

  ilock(dp);
80105bce:	83 ec 0c             	sub    $0xc,%esp
80105bd1:	ff 75 f4             	push   -0xc(%ebp)
80105bd4:	e8 3d be ff ff       	call   80101a16 <ilock>
80105bd9:	83 c4 10             	add    $0x10,%esp

  // Cannot unlink "." or "..".
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
80105bdc:	83 ec 08             	sub    $0x8,%esp
80105bdf:	68 00 89 10 80       	push   $0x80108900
80105be4:	8d 45 d2             	lea    -0x2e(%ebp),%eax
80105be7:	50                   	push   %eax
80105be8:	e8 f0 c5 ff ff       	call   801021dd <namecmp>
80105bed:	83 c4 10             	add    $0x10,%esp
80105bf0:	85 c0                	test   %eax,%eax
80105bf2:	0f 84 49 01 00 00    	je     80105d41 <sys_unlink+0x1c8>
80105bf8:	83 ec 08             	sub    $0x8,%esp
80105bfb:	68 02 89 10 80       	push   $0x80108902
80105c00:	8d 45 d2             	lea    -0x2e(%ebp),%eax
80105c03:	50                   	push   %eax
80105c04:	e8 d4 c5 ff ff       	call   801021dd <namecmp>
80105c09:	83 c4 10             	add    $0x10,%esp
80105c0c:	85 c0                	test   %eax,%eax
80105c0e:	0f 84 2d 01 00 00    	je     80105d41 <sys_unlink+0x1c8>
    goto bad;

  if((ip = dirlookup(dp, name, &off)) == 0)
80105c14:	83 ec 04             	sub    $0x4,%esp
80105c17:	8d 45 c8             	lea    -0x38(%ebp),%eax
80105c1a:	50                   	push   %eax
80105c1b:	8d 45 d2             	lea    -0x2e(%ebp),%eax
80105c1e:	50                   	push   %eax
80105c1f:	ff 75 f4             	push   -0xc(%ebp)
80105c22:	e8 d1 c5 ff ff       	call   801021f8 <dirlookup>
80105c27:	83 c4 10             	add    $0x10,%esp
80105c2a:	89 45 f0             	mov    %eax,-0x10(%ebp)
80105c2d:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80105c31:	0f 84 0d 01 00 00    	je     80105d44 <sys_unlink+0x1cb>
    goto bad;
  ilock(ip);
80105c37:	83 ec 0c             	sub    $0xc,%esp
80105c3a:	ff 75 f0             	push   -0x10(%ebp)
80105c3d:	e8 d4 bd ff ff       	call   80101a16 <ilock>
80105c42:	83 c4 10             	add    $0x10,%esp

  if(ip->nlink < 1)
80105c45:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105c48:	0f b7 40 56          	movzwl 0x56(%eax),%eax
80105c4c:	66 85 c0             	test   %ax,%ax
80105c4f:	7f 0d                	jg     80105c5e <sys_unlink+0xe5>
    panic("unlink: nlink < 1");
80105c51:	83 ec 0c             	sub    $0xc,%esp
80105c54:	68 05 89 10 80       	push   $0x80108905
80105c59:	e8 55 a9 ff ff       	call   801005b3 <panic>
  if(ip->type == T_DIR && !isdirempty(ip)){
80105c5e:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105c61:	0f b7 40 50          	movzwl 0x50(%eax),%eax
80105c65:	66 83 f8 01          	cmp    $0x1,%ax
80105c69:	75 25                	jne    80105c90 <sys_unlink+0x117>
80105c6b:	83 ec 0c             	sub    $0xc,%esp
80105c6e:	ff 75 f0             	push   -0x10(%ebp)
80105c71:	e8 a0 fe ff ff       	call   80105b16 <isdirempty>
80105c76:	83 c4 10             	add    $0x10,%esp
80105c79:	85 c0                	test   %eax,%eax
80105c7b:	75 13                	jne    80105c90 <sys_unlink+0x117>
    iunlockput(ip);
80105c7d:	83 ec 0c             	sub    $0xc,%esp
80105c80:	ff 75 f0             	push   -0x10(%ebp)
80105c83:	e8 bf bf ff ff       	call   80101c47 <iunlockput>
80105c88:	83 c4 10             	add    $0x10,%esp
    goto bad;
80105c8b:	e9 b5 00 00 00       	jmp    80105d45 <sys_unlink+0x1cc>
  }

  memset(&de, 0, sizeof(de));
80105c90:	83 ec 04             	sub    $0x4,%esp
80105c93:	6a 10                	push   $0x10
80105c95:	6a 00                	push   $0x0
80105c97:	8d 45 e0             	lea    -0x20(%ebp),%eax
80105c9a:	50                   	push   %eax
80105c9b:	e8 cf f5 ff ff       	call   8010526f <memset>
80105ca0:	83 c4 10             	add    $0x10,%esp
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80105ca3:	8b 45 c8             	mov    -0x38(%ebp),%eax
80105ca6:	6a 10                	push   $0x10
80105ca8:	50                   	push   %eax
80105ca9:	8d 45 e0             	lea    -0x20(%ebp),%eax
80105cac:	50                   	push   %eax
80105cad:	ff 75 f4             	push   -0xc(%ebp)
80105cb0:	e8 a2 c3 ff ff       	call   80102057 <writei>
80105cb5:	83 c4 10             	add    $0x10,%esp
80105cb8:	83 f8 10             	cmp    $0x10,%eax
80105cbb:	74 0d                	je     80105cca <sys_unlink+0x151>
    panic("unlink: writei");
80105cbd:	83 ec 0c             	sub    $0xc,%esp
80105cc0:	68 17 89 10 80       	push   $0x80108917
80105cc5:	e8 e9 a8 ff ff       	call   801005b3 <panic>
  if(ip->type == T_DIR){
80105cca:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105ccd:	0f b7 40 50          	movzwl 0x50(%eax),%eax
80105cd1:	66 83 f8 01          	cmp    $0x1,%ax
80105cd5:	75 21                	jne    80105cf8 <sys_unlink+0x17f>
    dp->nlink--;
80105cd7:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105cda:	0f b7 40 56          	movzwl 0x56(%eax),%eax
80105cde:	83 e8 01             	sub    $0x1,%eax
80105ce1:	89 c2                	mov    %eax,%edx
80105ce3:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105ce6:	66 89 50 56          	mov    %dx,0x56(%eax)
    iupdate(dp);
80105cea:	83 ec 0c             	sub    $0xc,%esp
80105ced:	ff 75 f4             	push   -0xc(%ebp)
80105cf0:	e8 44 bb ff ff       	call   80101839 <iupdate>
80105cf5:	83 c4 10             	add    $0x10,%esp
  }
  iunlockput(dp);
80105cf8:	83 ec 0c             	sub    $0xc,%esp
80105cfb:	ff 75 f4             	push   -0xc(%ebp)
80105cfe:	e8 44 bf ff ff       	call   80101c47 <iunlockput>
80105d03:	83 c4 10             	add    $0x10,%esp

  ip->nlink--;
80105d06:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105d09:	0f b7 40 56          	movzwl 0x56(%eax),%eax
80105d0d:	83 e8 01             	sub    $0x1,%eax
80105d10:	89 c2                	mov    %eax,%edx
80105d12:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105d15:	66 89 50 56          	mov    %dx,0x56(%eax)
  iupdate(ip);
80105d19:	83 ec 0c             	sub    $0xc,%esp
80105d1c:	ff 75 f0             	push   -0x10(%ebp)
80105d1f:	e8 15 bb ff ff       	call   80101839 <iupdate>
80105d24:	83 c4 10             	add    $0x10,%esp
  iunlockput(ip);
80105d27:	83 ec 0c             	sub    $0xc,%esp
80105d2a:	ff 75 f0             	push   -0x10(%ebp)
80105d2d:	e8 15 bf ff ff       	call   80101c47 <iunlockput>
80105d32:	83 c4 10             	add    $0x10,%esp

  end_op();
80105d35:	e8 74 d8 ff ff       	call   801035ae <end_op>

  return 0;
80105d3a:	b8 00 00 00 00       	mov    $0x0,%eax
80105d3f:	eb 1c                	jmp    80105d5d <sys_unlink+0x1e4>
    goto bad;
80105d41:	90                   	nop
80105d42:	eb 01                	jmp    80105d45 <sys_unlink+0x1cc>
    goto bad;
80105d44:	90                   	nop

bad:
  iunlockput(dp);
80105d45:	83 ec 0c             	sub    $0xc,%esp
80105d48:	ff 75 f4             	push   -0xc(%ebp)
80105d4b:	e8 f7 be ff ff       	call   80101c47 <iunlockput>
80105d50:	83 c4 10             	add    $0x10,%esp
  end_op();
80105d53:	e8 56 d8 ff ff       	call   801035ae <end_op>
  return -1;
80105d58:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105d5d:	c9                   	leave
80105d5e:	c3                   	ret

80105d5f <create>:

static struct inode*
create(char *path, short type, short major, short minor)
{
80105d5f:	55                   	push   %ebp
80105d60:	89 e5                	mov    %esp,%ebp
80105d62:	83 ec 38             	sub    $0x38,%esp
80105d65:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80105d68:	8b 55 10             	mov    0x10(%ebp),%edx
80105d6b:	8b 45 14             	mov    0x14(%ebp),%eax
80105d6e:	66 89 4d d4          	mov    %cx,-0x2c(%ebp)
80105d72:	66 89 55 d0          	mov    %dx,-0x30(%ebp)
80105d76:	66 89 45 cc          	mov    %ax,-0x34(%ebp)
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
80105d7a:	83 ec 08             	sub    $0x8,%esp
80105d7d:	8d 45 e2             	lea    -0x1e(%ebp),%eax
80105d80:	50                   	push   %eax
80105d81:	ff 75 08             	push   0x8(%ebp)
80105d84:	e8 dc c7 ff ff       	call   80102565 <nameiparent>
80105d89:	83 c4 10             	add    $0x10,%esp
80105d8c:	89 45 f4             	mov    %eax,-0xc(%ebp)
80105d8f:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80105d93:	75 0a                	jne    80105d9f <create+0x40>
    return 0;
80105d95:	b8 00 00 00 00       	mov    $0x0,%eax
80105d9a:	e9 8e 01 00 00       	jmp    80105f2d <create+0x1ce>
  ilock(dp);
80105d9f:	83 ec 0c             	sub    $0xc,%esp
80105da2:	ff 75 f4             	push   -0xc(%ebp)
80105da5:	e8 6c bc ff ff       	call   80101a16 <ilock>
80105daa:	83 c4 10             	add    $0x10,%esp

  if((ip = dirlookup(dp, name, 0)) != 0){
80105dad:	83 ec 04             	sub    $0x4,%esp
80105db0:	6a 00                	push   $0x0
80105db2:	8d 45 e2             	lea    -0x1e(%ebp),%eax
80105db5:	50                   	push   %eax
80105db6:	ff 75 f4             	push   -0xc(%ebp)
80105db9:	e8 3a c4 ff ff       	call   801021f8 <dirlookup>
80105dbe:	83 c4 10             	add    $0x10,%esp
80105dc1:	89 45 f0             	mov    %eax,-0x10(%ebp)
80105dc4:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80105dc8:	74 50                	je     80105e1a <create+0xbb>
    iunlockput(dp);
80105dca:	83 ec 0c             	sub    $0xc,%esp
80105dcd:	ff 75 f4             	push   -0xc(%ebp)
80105dd0:	e8 72 be ff ff       	call   80101c47 <iunlockput>
80105dd5:	83 c4 10             	add    $0x10,%esp
    ilock(ip);
80105dd8:	83 ec 0c             	sub    $0xc,%esp
80105ddb:	ff 75 f0             	push   -0x10(%ebp)
80105dde:	e8 33 bc ff ff       	call   80101a16 <ilock>
80105de3:	83 c4 10             	add    $0x10,%esp
    if(type == T_FILE && ip->type == T_FILE)
80105de6:	66 83 7d d4 02       	cmpw   $0x2,-0x2c(%ebp)
80105deb:	75 15                	jne    80105e02 <create+0xa3>
80105ded:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105df0:	0f b7 40 50          	movzwl 0x50(%eax),%eax
80105df4:	66 83 f8 02          	cmp    $0x2,%ax
80105df8:	75 08                	jne    80105e02 <create+0xa3>
      return ip;
80105dfa:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105dfd:	e9 2b 01 00 00       	jmp    80105f2d <create+0x1ce>
    iunlockput(ip);
80105e02:	83 ec 0c             	sub    $0xc,%esp
80105e05:	ff 75 f0             	push   -0x10(%ebp)
80105e08:	e8 3a be ff ff       	call   80101c47 <iunlockput>
80105e0d:	83 c4 10             	add    $0x10,%esp
    return 0;
80105e10:	b8 00 00 00 00       	mov    $0x0,%eax
80105e15:	e9 13 01 00 00       	jmp    80105f2d <create+0x1ce>
  }

  if((ip = ialloc(dp->dev, type)) == 0)
80105e1a:	0f bf 55 d4          	movswl -0x2c(%ebp),%edx
80105e1e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105e21:	8b 00                	mov    (%eax),%eax
80105e23:	83 ec 08             	sub    $0x8,%esp
80105e26:	52                   	push   %edx
80105e27:	50                   	push   %eax
80105e28:	e8 36 b9 ff ff       	call   80101763 <ialloc>
80105e2d:	83 c4 10             	add    $0x10,%esp
80105e30:	89 45 f0             	mov    %eax,-0x10(%ebp)
80105e33:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80105e37:	75 0d                	jne    80105e46 <create+0xe7>
    panic("create: ialloc");
80105e39:	83 ec 0c             	sub    $0xc,%esp
80105e3c:	68 26 89 10 80       	push   $0x80108926
80105e41:	e8 6d a7 ff ff       	call   801005b3 <panic>

  ilock(ip);
80105e46:	83 ec 0c             	sub    $0xc,%esp
80105e49:	ff 75 f0             	push   -0x10(%ebp)
80105e4c:	e8 c5 bb ff ff       	call   80101a16 <ilock>
80105e51:	83 c4 10             	add    $0x10,%esp
  ip->major = major;
80105e54:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105e57:	0f b7 55 d0          	movzwl -0x30(%ebp),%edx
80105e5b:	66 89 50 52          	mov    %dx,0x52(%eax)
  ip->minor = minor;
80105e5f:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105e62:	0f b7 55 cc          	movzwl -0x34(%ebp),%edx
80105e66:	66 89 50 54          	mov    %dx,0x54(%eax)
  ip->nlink = 1;
80105e6a:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105e6d:	66 c7 40 56 01 00    	movw   $0x1,0x56(%eax)
  iupdate(ip);
80105e73:	83 ec 0c             	sub    $0xc,%esp
80105e76:	ff 75 f0             	push   -0x10(%ebp)
80105e79:	e8 bb b9 ff ff       	call   80101839 <iupdate>
80105e7e:	83 c4 10             	add    $0x10,%esp

  if(type == T_DIR){  // Create . and .. entries.
80105e81:	66 83 7d d4 01       	cmpw   $0x1,-0x2c(%ebp)
80105e86:	75 6a                	jne    80105ef2 <create+0x193>
    dp->nlink++;  // for ".."
80105e88:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105e8b:	0f b7 40 56          	movzwl 0x56(%eax),%eax
80105e8f:	83 c0 01             	add    $0x1,%eax
80105e92:	89 c2                	mov    %eax,%edx
80105e94:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105e97:	66 89 50 56          	mov    %dx,0x56(%eax)
    iupdate(dp);
80105e9b:	83 ec 0c             	sub    $0xc,%esp
80105e9e:	ff 75 f4             	push   -0xc(%ebp)
80105ea1:	e8 93 b9 ff ff       	call   80101839 <iupdate>
80105ea6:	83 c4 10             	add    $0x10,%esp
    // No ip->nlink++ for ".": avoid cyclic ref count.
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
80105ea9:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105eac:	8b 40 04             	mov    0x4(%eax),%eax
80105eaf:	83 ec 04             	sub    $0x4,%esp
80105eb2:	50                   	push   %eax
80105eb3:	68 00 89 10 80       	push   $0x80108900
80105eb8:	ff 75 f0             	push   -0x10(%ebp)
80105ebb:	e8 f2 c3 ff ff       	call   801022b2 <dirlink>
80105ec0:	83 c4 10             	add    $0x10,%esp
80105ec3:	85 c0                	test   %eax,%eax
80105ec5:	78 1e                	js     80105ee5 <create+0x186>
80105ec7:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105eca:	8b 40 04             	mov    0x4(%eax),%eax
80105ecd:	83 ec 04             	sub    $0x4,%esp
80105ed0:	50                   	push   %eax
80105ed1:	68 02 89 10 80       	push   $0x80108902
80105ed6:	ff 75 f0             	push   -0x10(%ebp)
80105ed9:	e8 d4 c3 ff ff       	call   801022b2 <dirlink>
80105ede:	83 c4 10             	add    $0x10,%esp
80105ee1:	85 c0                	test   %eax,%eax
80105ee3:	79 0d                	jns    80105ef2 <create+0x193>
      panic("create dots");
80105ee5:	83 ec 0c             	sub    $0xc,%esp
80105ee8:	68 35 89 10 80       	push   $0x80108935
80105eed:	e8 c1 a6 ff ff       	call   801005b3 <panic>
  }

  if(dirlink(dp, name, ip->inum) < 0)
80105ef2:	8b 45 f0             	mov    -0x10(%ebp),%eax
80105ef5:	8b 40 04             	mov    0x4(%eax),%eax
80105ef8:	83 ec 04             	sub    $0x4,%esp
80105efb:	50                   	push   %eax
80105efc:	8d 45 e2             	lea    -0x1e(%ebp),%eax
80105eff:	50                   	push   %eax
80105f00:	ff 75 f4             	push   -0xc(%ebp)
80105f03:	e8 aa c3 ff ff       	call   801022b2 <dirlink>
80105f08:	83 c4 10             	add    $0x10,%esp
80105f0b:	85 c0                	test   %eax,%eax
80105f0d:	79 0d                	jns    80105f1c <create+0x1bd>
    panic("create: dirlink");
80105f0f:	83 ec 0c             	sub    $0xc,%esp
80105f12:	68 41 89 10 80       	push   $0x80108941
80105f17:	e8 97 a6 ff ff       	call   801005b3 <panic>

  iunlockput(dp);
80105f1c:	83 ec 0c             	sub    $0xc,%esp
80105f1f:	ff 75 f4             	push   -0xc(%ebp)
80105f22:	e8 20 bd ff ff       	call   80101c47 <iunlockput>
80105f27:	83 c4 10             	add    $0x10,%esp

  return ip;
80105f2a:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
80105f2d:	c9                   	leave
80105f2e:	c3                   	ret

80105f2f <sys_open>:

int
sys_open(void)
{
80105f2f:	55                   	push   %ebp
80105f30:	89 e5                	mov    %esp,%ebp
80105f32:	83 ec 28             	sub    $0x28,%esp
  char *path;
  int fd, omode;
  struct file *f;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
80105f35:	83 ec 08             	sub    $0x8,%esp
80105f38:	8d 45 e8             	lea    -0x18(%ebp),%eax
80105f3b:	50                   	push   %eax
80105f3c:	6a 00                	push   $0x0
80105f3e:	e8 ec f6 ff ff       	call   8010562f <argstr>
80105f43:	83 c4 10             	add    $0x10,%esp
80105f46:	85 c0                	test   %eax,%eax
80105f48:	78 15                	js     80105f5f <sys_open+0x30>
80105f4a:	83 ec 08             	sub    $0x8,%esp
80105f4d:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80105f50:	50                   	push   %eax
80105f51:	6a 01                	push   $0x1
80105f53:	e8 42 f6 ff ff       	call   8010559a <argint>
80105f58:	83 c4 10             	add    $0x10,%esp
80105f5b:	85 c0                	test   %eax,%eax
80105f5d:	79 0a                	jns    80105f69 <sys_open+0x3a>
    return -1;
80105f5f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105f64:	e9 62 01 00 00       	jmp    801060cb <sys_open+0x19c>

  begin_op();
80105f69:	e8 b4 d5 ff ff       	call   80103522 <begin_op>

  if(omode & O_CREATE){
80105f6e:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80105f71:	25 00 02 00 00       	and    $0x200,%eax
80105f76:	85 c0                	test   %eax,%eax
80105f78:	74 2a                	je     80105fa4 <sys_open+0x75>
    ip = create(path, T_FILE, 0, 0);
80105f7a:	8b 45 e8             	mov    -0x18(%ebp),%eax
80105f7d:	6a 00                	push   $0x0
80105f7f:	6a 00                	push   $0x0
80105f81:	6a 02                	push   $0x2
80105f83:	50                   	push   %eax
80105f84:	e8 d6 fd ff ff       	call   80105d5f <create>
80105f89:	83 c4 10             	add    $0x10,%esp
80105f8c:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(ip == 0){
80105f8f:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80105f93:	75 75                	jne    8010600a <sys_open+0xdb>
      end_op();
80105f95:	e8 14 d6 ff ff       	call   801035ae <end_op>
      return -1;
80105f9a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105f9f:	e9 27 01 00 00       	jmp    801060cb <sys_open+0x19c>
    }
  } else {
    if((ip = namei(path)) == 0){
80105fa4:	8b 45 e8             	mov    -0x18(%ebp),%eax
80105fa7:	83 ec 0c             	sub    $0xc,%esp
80105faa:	50                   	push   %eax
80105fab:	e8 99 c5 ff ff       	call   80102549 <namei>
80105fb0:	83 c4 10             	add    $0x10,%esp
80105fb3:	89 45 f4             	mov    %eax,-0xc(%ebp)
80105fb6:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80105fba:	75 0f                	jne    80105fcb <sys_open+0x9c>
      end_op();
80105fbc:	e8 ed d5 ff ff       	call   801035ae <end_op>
      return -1;
80105fc1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105fc6:	e9 00 01 00 00       	jmp    801060cb <sys_open+0x19c>
    }
    ilock(ip);
80105fcb:	83 ec 0c             	sub    $0xc,%esp
80105fce:	ff 75 f4             	push   -0xc(%ebp)
80105fd1:	e8 40 ba ff ff       	call   80101a16 <ilock>
80105fd6:	83 c4 10             	add    $0x10,%esp
    if(ip->type == T_DIR && omode != O_RDONLY){
80105fd9:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105fdc:	0f b7 40 50          	movzwl 0x50(%eax),%eax
80105fe0:	66 83 f8 01          	cmp    $0x1,%ax
80105fe4:	75 24                	jne    8010600a <sys_open+0xdb>
80105fe6:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80105fe9:	85 c0                	test   %eax,%eax
80105feb:	74 1d                	je     8010600a <sys_open+0xdb>
      iunlockput(ip);
80105fed:	83 ec 0c             	sub    $0xc,%esp
80105ff0:	ff 75 f4             	push   -0xc(%ebp)
80105ff3:	e8 4f bc ff ff       	call   80101c47 <iunlockput>
80105ff8:	83 c4 10             	add    $0x10,%esp
      end_op();
80105ffb:	e8 ae d5 ff ff       	call   801035ae <end_op>
      return -1;
80106000:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106005:	e9 c1 00 00 00       	jmp    801060cb <sys_open+0x19c>
    }
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
8010600a:	e8 0f b0 ff ff       	call   8010101e <filealloc>
8010600f:	89 45 f0             	mov    %eax,-0x10(%ebp)
80106012:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80106016:	74 17                	je     8010602f <sys_open+0x100>
80106018:	83 ec 0c             	sub    $0xc,%esp
8010601b:	ff 75 f0             	push   -0x10(%ebp)
8010601e:	e8 35 f7 ff ff       	call   80105758 <fdalloc>
80106023:	83 c4 10             	add    $0x10,%esp
80106026:	89 45 ec             	mov    %eax,-0x14(%ebp)
80106029:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
8010602d:	79 2e                	jns    8010605d <sys_open+0x12e>
    if(f)
8010602f:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80106033:	74 0e                	je     80106043 <sys_open+0x114>
      fileclose(f);
80106035:	83 ec 0c             	sub    $0xc,%esp
80106038:	ff 75 f0             	push   -0x10(%ebp)
8010603b:	e8 9c b0 ff ff       	call   801010dc <fileclose>
80106040:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
80106043:	83 ec 0c             	sub    $0xc,%esp
80106046:	ff 75 f4             	push   -0xc(%ebp)
80106049:	e8 f9 bb ff ff       	call   80101c47 <iunlockput>
8010604e:	83 c4 10             	add    $0x10,%esp
    end_op();
80106051:	e8 58 d5 ff ff       	call   801035ae <end_op>
    return -1;
80106056:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010605b:	eb 6e                	jmp    801060cb <sys_open+0x19c>
  }
  iunlock(ip);
8010605d:	83 ec 0c             	sub    $0xc,%esp
80106060:	ff 75 f4             	push   -0xc(%ebp)
80106063:	e8 c1 ba ff ff       	call   80101b29 <iunlock>
80106068:	83 c4 10             	add    $0x10,%esp
  end_op();
8010606b:	e8 3e d5 ff ff       	call   801035ae <end_op>

  f->type = FD_INODE;
80106070:	8b 45 f0             	mov    -0x10(%ebp),%eax
80106073:	c7 00 02 00 00 00    	movl   $0x2,(%eax)
  f->ip = ip;
80106079:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010607c:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010607f:	89 50 10             	mov    %edx,0x10(%eax)
  f->off = 0;
80106082:	8b 45 f0             	mov    -0x10(%ebp),%eax
80106085:	c7 40 14 00 00 00 00 	movl   $0x0,0x14(%eax)
  f->readable = !(omode & O_WRONLY);
8010608c:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010608f:	83 e0 01             	and    $0x1,%eax
80106092:	83 e0 01             	and    $0x1,%eax
80106095:	83 f0 01             	xor    $0x1,%eax
80106098:	89 c2                	mov    %eax,%edx
8010609a:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010609d:	88 50 08             	mov    %dl,0x8(%eax)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
801060a0:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801060a3:	83 e0 01             	and    $0x1,%eax
801060a6:	85 c0                	test   %eax,%eax
801060a8:	75 0a                	jne    801060b4 <sys_open+0x185>
801060aa:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801060ad:	83 e0 02             	and    $0x2,%eax
801060b0:	85 c0                	test   %eax,%eax
801060b2:	74 07                	je     801060bb <sys_open+0x18c>
801060b4:	b8 01 00 00 00       	mov    $0x1,%eax
801060b9:	eb 05                	jmp    801060c0 <sys_open+0x191>
801060bb:	b8 00 00 00 00       	mov    $0x0,%eax
801060c0:	89 c2                	mov    %eax,%edx
801060c2:	8b 45 f0             	mov    -0x10(%ebp),%eax
801060c5:	88 50 09             	mov    %dl,0x9(%eax)
  return fd;
801060c8:	8b 45 ec             	mov    -0x14(%ebp),%eax
}
801060cb:	c9                   	leave
801060cc:	c3                   	ret

801060cd <sys_mkdir>:

int
sys_mkdir(void)
{
801060cd:	55                   	push   %ebp
801060ce:	89 e5                	mov    %esp,%ebp
801060d0:	83 ec 18             	sub    $0x18,%esp
  char *path;
  struct inode *ip;

  begin_op();
801060d3:	e8 4a d4 ff ff       	call   80103522 <begin_op>
  if(argstr(0, &path) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
801060d8:	83 ec 08             	sub    $0x8,%esp
801060db:	8d 45 f0             	lea    -0x10(%ebp),%eax
801060de:	50                   	push   %eax
801060df:	6a 00                	push   $0x0
801060e1:	e8 49 f5 ff ff       	call   8010562f <argstr>
801060e6:	83 c4 10             	add    $0x10,%esp
801060e9:	85 c0                	test   %eax,%eax
801060eb:	78 1b                	js     80106108 <sys_mkdir+0x3b>
801060ed:	8b 45 f0             	mov    -0x10(%ebp),%eax
801060f0:	6a 00                	push   $0x0
801060f2:	6a 00                	push   $0x0
801060f4:	6a 01                	push   $0x1
801060f6:	50                   	push   %eax
801060f7:	e8 63 fc ff ff       	call   80105d5f <create>
801060fc:	83 c4 10             	add    $0x10,%esp
801060ff:	89 45 f4             	mov    %eax,-0xc(%ebp)
80106102:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80106106:	75 0c                	jne    80106114 <sys_mkdir+0x47>
    end_op();
80106108:	e8 a1 d4 ff ff       	call   801035ae <end_op>
    return -1;
8010610d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106112:	eb 18                	jmp    8010612c <sys_mkdir+0x5f>
  }
  iunlockput(ip);
80106114:	83 ec 0c             	sub    $0xc,%esp
80106117:	ff 75 f4             	push   -0xc(%ebp)
8010611a:	e8 28 bb ff ff       	call   80101c47 <iunlockput>
8010611f:	83 c4 10             	add    $0x10,%esp
  end_op();
80106122:	e8 87 d4 ff ff       	call   801035ae <end_op>
  return 0;
80106127:	b8 00 00 00 00       	mov    $0x0,%eax
}
8010612c:	c9                   	leave
8010612d:	c3                   	ret

8010612e <sys_mknod>:

int
sys_mknod(void)
{
8010612e:	55                   	push   %ebp
8010612f:	89 e5                	mov    %esp,%ebp
80106131:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip;
  char *path;
  int major, minor;

  begin_op();
80106134:	e8 e9 d3 ff ff       	call   80103522 <begin_op>
  if((argstr(0, &path)) < 0 ||
80106139:	83 ec 08             	sub    $0x8,%esp
8010613c:	8d 45 f0             	lea    -0x10(%ebp),%eax
8010613f:	50                   	push   %eax
80106140:	6a 00                	push   $0x0
80106142:	e8 e8 f4 ff ff       	call   8010562f <argstr>
80106147:	83 c4 10             	add    $0x10,%esp
8010614a:	85 c0                	test   %eax,%eax
8010614c:	78 4f                	js     8010619d <sys_mknod+0x6f>
     argint(1, &major) < 0 ||
8010614e:	83 ec 08             	sub    $0x8,%esp
80106151:	8d 45 ec             	lea    -0x14(%ebp),%eax
80106154:	50                   	push   %eax
80106155:	6a 01                	push   $0x1
80106157:	e8 3e f4 ff ff       	call   8010559a <argint>
8010615c:	83 c4 10             	add    $0x10,%esp
  if((argstr(0, &path)) < 0 ||
8010615f:	85 c0                	test   %eax,%eax
80106161:	78 3a                	js     8010619d <sys_mknod+0x6f>
     argint(2, &minor) < 0 ||
80106163:	83 ec 08             	sub    $0x8,%esp
80106166:	8d 45 e8             	lea    -0x18(%ebp),%eax
80106169:	50                   	push   %eax
8010616a:	6a 02                	push   $0x2
8010616c:	e8 29 f4 ff ff       	call   8010559a <argint>
80106171:	83 c4 10             	add    $0x10,%esp
     argint(1, &major) < 0 ||
80106174:	85 c0                	test   %eax,%eax
80106176:	78 25                	js     8010619d <sys_mknod+0x6f>
     (ip = create(path, T_DEV, major, minor)) == 0){
80106178:	8b 45 e8             	mov    -0x18(%ebp),%eax
8010617b:	0f bf c8             	movswl %ax,%ecx
8010617e:	8b 45 ec             	mov    -0x14(%ebp),%eax
80106181:	0f bf d0             	movswl %ax,%edx
80106184:	8b 45 f0             	mov    -0x10(%ebp),%eax
80106187:	51                   	push   %ecx
80106188:	52                   	push   %edx
80106189:	6a 03                	push   $0x3
8010618b:	50                   	push   %eax
8010618c:	e8 ce fb ff ff       	call   80105d5f <create>
80106191:	83 c4 10             	add    $0x10,%esp
80106194:	89 45 f4             	mov    %eax,-0xc(%ebp)
     argint(2, &minor) < 0 ||
80106197:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
8010619b:	75 0c                	jne    801061a9 <sys_mknod+0x7b>
    end_op();
8010619d:	e8 0c d4 ff ff       	call   801035ae <end_op>
    return -1;
801061a2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801061a7:	eb 18                	jmp    801061c1 <sys_mknod+0x93>
  }
  iunlockput(ip);
801061a9:	83 ec 0c             	sub    $0xc,%esp
801061ac:	ff 75 f4             	push   -0xc(%ebp)
801061af:	e8 93 ba ff ff       	call   80101c47 <iunlockput>
801061b4:	83 c4 10             	add    $0x10,%esp
  end_op();
801061b7:	e8 f2 d3 ff ff       	call   801035ae <end_op>
  return 0;
801061bc:	b8 00 00 00 00       	mov    $0x0,%eax
}
801061c1:	c9                   	leave
801061c2:	c3                   	ret

801061c3 <sys_chdir>:

int
sys_chdir(void)
{
801061c3:	55                   	push   %ebp
801061c4:	89 e5                	mov    %esp,%ebp
801061c6:	83 ec 18             	sub    $0x18,%esp
  char *path;
  struct inode *ip;
  struct proc *curproc = myproc();
801061c9:	e8 b7 e0 ff ff       	call   80104285 <myproc>
801061ce:	89 45 f4             	mov    %eax,-0xc(%ebp)
  
  begin_op();
801061d1:	e8 4c d3 ff ff       	call   80103522 <begin_op>
  if(argstr(0, &path) < 0 || (ip = namei(path)) == 0){
801061d6:	83 ec 08             	sub    $0x8,%esp
801061d9:	8d 45 ec             	lea    -0x14(%ebp),%eax
801061dc:	50                   	push   %eax
801061dd:	6a 00                	push   $0x0
801061df:	e8 4b f4 ff ff       	call   8010562f <argstr>
801061e4:	83 c4 10             	add    $0x10,%esp
801061e7:	85 c0                	test   %eax,%eax
801061e9:	78 18                	js     80106203 <sys_chdir+0x40>
801061eb:	8b 45 ec             	mov    -0x14(%ebp),%eax
801061ee:	83 ec 0c             	sub    $0xc,%esp
801061f1:	50                   	push   %eax
801061f2:	e8 52 c3 ff ff       	call   80102549 <namei>
801061f7:	83 c4 10             	add    $0x10,%esp
801061fa:	89 45 f0             	mov    %eax,-0x10(%ebp)
801061fd:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80106201:	75 0c                	jne    8010620f <sys_chdir+0x4c>
    end_op();
80106203:	e8 a6 d3 ff ff       	call   801035ae <end_op>
    return -1;
80106208:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010620d:	eb 68                	jmp    80106277 <sys_chdir+0xb4>
  }
  ilock(ip);
8010620f:	83 ec 0c             	sub    $0xc,%esp
80106212:	ff 75 f0             	push   -0x10(%ebp)
80106215:	e8 fc b7 ff ff       	call   80101a16 <ilock>
8010621a:	83 c4 10             	add    $0x10,%esp
  if(ip->type != T_DIR){
8010621d:	8b 45 f0             	mov    -0x10(%ebp),%eax
80106220:	0f b7 40 50          	movzwl 0x50(%eax),%eax
80106224:	66 83 f8 01          	cmp    $0x1,%ax
80106228:	74 1a                	je     80106244 <sys_chdir+0x81>
    iunlockput(ip);
8010622a:	83 ec 0c             	sub    $0xc,%esp
8010622d:	ff 75 f0             	push   -0x10(%ebp)
80106230:	e8 12 ba ff ff       	call   80101c47 <iunlockput>
80106235:	83 c4 10             	add    $0x10,%esp
    end_op();
80106238:	e8 71 d3 ff ff       	call   801035ae <end_op>
    return -1;
8010623d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106242:	eb 33                	jmp    80106277 <sys_chdir+0xb4>
  }
  iunlock(ip);
80106244:	83 ec 0c             	sub    $0xc,%esp
80106247:	ff 75 f0             	push   -0x10(%ebp)
8010624a:	e8 da b8 ff ff       	call   80101b29 <iunlock>
8010624f:	83 c4 10             	add    $0x10,%esp
  iput(curproc->cwd);
80106252:	8b 45 f4             	mov    -0xc(%ebp),%eax
80106255:	8b 40 68             	mov    0x68(%eax),%eax
80106258:	83 ec 0c             	sub    $0xc,%esp
8010625b:	50                   	push   %eax
8010625c:	e8 16 b9 ff ff       	call   80101b77 <iput>
80106261:	83 c4 10             	add    $0x10,%esp
  end_op();
80106264:	e8 45 d3 ff ff       	call   801035ae <end_op>
  curproc->cwd = ip;
80106269:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010626c:	8b 55 f0             	mov    -0x10(%ebp),%edx
8010626f:	89 50 68             	mov    %edx,0x68(%eax)
  return 0;
80106272:	b8 00 00 00 00       	mov    $0x0,%eax
}
80106277:	c9                   	leave
80106278:	c3                   	ret

80106279 <sys_exec>:

int
sys_exec(void)
{
80106279:	55                   	push   %ebp
8010627a:	89 e5                	mov    %esp,%ebp
8010627c:	81 ec 98 00 00 00    	sub    $0x98,%esp
  char *path, *argv[MAXARG];
  int i;
  uint uargv, uarg;

  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
80106282:	83 ec 08             	sub    $0x8,%esp
80106285:	8d 45 f0             	lea    -0x10(%ebp),%eax
80106288:	50                   	push   %eax
80106289:	6a 00                	push   $0x0
8010628b:	e8 9f f3 ff ff       	call   8010562f <argstr>
80106290:	83 c4 10             	add    $0x10,%esp
80106293:	85 c0                	test   %eax,%eax
80106295:	78 18                	js     801062af <sys_exec+0x36>
80106297:	83 ec 08             	sub    $0x8,%esp
8010629a:	8d 85 6c ff ff ff    	lea    -0x94(%ebp),%eax
801062a0:	50                   	push   %eax
801062a1:	6a 01                	push   $0x1
801062a3:	e8 f2 f2 ff ff       	call   8010559a <argint>
801062a8:	83 c4 10             	add    $0x10,%esp
801062ab:	85 c0                	test   %eax,%eax
801062ad:	79 0a                	jns    801062b9 <sys_exec+0x40>
    return -1;
801062af:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801062b4:	e9 c6 00 00 00       	jmp    8010637f <sys_exec+0x106>
  }
  memset(argv, 0, sizeof(argv));
801062b9:	83 ec 04             	sub    $0x4,%esp
801062bc:	68 80 00 00 00       	push   $0x80
801062c1:	6a 00                	push   $0x0
801062c3:	8d 85 70 ff ff ff    	lea    -0x90(%ebp),%eax
801062c9:	50                   	push   %eax
801062ca:	e8 a0 ef ff ff       	call   8010526f <memset>
801062cf:	83 c4 10             	add    $0x10,%esp
  for(i=0;; i++){
801062d2:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    if(i >= NELEM(argv))
801062d9:	8b 45 f4             	mov    -0xc(%ebp),%eax
801062dc:	83 f8 1f             	cmp    $0x1f,%eax
801062df:	76 0a                	jbe    801062eb <sys_exec+0x72>
      return -1;
801062e1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801062e6:	e9 94 00 00 00       	jmp    8010637f <sys_exec+0x106>
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)
801062eb:	8b 45 f4             	mov    -0xc(%ebp),%eax
801062ee:	c1 e0 02             	shl    $0x2,%eax
801062f1:	89 c2                	mov    %eax,%edx
801062f3:	8b 85 6c ff ff ff    	mov    -0x94(%ebp),%eax
801062f9:	01 c2                	add    %eax,%edx
801062fb:	83 ec 08             	sub    $0x8,%esp
801062fe:	8d 85 68 ff ff ff    	lea    -0x98(%ebp),%eax
80106304:	50                   	push   %eax
80106305:	52                   	push   %edx
80106306:	e8 ee f1 ff ff       	call   801054f9 <fetchint>
8010630b:	83 c4 10             	add    $0x10,%esp
8010630e:	85 c0                	test   %eax,%eax
80106310:	79 07                	jns    80106319 <sys_exec+0xa0>
      return -1;
80106312:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106317:	eb 66                	jmp    8010637f <sys_exec+0x106>
    if(uarg == 0){
80106319:	8b 85 68 ff ff ff    	mov    -0x98(%ebp),%eax
8010631f:	85 c0                	test   %eax,%eax
80106321:	75 27                	jne    8010634a <sys_exec+0xd1>
      argv[i] = 0;
80106323:	8b 45 f4             	mov    -0xc(%ebp),%eax
80106326:	c7 84 85 70 ff ff ff 	movl   $0x0,-0x90(%ebp,%eax,4)
8010632d:	00 00 00 00 
      break;
80106331:	90                   	nop
    }
    if(fetchstr(uarg, &argv[i]) < 0)
      return -1;
  }
  return exec(path, argv);
80106332:	8b 45 f0             	mov    -0x10(%ebp),%eax
80106335:	83 ec 08             	sub    $0x8,%esp
80106338:	8d 95 70 ff ff ff    	lea    -0x90(%ebp),%edx
8010633e:	52                   	push   %edx
8010633f:	50                   	push   %eax
80106340:	e8 7c a8 ff ff       	call   80100bc1 <exec>
80106345:	83 c4 10             	add    $0x10,%esp
80106348:	eb 35                	jmp    8010637f <sys_exec+0x106>
    if(fetchstr(uarg, &argv[i]) < 0)
8010634a:	8d 85 70 ff ff ff    	lea    -0x90(%ebp),%eax
80106350:	8b 55 f4             	mov    -0xc(%ebp),%edx
80106353:	c1 e2 02             	shl    $0x2,%edx
80106356:	01 c2                	add    %eax,%edx
80106358:	8b 85 68 ff ff ff    	mov    -0x98(%ebp),%eax
8010635e:	83 ec 08             	sub    $0x8,%esp
80106361:	52                   	push   %edx
80106362:	50                   	push   %eax
80106363:	e8 d0 f1 ff ff       	call   80105538 <fetchstr>
80106368:	83 c4 10             	add    $0x10,%esp
8010636b:	85 c0                	test   %eax,%eax
8010636d:	79 07                	jns    80106376 <sys_exec+0xfd>
      return -1;
8010636f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106374:	eb 09                	jmp    8010637f <sys_exec+0x106>
  for(i=0;; i++){
80106376:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    if(i >= NELEM(argv))
8010637a:	e9 5a ff ff ff       	jmp    801062d9 <sys_exec+0x60>
}
8010637f:	c9                   	leave
80106380:	c3                   	ret

80106381 <sys_pipe>:

int
sys_pipe(void)
{
80106381:	55                   	push   %ebp
80106382:	89 e5                	mov    %esp,%ebp
80106384:	83 ec 28             	sub    $0x28,%esp
  int *fd;
  struct file *rf, *wf;
  int fd0, fd1;

  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
80106387:	83 ec 04             	sub    $0x4,%esp
8010638a:	6a 08                	push   $0x8
8010638c:	8d 45 ec             	lea    -0x14(%ebp),%eax
8010638f:	50                   	push   %eax
80106390:	6a 00                	push   $0x0
80106392:	e8 30 f2 ff ff       	call   801055c7 <argptr>
80106397:	83 c4 10             	add    $0x10,%esp
8010639a:	85 c0                	test   %eax,%eax
8010639c:	79 0a                	jns    801063a8 <sys_pipe+0x27>
    return -1;
8010639e:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801063a3:	e9 ae 00 00 00       	jmp    80106456 <sys_pipe+0xd5>
  if(pipealloc(&rf, &wf) < 0)
801063a8:	83 ec 08             	sub    $0x8,%esp
801063ab:	8d 45 e4             	lea    -0x1c(%ebp),%eax
801063ae:	50                   	push   %eax
801063af:	8d 45 e8             	lea    -0x18(%ebp),%eax
801063b2:	50                   	push   %eax
801063b3:	e8 0a da ff ff       	call   80103dc2 <pipealloc>
801063b8:	83 c4 10             	add    $0x10,%esp
801063bb:	85 c0                	test   %eax,%eax
801063bd:	79 0a                	jns    801063c9 <sys_pipe+0x48>
    return -1;
801063bf:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801063c4:	e9 8d 00 00 00       	jmp    80106456 <sys_pipe+0xd5>
  fd0 = -1;
801063c9:	c7 45 f4 ff ff ff ff 	movl   $0xffffffff,-0xc(%ebp)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
801063d0:	8b 45 e8             	mov    -0x18(%ebp),%eax
801063d3:	83 ec 0c             	sub    $0xc,%esp
801063d6:	50                   	push   %eax
801063d7:	e8 7c f3 ff ff       	call   80105758 <fdalloc>
801063dc:	83 c4 10             	add    $0x10,%esp
801063df:	89 45 f4             	mov    %eax,-0xc(%ebp)
801063e2:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
801063e6:	78 18                	js     80106400 <sys_pipe+0x7f>
801063e8:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801063eb:	83 ec 0c             	sub    $0xc,%esp
801063ee:	50                   	push   %eax
801063ef:	e8 64 f3 ff ff       	call   80105758 <fdalloc>
801063f4:	83 c4 10             	add    $0x10,%esp
801063f7:	89 45 f0             	mov    %eax,-0x10(%ebp)
801063fa:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
801063fe:	79 3e                	jns    8010643e <sys_pipe+0xbd>
    if(fd0 >= 0)
80106400:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80106404:	78 13                	js     80106419 <sys_pipe+0x98>
      myproc()->ofile[fd0] = 0;
80106406:	e8 7a de ff ff       	call   80104285 <myproc>
8010640b:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010640e:	83 c2 08             	add    $0x8,%edx
80106411:	c7 44 90 08 00 00 00 	movl   $0x0,0x8(%eax,%edx,4)
80106418:	00 
    fileclose(rf);
80106419:	8b 45 e8             	mov    -0x18(%ebp),%eax
8010641c:	83 ec 0c             	sub    $0xc,%esp
8010641f:	50                   	push   %eax
80106420:	e8 b7 ac ff ff       	call   801010dc <fileclose>
80106425:	83 c4 10             	add    $0x10,%esp
    fileclose(wf);
80106428:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010642b:	83 ec 0c             	sub    $0xc,%esp
8010642e:	50                   	push   %eax
8010642f:	e8 a8 ac ff ff       	call   801010dc <fileclose>
80106434:	83 c4 10             	add    $0x10,%esp
    return -1;
80106437:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010643c:	eb 18                	jmp    80106456 <sys_pipe+0xd5>
  }
  fd[0] = fd0;
8010643e:	8b 45 ec             	mov    -0x14(%ebp),%eax
80106441:	8b 55 f4             	mov    -0xc(%ebp),%edx
80106444:	89 10                	mov    %edx,(%eax)
  fd[1] = fd1;
80106446:	8b 45 ec             	mov    -0x14(%ebp),%eax
80106449:	8d 50 04             	lea    0x4(%eax),%edx
8010644c:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010644f:	89 02                	mov    %eax,(%edx)
  return 0;
80106451:	b8 00 00 00 00       	mov    $0x0,%eax
}
80106456:	c9                   	leave
80106457:	c3                   	ret

80106458 <sys_fork>:
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
80106458:	55                   	push   %ebp
80106459:	89 e5                	mov    %esp,%ebp
8010645b:	83 ec 08             	sub    $0x8,%esp
  return fork();
8010645e:	e8 21 e1 ff ff       	call   80104584 <fork>
}
80106463:	c9                   	leave
80106464:	c3                   	ret

80106465 <sys_exit>:

int
sys_exit(void)
{
80106465:	55                   	push   %ebp
80106466:	89 e5                	mov    %esp,%ebp
80106468:	83 ec 08             	sub    $0x8,%esp
  exit();
8010646b:	e8 8d e2 ff ff       	call   801046fd <exit>
  return 0;  // not reached
80106470:	b8 00 00 00 00       	mov    $0x0,%eax
}
80106475:	c9                   	leave
80106476:	c3                   	ret

80106477 <sys_wait>:

int
sys_wait(void)
{
80106477:	55                   	push   %ebp
80106478:	89 e5                	mov    %esp,%ebp
8010647a:	83 ec 08             	sub    $0x8,%esp
  return wait();
8010647d:	e8 15 e4 ff ff       	call   80104897 <wait>
}
80106482:	c9                   	leave
80106483:	c3                   	ret

80106484 <sys_kill>:

int
sys_kill(void)
{
80106484:	55                   	push   %ebp
80106485:	89 e5                	mov    %esp,%ebp
80106487:	83 ec 18             	sub    $0x18,%esp
  int pid;

  if(argint(0, &pid) < 0)
8010648a:	83 ec 08             	sub    $0x8,%esp
8010648d:	8d 45 f4             	lea    -0xc(%ebp),%eax
80106490:	50                   	push   %eax
80106491:	6a 00                	push   $0x0
80106493:	e8 02 f1 ff ff       	call   8010559a <argint>
80106498:	83 c4 10             	add    $0x10,%esp
8010649b:	85 c0                	test   %eax,%eax
8010649d:	79 07                	jns    801064a6 <sys_kill+0x22>
    return -1;
8010649f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801064a4:	eb 0f                	jmp    801064b5 <sys_kill+0x31>
  return kill(pid);
801064a6:	8b 45 f4             	mov    -0xc(%ebp),%eax
801064a9:	83 ec 0c             	sub    $0xc,%esp
801064ac:	50                   	push   %eax
801064ad:	e8 14 e8 ff ff       	call   80104cc6 <kill>
801064b2:	83 c4 10             	add    $0x10,%esp
}
801064b5:	c9                   	leave
801064b6:	c3                   	ret

801064b7 <sys_getpid>:

int
sys_getpid(void)
{
801064b7:	55                   	push   %ebp
801064b8:	89 e5                	mov    %esp,%ebp
801064ba:	83 ec 08             	sub    $0x8,%esp
  return myproc()->pid;
801064bd:	e8 c3 dd ff ff       	call   80104285 <myproc>
801064c2:	8b 40 10             	mov    0x10(%eax),%eax
}
801064c5:	c9                   	leave
801064c6:	c3                   	ret

801064c7 <sys_sbrk>:

int
sys_sbrk(void)
{
801064c7:	55                   	push   %ebp
801064c8:	89 e5                	mov    %esp,%ebp
801064ca:	83 ec 18             	sub    $0x18,%esp
  int addr;
  int n;

  if(argint(0, &n) < 0)
801064cd:	83 ec 08             	sub    $0x8,%esp
801064d0:	8d 45 f0             	lea    -0x10(%ebp),%eax
801064d3:	50                   	push   %eax
801064d4:	6a 00                	push   $0x0
801064d6:	e8 bf f0 ff ff       	call   8010559a <argint>
801064db:	83 c4 10             	add    $0x10,%esp
801064de:	85 c0                	test   %eax,%eax
801064e0:	79 07                	jns    801064e9 <sys_sbrk+0x22>
    return -1;
801064e2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801064e7:	eb 27                	jmp    80106510 <sys_sbrk+0x49>
  addr = myproc()->sz;
801064e9:	e8 97 dd ff ff       	call   80104285 <myproc>
801064ee:	8b 00                	mov    (%eax),%eax
801064f0:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(growproc(n) < 0)
801064f3:	8b 45 f0             	mov    -0x10(%ebp),%eax
801064f6:	83 ec 0c             	sub    $0xc,%esp
801064f9:	50                   	push   %eax
801064fa:	e8 ea df ff ff       	call   801044e9 <growproc>
801064ff:	83 c4 10             	add    $0x10,%esp
80106502:	85 c0                	test   %eax,%eax
80106504:	79 07                	jns    8010650d <sys_sbrk+0x46>
    return -1;
80106506:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010650b:	eb 03                	jmp    80106510 <sys_sbrk+0x49>
  return addr;
8010650d:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
80106510:	c9                   	leave
80106511:	c3                   	ret

80106512 <sys_sleep>:

int
sys_sleep(void)
{
80106512:	55                   	push   %ebp
80106513:	89 e5                	mov    %esp,%ebp
80106515:	83 ec 18             	sub    $0x18,%esp
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
80106518:	83 ec 08             	sub    $0x8,%esp
8010651b:	8d 45 f0             	lea    -0x10(%ebp),%eax
8010651e:	50                   	push   %eax
8010651f:	6a 00                	push   $0x0
80106521:	e8 74 f0 ff ff       	call   8010559a <argint>
80106526:	83 c4 10             	add    $0x10,%esp
80106529:	85 c0                	test   %eax,%eax
8010652b:	79 07                	jns    80106534 <sys_sleep+0x22>
    return -1;
8010652d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106532:	eb 76                	jmp    801065aa <sys_sleep+0x98>
  acquire(&tickslock);
80106534:	83 ec 0c             	sub    $0xc,%esp
80106537:	68 c0 54 11 80       	push   $0x801154c0
8010653c:	e8 a8 ea ff ff       	call   80104fe9 <acquire>
80106541:	83 c4 10             	add    $0x10,%esp
  ticks0 = ticks;
80106544:	a1 f4 54 11 80       	mov    0x801154f4,%eax
80106549:	89 45 f4             	mov    %eax,-0xc(%ebp)
  while(ticks - ticks0 < n){
8010654c:	eb 38                	jmp    80106586 <sys_sleep+0x74>
    if(myproc()->killed){
8010654e:	e8 32 dd ff ff       	call   80104285 <myproc>
80106553:	8b 40 24             	mov    0x24(%eax),%eax
80106556:	85 c0                	test   %eax,%eax
80106558:	74 17                	je     80106571 <sys_sleep+0x5f>
      release(&tickslock);
8010655a:	83 ec 0c             	sub    $0xc,%esp
8010655d:	68 c0 54 11 80       	push   $0x801154c0
80106562:	e8 f0 ea ff ff       	call   80105057 <release>
80106567:	83 c4 10             	add    $0x10,%esp
      return -1;
8010656a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010656f:	eb 39                	jmp    801065aa <sys_sleep+0x98>
    }
    sleep(&ticks, &tickslock);
80106571:	83 ec 08             	sub    $0x8,%esp
80106574:	68 c0 54 11 80       	push   $0x801154c0
80106579:	68 f4 54 11 80       	push   $0x801154f4
8010657e:	e8 25 e6 ff ff       	call   80104ba8 <sleep>
80106583:	83 c4 10             	add    $0x10,%esp
  while(ticks - ticks0 < n){
80106586:	a1 f4 54 11 80       	mov    0x801154f4,%eax
8010658b:	2b 45 f4             	sub    -0xc(%ebp),%eax
8010658e:	8b 55 f0             	mov    -0x10(%ebp),%edx
80106591:	39 d0                	cmp    %edx,%eax
80106593:	72 b9                	jb     8010654e <sys_sleep+0x3c>
  }
  release(&tickslock);
80106595:	83 ec 0c             	sub    $0xc,%esp
80106598:	68 c0 54 11 80       	push   $0x801154c0
8010659d:	e8 b5 ea ff ff       	call   80105057 <release>
801065a2:	83 c4 10             	add    $0x10,%esp
  return 0;
801065a5:	b8 00 00 00 00       	mov    $0x0,%eax
}
801065aa:	c9                   	leave
801065ab:	c3                   	ret

801065ac <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
801065ac:	55                   	push   %ebp
801065ad:	89 e5                	mov    %esp,%ebp
801065af:	83 ec 18             	sub    $0x18,%esp
  uint xticks;

  acquire(&tickslock);
801065b2:	83 ec 0c             	sub    $0xc,%esp
801065b5:	68 c0 54 11 80       	push   $0x801154c0
801065ba:	e8 2a ea ff ff       	call   80104fe9 <acquire>
801065bf:	83 c4 10             	add    $0x10,%esp
  xticks = ticks;
801065c2:	a1 f4 54 11 80       	mov    0x801154f4,%eax
801065c7:	89 45 f4             	mov    %eax,-0xc(%ebp)
  release(&tickslock);
801065ca:	83 ec 0c             	sub    $0xc,%esp
801065cd:	68 c0 54 11 80       	push   $0x801154c0
801065d2:	e8 80 ea ff ff       	call   80105057 <release>
801065d7:	83 c4 10             	add    $0x10,%esp
  return xticks;
801065da:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
801065dd:	c9                   	leave
801065de:	c3                   	ret

801065df <sys_getparentname>:

int sys_getparentname(void) 
{
801065df:	55                   	push   %ebp
801065e0:	89 e5                	mov    %esp,%ebp
801065e2:	53                   	push   %ebx
801065e3:	83 ec 14             	sub    $0x14,%esp
  char* parentbuf, *childbuf;
  int parentbufsize, childbufsize;

  if(argstr(0, &parentbuf) < 0 || argstr(1, &childbuf) < 0 || argint(2, &parentbufsize) < 0 || argint(3, &childbufsize) < 0){
801065e6:	83 ec 08             	sub    $0x8,%esp
801065e9:	8d 45 f4             	lea    -0xc(%ebp),%eax
801065ec:	50                   	push   %eax
801065ed:	6a 00                	push   $0x0
801065ef:	e8 3b f0 ff ff       	call   8010562f <argstr>
801065f4:	83 c4 10             	add    $0x10,%esp
801065f7:	85 c0                	test   %eax,%eax
801065f9:	78 3f                	js     8010663a <sys_getparentname+0x5b>
801065fb:	83 ec 08             	sub    $0x8,%esp
801065fe:	8d 45 f0             	lea    -0x10(%ebp),%eax
80106601:	50                   	push   %eax
80106602:	6a 01                	push   $0x1
80106604:	e8 26 f0 ff ff       	call   8010562f <argstr>
80106609:	83 c4 10             	add    $0x10,%esp
8010660c:	85 c0                	test   %eax,%eax
8010660e:	78 2a                	js     8010663a <sys_getparentname+0x5b>
80106610:	83 ec 08             	sub    $0x8,%esp
80106613:	8d 45 ec             	lea    -0x14(%ebp),%eax
80106616:	50                   	push   %eax
80106617:	6a 02                	push   $0x2
80106619:	e8 7c ef ff ff       	call   8010559a <argint>
8010661e:	83 c4 10             	add    $0x10,%esp
80106621:	85 c0                	test   %eax,%eax
80106623:	78 15                	js     8010663a <sys_getparentname+0x5b>
80106625:	83 ec 08             	sub    $0x8,%esp
80106628:	8d 45 e8             	lea    -0x18(%ebp),%eax
8010662b:	50                   	push   %eax
8010662c:	6a 03                	push   $0x3
8010662e:	e8 67 ef ff ff       	call   8010559a <argint>
80106633:	83 c4 10             	add    $0x10,%esp
80106636:	85 c0                	test   %eax,%eax
80106638:	79 07                	jns    80106641 <sys_getparentname+0x62>
    return -1;
8010663a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010663f:	eb 18                	jmp    80106659 <sys_getparentname+0x7a>
  }

  return getparentname(parentbuf, childbuf, parentbufsize, childbufsize);
80106641:	8b 5d e8             	mov    -0x18(%ebp),%ebx
80106644:	8b 4d ec             	mov    -0x14(%ebp),%ecx
80106647:	8b 55 f0             	mov    -0x10(%ebp),%edx
8010664a:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010664d:	53                   	push   %ebx
8010664e:	51                   	push   %ecx
8010664f:	52                   	push   %edx
80106650:	50                   	push   %eax
80106651:	e8 c7 e1 ff ff       	call   8010481d <getparentname>
80106656:	83 c4 10             	add    $0x10,%esp
80106659:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010665c:	c9                   	leave
8010665d:	c3                   	ret

8010665e <alltraps>:

  # vectors.S sends all traps here.
.globl alltraps
alltraps:
  # Build trap frame.
  pushl %ds
8010665e:	1e                   	push   %ds
  pushl %es
8010665f:	06                   	push   %es
  pushl %fs
80106660:	0f a0                	push   %fs
  pushl %gs
80106662:	0f a8                	push   %gs
  pushal
80106664:	60                   	pusha
  
  # Set up data segments.
  movw $(SEG_KDATA<<3), %ax
80106665:	66 b8 10 00          	mov    $0x10,%ax
  movw %ax, %ds
80106669:	8e d8                	mov    %eax,%ds
  movw %ax, %es
8010666b:	8e c0                	mov    %eax,%es

  # Call trap(tf), where tf=%esp
  pushl %esp
8010666d:	54                   	push   %esp
  call trap
8010666e:	e8 d7 01 00 00       	call   8010684a <trap>
  addl $4, %esp
80106673:	83 c4 04             	add    $0x4,%esp

80106676 <trapret>:

  # Return falls through to trapret...
.globl trapret
trapret:
  popal
80106676:	61                   	popa
  popl %gs
80106677:	0f a9                	pop    %gs
  popl %fs
80106679:	0f a1                	pop    %fs
  popl %es
8010667b:	07                   	pop    %es
  popl %ds
8010667c:	1f                   	pop    %ds
  addl $0x8, %esp  # trapno and errcode
8010667d:	83 c4 08             	add    $0x8,%esp
  iret
80106680:	cf                   	iret

80106681 <lidt>:
{
80106681:	55                   	push   %ebp
80106682:	89 e5                	mov    %esp,%ebp
80106684:	83 ec 10             	sub    $0x10,%esp
  pd[0] = size-1;
80106687:	8b 45 0c             	mov    0xc(%ebp),%eax
8010668a:	83 e8 01             	sub    $0x1,%eax
8010668d:	66 89 45 fa          	mov    %ax,-0x6(%ebp)
  pd[1] = (uint)p;
80106691:	8b 45 08             	mov    0x8(%ebp),%eax
80106694:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  pd[2] = (uint)p >> 16;
80106698:	8b 45 08             	mov    0x8(%ebp),%eax
8010669b:	c1 e8 10             	shr    $0x10,%eax
8010669e:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
  asm volatile("lidt (%0)" : : "r" (pd));
801066a2:	8d 45 fa             	lea    -0x6(%ebp),%eax
801066a5:	0f 01 18             	lidtl  (%eax)
}
801066a8:	90                   	nop
801066a9:	c9                   	leave
801066aa:	c3                   	ret

801066ab <rcr2>:

static inline uint
rcr2(void)
{
801066ab:	55                   	push   %ebp
801066ac:	89 e5                	mov    %esp,%ebp
801066ae:	83 ec 10             	sub    $0x10,%esp
  uint val;
  asm volatile("movl %%cr2,%0" : "=r" (val));
801066b1:	0f 20 d0             	mov    %cr2,%eax
801066b4:	89 45 fc             	mov    %eax,-0x4(%ebp)
  return val;
801066b7:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
801066ba:	c9                   	leave
801066bb:	c3                   	ret

801066bc <tvinit>:
struct spinlock tickslock;
uint ticks;

void
tvinit(void)
{
801066bc:	55                   	push   %ebp
801066bd:	89 e5                	mov    %esp,%ebp
801066bf:	83 ec 18             	sub    $0x18,%esp
  int i;

  for(i = 0; i < 256; i++)
801066c2:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
801066c9:	e9 c3 00 00 00       	jmp    80106791 <tvinit+0xd5>
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
801066ce:	8b 45 f4             	mov    -0xc(%ebp),%eax
801066d1:	8b 04 85 7c b0 10 80 	mov    -0x7fef4f84(,%eax,4),%eax
801066d8:	89 c2                	mov    %eax,%edx
801066da:	8b 45 f4             	mov    -0xc(%ebp),%eax
801066dd:	66 89 14 c5 c0 4c 11 	mov    %dx,-0x7feeb340(,%eax,8)
801066e4:	80 
801066e5:	8b 45 f4             	mov    -0xc(%ebp),%eax
801066e8:	66 c7 04 c5 c2 4c 11 	movw   $0x8,-0x7feeb33e(,%eax,8)
801066ef:	80 08 00 
801066f2:	8b 45 f4             	mov    -0xc(%ebp),%eax
801066f5:	0f b6 14 c5 c4 4c 11 	movzbl -0x7feeb33c(,%eax,8),%edx
801066fc:	80 
801066fd:	83 e2 e0             	and    $0xffffffe0,%edx
80106700:	88 14 c5 c4 4c 11 80 	mov    %dl,-0x7feeb33c(,%eax,8)
80106707:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010670a:	0f b6 14 c5 c4 4c 11 	movzbl -0x7feeb33c(,%eax,8),%edx
80106711:	80 
80106712:	83 e2 1f             	and    $0x1f,%edx
80106715:	88 14 c5 c4 4c 11 80 	mov    %dl,-0x7feeb33c(,%eax,8)
8010671c:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010671f:	0f b6 14 c5 c5 4c 11 	movzbl -0x7feeb33b(,%eax,8),%edx
80106726:	80 
80106727:	83 e2 f0             	and    $0xfffffff0,%edx
8010672a:	83 ca 0e             	or     $0xe,%edx
8010672d:	88 14 c5 c5 4c 11 80 	mov    %dl,-0x7feeb33b(,%eax,8)
80106734:	8b 45 f4             	mov    -0xc(%ebp),%eax
80106737:	0f b6 14 c5 c5 4c 11 	movzbl -0x7feeb33b(,%eax,8),%edx
8010673e:	80 
8010673f:	83 e2 ef             	and    $0xffffffef,%edx
80106742:	88 14 c5 c5 4c 11 80 	mov    %dl,-0x7feeb33b(,%eax,8)
80106749:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010674c:	0f b6 14 c5 c5 4c 11 	movzbl -0x7feeb33b(,%eax,8),%edx
80106753:	80 
80106754:	83 e2 9f             	and    $0xffffff9f,%edx
80106757:	88 14 c5 c5 4c 11 80 	mov    %dl,-0x7feeb33b(,%eax,8)
8010675e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80106761:	0f b6 14 c5 c5 4c 11 	movzbl -0x7feeb33b(,%eax,8),%edx
80106768:	80 
80106769:	83 ca 80             	or     $0xffffff80,%edx
8010676c:	88 14 c5 c5 4c 11 80 	mov    %dl,-0x7feeb33b(,%eax,8)
80106773:	8b 45 f4             	mov    -0xc(%ebp),%eax
80106776:	8b 04 85 7c b0 10 80 	mov    -0x7fef4f84(,%eax,4),%eax
8010677d:	c1 e8 10             	shr    $0x10,%eax
80106780:	89 c2                	mov    %eax,%edx
80106782:	8b 45 f4             	mov    -0xc(%ebp),%eax
80106785:	66 89 14 c5 c6 4c 11 	mov    %dx,-0x7feeb33a(,%eax,8)
8010678c:	80 
  for(i = 0; i < 256; i++)
8010678d:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80106791:	81 7d f4 ff 00 00 00 	cmpl   $0xff,-0xc(%ebp)
80106798:	0f 8e 30 ff ff ff    	jle    801066ce <tvinit+0x12>
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
8010679e:	a1 7c b1 10 80       	mov    0x8010b17c,%eax
801067a3:	66 a3 c0 4e 11 80    	mov    %ax,0x80114ec0
801067a9:	66 c7 05 c2 4e 11 80 	movw   $0x8,0x80114ec2
801067b0:	08 00 
801067b2:	0f b6 05 c4 4e 11 80 	movzbl 0x80114ec4,%eax
801067b9:	83 e0 e0             	and    $0xffffffe0,%eax
801067bc:	a2 c4 4e 11 80       	mov    %al,0x80114ec4
801067c1:	0f b6 05 c4 4e 11 80 	movzbl 0x80114ec4,%eax
801067c8:	83 e0 1f             	and    $0x1f,%eax
801067cb:	a2 c4 4e 11 80       	mov    %al,0x80114ec4
801067d0:	0f b6 05 c5 4e 11 80 	movzbl 0x80114ec5,%eax
801067d7:	83 c8 0f             	or     $0xf,%eax
801067da:	a2 c5 4e 11 80       	mov    %al,0x80114ec5
801067df:	0f b6 05 c5 4e 11 80 	movzbl 0x80114ec5,%eax
801067e6:	83 e0 ef             	and    $0xffffffef,%eax
801067e9:	a2 c5 4e 11 80       	mov    %al,0x80114ec5
801067ee:	0f b6 05 c5 4e 11 80 	movzbl 0x80114ec5,%eax
801067f5:	83 c8 60             	or     $0x60,%eax
801067f8:	a2 c5 4e 11 80       	mov    %al,0x80114ec5
801067fd:	0f b6 05 c5 4e 11 80 	movzbl 0x80114ec5,%eax
80106804:	83 c8 80             	or     $0xffffff80,%eax
80106807:	a2 c5 4e 11 80       	mov    %al,0x80114ec5
8010680c:	a1 7c b1 10 80       	mov    0x8010b17c,%eax
80106811:	c1 e8 10             	shr    $0x10,%eax
80106814:	66 a3 c6 4e 11 80    	mov    %ax,0x80114ec6

  initlock(&tickslock, "time");
8010681a:	83 ec 08             	sub    $0x8,%esp
8010681d:	68 54 89 10 80       	push   $0x80108954
80106822:	68 c0 54 11 80       	push   $0x801154c0
80106827:	e8 9b e7 ff ff       	call   80104fc7 <initlock>
8010682c:	83 c4 10             	add    $0x10,%esp
}
8010682f:	90                   	nop
80106830:	c9                   	leave
80106831:	c3                   	ret

80106832 <idtinit>:

void
idtinit(void)
{
80106832:	55                   	push   %ebp
80106833:	89 e5                	mov    %esp,%ebp
  lidt(idt, sizeof(idt));
80106835:	68 00 08 00 00       	push   $0x800
8010683a:	68 c0 4c 11 80       	push   $0x80114cc0
8010683f:	e8 3d fe ff ff       	call   80106681 <lidt>
80106844:	83 c4 08             	add    $0x8,%esp
}
80106847:	90                   	nop
80106848:	c9                   	leave
80106849:	c3                   	ret

8010684a <trap>:

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
8010684a:	55                   	push   %ebp
8010684b:	89 e5                	mov    %esp,%ebp
8010684d:	57                   	push   %edi
8010684e:	56                   	push   %esi
8010684f:	53                   	push   %ebx
80106850:	83 ec 1c             	sub    $0x1c,%esp
  if(tf->trapno == T_SYSCALL){
80106853:	8b 45 08             	mov    0x8(%ebp),%eax
80106856:	8b 40 30             	mov    0x30(%eax),%eax
80106859:	83 f8 40             	cmp    $0x40,%eax
8010685c:	75 3b                	jne    80106899 <trap+0x4f>
    if(myproc()->killed)
8010685e:	e8 22 da ff ff       	call   80104285 <myproc>
80106863:	8b 40 24             	mov    0x24(%eax),%eax
80106866:	85 c0                	test   %eax,%eax
80106868:	74 05                	je     8010686f <trap+0x25>
      exit();
8010686a:	e8 8e de ff ff       	call   801046fd <exit>
    myproc()->tf = tf;
8010686f:	e8 11 da ff ff       	call   80104285 <myproc>
80106874:	8b 55 08             	mov    0x8(%ebp),%edx
80106877:	89 50 18             	mov    %edx,0x18(%eax)
    syscall();
8010687a:	e8 e7 ed ff ff       	call   80105666 <syscall>
    if(myproc()->killed)
8010687f:	e8 01 da ff ff       	call   80104285 <myproc>
80106884:	8b 40 24             	mov    0x24(%eax),%eax
80106887:	85 c0                	test   %eax,%eax
80106889:	0f 84 5a 02 00 00    	je     80106ae9 <trap+0x29f>
      exit();
8010688f:	e8 69 de ff ff       	call   801046fd <exit>
    return;
80106894:	e9 50 02 00 00       	jmp    80106ae9 <trap+0x29f>
  }

  switch(tf->trapno){
80106899:	8b 45 08             	mov    0x8(%ebp),%eax
8010689c:	8b 40 30             	mov    0x30(%eax),%eax
8010689f:	83 f8 3f             	cmp    $0x3f,%eax
801068a2:	0f 84 dd 00 00 00    	je     80106985 <trap+0x13b>
801068a8:	83 f8 3f             	cmp    $0x3f,%eax
801068ab:	0f 87 03 01 00 00    	ja     801069b4 <trap+0x16a>
801068b1:	83 f8 2f             	cmp    $0x2f,%eax
801068b4:	0f 84 ae 01 00 00    	je     80106a68 <trap+0x21e>
801068ba:	83 f8 2f             	cmp    $0x2f,%eax
801068bd:	0f 87 f1 00 00 00    	ja     801069b4 <trap+0x16a>
801068c3:	83 f8 2e             	cmp    $0x2e,%eax
801068c6:	0f 84 8c 00 00 00    	je     80106958 <trap+0x10e>
801068cc:	83 f8 2e             	cmp    $0x2e,%eax
801068cf:	0f 87 df 00 00 00    	ja     801069b4 <trap+0x16a>
801068d5:	83 f8 27             	cmp    $0x27,%eax
801068d8:	0f 84 a7 00 00 00    	je     80106985 <trap+0x13b>
801068de:	83 f8 27             	cmp    $0x27,%eax
801068e1:	0f 87 cd 00 00 00    	ja     801069b4 <trap+0x16a>
801068e7:	83 f8 24             	cmp    $0x24,%eax
801068ea:	0f 84 86 00 00 00    	je     80106976 <trap+0x12c>
801068f0:	83 f8 24             	cmp    $0x24,%eax
801068f3:	0f 87 bb 00 00 00    	ja     801069b4 <trap+0x16a>
801068f9:	83 f8 20             	cmp    $0x20,%eax
801068fc:	74 0a                	je     80106908 <trap+0xbe>
801068fe:	83 f8 21             	cmp    $0x21,%eax
80106901:	74 64                	je     80106967 <trap+0x11d>
80106903:	e9 ac 00 00 00       	jmp    801069b4 <trap+0x16a>
  case T_IRQ0 + IRQ_TIMER:
    if(cpuid() == 0){
80106908:	e8 e5 d8 ff ff       	call   801041f2 <cpuid>
8010690d:	85 c0                	test   %eax,%eax
8010690f:	75 3d                	jne    8010694e <trap+0x104>
      acquire(&tickslock);
80106911:	83 ec 0c             	sub    $0xc,%esp
80106914:	68 c0 54 11 80       	push   $0x801154c0
80106919:	e8 cb e6 ff ff       	call   80104fe9 <acquire>
8010691e:	83 c4 10             	add    $0x10,%esp
      ticks++;
80106921:	a1 f4 54 11 80       	mov    0x801154f4,%eax
80106926:	83 c0 01             	add    $0x1,%eax
80106929:	a3 f4 54 11 80       	mov    %eax,0x801154f4
      wakeup(&ticks);
8010692e:	83 ec 0c             	sub    $0xc,%esp
80106931:	68 f4 54 11 80       	push   $0x801154f4
80106936:	e8 54 e3 ff ff       	call   80104c8f <wakeup>
8010693b:	83 c4 10             	add    $0x10,%esp
      release(&tickslock);
8010693e:	83 ec 0c             	sub    $0xc,%esp
80106941:	68 c0 54 11 80       	push   $0x801154c0
80106946:	e8 0c e7 ff ff       	call   80105057 <release>
8010694b:	83 c4 10             	add    $0x10,%esp
    }
    lapiceoi();
8010694e:	e8 ab c6 ff ff       	call   80102ffe <lapiceoi>
    break;
80106953:	e9 11 01 00 00       	jmp    80106a69 <trap+0x21f>
  case T_IRQ0 + IRQ_IDE:
    ideintr();
80106958:	e8 25 bf ff ff       	call   80102882 <ideintr>
    lapiceoi();
8010695d:	e8 9c c6 ff ff       	call   80102ffe <lapiceoi>
    break;
80106962:	e9 02 01 00 00       	jmp    80106a69 <trap+0x21f>
  case T_IRQ0 + IRQ_IDE+1:
    // Bochs generates spurious IDE1 interrupts.
    break;
  case T_IRQ0 + IRQ_KBD:
    kbdintr();
80106967:	e8 dd c4 ff ff       	call   80102e49 <kbdintr>
    lapiceoi();
8010696c:	e8 8d c6 ff ff       	call   80102ffe <lapiceoi>
    break;
80106971:	e9 f3 00 00 00       	jmp    80106a69 <trap+0x21f>
  case T_IRQ0 + IRQ_COM1:
    uartintr();
80106976:	e8 42 03 00 00       	call   80106cbd <uartintr>
    lapiceoi();
8010697b:	e8 7e c6 ff ff       	call   80102ffe <lapiceoi>
    break;
80106980:	e9 e4 00 00 00       	jmp    80106a69 <trap+0x21f>
  case T_IRQ0 + 7:
  case T_IRQ0 + IRQ_SPURIOUS:
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
80106985:	8b 45 08             	mov    0x8(%ebp),%eax
80106988:	8b 70 38             	mov    0x38(%eax),%esi
            cpuid(), tf->cs, tf->eip);
8010698b:	8b 45 08             	mov    0x8(%ebp),%eax
8010698e:	0f b7 40 3c          	movzwl 0x3c(%eax),%eax
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
80106992:	0f b7 d8             	movzwl %ax,%ebx
80106995:	e8 58 d8 ff ff       	call   801041f2 <cpuid>
8010699a:	56                   	push   %esi
8010699b:	53                   	push   %ebx
8010699c:	50                   	push   %eax
8010699d:	68 5c 89 10 80       	push   $0x8010895c
801069a2:	e8 57 9a ff ff       	call   801003fe <cprintf>
801069a7:	83 c4 10             	add    $0x10,%esp
    lapiceoi();
801069aa:	e8 4f c6 ff ff       	call   80102ffe <lapiceoi>
    break;
801069af:	e9 b5 00 00 00       	jmp    80106a69 <trap+0x21f>

  //PAGEBREAK: 13
  default:
    if(myproc() == 0 || (tf->cs&3) == 0){
801069b4:	e8 cc d8 ff ff       	call   80104285 <myproc>
801069b9:	85 c0                	test   %eax,%eax
801069bb:	74 11                	je     801069ce <trap+0x184>
801069bd:	8b 45 08             	mov    0x8(%ebp),%eax
801069c0:	0f b7 40 3c          	movzwl 0x3c(%eax),%eax
801069c4:	0f b7 c0             	movzwl %ax,%eax
801069c7:	83 e0 03             	and    $0x3,%eax
801069ca:	85 c0                	test   %eax,%eax
801069cc:	75 39                	jne    80106a07 <trap+0x1bd>
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
801069ce:	e8 d8 fc ff ff       	call   801066ab <rcr2>
801069d3:	89 c3                	mov    %eax,%ebx
801069d5:	8b 45 08             	mov    0x8(%ebp),%eax
801069d8:	8b 70 38             	mov    0x38(%eax),%esi
801069db:	e8 12 d8 ff ff       	call   801041f2 <cpuid>
801069e0:	8b 55 08             	mov    0x8(%ebp),%edx
801069e3:	8b 52 30             	mov    0x30(%edx),%edx
801069e6:	83 ec 0c             	sub    $0xc,%esp
801069e9:	53                   	push   %ebx
801069ea:	56                   	push   %esi
801069eb:	50                   	push   %eax
801069ec:	52                   	push   %edx
801069ed:	68 80 89 10 80       	push   $0x80108980
801069f2:	e8 07 9a ff ff       	call   801003fe <cprintf>
801069f7:	83 c4 20             	add    $0x20,%esp
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
801069fa:	83 ec 0c             	sub    $0xc,%esp
801069fd:	68 b2 89 10 80       	push   $0x801089b2
80106a02:	e8 ac 9b ff ff       	call   801005b3 <panic>
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80106a07:	e8 9f fc ff ff       	call   801066ab <rcr2>
80106a0c:	89 c6                	mov    %eax,%esi
80106a0e:	8b 45 08             	mov    0x8(%ebp),%eax
80106a11:	8b 40 38             	mov    0x38(%eax),%eax
80106a14:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80106a17:	e8 d6 d7 ff ff       	call   801041f2 <cpuid>
80106a1c:	89 c3                	mov    %eax,%ebx
80106a1e:	8b 45 08             	mov    0x8(%ebp),%eax
80106a21:	8b 48 34             	mov    0x34(%eax),%ecx
80106a24:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80106a27:	8b 45 08             	mov    0x8(%ebp),%eax
80106a2a:	8b 78 30             	mov    0x30(%eax),%edi
            "eip 0x%x addr 0x%x--kill proc\n",
            myproc()->pid, myproc()->name, tf->trapno,
80106a2d:	e8 53 d8 ff ff       	call   80104285 <myproc>
80106a32:	8d 50 6c             	lea    0x6c(%eax),%edx
80106a35:	89 55 dc             	mov    %edx,-0x24(%ebp)
80106a38:	e8 48 d8 ff ff       	call   80104285 <myproc>
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80106a3d:	8b 40 10             	mov    0x10(%eax),%eax
80106a40:	56                   	push   %esi
80106a41:	ff 75 e4             	push   -0x1c(%ebp)
80106a44:	53                   	push   %ebx
80106a45:	ff 75 e0             	push   -0x20(%ebp)
80106a48:	57                   	push   %edi
80106a49:	ff 75 dc             	push   -0x24(%ebp)
80106a4c:	50                   	push   %eax
80106a4d:	68 b8 89 10 80       	push   $0x801089b8
80106a52:	e8 a7 99 ff ff       	call   801003fe <cprintf>
80106a57:	83 c4 20             	add    $0x20,%esp
            tf->err, cpuid(), tf->eip, rcr2());
    myproc()->killed = 1;
80106a5a:	e8 26 d8 ff ff       	call   80104285 <myproc>
80106a5f:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
80106a66:	eb 01                	jmp    80106a69 <trap+0x21f>
    break;
80106a68:	90                   	nop
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80106a69:	e8 17 d8 ff ff       	call   80104285 <myproc>
80106a6e:	85 c0                	test   %eax,%eax
80106a70:	74 23                	je     80106a95 <trap+0x24b>
80106a72:	e8 0e d8 ff ff       	call   80104285 <myproc>
80106a77:	8b 40 24             	mov    0x24(%eax),%eax
80106a7a:	85 c0                	test   %eax,%eax
80106a7c:	74 17                	je     80106a95 <trap+0x24b>
80106a7e:	8b 45 08             	mov    0x8(%ebp),%eax
80106a81:	0f b7 40 3c          	movzwl 0x3c(%eax),%eax
80106a85:	0f b7 c0             	movzwl %ax,%eax
80106a88:	83 e0 03             	and    $0x3,%eax
80106a8b:	83 f8 03             	cmp    $0x3,%eax
80106a8e:	75 05                	jne    80106a95 <trap+0x24b>
    exit();
80106a90:	e8 68 dc ff ff       	call   801046fd <exit>

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
80106a95:	e8 eb d7 ff ff       	call   80104285 <myproc>
80106a9a:	85 c0                	test   %eax,%eax
80106a9c:	74 1d                	je     80106abb <trap+0x271>
80106a9e:	e8 e2 d7 ff ff       	call   80104285 <myproc>
80106aa3:	8b 40 0c             	mov    0xc(%eax),%eax
80106aa6:	83 f8 04             	cmp    $0x4,%eax
80106aa9:	75 10                	jne    80106abb <trap+0x271>
     tf->trapno == T_IRQ0+IRQ_TIMER)
80106aab:	8b 45 08             	mov    0x8(%ebp),%eax
80106aae:	8b 40 30             	mov    0x30(%eax),%eax
  if(myproc() && myproc()->state == RUNNING &&
80106ab1:	83 f8 20             	cmp    $0x20,%eax
80106ab4:	75 05                	jne    80106abb <trap+0x271>
    yield();
80106ab6:	e8 6d e0 ff ff       	call   80104b28 <yield>

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80106abb:	e8 c5 d7 ff ff       	call   80104285 <myproc>
80106ac0:	85 c0                	test   %eax,%eax
80106ac2:	74 26                	je     80106aea <trap+0x2a0>
80106ac4:	e8 bc d7 ff ff       	call   80104285 <myproc>
80106ac9:	8b 40 24             	mov    0x24(%eax),%eax
80106acc:	85 c0                	test   %eax,%eax
80106ace:	74 1a                	je     80106aea <trap+0x2a0>
80106ad0:	8b 45 08             	mov    0x8(%ebp),%eax
80106ad3:	0f b7 40 3c          	movzwl 0x3c(%eax),%eax
80106ad7:	0f b7 c0             	movzwl %ax,%eax
80106ada:	83 e0 03             	and    $0x3,%eax
80106add:	83 f8 03             	cmp    $0x3,%eax
80106ae0:	75 08                	jne    80106aea <trap+0x2a0>
    exit();
80106ae2:	e8 16 dc ff ff       	call   801046fd <exit>
80106ae7:	eb 01                	jmp    80106aea <trap+0x2a0>
    return;
80106ae9:	90                   	nop
}
80106aea:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106aed:	5b                   	pop    %ebx
80106aee:	5e                   	pop    %esi
80106aef:	5f                   	pop    %edi
80106af0:	5d                   	pop    %ebp
80106af1:	c3                   	ret

80106af2 <inb>:
{
80106af2:	55                   	push   %ebp
80106af3:	89 e5                	mov    %esp,%ebp
80106af5:	83 ec 14             	sub    $0x14,%esp
80106af8:	8b 45 08             	mov    0x8(%ebp),%eax
80106afb:	66 89 45 ec          	mov    %ax,-0x14(%ebp)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80106aff:	0f b7 45 ec          	movzwl -0x14(%ebp),%eax
80106b03:	89 c2                	mov    %eax,%edx
80106b05:	ec                   	in     (%dx),%al
80106b06:	88 45 ff             	mov    %al,-0x1(%ebp)
  return data;
80106b09:	0f b6 45 ff          	movzbl -0x1(%ebp),%eax
}
80106b0d:	c9                   	leave
80106b0e:	c3                   	ret

80106b0f <outb>:
{
80106b0f:	55                   	push   %ebp
80106b10:	89 e5                	mov    %esp,%ebp
80106b12:	83 ec 08             	sub    $0x8,%esp
80106b15:	8b 55 08             	mov    0x8(%ebp),%edx
80106b18:	8b 45 0c             	mov    0xc(%ebp),%eax
80106b1b:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
80106b1f:	88 45 f8             	mov    %al,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80106b22:	0f b6 45 f8          	movzbl -0x8(%ebp),%eax
80106b26:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
80106b2a:	ee                   	out    %al,(%dx)
}
80106b2b:	90                   	nop
80106b2c:	c9                   	leave
80106b2d:	c3                   	ret

80106b2e <uartinit>:

static int uart;    // is there a uart?

void
uartinit(void)
{
80106b2e:	55                   	push   %ebp
80106b2f:	89 e5                	mov    %esp,%ebp
80106b31:	83 ec 18             	sub    $0x18,%esp
  char *p;

  // Turn off the FIFO
  outb(COM1+2, 0);
80106b34:	6a 00                	push   $0x0
80106b36:	68 fa 03 00 00       	push   $0x3fa
80106b3b:	e8 cf ff ff ff       	call   80106b0f <outb>
80106b40:	83 c4 08             	add    $0x8,%esp

  // 9600 baud, 8 data bits, 1 stop bit, parity off.
  outb(COM1+3, 0x80);    // Unlock divisor
80106b43:	68 80 00 00 00       	push   $0x80
80106b48:	68 fb 03 00 00       	push   $0x3fb
80106b4d:	e8 bd ff ff ff       	call   80106b0f <outb>
80106b52:	83 c4 08             	add    $0x8,%esp
  outb(COM1+0, 115200/9600);
80106b55:	6a 0c                	push   $0xc
80106b57:	68 f8 03 00 00       	push   $0x3f8
80106b5c:	e8 ae ff ff ff       	call   80106b0f <outb>
80106b61:	83 c4 08             	add    $0x8,%esp
  outb(COM1+1, 0);
80106b64:	6a 00                	push   $0x0
80106b66:	68 f9 03 00 00       	push   $0x3f9
80106b6b:	e8 9f ff ff ff       	call   80106b0f <outb>
80106b70:	83 c4 08             	add    $0x8,%esp
  outb(COM1+3, 0x03);    // Lock divisor, 8 data bits.
80106b73:	6a 03                	push   $0x3
80106b75:	68 fb 03 00 00       	push   $0x3fb
80106b7a:	e8 90 ff ff ff       	call   80106b0f <outb>
80106b7f:	83 c4 08             	add    $0x8,%esp
  outb(COM1+4, 0);
80106b82:	6a 00                	push   $0x0
80106b84:	68 fc 03 00 00       	push   $0x3fc
80106b89:	e8 81 ff ff ff       	call   80106b0f <outb>
80106b8e:	83 c4 08             	add    $0x8,%esp
  outb(COM1+1, 0x01);    // Enable receive interrupts.
80106b91:	6a 01                	push   $0x1
80106b93:	68 f9 03 00 00       	push   $0x3f9
80106b98:	e8 72 ff ff ff       	call   80106b0f <outb>
80106b9d:	83 c4 08             	add    $0x8,%esp

  // If status is 0xFF, no serial port.
  if(inb(COM1+5) == 0xFF)
80106ba0:	68 fd 03 00 00       	push   $0x3fd
80106ba5:	e8 48 ff ff ff       	call   80106af2 <inb>
80106baa:	83 c4 04             	add    $0x4,%esp
80106bad:	3c ff                	cmp    $0xff,%al
80106baf:	74 61                	je     80106c12 <uartinit+0xe4>
    return;
  uart = 1;
80106bb1:	c7 05 f8 54 11 80 01 	movl   $0x1,0x801154f8
80106bb8:	00 00 00 

  // Acknowledge pre-existing interrupt conditions;
  // enable interrupts.
  inb(COM1+2);
80106bbb:	68 fa 03 00 00       	push   $0x3fa
80106bc0:	e8 2d ff ff ff       	call   80106af2 <inb>
80106bc5:	83 c4 04             	add    $0x4,%esp
  inb(COM1+0);
80106bc8:	68 f8 03 00 00       	push   $0x3f8
80106bcd:	e8 20 ff ff ff       	call   80106af2 <inb>
80106bd2:	83 c4 04             	add    $0x4,%esp
  ioapicenable(IRQ_COM1, 0);
80106bd5:	83 ec 08             	sub    $0x8,%esp
80106bd8:	6a 00                	push   $0x0
80106bda:	6a 04                	push   $0x4
80106bdc:	e8 3f bf ff ff       	call   80102b20 <ioapicenable>
80106be1:	83 c4 10             	add    $0x10,%esp

  // Announce that we're here.
  for(p="xv6...\n"; *p; p++)
80106be4:	c7 45 f4 fb 89 10 80 	movl   $0x801089fb,-0xc(%ebp)
80106beb:	eb 19                	jmp    80106c06 <uartinit+0xd8>
    uartputc(*p);
80106bed:	8b 45 f4             	mov    -0xc(%ebp),%eax
80106bf0:	0f b6 00             	movzbl (%eax),%eax
80106bf3:	0f be c0             	movsbl %al,%eax
80106bf6:	83 ec 0c             	sub    $0xc,%esp
80106bf9:	50                   	push   %eax
80106bfa:	e8 16 00 00 00       	call   80106c15 <uartputc>
80106bff:	83 c4 10             	add    $0x10,%esp
  for(p="xv6...\n"; *p; p++)
80106c02:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80106c06:	8b 45 f4             	mov    -0xc(%ebp),%eax
80106c09:	0f b6 00             	movzbl (%eax),%eax
80106c0c:	84 c0                	test   %al,%al
80106c0e:	75 dd                	jne    80106bed <uartinit+0xbf>
80106c10:	eb 01                	jmp    80106c13 <uartinit+0xe5>
    return;
80106c12:	90                   	nop
}
80106c13:	c9                   	leave
80106c14:	c3                   	ret

80106c15 <uartputc>:

void
uartputc(int c)
{
80106c15:	55                   	push   %ebp
80106c16:	89 e5                	mov    %esp,%ebp
80106c18:	83 ec 18             	sub    $0x18,%esp
  int i;

  if(!uart)
80106c1b:	a1 f8 54 11 80       	mov    0x801154f8,%eax
80106c20:	85 c0                	test   %eax,%eax
80106c22:	74 53                	je     80106c77 <uartputc+0x62>
    return;
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80106c24:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80106c2b:	eb 11                	jmp    80106c3e <uartputc+0x29>
    microdelay(10);
80106c2d:	83 ec 0c             	sub    $0xc,%esp
80106c30:	6a 0a                	push   $0xa
80106c32:	e8 e2 c3 ff ff       	call   80103019 <microdelay>
80106c37:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80106c3a:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
80106c3e:	83 7d f4 7f          	cmpl   $0x7f,-0xc(%ebp)
80106c42:	7f 1a                	jg     80106c5e <uartputc+0x49>
80106c44:	83 ec 0c             	sub    $0xc,%esp
80106c47:	68 fd 03 00 00       	push   $0x3fd
80106c4c:	e8 a1 fe ff ff       	call   80106af2 <inb>
80106c51:	83 c4 10             	add    $0x10,%esp
80106c54:	0f b6 c0             	movzbl %al,%eax
80106c57:	83 e0 20             	and    $0x20,%eax
80106c5a:	85 c0                	test   %eax,%eax
80106c5c:	74 cf                	je     80106c2d <uartputc+0x18>
  outb(COM1+0, c);
80106c5e:	8b 45 08             	mov    0x8(%ebp),%eax
80106c61:	0f b6 c0             	movzbl %al,%eax
80106c64:	83 ec 08             	sub    $0x8,%esp
80106c67:	50                   	push   %eax
80106c68:	68 f8 03 00 00       	push   $0x3f8
80106c6d:	e8 9d fe ff ff       	call   80106b0f <outb>
80106c72:	83 c4 10             	add    $0x10,%esp
80106c75:	eb 01                	jmp    80106c78 <uartputc+0x63>
    return;
80106c77:	90                   	nop
}
80106c78:	c9                   	leave
80106c79:	c3                   	ret

80106c7a <uartgetc>:

static int
uartgetc(void)
{
80106c7a:	55                   	push   %ebp
80106c7b:	89 e5                	mov    %esp,%ebp
  if(!uart)
80106c7d:	a1 f8 54 11 80       	mov    0x801154f8,%eax
80106c82:	85 c0                	test   %eax,%eax
80106c84:	75 07                	jne    80106c8d <uartgetc+0x13>
    return -1;
80106c86:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106c8b:	eb 2e                	jmp    80106cbb <uartgetc+0x41>
  if(!(inb(COM1+5) & 0x01))
80106c8d:	68 fd 03 00 00       	push   $0x3fd
80106c92:	e8 5b fe ff ff       	call   80106af2 <inb>
80106c97:	83 c4 04             	add    $0x4,%esp
80106c9a:	0f b6 c0             	movzbl %al,%eax
80106c9d:	83 e0 01             	and    $0x1,%eax
80106ca0:	85 c0                	test   %eax,%eax
80106ca2:	75 07                	jne    80106cab <uartgetc+0x31>
    return -1;
80106ca4:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106ca9:	eb 10                	jmp    80106cbb <uartgetc+0x41>
  return inb(COM1+0);
80106cab:	68 f8 03 00 00       	push   $0x3f8
80106cb0:	e8 3d fe ff ff       	call   80106af2 <inb>
80106cb5:	83 c4 04             	add    $0x4,%esp
80106cb8:	0f b6 c0             	movzbl %al,%eax
}
80106cbb:	c9                   	leave
80106cbc:	c3                   	ret

80106cbd <uartintr>:

void
uartintr(void)
{
80106cbd:	55                   	push   %ebp
80106cbe:	89 e5                	mov    %esp,%ebp
80106cc0:	83 ec 08             	sub    $0x8,%esp
  consoleintr(uartgetc);
80106cc3:	83 ec 0c             	sub    $0xc,%esp
80106cc6:	68 7a 6c 10 80       	push   $0x80106c7a
80106ccb:	e8 79 9b ff ff       	call   80100849 <consoleintr>
80106cd0:	83 c4 10             	add    $0x10,%esp
}
80106cd3:	90                   	nop
80106cd4:	c9                   	leave
80106cd5:	c3                   	ret

80106cd6 <vector0>:
# generated by vectors.pl - do not edit
# handlers
.globl alltraps
.globl vector0
vector0:
  pushl $0
80106cd6:	6a 00                	push   $0x0
  pushl $0
80106cd8:	6a 00                	push   $0x0
  jmp alltraps
80106cda:	e9 7f f9 ff ff       	jmp    8010665e <alltraps>

80106cdf <vector1>:
.globl vector1
vector1:
  pushl $0
80106cdf:	6a 00                	push   $0x0
  pushl $1
80106ce1:	6a 01                	push   $0x1
  jmp alltraps
80106ce3:	e9 76 f9 ff ff       	jmp    8010665e <alltraps>

80106ce8 <vector2>:
.globl vector2
vector2:
  pushl $0
80106ce8:	6a 00                	push   $0x0
  pushl $2
80106cea:	6a 02                	push   $0x2
  jmp alltraps
80106cec:	e9 6d f9 ff ff       	jmp    8010665e <alltraps>

80106cf1 <vector3>:
.globl vector3
vector3:
  pushl $0
80106cf1:	6a 00                	push   $0x0
  pushl $3
80106cf3:	6a 03                	push   $0x3
  jmp alltraps
80106cf5:	e9 64 f9 ff ff       	jmp    8010665e <alltraps>

80106cfa <vector4>:
.globl vector4
vector4:
  pushl $0
80106cfa:	6a 00                	push   $0x0
  pushl $4
80106cfc:	6a 04                	push   $0x4
  jmp alltraps
80106cfe:	e9 5b f9 ff ff       	jmp    8010665e <alltraps>

80106d03 <vector5>:
.globl vector5
vector5:
  pushl $0
80106d03:	6a 00                	push   $0x0
  pushl $5
80106d05:	6a 05                	push   $0x5
  jmp alltraps
80106d07:	e9 52 f9 ff ff       	jmp    8010665e <alltraps>

80106d0c <vector6>:
.globl vector6
vector6:
  pushl $0
80106d0c:	6a 00                	push   $0x0
  pushl $6
80106d0e:	6a 06                	push   $0x6
  jmp alltraps
80106d10:	e9 49 f9 ff ff       	jmp    8010665e <alltraps>

80106d15 <vector7>:
.globl vector7
vector7:
  pushl $0
80106d15:	6a 00                	push   $0x0
  pushl $7
80106d17:	6a 07                	push   $0x7
  jmp alltraps
80106d19:	e9 40 f9 ff ff       	jmp    8010665e <alltraps>

80106d1e <vector8>:
.globl vector8
vector8:
  pushl $8
80106d1e:	6a 08                	push   $0x8
  jmp alltraps
80106d20:	e9 39 f9 ff ff       	jmp    8010665e <alltraps>

80106d25 <vector9>:
.globl vector9
vector9:
  pushl $0
80106d25:	6a 00                	push   $0x0
  pushl $9
80106d27:	6a 09                	push   $0x9
  jmp alltraps
80106d29:	e9 30 f9 ff ff       	jmp    8010665e <alltraps>

80106d2e <vector10>:
.globl vector10
vector10:
  pushl $10
80106d2e:	6a 0a                	push   $0xa
  jmp alltraps
80106d30:	e9 29 f9 ff ff       	jmp    8010665e <alltraps>

80106d35 <vector11>:
.globl vector11
vector11:
  pushl $11
80106d35:	6a 0b                	push   $0xb
  jmp alltraps
80106d37:	e9 22 f9 ff ff       	jmp    8010665e <alltraps>

80106d3c <vector12>:
.globl vector12
vector12:
  pushl $12
80106d3c:	6a 0c                	push   $0xc
  jmp alltraps
80106d3e:	e9 1b f9 ff ff       	jmp    8010665e <alltraps>

80106d43 <vector13>:
.globl vector13
vector13:
  pushl $13
80106d43:	6a 0d                	push   $0xd
  jmp alltraps
80106d45:	e9 14 f9 ff ff       	jmp    8010665e <alltraps>

80106d4a <vector14>:
.globl vector14
vector14:
  pushl $14
80106d4a:	6a 0e                	push   $0xe
  jmp alltraps
80106d4c:	e9 0d f9 ff ff       	jmp    8010665e <alltraps>

80106d51 <vector15>:
.globl vector15
vector15:
  pushl $0
80106d51:	6a 00                	push   $0x0
  pushl $15
80106d53:	6a 0f                	push   $0xf
  jmp alltraps
80106d55:	e9 04 f9 ff ff       	jmp    8010665e <alltraps>

80106d5a <vector16>:
.globl vector16
vector16:
  pushl $0
80106d5a:	6a 00                	push   $0x0
  pushl $16
80106d5c:	6a 10                	push   $0x10
  jmp alltraps
80106d5e:	e9 fb f8 ff ff       	jmp    8010665e <alltraps>

80106d63 <vector17>:
.globl vector17
vector17:
  pushl $17
80106d63:	6a 11                	push   $0x11
  jmp alltraps
80106d65:	e9 f4 f8 ff ff       	jmp    8010665e <alltraps>

80106d6a <vector18>:
.globl vector18
vector18:
  pushl $0
80106d6a:	6a 00                	push   $0x0
  pushl $18
80106d6c:	6a 12                	push   $0x12
  jmp alltraps
80106d6e:	e9 eb f8 ff ff       	jmp    8010665e <alltraps>

80106d73 <vector19>:
.globl vector19
vector19:
  pushl $0
80106d73:	6a 00                	push   $0x0
  pushl $19
80106d75:	6a 13                	push   $0x13
  jmp alltraps
80106d77:	e9 e2 f8 ff ff       	jmp    8010665e <alltraps>

80106d7c <vector20>:
.globl vector20
vector20:
  pushl $0
80106d7c:	6a 00                	push   $0x0
  pushl $20
80106d7e:	6a 14                	push   $0x14
  jmp alltraps
80106d80:	e9 d9 f8 ff ff       	jmp    8010665e <alltraps>

80106d85 <vector21>:
.globl vector21
vector21:
  pushl $0
80106d85:	6a 00                	push   $0x0
  pushl $21
80106d87:	6a 15                	push   $0x15
  jmp alltraps
80106d89:	e9 d0 f8 ff ff       	jmp    8010665e <alltraps>

80106d8e <vector22>:
.globl vector22
vector22:
  pushl $0
80106d8e:	6a 00                	push   $0x0
  pushl $22
80106d90:	6a 16                	push   $0x16
  jmp alltraps
80106d92:	e9 c7 f8 ff ff       	jmp    8010665e <alltraps>

80106d97 <vector23>:
.globl vector23
vector23:
  pushl $0
80106d97:	6a 00                	push   $0x0
  pushl $23
80106d99:	6a 17                	push   $0x17
  jmp alltraps
80106d9b:	e9 be f8 ff ff       	jmp    8010665e <alltraps>

80106da0 <vector24>:
.globl vector24
vector24:
  pushl $0
80106da0:	6a 00                	push   $0x0
  pushl $24
80106da2:	6a 18                	push   $0x18
  jmp alltraps
80106da4:	e9 b5 f8 ff ff       	jmp    8010665e <alltraps>

80106da9 <vector25>:
.globl vector25
vector25:
  pushl $0
80106da9:	6a 00                	push   $0x0
  pushl $25
80106dab:	6a 19                	push   $0x19
  jmp alltraps
80106dad:	e9 ac f8 ff ff       	jmp    8010665e <alltraps>

80106db2 <vector26>:
.globl vector26
vector26:
  pushl $0
80106db2:	6a 00                	push   $0x0
  pushl $26
80106db4:	6a 1a                	push   $0x1a
  jmp alltraps
80106db6:	e9 a3 f8 ff ff       	jmp    8010665e <alltraps>

80106dbb <vector27>:
.globl vector27
vector27:
  pushl $0
80106dbb:	6a 00                	push   $0x0
  pushl $27
80106dbd:	6a 1b                	push   $0x1b
  jmp alltraps
80106dbf:	e9 9a f8 ff ff       	jmp    8010665e <alltraps>

80106dc4 <vector28>:
.globl vector28
vector28:
  pushl $0
80106dc4:	6a 00                	push   $0x0
  pushl $28
80106dc6:	6a 1c                	push   $0x1c
  jmp alltraps
80106dc8:	e9 91 f8 ff ff       	jmp    8010665e <alltraps>

80106dcd <vector29>:
.globl vector29
vector29:
  pushl $0
80106dcd:	6a 00                	push   $0x0
  pushl $29
80106dcf:	6a 1d                	push   $0x1d
  jmp alltraps
80106dd1:	e9 88 f8 ff ff       	jmp    8010665e <alltraps>

80106dd6 <vector30>:
.globl vector30
vector30:
  pushl $0
80106dd6:	6a 00                	push   $0x0
  pushl $30
80106dd8:	6a 1e                	push   $0x1e
  jmp alltraps
80106dda:	e9 7f f8 ff ff       	jmp    8010665e <alltraps>

80106ddf <vector31>:
.globl vector31
vector31:
  pushl $0
80106ddf:	6a 00                	push   $0x0
  pushl $31
80106de1:	6a 1f                	push   $0x1f
  jmp alltraps
80106de3:	e9 76 f8 ff ff       	jmp    8010665e <alltraps>

80106de8 <vector32>:
.globl vector32
vector32:
  pushl $0
80106de8:	6a 00                	push   $0x0
  pushl $32
80106dea:	6a 20                	push   $0x20
  jmp alltraps
80106dec:	e9 6d f8 ff ff       	jmp    8010665e <alltraps>

80106df1 <vector33>:
.globl vector33
vector33:
  pushl $0
80106df1:	6a 00                	push   $0x0
  pushl $33
80106df3:	6a 21                	push   $0x21
  jmp alltraps
80106df5:	e9 64 f8 ff ff       	jmp    8010665e <alltraps>

80106dfa <vector34>:
.globl vector34
vector34:
  pushl $0
80106dfa:	6a 00                	push   $0x0
  pushl $34
80106dfc:	6a 22                	push   $0x22
  jmp alltraps
80106dfe:	e9 5b f8 ff ff       	jmp    8010665e <alltraps>

80106e03 <vector35>:
.globl vector35
vector35:
  pushl $0
80106e03:	6a 00                	push   $0x0
  pushl $35
80106e05:	6a 23                	push   $0x23
  jmp alltraps
80106e07:	e9 52 f8 ff ff       	jmp    8010665e <alltraps>

80106e0c <vector36>:
.globl vector36
vector36:
  pushl $0
80106e0c:	6a 00                	push   $0x0
  pushl $36
80106e0e:	6a 24                	push   $0x24
  jmp alltraps
80106e10:	e9 49 f8 ff ff       	jmp    8010665e <alltraps>

80106e15 <vector37>:
.globl vector37
vector37:
  pushl $0
80106e15:	6a 00                	push   $0x0
  pushl $37
80106e17:	6a 25                	push   $0x25
  jmp alltraps
80106e19:	e9 40 f8 ff ff       	jmp    8010665e <alltraps>

80106e1e <vector38>:
.globl vector38
vector38:
  pushl $0
80106e1e:	6a 00                	push   $0x0
  pushl $38
80106e20:	6a 26                	push   $0x26
  jmp alltraps
80106e22:	e9 37 f8 ff ff       	jmp    8010665e <alltraps>

80106e27 <vector39>:
.globl vector39
vector39:
  pushl $0
80106e27:	6a 00                	push   $0x0
  pushl $39
80106e29:	6a 27                	push   $0x27
  jmp alltraps
80106e2b:	e9 2e f8 ff ff       	jmp    8010665e <alltraps>

80106e30 <vector40>:
.globl vector40
vector40:
  pushl $0
80106e30:	6a 00                	push   $0x0
  pushl $40
80106e32:	6a 28                	push   $0x28
  jmp alltraps
80106e34:	e9 25 f8 ff ff       	jmp    8010665e <alltraps>

80106e39 <vector41>:
.globl vector41
vector41:
  pushl $0
80106e39:	6a 00                	push   $0x0
  pushl $41
80106e3b:	6a 29                	push   $0x29
  jmp alltraps
80106e3d:	e9 1c f8 ff ff       	jmp    8010665e <alltraps>

80106e42 <vector42>:
.globl vector42
vector42:
  pushl $0
80106e42:	6a 00                	push   $0x0
  pushl $42
80106e44:	6a 2a                	push   $0x2a
  jmp alltraps
80106e46:	e9 13 f8 ff ff       	jmp    8010665e <alltraps>

80106e4b <vector43>:
.globl vector43
vector43:
  pushl $0
80106e4b:	6a 00                	push   $0x0
  pushl $43
80106e4d:	6a 2b                	push   $0x2b
  jmp alltraps
80106e4f:	e9 0a f8 ff ff       	jmp    8010665e <alltraps>

80106e54 <vector44>:
.globl vector44
vector44:
  pushl $0
80106e54:	6a 00                	push   $0x0
  pushl $44
80106e56:	6a 2c                	push   $0x2c
  jmp alltraps
80106e58:	e9 01 f8 ff ff       	jmp    8010665e <alltraps>

80106e5d <vector45>:
.globl vector45
vector45:
  pushl $0
80106e5d:	6a 00                	push   $0x0
  pushl $45
80106e5f:	6a 2d                	push   $0x2d
  jmp alltraps
80106e61:	e9 f8 f7 ff ff       	jmp    8010665e <alltraps>

80106e66 <vector46>:
.globl vector46
vector46:
  pushl $0
80106e66:	6a 00                	push   $0x0
  pushl $46
80106e68:	6a 2e                	push   $0x2e
  jmp alltraps
80106e6a:	e9 ef f7 ff ff       	jmp    8010665e <alltraps>

80106e6f <vector47>:
.globl vector47
vector47:
  pushl $0
80106e6f:	6a 00                	push   $0x0
  pushl $47
80106e71:	6a 2f                	push   $0x2f
  jmp alltraps
80106e73:	e9 e6 f7 ff ff       	jmp    8010665e <alltraps>

80106e78 <vector48>:
.globl vector48
vector48:
  pushl $0
80106e78:	6a 00                	push   $0x0
  pushl $48
80106e7a:	6a 30                	push   $0x30
  jmp alltraps
80106e7c:	e9 dd f7 ff ff       	jmp    8010665e <alltraps>

80106e81 <vector49>:
.globl vector49
vector49:
  pushl $0
80106e81:	6a 00                	push   $0x0
  pushl $49
80106e83:	6a 31                	push   $0x31
  jmp alltraps
80106e85:	e9 d4 f7 ff ff       	jmp    8010665e <alltraps>

80106e8a <vector50>:
.globl vector50
vector50:
  pushl $0
80106e8a:	6a 00                	push   $0x0
  pushl $50
80106e8c:	6a 32                	push   $0x32
  jmp alltraps
80106e8e:	e9 cb f7 ff ff       	jmp    8010665e <alltraps>

80106e93 <vector51>:
.globl vector51
vector51:
  pushl $0
80106e93:	6a 00                	push   $0x0
  pushl $51
80106e95:	6a 33                	push   $0x33
  jmp alltraps
80106e97:	e9 c2 f7 ff ff       	jmp    8010665e <alltraps>

80106e9c <vector52>:
.globl vector52
vector52:
  pushl $0
80106e9c:	6a 00                	push   $0x0
  pushl $52
80106e9e:	6a 34                	push   $0x34
  jmp alltraps
80106ea0:	e9 b9 f7 ff ff       	jmp    8010665e <alltraps>

80106ea5 <vector53>:
.globl vector53
vector53:
  pushl $0
80106ea5:	6a 00                	push   $0x0
  pushl $53
80106ea7:	6a 35                	push   $0x35
  jmp alltraps
80106ea9:	e9 b0 f7 ff ff       	jmp    8010665e <alltraps>

80106eae <vector54>:
.globl vector54
vector54:
  pushl $0
80106eae:	6a 00                	push   $0x0
  pushl $54
80106eb0:	6a 36                	push   $0x36
  jmp alltraps
80106eb2:	e9 a7 f7 ff ff       	jmp    8010665e <alltraps>

80106eb7 <vector55>:
.globl vector55
vector55:
  pushl $0
80106eb7:	6a 00                	push   $0x0
  pushl $55
80106eb9:	6a 37                	push   $0x37
  jmp alltraps
80106ebb:	e9 9e f7 ff ff       	jmp    8010665e <alltraps>

80106ec0 <vector56>:
.globl vector56
vector56:
  pushl $0
80106ec0:	6a 00                	push   $0x0
  pushl $56
80106ec2:	6a 38                	push   $0x38
  jmp alltraps
80106ec4:	e9 95 f7 ff ff       	jmp    8010665e <alltraps>

80106ec9 <vector57>:
.globl vector57
vector57:
  pushl $0
80106ec9:	6a 00                	push   $0x0
  pushl $57
80106ecb:	6a 39                	push   $0x39
  jmp alltraps
80106ecd:	e9 8c f7 ff ff       	jmp    8010665e <alltraps>

80106ed2 <vector58>:
.globl vector58
vector58:
  pushl $0
80106ed2:	6a 00                	push   $0x0
  pushl $58
80106ed4:	6a 3a                	push   $0x3a
  jmp alltraps
80106ed6:	e9 83 f7 ff ff       	jmp    8010665e <alltraps>

80106edb <vector59>:
.globl vector59
vector59:
  pushl $0
80106edb:	6a 00                	push   $0x0
  pushl $59
80106edd:	6a 3b                	push   $0x3b
  jmp alltraps
80106edf:	e9 7a f7 ff ff       	jmp    8010665e <alltraps>

80106ee4 <vector60>:
.globl vector60
vector60:
  pushl $0
80106ee4:	6a 00                	push   $0x0
  pushl $60
80106ee6:	6a 3c                	push   $0x3c
  jmp alltraps
80106ee8:	e9 71 f7 ff ff       	jmp    8010665e <alltraps>

80106eed <vector61>:
.globl vector61
vector61:
  pushl $0
80106eed:	6a 00                	push   $0x0
  pushl $61
80106eef:	6a 3d                	push   $0x3d
  jmp alltraps
80106ef1:	e9 68 f7 ff ff       	jmp    8010665e <alltraps>

80106ef6 <vector62>:
.globl vector62
vector62:
  pushl $0
80106ef6:	6a 00                	push   $0x0
  pushl $62
80106ef8:	6a 3e                	push   $0x3e
  jmp alltraps
80106efa:	e9 5f f7 ff ff       	jmp    8010665e <alltraps>

80106eff <vector63>:
.globl vector63
vector63:
  pushl $0
80106eff:	6a 00                	push   $0x0
  pushl $63
80106f01:	6a 3f                	push   $0x3f
  jmp alltraps
80106f03:	e9 56 f7 ff ff       	jmp    8010665e <alltraps>

80106f08 <vector64>:
.globl vector64
vector64:
  pushl $0
80106f08:	6a 00                	push   $0x0
  pushl $64
80106f0a:	6a 40                	push   $0x40
  jmp alltraps
80106f0c:	e9 4d f7 ff ff       	jmp    8010665e <alltraps>

80106f11 <vector65>:
.globl vector65
vector65:
  pushl $0
80106f11:	6a 00                	push   $0x0
  pushl $65
80106f13:	6a 41                	push   $0x41
  jmp alltraps
80106f15:	e9 44 f7 ff ff       	jmp    8010665e <alltraps>

80106f1a <vector66>:
.globl vector66
vector66:
  pushl $0
80106f1a:	6a 00                	push   $0x0
  pushl $66
80106f1c:	6a 42                	push   $0x42
  jmp alltraps
80106f1e:	e9 3b f7 ff ff       	jmp    8010665e <alltraps>

80106f23 <vector67>:
.globl vector67
vector67:
  pushl $0
80106f23:	6a 00                	push   $0x0
  pushl $67
80106f25:	6a 43                	push   $0x43
  jmp alltraps
80106f27:	e9 32 f7 ff ff       	jmp    8010665e <alltraps>

80106f2c <vector68>:
.globl vector68
vector68:
  pushl $0
80106f2c:	6a 00                	push   $0x0
  pushl $68
80106f2e:	6a 44                	push   $0x44
  jmp alltraps
80106f30:	e9 29 f7 ff ff       	jmp    8010665e <alltraps>

80106f35 <vector69>:
.globl vector69
vector69:
  pushl $0
80106f35:	6a 00                	push   $0x0
  pushl $69
80106f37:	6a 45                	push   $0x45
  jmp alltraps
80106f39:	e9 20 f7 ff ff       	jmp    8010665e <alltraps>

80106f3e <vector70>:
.globl vector70
vector70:
  pushl $0
80106f3e:	6a 00                	push   $0x0
  pushl $70
80106f40:	6a 46                	push   $0x46
  jmp alltraps
80106f42:	e9 17 f7 ff ff       	jmp    8010665e <alltraps>

80106f47 <vector71>:
.globl vector71
vector71:
  pushl $0
80106f47:	6a 00                	push   $0x0
  pushl $71
80106f49:	6a 47                	push   $0x47
  jmp alltraps
80106f4b:	e9 0e f7 ff ff       	jmp    8010665e <alltraps>

80106f50 <vector72>:
.globl vector72
vector72:
  pushl $0
80106f50:	6a 00                	push   $0x0
  pushl $72
80106f52:	6a 48                	push   $0x48
  jmp alltraps
80106f54:	e9 05 f7 ff ff       	jmp    8010665e <alltraps>

80106f59 <vector73>:
.globl vector73
vector73:
  pushl $0
80106f59:	6a 00                	push   $0x0
  pushl $73
80106f5b:	6a 49                	push   $0x49
  jmp alltraps
80106f5d:	e9 fc f6 ff ff       	jmp    8010665e <alltraps>

80106f62 <vector74>:
.globl vector74
vector74:
  pushl $0
80106f62:	6a 00                	push   $0x0
  pushl $74
80106f64:	6a 4a                	push   $0x4a
  jmp alltraps
80106f66:	e9 f3 f6 ff ff       	jmp    8010665e <alltraps>

80106f6b <vector75>:
.globl vector75
vector75:
  pushl $0
80106f6b:	6a 00                	push   $0x0
  pushl $75
80106f6d:	6a 4b                	push   $0x4b
  jmp alltraps
80106f6f:	e9 ea f6 ff ff       	jmp    8010665e <alltraps>

80106f74 <vector76>:
.globl vector76
vector76:
  pushl $0
80106f74:	6a 00                	push   $0x0
  pushl $76
80106f76:	6a 4c                	push   $0x4c
  jmp alltraps
80106f78:	e9 e1 f6 ff ff       	jmp    8010665e <alltraps>

80106f7d <vector77>:
.globl vector77
vector77:
  pushl $0
80106f7d:	6a 00                	push   $0x0
  pushl $77
80106f7f:	6a 4d                	push   $0x4d
  jmp alltraps
80106f81:	e9 d8 f6 ff ff       	jmp    8010665e <alltraps>

80106f86 <vector78>:
.globl vector78
vector78:
  pushl $0
80106f86:	6a 00                	push   $0x0
  pushl $78
80106f88:	6a 4e                	push   $0x4e
  jmp alltraps
80106f8a:	e9 cf f6 ff ff       	jmp    8010665e <alltraps>

80106f8f <vector79>:
.globl vector79
vector79:
  pushl $0
80106f8f:	6a 00                	push   $0x0
  pushl $79
80106f91:	6a 4f                	push   $0x4f
  jmp alltraps
80106f93:	e9 c6 f6 ff ff       	jmp    8010665e <alltraps>

80106f98 <vector80>:
.globl vector80
vector80:
  pushl $0
80106f98:	6a 00                	push   $0x0
  pushl $80
80106f9a:	6a 50                	push   $0x50
  jmp alltraps
80106f9c:	e9 bd f6 ff ff       	jmp    8010665e <alltraps>

80106fa1 <vector81>:
.globl vector81
vector81:
  pushl $0
80106fa1:	6a 00                	push   $0x0
  pushl $81
80106fa3:	6a 51                	push   $0x51
  jmp alltraps
80106fa5:	e9 b4 f6 ff ff       	jmp    8010665e <alltraps>

80106faa <vector82>:
.globl vector82
vector82:
  pushl $0
80106faa:	6a 00                	push   $0x0
  pushl $82
80106fac:	6a 52                	push   $0x52
  jmp alltraps
80106fae:	e9 ab f6 ff ff       	jmp    8010665e <alltraps>

80106fb3 <vector83>:
.globl vector83
vector83:
  pushl $0
80106fb3:	6a 00                	push   $0x0
  pushl $83
80106fb5:	6a 53                	push   $0x53
  jmp alltraps
80106fb7:	e9 a2 f6 ff ff       	jmp    8010665e <alltraps>

80106fbc <vector84>:
.globl vector84
vector84:
  pushl $0
80106fbc:	6a 00                	push   $0x0
  pushl $84
80106fbe:	6a 54                	push   $0x54
  jmp alltraps
80106fc0:	e9 99 f6 ff ff       	jmp    8010665e <alltraps>

80106fc5 <vector85>:
.globl vector85
vector85:
  pushl $0
80106fc5:	6a 00                	push   $0x0
  pushl $85
80106fc7:	6a 55                	push   $0x55
  jmp alltraps
80106fc9:	e9 90 f6 ff ff       	jmp    8010665e <alltraps>

80106fce <vector86>:
.globl vector86
vector86:
  pushl $0
80106fce:	6a 00                	push   $0x0
  pushl $86
80106fd0:	6a 56                	push   $0x56
  jmp alltraps
80106fd2:	e9 87 f6 ff ff       	jmp    8010665e <alltraps>

80106fd7 <vector87>:
.globl vector87
vector87:
  pushl $0
80106fd7:	6a 00                	push   $0x0
  pushl $87
80106fd9:	6a 57                	push   $0x57
  jmp alltraps
80106fdb:	e9 7e f6 ff ff       	jmp    8010665e <alltraps>

80106fe0 <vector88>:
.globl vector88
vector88:
  pushl $0
80106fe0:	6a 00                	push   $0x0
  pushl $88
80106fe2:	6a 58                	push   $0x58
  jmp alltraps
80106fe4:	e9 75 f6 ff ff       	jmp    8010665e <alltraps>

80106fe9 <vector89>:
.globl vector89
vector89:
  pushl $0
80106fe9:	6a 00                	push   $0x0
  pushl $89
80106feb:	6a 59                	push   $0x59
  jmp alltraps
80106fed:	e9 6c f6 ff ff       	jmp    8010665e <alltraps>

80106ff2 <vector90>:
.globl vector90
vector90:
  pushl $0
80106ff2:	6a 00                	push   $0x0
  pushl $90
80106ff4:	6a 5a                	push   $0x5a
  jmp alltraps
80106ff6:	e9 63 f6 ff ff       	jmp    8010665e <alltraps>

80106ffb <vector91>:
.globl vector91
vector91:
  pushl $0
80106ffb:	6a 00                	push   $0x0
  pushl $91
80106ffd:	6a 5b                	push   $0x5b
  jmp alltraps
80106fff:	e9 5a f6 ff ff       	jmp    8010665e <alltraps>

80107004 <vector92>:
.globl vector92
vector92:
  pushl $0
80107004:	6a 00                	push   $0x0
  pushl $92
80107006:	6a 5c                	push   $0x5c
  jmp alltraps
80107008:	e9 51 f6 ff ff       	jmp    8010665e <alltraps>

8010700d <vector93>:
.globl vector93
vector93:
  pushl $0
8010700d:	6a 00                	push   $0x0
  pushl $93
8010700f:	6a 5d                	push   $0x5d
  jmp alltraps
80107011:	e9 48 f6 ff ff       	jmp    8010665e <alltraps>

80107016 <vector94>:
.globl vector94
vector94:
  pushl $0
80107016:	6a 00                	push   $0x0
  pushl $94
80107018:	6a 5e                	push   $0x5e
  jmp alltraps
8010701a:	e9 3f f6 ff ff       	jmp    8010665e <alltraps>

8010701f <vector95>:
.globl vector95
vector95:
  pushl $0
8010701f:	6a 00                	push   $0x0
  pushl $95
80107021:	6a 5f                	push   $0x5f
  jmp alltraps
80107023:	e9 36 f6 ff ff       	jmp    8010665e <alltraps>

80107028 <vector96>:
.globl vector96
vector96:
  pushl $0
80107028:	6a 00                	push   $0x0
  pushl $96
8010702a:	6a 60                	push   $0x60
  jmp alltraps
8010702c:	e9 2d f6 ff ff       	jmp    8010665e <alltraps>

80107031 <vector97>:
.globl vector97
vector97:
  pushl $0
80107031:	6a 00                	push   $0x0
  pushl $97
80107033:	6a 61                	push   $0x61
  jmp alltraps
80107035:	e9 24 f6 ff ff       	jmp    8010665e <alltraps>

8010703a <vector98>:
.globl vector98
vector98:
  pushl $0
8010703a:	6a 00                	push   $0x0
  pushl $98
8010703c:	6a 62                	push   $0x62
  jmp alltraps
8010703e:	e9 1b f6 ff ff       	jmp    8010665e <alltraps>

80107043 <vector99>:
.globl vector99
vector99:
  pushl $0
80107043:	6a 00                	push   $0x0
  pushl $99
80107045:	6a 63                	push   $0x63
  jmp alltraps
80107047:	e9 12 f6 ff ff       	jmp    8010665e <alltraps>

8010704c <vector100>:
.globl vector100
vector100:
  pushl $0
8010704c:	6a 00                	push   $0x0
  pushl $100
8010704e:	6a 64                	push   $0x64
  jmp alltraps
80107050:	e9 09 f6 ff ff       	jmp    8010665e <alltraps>

80107055 <vector101>:
.globl vector101
vector101:
  pushl $0
80107055:	6a 00                	push   $0x0
  pushl $101
80107057:	6a 65                	push   $0x65
  jmp alltraps
80107059:	e9 00 f6 ff ff       	jmp    8010665e <alltraps>

8010705e <vector102>:
.globl vector102
vector102:
  pushl $0
8010705e:	6a 00                	push   $0x0
  pushl $102
80107060:	6a 66                	push   $0x66
  jmp alltraps
80107062:	e9 f7 f5 ff ff       	jmp    8010665e <alltraps>

80107067 <vector103>:
.globl vector103
vector103:
  pushl $0
80107067:	6a 00                	push   $0x0
  pushl $103
80107069:	6a 67                	push   $0x67
  jmp alltraps
8010706b:	e9 ee f5 ff ff       	jmp    8010665e <alltraps>

80107070 <vector104>:
.globl vector104
vector104:
  pushl $0
80107070:	6a 00                	push   $0x0
  pushl $104
80107072:	6a 68                	push   $0x68
  jmp alltraps
80107074:	e9 e5 f5 ff ff       	jmp    8010665e <alltraps>

80107079 <vector105>:
.globl vector105
vector105:
  pushl $0
80107079:	6a 00                	push   $0x0
  pushl $105
8010707b:	6a 69                	push   $0x69
  jmp alltraps
8010707d:	e9 dc f5 ff ff       	jmp    8010665e <alltraps>

80107082 <vector106>:
.globl vector106
vector106:
  pushl $0
80107082:	6a 00                	push   $0x0
  pushl $106
80107084:	6a 6a                	push   $0x6a
  jmp alltraps
80107086:	e9 d3 f5 ff ff       	jmp    8010665e <alltraps>

8010708b <vector107>:
.globl vector107
vector107:
  pushl $0
8010708b:	6a 00                	push   $0x0
  pushl $107
8010708d:	6a 6b                	push   $0x6b
  jmp alltraps
8010708f:	e9 ca f5 ff ff       	jmp    8010665e <alltraps>

80107094 <vector108>:
.globl vector108
vector108:
  pushl $0
80107094:	6a 00                	push   $0x0
  pushl $108
80107096:	6a 6c                	push   $0x6c
  jmp alltraps
80107098:	e9 c1 f5 ff ff       	jmp    8010665e <alltraps>

8010709d <vector109>:
.globl vector109
vector109:
  pushl $0
8010709d:	6a 00                	push   $0x0
  pushl $109
8010709f:	6a 6d                	push   $0x6d
  jmp alltraps
801070a1:	e9 b8 f5 ff ff       	jmp    8010665e <alltraps>

801070a6 <vector110>:
.globl vector110
vector110:
  pushl $0
801070a6:	6a 00                	push   $0x0
  pushl $110
801070a8:	6a 6e                	push   $0x6e
  jmp alltraps
801070aa:	e9 af f5 ff ff       	jmp    8010665e <alltraps>

801070af <vector111>:
.globl vector111
vector111:
  pushl $0
801070af:	6a 00                	push   $0x0
  pushl $111
801070b1:	6a 6f                	push   $0x6f
  jmp alltraps
801070b3:	e9 a6 f5 ff ff       	jmp    8010665e <alltraps>

801070b8 <vector112>:
.globl vector112
vector112:
  pushl $0
801070b8:	6a 00                	push   $0x0
  pushl $112
801070ba:	6a 70                	push   $0x70
  jmp alltraps
801070bc:	e9 9d f5 ff ff       	jmp    8010665e <alltraps>

801070c1 <vector113>:
.globl vector113
vector113:
  pushl $0
801070c1:	6a 00                	push   $0x0
  pushl $113
801070c3:	6a 71                	push   $0x71
  jmp alltraps
801070c5:	e9 94 f5 ff ff       	jmp    8010665e <alltraps>

801070ca <vector114>:
.globl vector114
vector114:
  pushl $0
801070ca:	6a 00                	push   $0x0
  pushl $114
801070cc:	6a 72                	push   $0x72
  jmp alltraps
801070ce:	e9 8b f5 ff ff       	jmp    8010665e <alltraps>

801070d3 <vector115>:
.globl vector115
vector115:
  pushl $0
801070d3:	6a 00                	push   $0x0
  pushl $115
801070d5:	6a 73                	push   $0x73
  jmp alltraps
801070d7:	e9 82 f5 ff ff       	jmp    8010665e <alltraps>

801070dc <vector116>:
.globl vector116
vector116:
  pushl $0
801070dc:	6a 00                	push   $0x0
  pushl $116
801070de:	6a 74                	push   $0x74
  jmp alltraps
801070e0:	e9 79 f5 ff ff       	jmp    8010665e <alltraps>

801070e5 <vector117>:
.globl vector117
vector117:
  pushl $0
801070e5:	6a 00                	push   $0x0
  pushl $117
801070e7:	6a 75                	push   $0x75
  jmp alltraps
801070e9:	e9 70 f5 ff ff       	jmp    8010665e <alltraps>

801070ee <vector118>:
.globl vector118
vector118:
  pushl $0
801070ee:	6a 00                	push   $0x0
  pushl $118
801070f0:	6a 76                	push   $0x76
  jmp alltraps
801070f2:	e9 67 f5 ff ff       	jmp    8010665e <alltraps>

801070f7 <vector119>:
.globl vector119
vector119:
  pushl $0
801070f7:	6a 00                	push   $0x0
  pushl $119
801070f9:	6a 77                	push   $0x77
  jmp alltraps
801070fb:	e9 5e f5 ff ff       	jmp    8010665e <alltraps>

80107100 <vector120>:
.globl vector120
vector120:
  pushl $0
80107100:	6a 00                	push   $0x0
  pushl $120
80107102:	6a 78                	push   $0x78
  jmp alltraps
80107104:	e9 55 f5 ff ff       	jmp    8010665e <alltraps>

80107109 <vector121>:
.globl vector121
vector121:
  pushl $0
80107109:	6a 00                	push   $0x0
  pushl $121
8010710b:	6a 79                	push   $0x79
  jmp alltraps
8010710d:	e9 4c f5 ff ff       	jmp    8010665e <alltraps>

80107112 <vector122>:
.globl vector122
vector122:
  pushl $0
80107112:	6a 00                	push   $0x0
  pushl $122
80107114:	6a 7a                	push   $0x7a
  jmp alltraps
80107116:	e9 43 f5 ff ff       	jmp    8010665e <alltraps>

8010711b <vector123>:
.globl vector123
vector123:
  pushl $0
8010711b:	6a 00                	push   $0x0
  pushl $123
8010711d:	6a 7b                	push   $0x7b
  jmp alltraps
8010711f:	e9 3a f5 ff ff       	jmp    8010665e <alltraps>

80107124 <vector124>:
.globl vector124
vector124:
  pushl $0
80107124:	6a 00                	push   $0x0
  pushl $124
80107126:	6a 7c                	push   $0x7c
  jmp alltraps
80107128:	e9 31 f5 ff ff       	jmp    8010665e <alltraps>

8010712d <vector125>:
.globl vector125
vector125:
  pushl $0
8010712d:	6a 00                	push   $0x0
  pushl $125
8010712f:	6a 7d                	push   $0x7d
  jmp alltraps
80107131:	e9 28 f5 ff ff       	jmp    8010665e <alltraps>

80107136 <vector126>:
.globl vector126
vector126:
  pushl $0
80107136:	6a 00                	push   $0x0
  pushl $126
80107138:	6a 7e                	push   $0x7e
  jmp alltraps
8010713a:	e9 1f f5 ff ff       	jmp    8010665e <alltraps>

8010713f <vector127>:
.globl vector127
vector127:
  pushl $0
8010713f:	6a 00                	push   $0x0
  pushl $127
80107141:	6a 7f                	push   $0x7f
  jmp alltraps
80107143:	e9 16 f5 ff ff       	jmp    8010665e <alltraps>

80107148 <vector128>:
.globl vector128
vector128:
  pushl $0
80107148:	6a 00                	push   $0x0
  pushl $128
8010714a:	68 80 00 00 00       	push   $0x80
  jmp alltraps
8010714f:	e9 0a f5 ff ff       	jmp    8010665e <alltraps>

80107154 <vector129>:
.globl vector129
vector129:
  pushl $0
80107154:	6a 00                	push   $0x0
  pushl $129
80107156:	68 81 00 00 00       	push   $0x81
  jmp alltraps
8010715b:	e9 fe f4 ff ff       	jmp    8010665e <alltraps>

80107160 <vector130>:
.globl vector130
vector130:
  pushl $0
80107160:	6a 00                	push   $0x0
  pushl $130
80107162:	68 82 00 00 00       	push   $0x82
  jmp alltraps
80107167:	e9 f2 f4 ff ff       	jmp    8010665e <alltraps>

8010716c <vector131>:
.globl vector131
vector131:
  pushl $0
8010716c:	6a 00                	push   $0x0
  pushl $131
8010716e:	68 83 00 00 00       	push   $0x83
  jmp alltraps
80107173:	e9 e6 f4 ff ff       	jmp    8010665e <alltraps>

80107178 <vector132>:
.globl vector132
vector132:
  pushl $0
80107178:	6a 00                	push   $0x0
  pushl $132
8010717a:	68 84 00 00 00       	push   $0x84
  jmp alltraps
8010717f:	e9 da f4 ff ff       	jmp    8010665e <alltraps>

80107184 <vector133>:
.globl vector133
vector133:
  pushl $0
80107184:	6a 00                	push   $0x0
  pushl $133
80107186:	68 85 00 00 00       	push   $0x85
  jmp alltraps
8010718b:	e9 ce f4 ff ff       	jmp    8010665e <alltraps>

80107190 <vector134>:
.globl vector134
vector134:
  pushl $0
80107190:	6a 00                	push   $0x0
  pushl $134
80107192:	68 86 00 00 00       	push   $0x86
  jmp alltraps
80107197:	e9 c2 f4 ff ff       	jmp    8010665e <alltraps>

8010719c <vector135>:
.globl vector135
vector135:
  pushl $0
8010719c:	6a 00                	push   $0x0
  pushl $135
8010719e:	68 87 00 00 00       	push   $0x87
  jmp alltraps
801071a3:	e9 b6 f4 ff ff       	jmp    8010665e <alltraps>

801071a8 <vector136>:
.globl vector136
vector136:
  pushl $0
801071a8:	6a 00                	push   $0x0
  pushl $136
801071aa:	68 88 00 00 00       	push   $0x88
  jmp alltraps
801071af:	e9 aa f4 ff ff       	jmp    8010665e <alltraps>

801071b4 <vector137>:
.globl vector137
vector137:
  pushl $0
801071b4:	6a 00                	push   $0x0
  pushl $137
801071b6:	68 89 00 00 00       	push   $0x89
  jmp alltraps
801071bb:	e9 9e f4 ff ff       	jmp    8010665e <alltraps>

801071c0 <vector138>:
.globl vector138
vector138:
  pushl $0
801071c0:	6a 00                	push   $0x0
  pushl $138
801071c2:	68 8a 00 00 00       	push   $0x8a
  jmp alltraps
801071c7:	e9 92 f4 ff ff       	jmp    8010665e <alltraps>

801071cc <vector139>:
.globl vector139
vector139:
  pushl $0
801071cc:	6a 00                	push   $0x0
  pushl $139
801071ce:	68 8b 00 00 00       	push   $0x8b
  jmp alltraps
801071d3:	e9 86 f4 ff ff       	jmp    8010665e <alltraps>

801071d8 <vector140>:
.globl vector140
vector140:
  pushl $0
801071d8:	6a 00                	push   $0x0
  pushl $140
801071da:	68 8c 00 00 00       	push   $0x8c
  jmp alltraps
801071df:	e9 7a f4 ff ff       	jmp    8010665e <alltraps>

801071e4 <vector141>:
.globl vector141
vector141:
  pushl $0
801071e4:	6a 00                	push   $0x0
  pushl $141
801071e6:	68 8d 00 00 00       	push   $0x8d
  jmp alltraps
801071eb:	e9 6e f4 ff ff       	jmp    8010665e <alltraps>

801071f0 <vector142>:
.globl vector142
vector142:
  pushl $0
801071f0:	6a 00                	push   $0x0
  pushl $142
801071f2:	68 8e 00 00 00       	push   $0x8e
  jmp alltraps
801071f7:	e9 62 f4 ff ff       	jmp    8010665e <alltraps>

801071fc <vector143>:
.globl vector143
vector143:
  pushl $0
801071fc:	6a 00                	push   $0x0
  pushl $143
801071fe:	68 8f 00 00 00       	push   $0x8f
  jmp alltraps
80107203:	e9 56 f4 ff ff       	jmp    8010665e <alltraps>

80107208 <vector144>:
.globl vector144
vector144:
  pushl $0
80107208:	6a 00                	push   $0x0
  pushl $144
8010720a:	68 90 00 00 00       	push   $0x90
  jmp alltraps
8010720f:	e9 4a f4 ff ff       	jmp    8010665e <alltraps>

80107214 <vector145>:
.globl vector145
vector145:
  pushl $0
80107214:	6a 00                	push   $0x0
  pushl $145
80107216:	68 91 00 00 00       	push   $0x91
  jmp alltraps
8010721b:	e9 3e f4 ff ff       	jmp    8010665e <alltraps>

80107220 <vector146>:
.globl vector146
vector146:
  pushl $0
80107220:	6a 00                	push   $0x0
  pushl $146
80107222:	68 92 00 00 00       	push   $0x92
  jmp alltraps
80107227:	e9 32 f4 ff ff       	jmp    8010665e <alltraps>

8010722c <vector147>:
.globl vector147
vector147:
  pushl $0
8010722c:	6a 00                	push   $0x0
  pushl $147
8010722e:	68 93 00 00 00       	push   $0x93
  jmp alltraps
80107233:	e9 26 f4 ff ff       	jmp    8010665e <alltraps>

80107238 <vector148>:
.globl vector148
vector148:
  pushl $0
80107238:	6a 00                	push   $0x0
  pushl $148
8010723a:	68 94 00 00 00       	push   $0x94
  jmp alltraps
8010723f:	e9 1a f4 ff ff       	jmp    8010665e <alltraps>

80107244 <vector149>:
.globl vector149
vector149:
  pushl $0
80107244:	6a 00                	push   $0x0
  pushl $149
80107246:	68 95 00 00 00       	push   $0x95
  jmp alltraps
8010724b:	e9 0e f4 ff ff       	jmp    8010665e <alltraps>

80107250 <vector150>:
.globl vector150
vector150:
  pushl $0
80107250:	6a 00                	push   $0x0
  pushl $150
80107252:	68 96 00 00 00       	push   $0x96
  jmp alltraps
80107257:	e9 02 f4 ff ff       	jmp    8010665e <alltraps>

8010725c <vector151>:
.globl vector151
vector151:
  pushl $0
8010725c:	6a 00                	push   $0x0
  pushl $151
8010725e:	68 97 00 00 00       	push   $0x97
  jmp alltraps
80107263:	e9 f6 f3 ff ff       	jmp    8010665e <alltraps>

80107268 <vector152>:
.globl vector152
vector152:
  pushl $0
80107268:	6a 00                	push   $0x0
  pushl $152
8010726a:	68 98 00 00 00       	push   $0x98
  jmp alltraps
8010726f:	e9 ea f3 ff ff       	jmp    8010665e <alltraps>

80107274 <vector153>:
.globl vector153
vector153:
  pushl $0
80107274:	6a 00                	push   $0x0
  pushl $153
80107276:	68 99 00 00 00       	push   $0x99
  jmp alltraps
8010727b:	e9 de f3 ff ff       	jmp    8010665e <alltraps>

80107280 <vector154>:
.globl vector154
vector154:
  pushl $0
80107280:	6a 00                	push   $0x0
  pushl $154
80107282:	68 9a 00 00 00       	push   $0x9a
  jmp alltraps
80107287:	e9 d2 f3 ff ff       	jmp    8010665e <alltraps>

8010728c <vector155>:
.globl vector155
vector155:
  pushl $0
8010728c:	6a 00                	push   $0x0
  pushl $155
8010728e:	68 9b 00 00 00       	push   $0x9b
  jmp alltraps
80107293:	e9 c6 f3 ff ff       	jmp    8010665e <alltraps>

80107298 <vector156>:
.globl vector156
vector156:
  pushl $0
80107298:	6a 00                	push   $0x0
  pushl $156
8010729a:	68 9c 00 00 00       	push   $0x9c
  jmp alltraps
8010729f:	e9 ba f3 ff ff       	jmp    8010665e <alltraps>

801072a4 <vector157>:
.globl vector157
vector157:
  pushl $0
801072a4:	6a 00                	push   $0x0
  pushl $157
801072a6:	68 9d 00 00 00       	push   $0x9d
  jmp alltraps
801072ab:	e9 ae f3 ff ff       	jmp    8010665e <alltraps>

801072b0 <vector158>:
.globl vector158
vector158:
  pushl $0
801072b0:	6a 00                	push   $0x0
  pushl $158
801072b2:	68 9e 00 00 00       	push   $0x9e
  jmp alltraps
801072b7:	e9 a2 f3 ff ff       	jmp    8010665e <alltraps>

801072bc <vector159>:
.globl vector159
vector159:
  pushl $0
801072bc:	6a 00                	push   $0x0
  pushl $159
801072be:	68 9f 00 00 00       	push   $0x9f
  jmp alltraps
801072c3:	e9 96 f3 ff ff       	jmp    8010665e <alltraps>

801072c8 <vector160>:
.globl vector160
vector160:
  pushl $0
801072c8:	6a 00                	push   $0x0
  pushl $160
801072ca:	68 a0 00 00 00       	push   $0xa0
  jmp alltraps
801072cf:	e9 8a f3 ff ff       	jmp    8010665e <alltraps>

801072d4 <vector161>:
.globl vector161
vector161:
  pushl $0
801072d4:	6a 00                	push   $0x0
  pushl $161
801072d6:	68 a1 00 00 00       	push   $0xa1
  jmp alltraps
801072db:	e9 7e f3 ff ff       	jmp    8010665e <alltraps>

801072e0 <vector162>:
.globl vector162
vector162:
  pushl $0
801072e0:	6a 00                	push   $0x0
  pushl $162
801072e2:	68 a2 00 00 00       	push   $0xa2
  jmp alltraps
801072e7:	e9 72 f3 ff ff       	jmp    8010665e <alltraps>

801072ec <vector163>:
.globl vector163
vector163:
  pushl $0
801072ec:	6a 00                	push   $0x0
  pushl $163
801072ee:	68 a3 00 00 00       	push   $0xa3
  jmp alltraps
801072f3:	e9 66 f3 ff ff       	jmp    8010665e <alltraps>

801072f8 <vector164>:
.globl vector164
vector164:
  pushl $0
801072f8:	6a 00                	push   $0x0
  pushl $164
801072fa:	68 a4 00 00 00       	push   $0xa4
  jmp alltraps
801072ff:	e9 5a f3 ff ff       	jmp    8010665e <alltraps>

80107304 <vector165>:
.globl vector165
vector165:
  pushl $0
80107304:	6a 00                	push   $0x0
  pushl $165
80107306:	68 a5 00 00 00       	push   $0xa5
  jmp alltraps
8010730b:	e9 4e f3 ff ff       	jmp    8010665e <alltraps>

80107310 <vector166>:
.globl vector166
vector166:
  pushl $0
80107310:	6a 00                	push   $0x0
  pushl $166
80107312:	68 a6 00 00 00       	push   $0xa6
  jmp alltraps
80107317:	e9 42 f3 ff ff       	jmp    8010665e <alltraps>

8010731c <vector167>:
.globl vector167
vector167:
  pushl $0
8010731c:	6a 00                	push   $0x0
  pushl $167
8010731e:	68 a7 00 00 00       	push   $0xa7
  jmp alltraps
80107323:	e9 36 f3 ff ff       	jmp    8010665e <alltraps>

80107328 <vector168>:
.globl vector168
vector168:
  pushl $0
80107328:	6a 00                	push   $0x0
  pushl $168
8010732a:	68 a8 00 00 00       	push   $0xa8
  jmp alltraps
8010732f:	e9 2a f3 ff ff       	jmp    8010665e <alltraps>

80107334 <vector169>:
.globl vector169
vector169:
  pushl $0
80107334:	6a 00                	push   $0x0
  pushl $169
80107336:	68 a9 00 00 00       	push   $0xa9
  jmp alltraps
8010733b:	e9 1e f3 ff ff       	jmp    8010665e <alltraps>

80107340 <vector170>:
.globl vector170
vector170:
  pushl $0
80107340:	6a 00                	push   $0x0
  pushl $170
80107342:	68 aa 00 00 00       	push   $0xaa
  jmp alltraps
80107347:	e9 12 f3 ff ff       	jmp    8010665e <alltraps>

8010734c <vector171>:
.globl vector171
vector171:
  pushl $0
8010734c:	6a 00                	push   $0x0
  pushl $171
8010734e:	68 ab 00 00 00       	push   $0xab
  jmp alltraps
80107353:	e9 06 f3 ff ff       	jmp    8010665e <alltraps>

80107358 <vector172>:
.globl vector172
vector172:
  pushl $0
80107358:	6a 00                	push   $0x0
  pushl $172
8010735a:	68 ac 00 00 00       	push   $0xac
  jmp alltraps
8010735f:	e9 fa f2 ff ff       	jmp    8010665e <alltraps>

80107364 <vector173>:
.globl vector173
vector173:
  pushl $0
80107364:	6a 00                	push   $0x0
  pushl $173
80107366:	68 ad 00 00 00       	push   $0xad
  jmp alltraps
8010736b:	e9 ee f2 ff ff       	jmp    8010665e <alltraps>

80107370 <vector174>:
.globl vector174
vector174:
  pushl $0
80107370:	6a 00                	push   $0x0
  pushl $174
80107372:	68 ae 00 00 00       	push   $0xae
  jmp alltraps
80107377:	e9 e2 f2 ff ff       	jmp    8010665e <alltraps>

8010737c <vector175>:
.globl vector175
vector175:
  pushl $0
8010737c:	6a 00                	push   $0x0
  pushl $175
8010737e:	68 af 00 00 00       	push   $0xaf
  jmp alltraps
80107383:	e9 d6 f2 ff ff       	jmp    8010665e <alltraps>

80107388 <vector176>:
.globl vector176
vector176:
  pushl $0
80107388:	6a 00                	push   $0x0
  pushl $176
8010738a:	68 b0 00 00 00       	push   $0xb0
  jmp alltraps
8010738f:	e9 ca f2 ff ff       	jmp    8010665e <alltraps>

80107394 <vector177>:
.globl vector177
vector177:
  pushl $0
80107394:	6a 00                	push   $0x0
  pushl $177
80107396:	68 b1 00 00 00       	push   $0xb1
  jmp alltraps
8010739b:	e9 be f2 ff ff       	jmp    8010665e <alltraps>

801073a0 <vector178>:
.globl vector178
vector178:
  pushl $0
801073a0:	6a 00                	push   $0x0
  pushl $178
801073a2:	68 b2 00 00 00       	push   $0xb2
  jmp alltraps
801073a7:	e9 b2 f2 ff ff       	jmp    8010665e <alltraps>

801073ac <vector179>:
.globl vector179
vector179:
  pushl $0
801073ac:	6a 00                	push   $0x0
  pushl $179
801073ae:	68 b3 00 00 00       	push   $0xb3
  jmp alltraps
801073b3:	e9 a6 f2 ff ff       	jmp    8010665e <alltraps>

801073b8 <vector180>:
.globl vector180
vector180:
  pushl $0
801073b8:	6a 00                	push   $0x0
  pushl $180
801073ba:	68 b4 00 00 00       	push   $0xb4
  jmp alltraps
801073bf:	e9 9a f2 ff ff       	jmp    8010665e <alltraps>

801073c4 <vector181>:
.globl vector181
vector181:
  pushl $0
801073c4:	6a 00                	push   $0x0
  pushl $181
801073c6:	68 b5 00 00 00       	push   $0xb5
  jmp alltraps
801073cb:	e9 8e f2 ff ff       	jmp    8010665e <alltraps>

801073d0 <vector182>:
.globl vector182
vector182:
  pushl $0
801073d0:	6a 00                	push   $0x0
  pushl $182
801073d2:	68 b6 00 00 00       	push   $0xb6
  jmp alltraps
801073d7:	e9 82 f2 ff ff       	jmp    8010665e <alltraps>

801073dc <vector183>:
.globl vector183
vector183:
  pushl $0
801073dc:	6a 00                	push   $0x0
  pushl $183
801073de:	68 b7 00 00 00       	push   $0xb7
  jmp alltraps
801073e3:	e9 76 f2 ff ff       	jmp    8010665e <alltraps>

801073e8 <vector184>:
.globl vector184
vector184:
  pushl $0
801073e8:	6a 00                	push   $0x0
  pushl $184
801073ea:	68 b8 00 00 00       	push   $0xb8
  jmp alltraps
801073ef:	e9 6a f2 ff ff       	jmp    8010665e <alltraps>

801073f4 <vector185>:
.globl vector185
vector185:
  pushl $0
801073f4:	6a 00                	push   $0x0
  pushl $185
801073f6:	68 b9 00 00 00       	push   $0xb9
  jmp alltraps
801073fb:	e9 5e f2 ff ff       	jmp    8010665e <alltraps>

80107400 <vector186>:
.globl vector186
vector186:
  pushl $0
80107400:	6a 00                	push   $0x0
  pushl $186
80107402:	68 ba 00 00 00       	push   $0xba
  jmp alltraps
80107407:	e9 52 f2 ff ff       	jmp    8010665e <alltraps>

8010740c <vector187>:
.globl vector187
vector187:
  pushl $0
8010740c:	6a 00                	push   $0x0
  pushl $187
8010740e:	68 bb 00 00 00       	push   $0xbb
  jmp alltraps
80107413:	e9 46 f2 ff ff       	jmp    8010665e <alltraps>

80107418 <vector188>:
.globl vector188
vector188:
  pushl $0
80107418:	6a 00                	push   $0x0
  pushl $188
8010741a:	68 bc 00 00 00       	push   $0xbc
  jmp alltraps
8010741f:	e9 3a f2 ff ff       	jmp    8010665e <alltraps>

80107424 <vector189>:
.globl vector189
vector189:
  pushl $0
80107424:	6a 00                	push   $0x0
  pushl $189
80107426:	68 bd 00 00 00       	push   $0xbd
  jmp alltraps
8010742b:	e9 2e f2 ff ff       	jmp    8010665e <alltraps>

80107430 <vector190>:
.globl vector190
vector190:
  pushl $0
80107430:	6a 00                	push   $0x0
  pushl $190
80107432:	68 be 00 00 00       	push   $0xbe
  jmp alltraps
80107437:	e9 22 f2 ff ff       	jmp    8010665e <alltraps>

8010743c <vector191>:
.globl vector191
vector191:
  pushl $0
8010743c:	6a 00                	push   $0x0
  pushl $191
8010743e:	68 bf 00 00 00       	push   $0xbf
  jmp alltraps
80107443:	e9 16 f2 ff ff       	jmp    8010665e <alltraps>

80107448 <vector192>:
.globl vector192
vector192:
  pushl $0
80107448:	6a 00                	push   $0x0
  pushl $192
8010744a:	68 c0 00 00 00       	push   $0xc0
  jmp alltraps
8010744f:	e9 0a f2 ff ff       	jmp    8010665e <alltraps>

80107454 <vector193>:
.globl vector193
vector193:
  pushl $0
80107454:	6a 00                	push   $0x0
  pushl $193
80107456:	68 c1 00 00 00       	push   $0xc1
  jmp alltraps
8010745b:	e9 fe f1 ff ff       	jmp    8010665e <alltraps>

80107460 <vector194>:
.globl vector194
vector194:
  pushl $0
80107460:	6a 00                	push   $0x0
  pushl $194
80107462:	68 c2 00 00 00       	push   $0xc2
  jmp alltraps
80107467:	e9 f2 f1 ff ff       	jmp    8010665e <alltraps>

8010746c <vector195>:
.globl vector195
vector195:
  pushl $0
8010746c:	6a 00                	push   $0x0
  pushl $195
8010746e:	68 c3 00 00 00       	push   $0xc3
  jmp alltraps
80107473:	e9 e6 f1 ff ff       	jmp    8010665e <alltraps>

80107478 <vector196>:
.globl vector196
vector196:
  pushl $0
80107478:	6a 00                	push   $0x0
  pushl $196
8010747a:	68 c4 00 00 00       	push   $0xc4
  jmp alltraps
8010747f:	e9 da f1 ff ff       	jmp    8010665e <alltraps>

80107484 <vector197>:
.globl vector197
vector197:
  pushl $0
80107484:	6a 00                	push   $0x0
  pushl $197
80107486:	68 c5 00 00 00       	push   $0xc5
  jmp alltraps
8010748b:	e9 ce f1 ff ff       	jmp    8010665e <alltraps>

80107490 <vector198>:
.globl vector198
vector198:
  pushl $0
80107490:	6a 00                	push   $0x0
  pushl $198
80107492:	68 c6 00 00 00       	push   $0xc6
  jmp alltraps
80107497:	e9 c2 f1 ff ff       	jmp    8010665e <alltraps>

8010749c <vector199>:
.globl vector199
vector199:
  pushl $0
8010749c:	6a 00                	push   $0x0
  pushl $199
8010749e:	68 c7 00 00 00       	push   $0xc7
  jmp alltraps
801074a3:	e9 b6 f1 ff ff       	jmp    8010665e <alltraps>

801074a8 <vector200>:
.globl vector200
vector200:
  pushl $0
801074a8:	6a 00                	push   $0x0
  pushl $200
801074aa:	68 c8 00 00 00       	push   $0xc8
  jmp alltraps
801074af:	e9 aa f1 ff ff       	jmp    8010665e <alltraps>

801074b4 <vector201>:
.globl vector201
vector201:
  pushl $0
801074b4:	6a 00                	push   $0x0
  pushl $201
801074b6:	68 c9 00 00 00       	push   $0xc9
  jmp alltraps
801074bb:	e9 9e f1 ff ff       	jmp    8010665e <alltraps>

801074c0 <vector202>:
.globl vector202
vector202:
  pushl $0
801074c0:	6a 00                	push   $0x0
  pushl $202
801074c2:	68 ca 00 00 00       	push   $0xca
  jmp alltraps
801074c7:	e9 92 f1 ff ff       	jmp    8010665e <alltraps>

801074cc <vector203>:
.globl vector203
vector203:
  pushl $0
801074cc:	6a 00                	push   $0x0
  pushl $203
801074ce:	68 cb 00 00 00       	push   $0xcb
  jmp alltraps
801074d3:	e9 86 f1 ff ff       	jmp    8010665e <alltraps>

801074d8 <vector204>:
.globl vector204
vector204:
  pushl $0
801074d8:	6a 00                	push   $0x0
  pushl $204
801074da:	68 cc 00 00 00       	push   $0xcc
  jmp alltraps
801074df:	e9 7a f1 ff ff       	jmp    8010665e <alltraps>

801074e4 <vector205>:
.globl vector205
vector205:
  pushl $0
801074e4:	6a 00                	push   $0x0
  pushl $205
801074e6:	68 cd 00 00 00       	push   $0xcd
  jmp alltraps
801074eb:	e9 6e f1 ff ff       	jmp    8010665e <alltraps>

801074f0 <vector206>:
.globl vector206
vector206:
  pushl $0
801074f0:	6a 00                	push   $0x0
  pushl $206
801074f2:	68 ce 00 00 00       	push   $0xce
  jmp alltraps
801074f7:	e9 62 f1 ff ff       	jmp    8010665e <alltraps>

801074fc <vector207>:
.globl vector207
vector207:
  pushl $0
801074fc:	6a 00                	push   $0x0
  pushl $207
801074fe:	68 cf 00 00 00       	push   $0xcf
  jmp alltraps
80107503:	e9 56 f1 ff ff       	jmp    8010665e <alltraps>

80107508 <vector208>:
.globl vector208
vector208:
  pushl $0
80107508:	6a 00                	push   $0x0
  pushl $208
8010750a:	68 d0 00 00 00       	push   $0xd0
  jmp alltraps
8010750f:	e9 4a f1 ff ff       	jmp    8010665e <alltraps>

80107514 <vector209>:
.globl vector209
vector209:
  pushl $0
80107514:	6a 00                	push   $0x0
  pushl $209
80107516:	68 d1 00 00 00       	push   $0xd1
  jmp alltraps
8010751b:	e9 3e f1 ff ff       	jmp    8010665e <alltraps>

80107520 <vector210>:
.globl vector210
vector210:
  pushl $0
80107520:	6a 00                	push   $0x0
  pushl $210
80107522:	68 d2 00 00 00       	push   $0xd2
  jmp alltraps
80107527:	e9 32 f1 ff ff       	jmp    8010665e <alltraps>

8010752c <vector211>:
.globl vector211
vector211:
  pushl $0
8010752c:	6a 00                	push   $0x0
  pushl $211
8010752e:	68 d3 00 00 00       	push   $0xd3
  jmp alltraps
80107533:	e9 26 f1 ff ff       	jmp    8010665e <alltraps>

80107538 <vector212>:
.globl vector212
vector212:
  pushl $0
80107538:	6a 00                	push   $0x0
  pushl $212
8010753a:	68 d4 00 00 00       	push   $0xd4
  jmp alltraps
8010753f:	e9 1a f1 ff ff       	jmp    8010665e <alltraps>

80107544 <vector213>:
.globl vector213
vector213:
  pushl $0
80107544:	6a 00                	push   $0x0
  pushl $213
80107546:	68 d5 00 00 00       	push   $0xd5
  jmp alltraps
8010754b:	e9 0e f1 ff ff       	jmp    8010665e <alltraps>

80107550 <vector214>:
.globl vector214
vector214:
  pushl $0
80107550:	6a 00                	push   $0x0
  pushl $214
80107552:	68 d6 00 00 00       	push   $0xd6
  jmp alltraps
80107557:	e9 02 f1 ff ff       	jmp    8010665e <alltraps>

8010755c <vector215>:
.globl vector215
vector215:
  pushl $0
8010755c:	6a 00                	push   $0x0
  pushl $215
8010755e:	68 d7 00 00 00       	push   $0xd7
  jmp alltraps
80107563:	e9 f6 f0 ff ff       	jmp    8010665e <alltraps>

80107568 <vector216>:
.globl vector216
vector216:
  pushl $0
80107568:	6a 00                	push   $0x0
  pushl $216
8010756a:	68 d8 00 00 00       	push   $0xd8
  jmp alltraps
8010756f:	e9 ea f0 ff ff       	jmp    8010665e <alltraps>

80107574 <vector217>:
.globl vector217
vector217:
  pushl $0
80107574:	6a 00                	push   $0x0
  pushl $217
80107576:	68 d9 00 00 00       	push   $0xd9
  jmp alltraps
8010757b:	e9 de f0 ff ff       	jmp    8010665e <alltraps>

80107580 <vector218>:
.globl vector218
vector218:
  pushl $0
80107580:	6a 00                	push   $0x0
  pushl $218
80107582:	68 da 00 00 00       	push   $0xda
  jmp alltraps
80107587:	e9 d2 f0 ff ff       	jmp    8010665e <alltraps>

8010758c <vector219>:
.globl vector219
vector219:
  pushl $0
8010758c:	6a 00                	push   $0x0
  pushl $219
8010758e:	68 db 00 00 00       	push   $0xdb
  jmp alltraps
80107593:	e9 c6 f0 ff ff       	jmp    8010665e <alltraps>

80107598 <vector220>:
.globl vector220
vector220:
  pushl $0
80107598:	6a 00                	push   $0x0
  pushl $220
8010759a:	68 dc 00 00 00       	push   $0xdc
  jmp alltraps
8010759f:	e9 ba f0 ff ff       	jmp    8010665e <alltraps>

801075a4 <vector221>:
.globl vector221
vector221:
  pushl $0
801075a4:	6a 00                	push   $0x0
  pushl $221
801075a6:	68 dd 00 00 00       	push   $0xdd
  jmp alltraps
801075ab:	e9 ae f0 ff ff       	jmp    8010665e <alltraps>

801075b0 <vector222>:
.globl vector222
vector222:
  pushl $0
801075b0:	6a 00                	push   $0x0
  pushl $222
801075b2:	68 de 00 00 00       	push   $0xde
  jmp alltraps
801075b7:	e9 a2 f0 ff ff       	jmp    8010665e <alltraps>

801075bc <vector223>:
.globl vector223
vector223:
  pushl $0
801075bc:	6a 00                	push   $0x0
  pushl $223
801075be:	68 df 00 00 00       	push   $0xdf
  jmp alltraps
801075c3:	e9 96 f0 ff ff       	jmp    8010665e <alltraps>

801075c8 <vector224>:
.globl vector224
vector224:
  pushl $0
801075c8:	6a 00                	push   $0x0
  pushl $224
801075ca:	68 e0 00 00 00       	push   $0xe0
  jmp alltraps
801075cf:	e9 8a f0 ff ff       	jmp    8010665e <alltraps>

801075d4 <vector225>:
.globl vector225
vector225:
  pushl $0
801075d4:	6a 00                	push   $0x0
  pushl $225
801075d6:	68 e1 00 00 00       	push   $0xe1
  jmp alltraps
801075db:	e9 7e f0 ff ff       	jmp    8010665e <alltraps>

801075e0 <vector226>:
.globl vector226
vector226:
  pushl $0
801075e0:	6a 00                	push   $0x0
  pushl $226
801075e2:	68 e2 00 00 00       	push   $0xe2
  jmp alltraps
801075e7:	e9 72 f0 ff ff       	jmp    8010665e <alltraps>

801075ec <vector227>:
.globl vector227
vector227:
  pushl $0
801075ec:	6a 00                	push   $0x0
  pushl $227
801075ee:	68 e3 00 00 00       	push   $0xe3
  jmp alltraps
801075f3:	e9 66 f0 ff ff       	jmp    8010665e <alltraps>

801075f8 <vector228>:
.globl vector228
vector228:
  pushl $0
801075f8:	6a 00                	push   $0x0
  pushl $228
801075fa:	68 e4 00 00 00       	push   $0xe4
  jmp alltraps
801075ff:	e9 5a f0 ff ff       	jmp    8010665e <alltraps>

80107604 <vector229>:
.globl vector229
vector229:
  pushl $0
80107604:	6a 00                	push   $0x0
  pushl $229
80107606:	68 e5 00 00 00       	push   $0xe5
  jmp alltraps
8010760b:	e9 4e f0 ff ff       	jmp    8010665e <alltraps>

80107610 <vector230>:
.globl vector230
vector230:
  pushl $0
80107610:	6a 00                	push   $0x0
  pushl $230
80107612:	68 e6 00 00 00       	push   $0xe6
  jmp alltraps
80107617:	e9 42 f0 ff ff       	jmp    8010665e <alltraps>

8010761c <vector231>:
.globl vector231
vector231:
  pushl $0
8010761c:	6a 00                	push   $0x0
  pushl $231
8010761e:	68 e7 00 00 00       	push   $0xe7
  jmp alltraps
80107623:	e9 36 f0 ff ff       	jmp    8010665e <alltraps>

80107628 <vector232>:
.globl vector232
vector232:
  pushl $0
80107628:	6a 00                	push   $0x0
  pushl $232
8010762a:	68 e8 00 00 00       	push   $0xe8
  jmp alltraps
8010762f:	e9 2a f0 ff ff       	jmp    8010665e <alltraps>

80107634 <vector233>:
.globl vector233
vector233:
  pushl $0
80107634:	6a 00                	push   $0x0
  pushl $233
80107636:	68 e9 00 00 00       	push   $0xe9
  jmp alltraps
8010763b:	e9 1e f0 ff ff       	jmp    8010665e <alltraps>

80107640 <vector234>:
.globl vector234
vector234:
  pushl $0
80107640:	6a 00                	push   $0x0
  pushl $234
80107642:	68 ea 00 00 00       	push   $0xea
  jmp alltraps
80107647:	e9 12 f0 ff ff       	jmp    8010665e <alltraps>

8010764c <vector235>:
.globl vector235
vector235:
  pushl $0
8010764c:	6a 00                	push   $0x0
  pushl $235
8010764e:	68 eb 00 00 00       	push   $0xeb
  jmp alltraps
80107653:	e9 06 f0 ff ff       	jmp    8010665e <alltraps>

80107658 <vector236>:
.globl vector236
vector236:
  pushl $0
80107658:	6a 00                	push   $0x0
  pushl $236
8010765a:	68 ec 00 00 00       	push   $0xec
  jmp alltraps
8010765f:	e9 fa ef ff ff       	jmp    8010665e <alltraps>

80107664 <vector237>:
.globl vector237
vector237:
  pushl $0
80107664:	6a 00                	push   $0x0
  pushl $237
80107666:	68 ed 00 00 00       	push   $0xed
  jmp alltraps
8010766b:	e9 ee ef ff ff       	jmp    8010665e <alltraps>

80107670 <vector238>:
.globl vector238
vector238:
  pushl $0
80107670:	6a 00                	push   $0x0
  pushl $238
80107672:	68 ee 00 00 00       	push   $0xee
  jmp alltraps
80107677:	e9 e2 ef ff ff       	jmp    8010665e <alltraps>

8010767c <vector239>:
.globl vector239
vector239:
  pushl $0
8010767c:	6a 00                	push   $0x0
  pushl $239
8010767e:	68 ef 00 00 00       	push   $0xef
  jmp alltraps
80107683:	e9 d6 ef ff ff       	jmp    8010665e <alltraps>

80107688 <vector240>:
.globl vector240
vector240:
  pushl $0
80107688:	6a 00                	push   $0x0
  pushl $240
8010768a:	68 f0 00 00 00       	push   $0xf0
  jmp alltraps
8010768f:	e9 ca ef ff ff       	jmp    8010665e <alltraps>

80107694 <vector241>:
.globl vector241
vector241:
  pushl $0
80107694:	6a 00                	push   $0x0
  pushl $241
80107696:	68 f1 00 00 00       	push   $0xf1
  jmp alltraps
8010769b:	e9 be ef ff ff       	jmp    8010665e <alltraps>

801076a0 <vector242>:
.globl vector242
vector242:
  pushl $0
801076a0:	6a 00                	push   $0x0
  pushl $242
801076a2:	68 f2 00 00 00       	push   $0xf2
  jmp alltraps
801076a7:	e9 b2 ef ff ff       	jmp    8010665e <alltraps>

801076ac <vector243>:
.globl vector243
vector243:
  pushl $0
801076ac:	6a 00                	push   $0x0
  pushl $243
801076ae:	68 f3 00 00 00       	push   $0xf3
  jmp alltraps
801076b3:	e9 a6 ef ff ff       	jmp    8010665e <alltraps>

801076b8 <vector244>:
.globl vector244
vector244:
  pushl $0
801076b8:	6a 00                	push   $0x0
  pushl $244
801076ba:	68 f4 00 00 00       	push   $0xf4
  jmp alltraps
801076bf:	e9 9a ef ff ff       	jmp    8010665e <alltraps>

801076c4 <vector245>:
.globl vector245
vector245:
  pushl $0
801076c4:	6a 00                	push   $0x0
  pushl $245
801076c6:	68 f5 00 00 00       	push   $0xf5
  jmp alltraps
801076cb:	e9 8e ef ff ff       	jmp    8010665e <alltraps>

801076d0 <vector246>:
.globl vector246
vector246:
  pushl $0
801076d0:	6a 00                	push   $0x0
  pushl $246
801076d2:	68 f6 00 00 00       	push   $0xf6
  jmp alltraps
801076d7:	e9 82 ef ff ff       	jmp    8010665e <alltraps>

801076dc <vector247>:
.globl vector247
vector247:
  pushl $0
801076dc:	6a 00                	push   $0x0
  pushl $247
801076de:	68 f7 00 00 00       	push   $0xf7
  jmp alltraps
801076e3:	e9 76 ef ff ff       	jmp    8010665e <alltraps>

801076e8 <vector248>:
.globl vector248
vector248:
  pushl $0
801076e8:	6a 00                	push   $0x0
  pushl $248
801076ea:	68 f8 00 00 00       	push   $0xf8
  jmp alltraps
801076ef:	e9 6a ef ff ff       	jmp    8010665e <alltraps>

801076f4 <vector249>:
.globl vector249
vector249:
  pushl $0
801076f4:	6a 00                	push   $0x0
  pushl $249
801076f6:	68 f9 00 00 00       	push   $0xf9
  jmp alltraps
801076fb:	e9 5e ef ff ff       	jmp    8010665e <alltraps>

80107700 <vector250>:
.globl vector250
vector250:
  pushl $0
80107700:	6a 00                	push   $0x0
  pushl $250
80107702:	68 fa 00 00 00       	push   $0xfa
  jmp alltraps
80107707:	e9 52 ef ff ff       	jmp    8010665e <alltraps>

8010770c <vector251>:
.globl vector251
vector251:
  pushl $0
8010770c:	6a 00                	push   $0x0
  pushl $251
8010770e:	68 fb 00 00 00       	push   $0xfb
  jmp alltraps
80107713:	e9 46 ef ff ff       	jmp    8010665e <alltraps>

80107718 <vector252>:
.globl vector252
vector252:
  pushl $0
80107718:	6a 00                	push   $0x0
  pushl $252
8010771a:	68 fc 00 00 00       	push   $0xfc
  jmp alltraps
8010771f:	e9 3a ef ff ff       	jmp    8010665e <alltraps>

80107724 <vector253>:
.globl vector253
vector253:
  pushl $0
80107724:	6a 00                	push   $0x0
  pushl $253
80107726:	68 fd 00 00 00       	push   $0xfd
  jmp alltraps
8010772b:	e9 2e ef ff ff       	jmp    8010665e <alltraps>

80107730 <vector254>:
.globl vector254
vector254:
  pushl $0
80107730:	6a 00                	push   $0x0
  pushl $254
80107732:	68 fe 00 00 00       	push   $0xfe
  jmp alltraps
80107737:	e9 22 ef ff ff       	jmp    8010665e <alltraps>

8010773c <vector255>:
.globl vector255
vector255:
  pushl $0
8010773c:	6a 00                	push   $0x0
  pushl $255
8010773e:	68 ff 00 00 00       	push   $0xff
  jmp alltraps
80107743:	e9 16 ef ff ff       	jmp    8010665e <alltraps>

80107748 <lgdt>:
{
80107748:	55                   	push   %ebp
80107749:	89 e5                	mov    %esp,%ebp
8010774b:	83 ec 10             	sub    $0x10,%esp
  pd[0] = size-1;
8010774e:	8b 45 0c             	mov    0xc(%ebp),%eax
80107751:	83 e8 01             	sub    $0x1,%eax
80107754:	66 89 45 fa          	mov    %ax,-0x6(%ebp)
  pd[1] = (uint)p;
80107758:	8b 45 08             	mov    0x8(%ebp),%eax
8010775b:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  pd[2] = (uint)p >> 16;
8010775f:	8b 45 08             	mov    0x8(%ebp),%eax
80107762:	c1 e8 10             	shr    $0x10,%eax
80107765:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
  asm volatile("lgdt (%0)" : : "r" (pd));
80107769:	8d 45 fa             	lea    -0x6(%ebp),%eax
8010776c:	0f 01 10             	lgdtl  (%eax)
}
8010776f:	90                   	nop
80107770:	c9                   	leave
80107771:	c3                   	ret

80107772 <ltr>:
{
80107772:	55                   	push   %ebp
80107773:	89 e5                	mov    %esp,%ebp
80107775:	83 ec 04             	sub    $0x4,%esp
80107778:	8b 45 08             	mov    0x8(%ebp),%eax
8010777b:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  asm volatile("ltr %0" : : "r" (sel));
8010777f:	0f b7 45 fc          	movzwl -0x4(%ebp),%eax
80107783:	0f 00 d8             	ltr    %eax
}
80107786:	90                   	nop
80107787:	c9                   	leave
80107788:	c3                   	ret

80107789 <lcr3>:

static inline void
lcr3(uint val)
{
80107789:	55                   	push   %ebp
8010778a:	89 e5                	mov    %esp,%ebp
  asm volatile("movl %0,%%cr3" : : "r" (val));
8010778c:	8b 45 08             	mov    0x8(%ebp),%eax
8010778f:	0f 22 d8             	mov    %eax,%cr3
}
80107792:	90                   	nop
80107793:	5d                   	pop    %ebp
80107794:	c3                   	ret

80107795 <seginit>:

// Set up CPU's kernel segment descriptors.
// Run once on entry on each CPU.
void
seginit(void)
{
80107795:	55                   	push   %ebp
80107796:	89 e5                	mov    %esp,%ebp
80107798:	83 ec 18             	sub    $0x18,%esp

  // Map "logical" addresses to virtual addresses using identity map.
  // Cannot share a CODE descriptor for both kernel and user
  // because it would have to have DPL_USR, but the CPU forbids
  // an interrupt from CPL=0 to DPL=3.
  c = &cpus[cpuid()];
8010779b:	e8 52 ca ff ff       	call   801041f2 <cpuid>
801077a0:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
801077a6:	05 e0 27 11 80       	add    $0x801127e0,%eax
801077ab:	89 45 f4             	mov    %eax,-0xc(%ebp)
  c->gdt[SEG_KCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, 0);
801077ae:	8b 45 f4             	mov    -0xc(%ebp),%eax
801077b1:	66 c7 40 78 ff ff    	movw   $0xffff,0x78(%eax)
801077b7:	8b 45 f4             	mov    -0xc(%ebp),%eax
801077ba:	66 c7 40 7a 00 00    	movw   $0x0,0x7a(%eax)
801077c0:	8b 45 f4             	mov    -0xc(%ebp),%eax
801077c3:	c6 40 7c 00          	movb   $0x0,0x7c(%eax)
801077c7:	8b 45 f4             	mov    -0xc(%ebp),%eax
801077ca:	0f b6 50 7d          	movzbl 0x7d(%eax),%edx
801077ce:	83 e2 f0             	and    $0xfffffff0,%edx
801077d1:	83 ca 0a             	or     $0xa,%edx
801077d4:	88 50 7d             	mov    %dl,0x7d(%eax)
801077d7:	8b 45 f4             	mov    -0xc(%ebp),%eax
801077da:	0f b6 50 7d          	movzbl 0x7d(%eax),%edx
801077de:	83 ca 10             	or     $0x10,%edx
801077e1:	88 50 7d             	mov    %dl,0x7d(%eax)
801077e4:	8b 45 f4             	mov    -0xc(%ebp),%eax
801077e7:	0f b6 50 7d          	movzbl 0x7d(%eax),%edx
801077eb:	83 e2 9f             	and    $0xffffff9f,%edx
801077ee:	88 50 7d             	mov    %dl,0x7d(%eax)
801077f1:	8b 45 f4             	mov    -0xc(%ebp),%eax
801077f4:	0f b6 50 7d          	movzbl 0x7d(%eax),%edx
801077f8:	83 ca 80             	or     $0xffffff80,%edx
801077fb:	88 50 7d             	mov    %dl,0x7d(%eax)
801077fe:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107801:	0f b6 50 7e          	movzbl 0x7e(%eax),%edx
80107805:	83 ca 0f             	or     $0xf,%edx
80107808:	88 50 7e             	mov    %dl,0x7e(%eax)
8010780b:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010780e:	0f b6 50 7e          	movzbl 0x7e(%eax),%edx
80107812:	83 e2 ef             	and    $0xffffffef,%edx
80107815:	88 50 7e             	mov    %dl,0x7e(%eax)
80107818:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010781b:	0f b6 50 7e          	movzbl 0x7e(%eax),%edx
8010781f:	83 e2 df             	and    $0xffffffdf,%edx
80107822:	88 50 7e             	mov    %dl,0x7e(%eax)
80107825:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107828:	0f b6 50 7e          	movzbl 0x7e(%eax),%edx
8010782c:	83 ca 40             	or     $0x40,%edx
8010782f:	88 50 7e             	mov    %dl,0x7e(%eax)
80107832:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107835:	0f b6 50 7e          	movzbl 0x7e(%eax),%edx
80107839:	83 ca 80             	or     $0xffffff80,%edx
8010783c:	88 50 7e             	mov    %dl,0x7e(%eax)
8010783f:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107842:	c6 40 7f 00          	movb   $0x0,0x7f(%eax)
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
80107846:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107849:	66 c7 80 80 00 00 00 	movw   $0xffff,0x80(%eax)
80107850:	ff ff 
80107852:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107855:	66 c7 80 82 00 00 00 	movw   $0x0,0x82(%eax)
8010785c:	00 00 
8010785e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107861:	c6 80 84 00 00 00 00 	movb   $0x0,0x84(%eax)
80107868:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010786b:	0f b6 90 85 00 00 00 	movzbl 0x85(%eax),%edx
80107872:	83 e2 f0             	and    $0xfffffff0,%edx
80107875:	83 ca 02             	or     $0x2,%edx
80107878:	88 90 85 00 00 00    	mov    %dl,0x85(%eax)
8010787e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107881:	0f b6 90 85 00 00 00 	movzbl 0x85(%eax),%edx
80107888:	83 ca 10             	or     $0x10,%edx
8010788b:	88 90 85 00 00 00    	mov    %dl,0x85(%eax)
80107891:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107894:	0f b6 90 85 00 00 00 	movzbl 0x85(%eax),%edx
8010789b:	83 e2 9f             	and    $0xffffff9f,%edx
8010789e:	88 90 85 00 00 00    	mov    %dl,0x85(%eax)
801078a4:	8b 45 f4             	mov    -0xc(%ebp),%eax
801078a7:	0f b6 90 85 00 00 00 	movzbl 0x85(%eax),%edx
801078ae:	83 ca 80             	or     $0xffffff80,%edx
801078b1:	88 90 85 00 00 00    	mov    %dl,0x85(%eax)
801078b7:	8b 45 f4             	mov    -0xc(%ebp),%eax
801078ba:	0f b6 90 86 00 00 00 	movzbl 0x86(%eax),%edx
801078c1:	83 ca 0f             	or     $0xf,%edx
801078c4:	88 90 86 00 00 00    	mov    %dl,0x86(%eax)
801078ca:	8b 45 f4             	mov    -0xc(%ebp),%eax
801078cd:	0f b6 90 86 00 00 00 	movzbl 0x86(%eax),%edx
801078d4:	83 e2 ef             	and    $0xffffffef,%edx
801078d7:	88 90 86 00 00 00    	mov    %dl,0x86(%eax)
801078dd:	8b 45 f4             	mov    -0xc(%ebp),%eax
801078e0:	0f b6 90 86 00 00 00 	movzbl 0x86(%eax),%edx
801078e7:	83 e2 df             	and    $0xffffffdf,%edx
801078ea:	88 90 86 00 00 00    	mov    %dl,0x86(%eax)
801078f0:	8b 45 f4             	mov    -0xc(%ebp),%eax
801078f3:	0f b6 90 86 00 00 00 	movzbl 0x86(%eax),%edx
801078fa:	83 ca 40             	or     $0x40,%edx
801078fd:	88 90 86 00 00 00    	mov    %dl,0x86(%eax)
80107903:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107906:	0f b6 90 86 00 00 00 	movzbl 0x86(%eax),%edx
8010790d:	83 ca 80             	or     $0xffffff80,%edx
80107910:	88 90 86 00 00 00    	mov    %dl,0x86(%eax)
80107916:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107919:	c6 80 87 00 00 00 00 	movb   $0x0,0x87(%eax)
  c->gdt[SEG_UCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, DPL_USER);
80107920:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107923:	66 c7 80 88 00 00 00 	movw   $0xffff,0x88(%eax)
8010792a:	ff ff 
8010792c:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010792f:	66 c7 80 8a 00 00 00 	movw   $0x0,0x8a(%eax)
80107936:	00 00 
80107938:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010793b:	c6 80 8c 00 00 00 00 	movb   $0x0,0x8c(%eax)
80107942:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107945:	0f b6 90 8d 00 00 00 	movzbl 0x8d(%eax),%edx
8010794c:	83 e2 f0             	and    $0xfffffff0,%edx
8010794f:	83 ca 0a             	or     $0xa,%edx
80107952:	88 90 8d 00 00 00    	mov    %dl,0x8d(%eax)
80107958:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010795b:	0f b6 90 8d 00 00 00 	movzbl 0x8d(%eax),%edx
80107962:	83 ca 10             	or     $0x10,%edx
80107965:	88 90 8d 00 00 00    	mov    %dl,0x8d(%eax)
8010796b:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010796e:	0f b6 90 8d 00 00 00 	movzbl 0x8d(%eax),%edx
80107975:	83 ca 60             	or     $0x60,%edx
80107978:	88 90 8d 00 00 00    	mov    %dl,0x8d(%eax)
8010797e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107981:	0f b6 90 8d 00 00 00 	movzbl 0x8d(%eax),%edx
80107988:	83 ca 80             	or     $0xffffff80,%edx
8010798b:	88 90 8d 00 00 00    	mov    %dl,0x8d(%eax)
80107991:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107994:	0f b6 90 8e 00 00 00 	movzbl 0x8e(%eax),%edx
8010799b:	83 ca 0f             	or     $0xf,%edx
8010799e:	88 90 8e 00 00 00    	mov    %dl,0x8e(%eax)
801079a4:	8b 45 f4             	mov    -0xc(%ebp),%eax
801079a7:	0f b6 90 8e 00 00 00 	movzbl 0x8e(%eax),%edx
801079ae:	83 e2 ef             	and    $0xffffffef,%edx
801079b1:	88 90 8e 00 00 00    	mov    %dl,0x8e(%eax)
801079b7:	8b 45 f4             	mov    -0xc(%ebp),%eax
801079ba:	0f b6 90 8e 00 00 00 	movzbl 0x8e(%eax),%edx
801079c1:	83 e2 df             	and    $0xffffffdf,%edx
801079c4:	88 90 8e 00 00 00    	mov    %dl,0x8e(%eax)
801079ca:	8b 45 f4             	mov    -0xc(%ebp),%eax
801079cd:	0f b6 90 8e 00 00 00 	movzbl 0x8e(%eax),%edx
801079d4:	83 ca 40             	or     $0x40,%edx
801079d7:	88 90 8e 00 00 00    	mov    %dl,0x8e(%eax)
801079dd:	8b 45 f4             	mov    -0xc(%ebp),%eax
801079e0:	0f b6 90 8e 00 00 00 	movzbl 0x8e(%eax),%edx
801079e7:	83 ca 80             	or     $0xffffff80,%edx
801079ea:	88 90 8e 00 00 00    	mov    %dl,0x8e(%eax)
801079f0:	8b 45 f4             	mov    -0xc(%ebp),%eax
801079f3:	c6 80 8f 00 00 00 00 	movb   $0x0,0x8f(%eax)
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
801079fa:	8b 45 f4             	mov    -0xc(%ebp),%eax
801079fd:	66 c7 80 90 00 00 00 	movw   $0xffff,0x90(%eax)
80107a04:	ff ff 
80107a06:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107a09:	66 c7 80 92 00 00 00 	movw   $0x0,0x92(%eax)
80107a10:	00 00 
80107a12:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107a15:	c6 80 94 00 00 00 00 	movb   $0x0,0x94(%eax)
80107a1c:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107a1f:	0f b6 90 95 00 00 00 	movzbl 0x95(%eax),%edx
80107a26:	83 e2 f0             	and    $0xfffffff0,%edx
80107a29:	83 ca 02             	or     $0x2,%edx
80107a2c:	88 90 95 00 00 00    	mov    %dl,0x95(%eax)
80107a32:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107a35:	0f b6 90 95 00 00 00 	movzbl 0x95(%eax),%edx
80107a3c:	83 ca 10             	or     $0x10,%edx
80107a3f:	88 90 95 00 00 00    	mov    %dl,0x95(%eax)
80107a45:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107a48:	0f b6 90 95 00 00 00 	movzbl 0x95(%eax),%edx
80107a4f:	83 ca 60             	or     $0x60,%edx
80107a52:	88 90 95 00 00 00    	mov    %dl,0x95(%eax)
80107a58:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107a5b:	0f b6 90 95 00 00 00 	movzbl 0x95(%eax),%edx
80107a62:	83 ca 80             	or     $0xffffff80,%edx
80107a65:	88 90 95 00 00 00    	mov    %dl,0x95(%eax)
80107a6b:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107a6e:	0f b6 90 96 00 00 00 	movzbl 0x96(%eax),%edx
80107a75:	83 ca 0f             	or     $0xf,%edx
80107a78:	88 90 96 00 00 00    	mov    %dl,0x96(%eax)
80107a7e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107a81:	0f b6 90 96 00 00 00 	movzbl 0x96(%eax),%edx
80107a88:	83 e2 ef             	and    $0xffffffef,%edx
80107a8b:	88 90 96 00 00 00    	mov    %dl,0x96(%eax)
80107a91:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107a94:	0f b6 90 96 00 00 00 	movzbl 0x96(%eax),%edx
80107a9b:	83 e2 df             	and    $0xffffffdf,%edx
80107a9e:	88 90 96 00 00 00    	mov    %dl,0x96(%eax)
80107aa4:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107aa7:	0f b6 90 96 00 00 00 	movzbl 0x96(%eax),%edx
80107aae:	83 ca 40             	or     $0x40,%edx
80107ab1:	88 90 96 00 00 00    	mov    %dl,0x96(%eax)
80107ab7:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107aba:	0f b6 90 96 00 00 00 	movzbl 0x96(%eax),%edx
80107ac1:	83 ca 80             	or     $0xffffff80,%edx
80107ac4:	88 90 96 00 00 00    	mov    %dl,0x96(%eax)
80107aca:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107acd:	c6 80 97 00 00 00 00 	movb   $0x0,0x97(%eax)
  lgdt(c->gdt, sizeof(c->gdt));
80107ad4:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107ad7:	83 c0 70             	add    $0x70,%eax
80107ada:	83 ec 08             	sub    $0x8,%esp
80107add:	6a 30                	push   $0x30
80107adf:	50                   	push   %eax
80107ae0:	e8 63 fc ff ff       	call   80107748 <lgdt>
80107ae5:	83 c4 10             	add    $0x10,%esp
}
80107ae8:	90                   	nop
80107ae9:	c9                   	leave
80107aea:	c3                   	ret

80107aeb <walkpgdir>:
// Return the address of the PTE in page table pgdir
// that corresponds to virtual address va.  If alloc!=0,
// create any required page table pages.
static pte_t *
walkpgdir(pde_t *pgdir, const void *va, int alloc)
{
80107aeb:	55                   	push   %ebp
80107aec:	89 e5                	mov    %esp,%ebp
80107aee:	83 ec 18             	sub    $0x18,%esp
  pde_t *pde;
  pte_t *pgtab;

  pde = &pgdir[PDX(va)];
80107af1:	8b 45 0c             	mov    0xc(%ebp),%eax
80107af4:	c1 e8 16             	shr    $0x16,%eax
80107af7:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80107afe:	8b 45 08             	mov    0x8(%ebp),%eax
80107b01:	01 d0                	add    %edx,%eax
80107b03:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(*pde & PTE_P){
80107b06:	8b 45 f0             	mov    -0x10(%ebp),%eax
80107b09:	8b 00                	mov    (%eax),%eax
80107b0b:	83 e0 01             	and    $0x1,%eax
80107b0e:	85 c0                	test   %eax,%eax
80107b10:	74 14                	je     80107b26 <walkpgdir+0x3b>
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80107b12:	8b 45 f0             	mov    -0x10(%ebp),%eax
80107b15:	8b 00                	mov    (%eax),%eax
80107b17:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80107b1c:	05 00 00 00 80       	add    $0x80000000,%eax
80107b21:	89 45 f4             	mov    %eax,-0xc(%ebp)
80107b24:	eb 42                	jmp    80107b68 <walkpgdir+0x7d>
  } else {
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)
80107b26:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80107b2a:	74 0e                	je     80107b3a <walkpgdir+0x4f>
80107b2c:	e8 61 b1 ff ff       	call   80102c92 <kalloc>
80107b31:	89 45 f4             	mov    %eax,-0xc(%ebp)
80107b34:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80107b38:	75 07                	jne    80107b41 <walkpgdir+0x56>
      return 0;
80107b3a:	b8 00 00 00 00       	mov    $0x0,%eax
80107b3f:	eb 3e                	jmp    80107b7f <walkpgdir+0x94>
    // Make sure all those PTE_P bits are zero.
    memset(pgtab, 0, PGSIZE);
80107b41:	83 ec 04             	sub    $0x4,%esp
80107b44:	68 00 10 00 00       	push   $0x1000
80107b49:	6a 00                	push   $0x0
80107b4b:	ff 75 f4             	push   -0xc(%ebp)
80107b4e:	e8 1c d7 ff ff       	call   8010526f <memset>
80107b53:	83 c4 10             	add    $0x10,%esp
    // The permissions here are overly generous, but they can
    // be further restricted by the permissions in the page table
    // entries, if necessary.
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80107b56:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107b59:	05 00 00 00 80       	add    $0x80000000,%eax
80107b5e:	83 c8 07             	or     $0x7,%eax
80107b61:	89 c2                	mov    %eax,%edx
80107b63:	8b 45 f0             	mov    -0x10(%ebp),%eax
80107b66:	89 10                	mov    %edx,(%eax)
  }
  return &pgtab[PTX(va)];
80107b68:	8b 45 0c             	mov    0xc(%ebp),%eax
80107b6b:	c1 e8 0c             	shr    $0xc,%eax
80107b6e:	25 ff 03 00 00       	and    $0x3ff,%eax
80107b73:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
80107b7a:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107b7d:	01 d0                	add    %edx,%eax
}
80107b7f:	c9                   	leave
80107b80:	c3                   	ret

80107b81 <mappages>:
// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa. va and size might not
// be page-aligned.
static int
mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm)
{
80107b81:	55                   	push   %ebp
80107b82:	89 e5                	mov    %esp,%ebp
80107b84:	83 ec 18             	sub    $0x18,%esp
  char *a, *last;
  pte_t *pte;

  a = (char*)PGROUNDDOWN((uint)va);
80107b87:	8b 45 0c             	mov    0xc(%ebp),%eax
80107b8a:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80107b8f:	89 45 f4             	mov    %eax,-0xc(%ebp)
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80107b92:	8b 55 0c             	mov    0xc(%ebp),%edx
80107b95:	8b 45 10             	mov    0x10(%ebp),%eax
80107b98:	01 d0                	add    %edx,%eax
80107b9a:	83 e8 01             	sub    $0x1,%eax
80107b9d:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80107ba2:	89 45 f0             	mov    %eax,-0x10(%ebp)
  for(;;){
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
80107ba5:	83 ec 04             	sub    $0x4,%esp
80107ba8:	6a 01                	push   $0x1
80107baa:	ff 75 f4             	push   -0xc(%ebp)
80107bad:	ff 75 08             	push   0x8(%ebp)
80107bb0:	e8 36 ff ff ff       	call   80107aeb <walkpgdir>
80107bb5:	83 c4 10             	add    $0x10,%esp
80107bb8:	89 45 ec             	mov    %eax,-0x14(%ebp)
80107bbb:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
80107bbf:	75 07                	jne    80107bc8 <mappages+0x47>
      return -1;
80107bc1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80107bc6:	eb 47                	jmp    80107c0f <mappages+0x8e>
    if(*pte & PTE_P)
80107bc8:	8b 45 ec             	mov    -0x14(%ebp),%eax
80107bcb:	8b 00                	mov    (%eax),%eax
80107bcd:	83 e0 01             	and    $0x1,%eax
80107bd0:	85 c0                	test   %eax,%eax
80107bd2:	74 0d                	je     80107be1 <mappages+0x60>
      panic("remap");
80107bd4:	83 ec 0c             	sub    $0xc,%esp
80107bd7:	68 04 8a 10 80       	push   $0x80108a04
80107bdc:	e8 d2 89 ff ff       	call   801005b3 <panic>
    *pte = pa | perm | PTE_P;
80107be1:	8b 45 18             	mov    0x18(%ebp),%eax
80107be4:	0b 45 14             	or     0x14(%ebp),%eax
80107be7:	83 c8 01             	or     $0x1,%eax
80107bea:	89 c2                	mov    %eax,%edx
80107bec:	8b 45 ec             	mov    -0x14(%ebp),%eax
80107bef:	89 10                	mov    %edx,(%eax)
    if(a == last)
80107bf1:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107bf4:	3b 45 f0             	cmp    -0x10(%ebp),%eax
80107bf7:	74 10                	je     80107c09 <mappages+0x88>
      break;
    a += PGSIZE;
80107bf9:	81 45 f4 00 10 00 00 	addl   $0x1000,-0xc(%ebp)
    pa += PGSIZE;
80107c00:	81 45 14 00 10 00 00 	addl   $0x1000,0x14(%ebp)
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
80107c07:	eb 9c                	jmp    80107ba5 <mappages+0x24>
      break;
80107c09:	90                   	nop
  }
  return 0;
80107c0a:	b8 00 00 00 00       	mov    $0x0,%eax
}
80107c0f:	c9                   	leave
80107c10:	c3                   	ret

80107c11 <setupkvm>:
};

// Set up kernel part of a page table.
pde_t*
setupkvm(void)
{
80107c11:	55                   	push   %ebp
80107c12:	89 e5                	mov    %esp,%ebp
80107c14:	53                   	push   %ebx
80107c15:	83 ec 14             	sub    $0x14,%esp
  pde_t *pgdir;
  struct kmap *k;

  if((pgdir = (pde_t*)kalloc()) == 0)
80107c18:	e8 75 b0 ff ff       	call   80102c92 <kalloc>
80107c1d:	89 45 f0             	mov    %eax,-0x10(%ebp)
80107c20:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80107c24:	75 07                	jne    80107c2d <setupkvm+0x1c>
    return 0;
80107c26:	b8 00 00 00 00       	mov    $0x0,%eax
80107c2b:	eb 78                	jmp    80107ca5 <setupkvm+0x94>
  memset(pgdir, 0, PGSIZE);
80107c2d:	83 ec 04             	sub    $0x4,%esp
80107c30:	68 00 10 00 00       	push   $0x1000
80107c35:	6a 00                	push   $0x0
80107c37:	ff 75 f0             	push   -0x10(%ebp)
80107c3a:	e8 30 d6 ff ff       	call   8010526f <memset>
80107c3f:	83 c4 10             	add    $0x10,%esp
  if (P2V(PHYSTOP) > (void*)DEVSPACE)
    panic("PHYSTOP too high");
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
80107c42:	c7 45 f4 80 b4 10 80 	movl   $0x8010b480,-0xc(%ebp)
80107c49:	eb 4e                	jmp    80107c99 <setupkvm+0x88>
    if(mappages(pgdir, k->virt, k->phys_end - k->phys_start,
80107c4b:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107c4e:	8b 48 0c             	mov    0xc(%eax),%ecx
80107c51:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107c54:	8b 50 04             	mov    0x4(%eax),%edx
80107c57:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107c5a:	8b 58 08             	mov    0x8(%eax),%ebx
80107c5d:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107c60:	8b 40 04             	mov    0x4(%eax),%eax
80107c63:	29 c3                	sub    %eax,%ebx
80107c65:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107c68:	8b 00                	mov    (%eax),%eax
80107c6a:	83 ec 0c             	sub    $0xc,%esp
80107c6d:	51                   	push   %ecx
80107c6e:	52                   	push   %edx
80107c6f:	53                   	push   %ebx
80107c70:	50                   	push   %eax
80107c71:	ff 75 f0             	push   -0x10(%ebp)
80107c74:	e8 08 ff ff ff       	call   80107b81 <mappages>
80107c79:	83 c4 20             	add    $0x20,%esp
80107c7c:	85 c0                	test   %eax,%eax
80107c7e:	79 15                	jns    80107c95 <setupkvm+0x84>
                (uint)k->phys_start, k->perm) < 0) {
      freevm(pgdir);
80107c80:	83 ec 0c             	sub    $0xc,%esp
80107c83:	ff 75 f0             	push   -0x10(%ebp)
80107c86:	e8 f5 04 00 00       	call   80108180 <freevm>
80107c8b:	83 c4 10             	add    $0x10,%esp
      return 0;
80107c8e:	b8 00 00 00 00       	mov    $0x0,%eax
80107c93:	eb 10                	jmp    80107ca5 <setupkvm+0x94>
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
80107c95:	83 45 f4 10          	addl   $0x10,-0xc(%ebp)
80107c99:	81 7d f4 c0 b4 10 80 	cmpl   $0x8010b4c0,-0xc(%ebp)
80107ca0:	72 a9                	jb     80107c4b <setupkvm+0x3a>
    }
  return pgdir;
80107ca2:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
80107ca5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80107ca8:	c9                   	leave
80107ca9:	c3                   	ret

80107caa <kvmalloc>:

// Allocate one page table for the machine for the kernel address
// space for scheduler processes.
void
kvmalloc(void)
{
80107caa:	55                   	push   %ebp
80107cab:	89 e5                	mov    %esp,%ebp
80107cad:	83 ec 08             	sub    $0x8,%esp
  kpgdir = setupkvm();
80107cb0:	e8 5c ff ff ff       	call   80107c11 <setupkvm>
80107cb5:	a3 fc 54 11 80       	mov    %eax,0x801154fc
  switchkvm();
80107cba:	e8 03 00 00 00       	call   80107cc2 <switchkvm>
}
80107cbf:	90                   	nop
80107cc0:	c9                   	leave
80107cc1:	c3                   	ret

80107cc2 <switchkvm>:

// Switch h/w page table register to the kernel-only page table,
// for when no process is running.
void
switchkvm(void)
{
80107cc2:	55                   	push   %ebp
80107cc3:	89 e5                	mov    %esp,%ebp
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80107cc5:	a1 fc 54 11 80       	mov    0x801154fc,%eax
80107cca:	05 00 00 00 80       	add    $0x80000000,%eax
80107ccf:	50                   	push   %eax
80107cd0:	e8 b4 fa ff ff       	call   80107789 <lcr3>
80107cd5:	83 c4 04             	add    $0x4,%esp
}
80107cd8:	90                   	nop
80107cd9:	c9                   	leave
80107cda:	c3                   	ret

80107cdb <switchuvm>:

// Switch TSS and h/w page table to correspond to process p.
void
switchuvm(struct proc *p)
{
80107cdb:	55                   	push   %ebp
80107cdc:	89 e5                	mov    %esp,%ebp
80107cde:	56                   	push   %esi
80107cdf:	53                   	push   %ebx
80107ce0:	83 ec 10             	sub    $0x10,%esp
  if(p == 0)
80107ce3:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
80107ce7:	75 0d                	jne    80107cf6 <switchuvm+0x1b>
    panic("switchuvm: no process");
80107ce9:	83 ec 0c             	sub    $0xc,%esp
80107cec:	68 0a 8a 10 80       	push   $0x80108a0a
80107cf1:	e8 bd 88 ff ff       	call   801005b3 <panic>
  if(p->kstack == 0)
80107cf6:	8b 45 08             	mov    0x8(%ebp),%eax
80107cf9:	8b 40 08             	mov    0x8(%eax),%eax
80107cfc:	85 c0                	test   %eax,%eax
80107cfe:	75 0d                	jne    80107d0d <switchuvm+0x32>
    panic("switchuvm: no kstack");
80107d00:	83 ec 0c             	sub    $0xc,%esp
80107d03:	68 20 8a 10 80       	push   $0x80108a20
80107d08:	e8 a6 88 ff ff       	call   801005b3 <panic>
  if(p->pgdir == 0)
80107d0d:	8b 45 08             	mov    0x8(%ebp),%eax
80107d10:	8b 40 04             	mov    0x4(%eax),%eax
80107d13:	85 c0                	test   %eax,%eax
80107d15:	75 0d                	jne    80107d24 <switchuvm+0x49>
    panic("switchuvm: no pgdir");
80107d17:	83 ec 0c             	sub    $0xc,%esp
80107d1a:	68 35 8a 10 80       	push   $0x80108a35
80107d1f:	e8 8f 88 ff ff       	call   801005b3 <panic>

  pushcli();
80107d24:	e8 3b d4 ff ff       	call   80105164 <pushcli>
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
80107d29:	e8 df c4 ff ff       	call   8010420d <mycpu>
80107d2e:	89 c3                	mov    %eax,%ebx
80107d30:	e8 d8 c4 ff ff       	call   8010420d <mycpu>
80107d35:	83 c0 08             	add    $0x8,%eax
80107d38:	89 c6                	mov    %eax,%esi
80107d3a:	e8 ce c4 ff ff       	call   8010420d <mycpu>
80107d3f:	83 c0 08             	add    $0x8,%eax
80107d42:	c1 e8 10             	shr    $0x10,%eax
80107d45:	88 45 f7             	mov    %al,-0x9(%ebp)
80107d48:	e8 c0 c4 ff ff       	call   8010420d <mycpu>
80107d4d:	83 c0 08             	add    $0x8,%eax
80107d50:	c1 e8 18             	shr    $0x18,%eax
80107d53:	89 c2                	mov    %eax,%edx
80107d55:	66 c7 83 98 00 00 00 	movw   $0x67,0x98(%ebx)
80107d5c:	67 00 
80107d5e:	66 89 b3 9a 00 00 00 	mov    %si,0x9a(%ebx)
80107d65:	0f b6 45 f7          	movzbl -0x9(%ebp),%eax
80107d69:	88 83 9c 00 00 00    	mov    %al,0x9c(%ebx)
80107d6f:	0f b6 83 9d 00 00 00 	movzbl 0x9d(%ebx),%eax
80107d76:	83 e0 f0             	and    $0xfffffff0,%eax
80107d79:	83 c8 09             	or     $0x9,%eax
80107d7c:	88 83 9d 00 00 00    	mov    %al,0x9d(%ebx)
80107d82:	0f b6 83 9d 00 00 00 	movzbl 0x9d(%ebx),%eax
80107d89:	83 c8 10             	or     $0x10,%eax
80107d8c:	88 83 9d 00 00 00    	mov    %al,0x9d(%ebx)
80107d92:	0f b6 83 9d 00 00 00 	movzbl 0x9d(%ebx),%eax
80107d99:	83 e0 9f             	and    $0xffffff9f,%eax
80107d9c:	88 83 9d 00 00 00    	mov    %al,0x9d(%ebx)
80107da2:	0f b6 83 9d 00 00 00 	movzbl 0x9d(%ebx),%eax
80107da9:	83 c8 80             	or     $0xffffff80,%eax
80107dac:	88 83 9d 00 00 00    	mov    %al,0x9d(%ebx)
80107db2:	0f b6 83 9e 00 00 00 	movzbl 0x9e(%ebx),%eax
80107db9:	83 e0 f0             	and    $0xfffffff0,%eax
80107dbc:	88 83 9e 00 00 00    	mov    %al,0x9e(%ebx)
80107dc2:	0f b6 83 9e 00 00 00 	movzbl 0x9e(%ebx),%eax
80107dc9:	83 e0 ef             	and    $0xffffffef,%eax
80107dcc:	88 83 9e 00 00 00    	mov    %al,0x9e(%ebx)
80107dd2:	0f b6 83 9e 00 00 00 	movzbl 0x9e(%ebx),%eax
80107dd9:	83 e0 df             	and    $0xffffffdf,%eax
80107ddc:	88 83 9e 00 00 00    	mov    %al,0x9e(%ebx)
80107de2:	0f b6 83 9e 00 00 00 	movzbl 0x9e(%ebx),%eax
80107de9:	83 c8 40             	or     $0x40,%eax
80107dec:	88 83 9e 00 00 00    	mov    %al,0x9e(%ebx)
80107df2:	0f b6 83 9e 00 00 00 	movzbl 0x9e(%ebx),%eax
80107df9:	83 e0 7f             	and    $0x7f,%eax
80107dfc:	88 83 9e 00 00 00    	mov    %al,0x9e(%ebx)
80107e02:	88 93 9f 00 00 00    	mov    %dl,0x9f(%ebx)
                                sizeof(mycpu()->ts)-1, 0);
  mycpu()->gdt[SEG_TSS].s = 0;
80107e08:	e8 00 c4 ff ff       	call   8010420d <mycpu>
80107e0d:	0f b6 90 9d 00 00 00 	movzbl 0x9d(%eax),%edx
80107e14:	83 e2 ef             	and    $0xffffffef,%edx
80107e17:	88 90 9d 00 00 00    	mov    %dl,0x9d(%eax)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
80107e1d:	e8 eb c3 ff ff       	call   8010420d <mycpu>
80107e22:	66 c7 40 10 10 00    	movw   $0x10,0x10(%eax)
  mycpu()->ts.esp0 = (uint)p->kstack + KSTACKSIZE;
80107e28:	8b 45 08             	mov    0x8(%ebp),%eax
80107e2b:	8b 40 08             	mov    0x8(%eax),%eax
80107e2e:	89 c3                	mov    %eax,%ebx
80107e30:	e8 d8 c3 ff ff       	call   8010420d <mycpu>
80107e35:	8d 93 00 10 00 00    	lea    0x1000(%ebx),%edx
80107e3b:	89 50 0c             	mov    %edx,0xc(%eax)
  // setting IOPL=0 in eflags *and* iomb beyond the tss segment limit
  // forbids I/O instructions (e.g., inb and outb) from user space
  mycpu()->ts.iomb = (ushort) 0xFFFF;
80107e3e:	e8 ca c3 ff ff       	call   8010420d <mycpu>
80107e43:	66 c7 40 6e ff ff    	movw   $0xffff,0x6e(%eax)
  ltr(SEG_TSS << 3);
80107e49:	83 ec 0c             	sub    $0xc,%esp
80107e4c:	6a 28                	push   $0x28
80107e4e:	e8 1f f9 ff ff       	call   80107772 <ltr>
80107e53:	83 c4 10             	add    $0x10,%esp
  lcr3(V2P(p->pgdir));  // switch to process's address space
80107e56:	8b 45 08             	mov    0x8(%ebp),%eax
80107e59:	8b 40 04             	mov    0x4(%eax),%eax
80107e5c:	05 00 00 00 80       	add    $0x80000000,%eax
80107e61:	83 ec 0c             	sub    $0xc,%esp
80107e64:	50                   	push   %eax
80107e65:	e8 1f f9 ff ff       	call   80107789 <lcr3>
80107e6a:	83 c4 10             	add    $0x10,%esp
  popcli();
80107e6d:	e8 3f d3 ff ff       	call   801051b1 <popcli>
}
80107e72:	90                   	nop
80107e73:	8d 65 f8             	lea    -0x8(%ebp),%esp
80107e76:	5b                   	pop    %ebx
80107e77:	5e                   	pop    %esi
80107e78:	5d                   	pop    %ebp
80107e79:	c3                   	ret

80107e7a <inituvm>:

// Load the initcode into address 0 of pgdir.
// sz must be less than a page.
void
inituvm(pde_t *pgdir, char *init, uint sz)
{
80107e7a:	55                   	push   %ebp
80107e7b:	89 e5                	mov    %esp,%ebp
80107e7d:	83 ec 18             	sub    $0x18,%esp
  char *mem;

  if(sz >= PGSIZE)
80107e80:	81 7d 10 ff 0f 00 00 	cmpl   $0xfff,0x10(%ebp)
80107e87:	76 0d                	jbe    80107e96 <inituvm+0x1c>
    panic("inituvm: more than a page");
80107e89:	83 ec 0c             	sub    $0xc,%esp
80107e8c:	68 49 8a 10 80       	push   $0x80108a49
80107e91:	e8 1d 87 ff ff       	call   801005b3 <panic>
  mem = kalloc();
80107e96:	e8 f7 ad ff ff       	call   80102c92 <kalloc>
80107e9b:	89 45 f4             	mov    %eax,-0xc(%ebp)
  memset(mem, 0, PGSIZE);
80107e9e:	83 ec 04             	sub    $0x4,%esp
80107ea1:	68 00 10 00 00       	push   $0x1000
80107ea6:	6a 00                	push   $0x0
80107ea8:	ff 75 f4             	push   -0xc(%ebp)
80107eab:	e8 bf d3 ff ff       	call   8010526f <memset>
80107eb0:	83 c4 10             	add    $0x10,%esp
  mappages(pgdir, 0, PGSIZE, V2P(mem), PTE_W|PTE_U);
80107eb3:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107eb6:	05 00 00 00 80       	add    $0x80000000,%eax
80107ebb:	83 ec 0c             	sub    $0xc,%esp
80107ebe:	6a 06                	push   $0x6
80107ec0:	50                   	push   %eax
80107ec1:	68 00 10 00 00       	push   $0x1000
80107ec6:	6a 00                	push   $0x0
80107ec8:	ff 75 08             	push   0x8(%ebp)
80107ecb:	e8 b1 fc ff ff       	call   80107b81 <mappages>
80107ed0:	83 c4 20             	add    $0x20,%esp
  memmove(mem, init, sz);
80107ed3:	83 ec 04             	sub    $0x4,%esp
80107ed6:	ff 75 10             	push   0x10(%ebp)
80107ed9:	ff 75 0c             	push   0xc(%ebp)
80107edc:	ff 75 f4             	push   -0xc(%ebp)
80107edf:	e8 4a d4 ff ff       	call   8010532e <memmove>
80107ee4:	83 c4 10             	add    $0x10,%esp
}
80107ee7:	90                   	nop
80107ee8:	c9                   	leave
80107ee9:	c3                   	ret

80107eea <loaduvm>:

// Load a program segment into pgdir.  addr must be page-aligned
// and the pages from addr to addr+sz must already be mapped.
int
loaduvm(pde_t *pgdir, char *addr, struct inode *ip, uint offset, uint sz)
{
80107eea:	55                   	push   %ebp
80107eeb:	89 e5                	mov    %esp,%ebp
80107eed:	83 ec 18             	sub    $0x18,%esp
  uint i, pa, n;
  pte_t *pte;

  if((uint) addr % PGSIZE != 0)
80107ef0:	8b 45 0c             	mov    0xc(%ebp),%eax
80107ef3:	25 ff 0f 00 00       	and    $0xfff,%eax
80107ef8:	85 c0                	test   %eax,%eax
80107efa:	74 0d                	je     80107f09 <loaduvm+0x1f>
    panic("loaduvm: addr must be page aligned");
80107efc:	83 ec 0c             	sub    $0xc,%esp
80107eff:	68 64 8a 10 80       	push   $0x80108a64
80107f04:	e8 aa 86 ff ff       	call   801005b3 <panic>
  for(i = 0; i < sz; i += PGSIZE){
80107f09:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
80107f10:	e9 8f 00 00 00       	jmp    80107fa4 <loaduvm+0xba>
    if((pte = walkpgdir(pgdir, addr+i, 0)) == 0)
80107f15:	8b 55 0c             	mov    0xc(%ebp),%edx
80107f18:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107f1b:	01 d0                	add    %edx,%eax
80107f1d:	83 ec 04             	sub    $0x4,%esp
80107f20:	6a 00                	push   $0x0
80107f22:	50                   	push   %eax
80107f23:	ff 75 08             	push   0x8(%ebp)
80107f26:	e8 c0 fb ff ff       	call   80107aeb <walkpgdir>
80107f2b:	83 c4 10             	add    $0x10,%esp
80107f2e:	89 45 ec             	mov    %eax,-0x14(%ebp)
80107f31:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
80107f35:	75 0d                	jne    80107f44 <loaduvm+0x5a>
      panic("loaduvm: address should exist");
80107f37:	83 ec 0c             	sub    $0xc,%esp
80107f3a:	68 87 8a 10 80       	push   $0x80108a87
80107f3f:	e8 6f 86 ff ff       	call   801005b3 <panic>
    pa = PTE_ADDR(*pte);
80107f44:	8b 45 ec             	mov    -0x14(%ebp),%eax
80107f47:	8b 00                	mov    (%eax),%eax
80107f49:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80107f4e:	89 45 e8             	mov    %eax,-0x18(%ebp)
    if(sz - i < PGSIZE)
80107f51:	8b 45 18             	mov    0x18(%ebp),%eax
80107f54:	2b 45 f4             	sub    -0xc(%ebp),%eax
80107f57:	3d ff 0f 00 00       	cmp    $0xfff,%eax
80107f5c:	77 0b                	ja     80107f69 <loaduvm+0x7f>
      n = sz - i;
80107f5e:	8b 45 18             	mov    0x18(%ebp),%eax
80107f61:	2b 45 f4             	sub    -0xc(%ebp),%eax
80107f64:	89 45 f0             	mov    %eax,-0x10(%ebp)
80107f67:	eb 07                	jmp    80107f70 <loaduvm+0x86>
    else
      n = PGSIZE;
80107f69:	c7 45 f0 00 10 00 00 	movl   $0x1000,-0x10(%ebp)
    if(readi(ip, P2V(pa), offset+i, n) != n)
80107f70:	8b 55 14             	mov    0x14(%ebp),%edx
80107f73:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107f76:	01 d0                	add    %edx,%eax
80107f78:	8b 55 e8             	mov    -0x18(%ebp),%edx
80107f7b:	81 c2 00 00 00 80    	add    $0x80000000,%edx
80107f81:	ff 75 f0             	push   -0x10(%ebp)
80107f84:	50                   	push   %eax
80107f85:	52                   	push   %edx
80107f86:	ff 75 10             	push   0x10(%ebp)
80107f89:	e8 74 9f ff ff       	call   80101f02 <readi>
80107f8e:	83 c4 10             	add    $0x10,%esp
80107f91:	39 45 f0             	cmp    %eax,-0x10(%ebp)
80107f94:	74 07                	je     80107f9d <loaduvm+0xb3>
      return -1;
80107f96:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80107f9b:	eb 18                	jmp    80107fb5 <loaduvm+0xcb>
  for(i = 0; i < sz; i += PGSIZE){
80107f9d:	81 45 f4 00 10 00 00 	addl   $0x1000,-0xc(%ebp)
80107fa4:	8b 45 f4             	mov    -0xc(%ebp),%eax
80107fa7:	3b 45 18             	cmp    0x18(%ebp),%eax
80107faa:	0f 82 65 ff ff ff    	jb     80107f15 <loaduvm+0x2b>
  }
  return 0;
80107fb0:	b8 00 00 00 00       	mov    $0x0,%eax
}
80107fb5:	c9                   	leave
80107fb6:	c3                   	ret

80107fb7 <allocuvm>:

// Allocate page tables and physical memory to grow process from oldsz to
// newsz, which need not be page aligned.  Returns new size or 0 on error.
int
allocuvm(pde_t *pgdir, uint oldsz, uint newsz)
{
80107fb7:	55                   	push   %ebp
80107fb8:	89 e5                	mov    %esp,%ebp
80107fba:	83 ec 18             	sub    $0x18,%esp
  char *mem;
  uint a;

  if(newsz >= KERNBASE)
80107fbd:	8b 45 10             	mov    0x10(%ebp),%eax
80107fc0:	85 c0                	test   %eax,%eax
80107fc2:	79 0a                	jns    80107fce <allocuvm+0x17>
    return 0;
80107fc4:	b8 00 00 00 00       	mov    $0x0,%eax
80107fc9:	e9 ec 00 00 00       	jmp    801080ba <allocuvm+0x103>
  if(newsz < oldsz)
80107fce:	8b 45 10             	mov    0x10(%ebp),%eax
80107fd1:	3b 45 0c             	cmp    0xc(%ebp),%eax
80107fd4:	73 08                	jae    80107fde <allocuvm+0x27>
    return oldsz;
80107fd6:	8b 45 0c             	mov    0xc(%ebp),%eax
80107fd9:	e9 dc 00 00 00       	jmp    801080ba <allocuvm+0x103>

  a = PGROUNDUP(oldsz);
80107fde:	8b 45 0c             	mov    0xc(%ebp),%eax
80107fe1:	05 ff 0f 00 00       	add    $0xfff,%eax
80107fe6:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80107feb:	89 45 f4             	mov    %eax,-0xc(%ebp)
  for(; a < newsz; a += PGSIZE){
80107fee:	e9 b8 00 00 00       	jmp    801080ab <allocuvm+0xf4>
    mem = kalloc();
80107ff3:	e8 9a ac ff ff       	call   80102c92 <kalloc>
80107ff8:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(mem == 0){
80107ffb:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80107fff:	75 2e                	jne    8010802f <allocuvm+0x78>
      cprintf("allocuvm out of memory\n");
80108001:	83 ec 0c             	sub    $0xc,%esp
80108004:	68 a5 8a 10 80       	push   $0x80108aa5
80108009:	e8 f0 83 ff ff       	call   801003fe <cprintf>
8010800e:	83 c4 10             	add    $0x10,%esp
      deallocuvm(pgdir, newsz, oldsz);
80108011:	83 ec 04             	sub    $0x4,%esp
80108014:	ff 75 0c             	push   0xc(%ebp)
80108017:	ff 75 10             	push   0x10(%ebp)
8010801a:	ff 75 08             	push   0x8(%ebp)
8010801d:	e8 9a 00 00 00       	call   801080bc <deallocuvm>
80108022:	83 c4 10             	add    $0x10,%esp
      return 0;
80108025:	b8 00 00 00 00       	mov    $0x0,%eax
8010802a:	e9 8b 00 00 00       	jmp    801080ba <allocuvm+0x103>
    }
    memset(mem, 0, PGSIZE);
8010802f:	83 ec 04             	sub    $0x4,%esp
80108032:	68 00 10 00 00       	push   $0x1000
80108037:	6a 00                	push   $0x0
80108039:	ff 75 f0             	push   -0x10(%ebp)
8010803c:	e8 2e d2 ff ff       	call   8010526f <memset>
80108041:	83 c4 10             	add    $0x10,%esp
    if(mappages(pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U) < 0){
80108044:	8b 45 f0             	mov    -0x10(%ebp),%eax
80108047:	8d 90 00 00 00 80    	lea    -0x80000000(%eax),%edx
8010804d:	8b 45 f4             	mov    -0xc(%ebp),%eax
80108050:	83 ec 0c             	sub    $0xc,%esp
80108053:	6a 06                	push   $0x6
80108055:	52                   	push   %edx
80108056:	68 00 10 00 00       	push   $0x1000
8010805b:	50                   	push   %eax
8010805c:	ff 75 08             	push   0x8(%ebp)
8010805f:	e8 1d fb ff ff       	call   80107b81 <mappages>
80108064:	83 c4 20             	add    $0x20,%esp
80108067:	85 c0                	test   %eax,%eax
80108069:	79 39                	jns    801080a4 <allocuvm+0xed>
      cprintf("allocuvm out of memory (2)\n");
8010806b:	83 ec 0c             	sub    $0xc,%esp
8010806e:	68 bd 8a 10 80       	push   $0x80108abd
80108073:	e8 86 83 ff ff       	call   801003fe <cprintf>
80108078:	83 c4 10             	add    $0x10,%esp
      deallocuvm(pgdir, newsz, oldsz);
8010807b:	83 ec 04             	sub    $0x4,%esp
8010807e:	ff 75 0c             	push   0xc(%ebp)
80108081:	ff 75 10             	push   0x10(%ebp)
80108084:	ff 75 08             	push   0x8(%ebp)
80108087:	e8 30 00 00 00       	call   801080bc <deallocuvm>
8010808c:	83 c4 10             	add    $0x10,%esp
      kfree(mem);
8010808f:	83 ec 0c             	sub    $0xc,%esp
80108092:	ff 75 f0             	push   -0x10(%ebp)
80108095:	e8 5e ab ff ff       	call   80102bf8 <kfree>
8010809a:	83 c4 10             	add    $0x10,%esp
      return 0;
8010809d:	b8 00 00 00 00       	mov    $0x0,%eax
801080a2:	eb 16                	jmp    801080ba <allocuvm+0x103>
  for(; a < newsz; a += PGSIZE){
801080a4:	81 45 f4 00 10 00 00 	addl   $0x1000,-0xc(%ebp)
801080ab:	8b 45 f4             	mov    -0xc(%ebp),%eax
801080ae:	3b 45 10             	cmp    0x10(%ebp),%eax
801080b1:	0f 82 3c ff ff ff    	jb     80107ff3 <allocuvm+0x3c>
    }
  }
  return newsz;
801080b7:	8b 45 10             	mov    0x10(%ebp),%eax
}
801080ba:	c9                   	leave
801080bb:	c3                   	ret

801080bc <deallocuvm>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
int
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
{
801080bc:	55                   	push   %ebp
801080bd:	89 e5                	mov    %esp,%ebp
801080bf:	83 ec 18             	sub    $0x18,%esp
  pte_t *pte;
  uint a, pa;

  if(newsz >= oldsz)
801080c2:	8b 45 10             	mov    0x10(%ebp),%eax
801080c5:	3b 45 0c             	cmp    0xc(%ebp),%eax
801080c8:	72 08                	jb     801080d2 <deallocuvm+0x16>
    return oldsz;
801080ca:	8b 45 0c             	mov    0xc(%ebp),%eax
801080cd:	e9 ac 00 00 00       	jmp    8010817e <deallocuvm+0xc2>

  a = PGROUNDUP(newsz);
801080d2:	8b 45 10             	mov    0x10(%ebp),%eax
801080d5:	05 ff 0f 00 00       	add    $0xfff,%eax
801080da:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801080df:	89 45 f4             	mov    %eax,-0xc(%ebp)
  for(; a  < oldsz; a += PGSIZE){
801080e2:	e9 88 00 00 00       	jmp    8010816f <deallocuvm+0xb3>
    pte = walkpgdir(pgdir, (char*)a, 0);
801080e7:	8b 45 f4             	mov    -0xc(%ebp),%eax
801080ea:	83 ec 04             	sub    $0x4,%esp
801080ed:	6a 00                	push   $0x0
801080ef:	50                   	push   %eax
801080f0:	ff 75 08             	push   0x8(%ebp)
801080f3:	e8 f3 f9 ff ff       	call   80107aeb <walkpgdir>
801080f8:	83 c4 10             	add    $0x10,%esp
801080fb:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(!pte)
801080fe:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
80108102:	75 16                	jne    8010811a <deallocuvm+0x5e>
      a = PGADDR(PDX(a) + 1, 0, 0) - PGSIZE;
80108104:	8b 45 f4             	mov    -0xc(%ebp),%eax
80108107:	c1 e8 16             	shr    $0x16,%eax
8010810a:	83 c0 01             	add    $0x1,%eax
8010810d:	c1 e0 16             	shl    $0x16,%eax
80108110:	2d 00 10 00 00       	sub    $0x1000,%eax
80108115:	89 45 f4             	mov    %eax,-0xc(%ebp)
80108118:	eb 4e                	jmp    80108168 <deallocuvm+0xac>
    else if((*pte & PTE_P) != 0){
8010811a:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010811d:	8b 00                	mov    (%eax),%eax
8010811f:	83 e0 01             	and    $0x1,%eax
80108122:	85 c0                	test   %eax,%eax
80108124:	74 42                	je     80108168 <deallocuvm+0xac>
      pa = PTE_ADDR(*pte);
80108126:	8b 45 f0             	mov    -0x10(%ebp),%eax
80108129:	8b 00                	mov    (%eax),%eax
8010812b:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80108130:	89 45 ec             	mov    %eax,-0x14(%ebp)
      if(pa == 0)
80108133:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
80108137:	75 0d                	jne    80108146 <deallocuvm+0x8a>
        panic("kfree");
80108139:	83 ec 0c             	sub    $0xc,%esp
8010813c:	68 d9 8a 10 80       	push   $0x80108ad9
80108141:	e8 6d 84 ff ff       	call   801005b3 <panic>
      char *v = P2V(pa);
80108146:	8b 45 ec             	mov    -0x14(%ebp),%eax
80108149:	05 00 00 00 80       	add    $0x80000000,%eax
8010814e:	89 45 e8             	mov    %eax,-0x18(%ebp)
      kfree(v);
80108151:	83 ec 0c             	sub    $0xc,%esp
80108154:	ff 75 e8             	push   -0x18(%ebp)
80108157:	e8 9c aa ff ff       	call   80102bf8 <kfree>
8010815c:	83 c4 10             	add    $0x10,%esp
      *pte = 0;
8010815f:	8b 45 f0             	mov    -0x10(%ebp),%eax
80108162:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; a  < oldsz; a += PGSIZE){
80108168:	81 45 f4 00 10 00 00 	addl   $0x1000,-0xc(%ebp)
8010816f:	8b 45 f4             	mov    -0xc(%ebp),%eax
80108172:	3b 45 0c             	cmp    0xc(%ebp),%eax
80108175:	0f 82 6c ff ff ff    	jb     801080e7 <deallocuvm+0x2b>
    }
  }
  return newsz;
8010817b:	8b 45 10             	mov    0x10(%ebp),%eax
}
8010817e:	c9                   	leave
8010817f:	c3                   	ret

80108180 <freevm>:

// Free a page table and all the physical memory pages
// in the user part.
void
freevm(pde_t *pgdir)
{
80108180:	55                   	push   %ebp
80108181:	89 e5                	mov    %esp,%ebp
80108183:	83 ec 18             	sub    $0x18,%esp
  uint i;

  if(pgdir == 0)
80108186:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
8010818a:	75 0d                	jne    80108199 <freevm+0x19>
    panic("freevm: no pgdir");
8010818c:	83 ec 0c             	sub    $0xc,%esp
8010818f:	68 df 8a 10 80       	push   $0x80108adf
80108194:	e8 1a 84 ff ff       	call   801005b3 <panic>
  deallocuvm(pgdir, KERNBASE, 0);
80108199:	83 ec 04             	sub    $0x4,%esp
8010819c:	6a 00                	push   $0x0
8010819e:	68 00 00 00 80       	push   $0x80000000
801081a3:	ff 75 08             	push   0x8(%ebp)
801081a6:	e8 11 ff ff ff       	call   801080bc <deallocuvm>
801081ab:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < NPDENTRIES; i++){
801081ae:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
801081b5:	eb 48                	jmp    801081ff <freevm+0x7f>
    if(pgdir[i] & PTE_P){
801081b7:	8b 45 f4             	mov    -0xc(%ebp),%eax
801081ba:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
801081c1:	8b 45 08             	mov    0x8(%ebp),%eax
801081c4:	01 d0                	add    %edx,%eax
801081c6:	8b 00                	mov    (%eax),%eax
801081c8:	83 e0 01             	and    $0x1,%eax
801081cb:	85 c0                	test   %eax,%eax
801081cd:	74 2c                	je     801081fb <freevm+0x7b>
      char * v = P2V(PTE_ADDR(pgdir[i]));
801081cf:	8b 45 f4             	mov    -0xc(%ebp),%eax
801081d2:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
801081d9:	8b 45 08             	mov    0x8(%ebp),%eax
801081dc:	01 d0                	add    %edx,%eax
801081de:	8b 00                	mov    (%eax),%eax
801081e0:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801081e5:	05 00 00 00 80       	add    $0x80000000,%eax
801081ea:	89 45 f0             	mov    %eax,-0x10(%ebp)
      kfree(v);
801081ed:	83 ec 0c             	sub    $0xc,%esp
801081f0:	ff 75 f0             	push   -0x10(%ebp)
801081f3:	e8 00 aa ff ff       	call   80102bf8 <kfree>
801081f8:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < NPDENTRIES; i++){
801081fb:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
801081ff:	81 7d f4 ff 03 00 00 	cmpl   $0x3ff,-0xc(%ebp)
80108206:	76 af                	jbe    801081b7 <freevm+0x37>
    }
  }
  kfree((char*)pgdir);
80108208:	83 ec 0c             	sub    $0xc,%esp
8010820b:	ff 75 08             	push   0x8(%ebp)
8010820e:	e8 e5 a9 ff ff       	call   80102bf8 <kfree>
80108213:	83 c4 10             	add    $0x10,%esp
}
80108216:	90                   	nop
80108217:	c9                   	leave
80108218:	c3                   	ret

80108219 <clearpteu>:

// Clear PTE_U on a page. Used to create an inaccessible
// page beneath the user stack.
void
clearpteu(pde_t *pgdir, char *uva)
{
80108219:	55                   	push   %ebp
8010821a:	89 e5                	mov    %esp,%ebp
8010821c:	83 ec 18             	sub    $0x18,%esp
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
8010821f:	83 ec 04             	sub    $0x4,%esp
80108222:	6a 00                	push   $0x0
80108224:	ff 75 0c             	push   0xc(%ebp)
80108227:	ff 75 08             	push   0x8(%ebp)
8010822a:	e8 bc f8 ff ff       	call   80107aeb <walkpgdir>
8010822f:	83 c4 10             	add    $0x10,%esp
80108232:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(pte == 0)
80108235:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80108239:	75 0d                	jne    80108248 <clearpteu+0x2f>
    panic("clearpteu");
8010823b:	83 ec 0c             	sub    $0xc,%esp
8010823e:	68 f0 8a 10 80       	push   $0x80108af0
80108243:	e8 6b 83 ff ff       	call   801005b3 <panic>
  *pte &= ~PTE_U;
80108248:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010824b:	8b 00                	mov    (%eax),%eax
8010824d:	83 e0 fb             	and    $0xfffffffb,%eax
80108250:	89 c2                	mov    %eax,%edx
80108252:	8b 45 f4             	mov    -0xc(%ebp),%eax
80108255:	89 10                	mov    %edx,(%eax)
}
80108257:	90                   	nop
80108258:	c9                   	leave
80108259:	c3                   	ret

8010825a <copyuvm>:

// Given a parent process's page table, create a copy
// of it for a child.
pde_t*
copyuvm(pde_t *pgdir, uint sz)
{
8010825a:	55                   	push   %ebp
8010825b:	89 e5                	mov    %esp,%ebp
8010825d:	83 ec 28             	sub    $0x28,%esp
  pde_t *d;
  pte_t *pte;
  uint pa, i, flags;
  char *mem;

  if((d = setupkvm()) == 0)
80108260:	e8 ac f9 ff ff       	call   80107c11 <setupkvm>
80108265:	89 45 f0             	mov    %eax,-0x10(%ebp)
80108268:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
8010826c:	75 0a                	jne    80108278 <copyuvm+0x1e>
    return 0;
8010826e:	b8 00 00 00 00       	mov    $0x0,%eax
80108273:	e9 f8 00 00 00       	jmp    80108370 <copyuvm+0x116>
  for(i = 0; i < sz; i += PGSIZE){
80108278:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
8010827f:	e9 c7 00 00 00       	jmp    8010834b <copyuvm+0xf1>
    if((pte = walkpgdir(pgdir, (void *) i, 0)) == 0)
80108284:	8b 45 f4             	mov    -0xc(%ebp),%eax
80108287:	83 ec 04             	sub    $0x4,%esp
8010828a:	6a 00                	push   $0x0
8010828c:	50                   	push   %eax
8010828d:	ff 75 08             	push   0x8(%ebp)
80108290:	e8 56 f8 ff ff       	call   80107aeb <walkpgdir>
80108295:	83 c4 10             	add    $0x10,%esp
80108298:	89 45 ec             	mov    %eax,-0x14(%ebp)
8010829b:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
8010829f:	75 0d                	jne    801082ae <copyuvm+0x54>
      panic("copyuvm: pte should exist");
801082a1:	83 ec 0c             	sub    $0xc,%esp
801082a4:	68 fa 8a 10 80       	push   $0x80108afa
801082a9:	e8 05 83 ff ff       	call   801005b3 <panic>
    if(!(*pte & PTE_P))
801082ae:	8b 45 ec             	mov    -0x14(%ebp),%eax
801082b1:	8b 00                	mov    (%eax),%eax
801082b3:	83 e0 01             	and    $0x1,%eax
801082b6:	85 c0                	test   %eax,%eax
801082b8:	75 0d                	jne    801082c7 <copyuvm+0x6d>
      panic("copyuvm: page not present");
801082ba:	83 ec 0c             	sub    $0xc,%esp
801082bd:	68 14 8b 10 80       	push   $0x80108b14
801082c2:	e8 ec 82 ff ff       	call   801005b3 <panic>
    pa = PTE_ADDR(*pte);
801082c7:	8b 45 ec             	mov    -0x14(%ebp),%eax
801082ca:	8b 00                	mov    (%eax),%eax
801082cc:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801082d1:	89 45 e8             	mov    %eax,-0x18(%ebp)
    flags = PTE_FLAGS(*pte);
801082d4:	8b 45 ec             	mov    -0x14(%ebp),%eax
801082d7:	8b 00                	mov    (%eax),%eax
801082d9:	25 ff 0f 00 00       	and    $0xfff,%eax
801082de:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if((mem = kalloc()) == 0)
801082e1:	e8 ac a9 ff ff       	call   80102c92 <kalloc>
801082e6:	89 45 e0             	mov    %eax,-0x20(%ebp)
801082e9:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
801082ed:	74 6d                	je     8010835c <copyuvm+0x102>
      goto bad;
    memmove(mem, (char*)P2V(pa), PGSIZE);
801082ef:	8b 45 e8             	mov    -0x18(%ebp),%eax
801082f2:	05 00 00 00 80       	add    $0x80000000,%eax
801082f7:	83 ec 04             	sub    $0x4,%esp
801082fa:	68 00 10 00 00       	push   $0x1000
801082ff:	50                   	push   %eax
80108300:	ff 75 e0             	push   -0x20(%ebp)
80108303:	e8 26 d0 ff ff       	call   8010532e <memmove>
80108308:	83 c4 10             	add    $0x10,%esp
    if(mappages(d, (void*)i, PGSIZE, V2P(mem), flags) < 0) {
8010830b:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010830e:	8b 45 e0             	mov    -0x20(%ebp),%eax
80108311:	8d 88 00 00 00 80    	lea    -0x80000000(%eax),%ecx
80108317:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010831a:	83 ec 0c             	sub    $0xc,%esp
8010831d:	52                   	push   %edx
8010831e:	51                   	push   %ecx
8010831f:	68 00 10 00 00       	push   $0x1000
80108324:	50                   	push   %eax
80108325:	ff 75 f0             	push   -0x10(%ebp)
80108328:	e8 54 f8 ff ff       	call   80107b81 <mappages>
8010832d:	83 c4 20             	add    $0x20,%esp
80108330:	85 c0                	test   %eax,%eax
80108332:	79 10                	jns    80108344 <copyuvm+0xea>
      kfree(mem);
80108334:	83 ec 0c             	sub    $0xc,%esp
80108337:	ff 75 e0             	push   -0x20(%ebp)
8010833a:	e8 b9 a8 ff ff       	call   80102bf8 <kfree>
8010833f:	83 c4 10             	add    $0x10,%esp
      goto bad;
80108342:	eb 19                	jmp    8010835d <copyuvm+0x103>
  for(i = 0; i < sz; i += PGSIZE){
80108344:	81 45 f4 00 10 00 00 	addl   $0x1000,-0xc(%ebp)
8010834b:	8b 45 f4             	mov    -0xc(%ebp),%eax
8010834e:	3b 45 0c             	cmp    0xc(%ebp),%eax
80108351:	0f 82 2d ff ff ff    	jb     80108284 <copyuvm+0x2a>
    }
  }
  return d;
80108357:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010835a:	eb 14                	jmp    80108370 <copyuvm+0x116>
      goto bad;
8010835c:	90                   	nop

bad:
  freevm(d);
8010835d:	83 ec 0c             	sub    $0xc,%esp
80108360:	ff 75 f0             	push   -0x10(%ebp)
80108363:	e8 18 fe ff ff       	call   80108180 <freevm>
80108368:	83 c4 10             	add    $0x10,%esp
  return 0;
8010836b:	b8 00 00 00 00       	mov    $0x0,%eax
}
80108370:	c9                   	leave
80108371:	c3                   	ret

80108372 <uva2ka>:

//PAGEBREAK!
// Map user virtual address to kernel address.
char*
uva2ka(pde_t *pgdir, char *uva)
{
80108372:	55                   	push   %ebp
80108373:	89 e5                	mov    %esp,%ebp
80108375:	83 ec 18             	sub    $0x18,%esp
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
80108378:	83 ec 04             	sub    $0x4,%esp
8010837b:	6a 00                	push   $0x0
8010837d:	ff 75 0c             	push   0xc(%ebp)
80108380:	ff 75 08             	push   0x8(%ebp)
80108383:	e8 63 f7 ff ff       	call   80107aeb <walkpgdir>
80108388:	83 c4 10             	add    $0x10,%esp
8010838b:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if((*pte & PTE_P) == 0)
8010838e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80108391:	8b 00                	mov    (%eax),%eax
80108393:	83 e0 01             	and    $0x1,%eax
80108396:	85 c0                	test   %eax,%eax
80108398:	75 07                	jne    801083a1 <uva2ka+0x2f>
    return 0;
8010839a:	b8 00 00 00 00       	mov    $0x0,%eax
8010839f:	eb 22                	jmp    801083c3 <uva2ka+0x51>
  if((*pte & PTE_U) == 0)
801083a1:	8b 45 f4             	mov    -0xc(%ebp),%eax
801083a4:	8b 00                	mov    (%eax),%eax
801083a6:	83 e0 04             	and    $0x4,%eax
801083a9:	85 c0                	test   %eax,%eax
801083ab:	75 07                	jne    801083b4 <uva2ka+0x42>
    return 0;
801083ad:	b8 00 00 00 00       	mov    $0x0,%eax
801083b2:	eb 0f                	jmp    801083c3 <uva2ka+0x51>
  return (char*)P2V(PTE_ADDR(*pte));
801083b4:	8b 45 f4             	mov    -0xc(%ebp),%eax
801083b7:	8b 00                	mov    (%eax),%eax
801083b9:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801083be:	05 00 00 00 80       	add    $0x80000000,%eax
}
801083c3:	c9                   	leave
801083c4:	c3                   	ret

801083c5 <copyout>:
// Copy len bytes from p to user address va in page table pgdir.
// Most useful when pgdir is not the current page table.
// uva2ka ensures this only works for PTE_U pages.
int
copyout(pde_t *pgdir, uint va, void *p, uint len)
{
801083c5:	55                   	push   %ebp
801083c6:	89 e5                	mov    %esp,%ebp
801083c8:	83 ec 18             	sub    $0x18,%esp
  char *buf, *pa0;
  uint n, va0;

  buf = (char*)p;
801083cb:	8b 45 10             	mov    0x10(%ebp),%eax
801083ce:	89 45 f4             	mov    %eax,-0xc(%ebp)
  while(len > 0){
801083d1:	eb 7f                	jmp    80108452 <copyout+0x8d>
    va0 = (uint)PGROUNDDOWN(va);
801083d3:	8b 45 0c             	mov    0xc(%ebp),%eax
801083d6:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801083db:	89 45 ec             	mov    %eax,-0x14(%ebp)
    pa0 = uva2ka(pgdir, (char*)va0);
801083de:	8b 45 ec             	mov    -0x14(%ebp),%eax
801083e1:	83 ec 08             	sub    $0x8,%esp
801083e4:	50                   	push   %eax
801083e5:	ff 75 08             	push   0x8(%ebp)
801083e8:	e8 85 ff ff ff       	call   80108372 <uva2ka>
801083ed:	83 c4 10             	add    $0x10,%esp
801083f0:	89 45 e8             	mov    %eax,-0x18(%ebp)
    if(pa0 == 0)
801083f3:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
801083f7:	75 07                	jne    80108400 <copyout+0x3b>
      return -1;
801083f9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801083fe:	eb 61                	jmp    80108461 <copyout+0x9c>
    n = PGSIZE - (va - va0);
80108400:	8b 45 ec             	mov    -0x14(%ebp),%eax
80108403:	2b 45 0c             	sub    0xc(%ebp),%eax
80108406:	05 00 10 00 00       	add    $0x1000,%eax
8010840b:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(n > len)
8010840e:	8b 45 f0             	mov    -0x10(%ebp),%eax
80108411:	39 45 14             	cmp    %eax,0x14(%ebp)
80108414:	73 06                	jae    8010841c <copyout+0x57>
      n = len;
80108416:	8b 45 14             	mov    0x14(%ebp),%eax
80108419:	89 45 f0             	mov    %eax,-0x10(%ebp)
    memmove(pa0 + (va - va0), buf, n);
8010841c:	8b 45 0c             	mov    0xc(%ebp),%eax
8010841f:	2b 45 ec             	sub    -0x14(%ebp),%eax
80108422:	89 c2                	mov    %eax,%edx
80108424:	8b 45 e8             	mov    -0x18(%ebp),%eax
80108427:	01 d0                	add    %edx,%eax
80108429:	83 ec 04             	sub    $0x4,%esp
8010842c:	ff 75 f0             	push   -0x10(%ebp)
8010842f:	ff 75 f4             	push   -0xc(%ebp)
80108432:	50                   	push   %eax
80108433:	e8 f6 ce ff ff       	call   8010532e <memmove>
80108438:	83 c4 10             	add    $0x10,%esp
    len -= n;
8010843b:	8b 45 f0             	mov    -0x10(%ebp),%eax
8010843e:	29 45 14             	sub    %eax,0x14(%ebp)
    buf += n;
80108441:	8b 45 f0             	mov    -0x10(%ebp),%eax
80108444:	01 45 f4             	add    %eax,-0xc(%ebp)
    va = va0 + PGSIZE;
80108447:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010844a:	05 00 10 00 00       	add    $0x1000,%eax
8010844f:	89 45 0c             	mov    %eax,0xc(%ebp)
  while(len > 0){
80108452:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
80108456:	0f 85 77 ff ff ff    	jne    801083d3 <copyout+0xe>
  }
  return 0;
8010845c:	b8 00 00 00 00       	mov    $0x0,%eax
}
80108461:	c9                   	leave
80108462:	c3                   	ret
