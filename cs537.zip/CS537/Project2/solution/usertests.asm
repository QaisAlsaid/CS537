
_usertests:     file format elf32-i386


Disassembly of section .text:

00000000 <iputtest>:
int stdout = 1;

// does chdir() call iput(p->cwd) in a transaction?
void
iputtest(void)
{
       0:	55                   	push   %ebp
       1:	89 e5                	mov    %esp,%ebp
       3:	83 ec 08             	sub    $0x8,%esp
  printf(stdout, "iput test\n");
       6:	a1 ac 64 00 00       	mov    0x64ac,%eax
       b:	83 ec 08             	sub    $0x8,%esp
       e:	68 46 45 00 00       	push   $0x4546
      13:	50                   	push   %eax
      14:	e8 5d 41 00 00       	call   4176 <printf>
      19:	83 c4 10             	add    $0x10,%esp

  if(mkdir("iputdir") < 0){
      1c:	83 ec 0c             	sub    $0xc,%esp
      1f:	68 51 45 00 00       	push   $0x4551
      24:	e8 39 40 00 00       	call   4062 <mkdir>
      29:	83 c4 10             	add    $0x10,%esp
      2c:	85 c0                	test   %eax,%eax
      2e:	79 1b                	jns    4b <iputtest+0x4b>
    printf(stdout, "mkdir failed\n");
      30:	a1 ac 64 00 00       	mov    0x64ac,%eax
      35:	83 ec 08             	sub    $0x8,%esp
      38:	68 59 45 00 00       	push   $0x4559
      3d:	50                   	push   %eax
      3e:	e8 33 41 00 00       	call   4176 <printf>
      43:	83 c4 10             	add    $0x10,%esp
    exit();
      46:	e8 af 3f 00 00       	call   3ffa <exit>
  }
  if(chdir("iputdir") < 0){
      4b:	83 ec 0c             	sub    $0xc,%esp
      4e:	68 51 45 00 00       	push   $0x4551
      53:	e8 12 40 00 00       	call   406a <chdir>
      58:	83 c4 10             	add    $0x10,%esp
      5b:	85 c0                	test   %eax,%eax
      5d:	79 1b                	jns    7a <iputtest+0x7a>
    printf(stdout, "chdir iputdir failed\n");
      5f:	a1 ac 64 00 00       	mov    0x64ac,%eax
      64:	83 ec 08             	sub    $0x8,%esp
      67:	68 67 45 00 00       	push   $0x4567
      6c:	50                   	push   %eax
      6d:	e8 04 41 00 00       	call   4176 <printf>
      72:	83 c4 10             	add    $0x10,%esp
    exit();
      75:	e8 80 3f 00 00       	call   3ffa <exit>
  }
  if(unlink("../iputdir") < 0){
      7a:	83 ec 0c             	sub    $0xc,%esp
      7d:	68 7d 45 00 00       	push   $0x457d
      82:	e8 c3 3f 00 00       	call   404a <unlink>
      87:	83 c4 10             	add    $0x10,%esp
      8a:	85 c0                	test   %eax,%eax
      8c:	79 1b                	jns    a9 <iputtest+0xa9>
    printf(stdout, "unlink ../iputdir failed\n");
      8e:	a1 ac 64 00 00       	mov    0x64ac,%eax
      93:	83 ec 08             	sub    $0x8,%esp
      96:	68 88 45 00 00       	push   $0x4588
      9b:	50                   	push   %eax
      9c:	e8 d5 40 00 00       	call   4176 <printf>
      a1:	83 c4 10             	add    $0x10,%esp
    exit();
      a4:	e8 51 3f 00 00       	call   3ffa <exit>
  }
  if(chdir("/") < 0){
      a9:	83 ec 0c             	sub    $0xc,%esp
      ac:	68 a2 45 00 00       	push   $0x45a2
      b1:	e8 b4 3f 00 00       	call   406a <chdir>
      b6:	83 c4 10             	add    $0x10,%esp
      b9:	85 c0                	test   %eax,%eax
      bb:	79 1b                	jns    d8 <iputtest+0xd8>
    printf(stdout, "chdir / failed\n");
      bd:	a1 ac 64 00 00       	mov    0x64ac,%eax
      c2:	83 ec 08             	sub    $0x8,%esp
      c5:	68 a4 45 00 00       	push   $0x45a4
      ca:	50                   	push   %eax
      cb:	e8 a6 40 00 00       	call   4176 <printf>
      d0:	83 c4 10             	add    $0x10,%esp
    exit();
      d3:	e8 22 3f 00 00       	call   3ffa <exit>
  }
  printf(stdout, "iput test ok\n");
      d8:	a1 ac 64 00 00       	mov    0x64ac,%eax
      dd:	83 ec 08             	sub    $0x8,%esp
      e0:	68 b4 45 00 00       	push   $0x45b4
      e5:	50                   	push   %eax
      e6:	e8 8b 40 00 00       	call   4176 <printf>
      eb:	83 c4 10             	add    $0x10,%esp
}
      ee:	90                   	nop
      ef:	c9                   	leave
      f0:	c3                   	ret

000000f1 <exitiputtest>:

// does exit() call iput(p->cwd) in a transaction?
void
exitiputtest(void)
{
      f1:	55                   	push   %ebp
      f2:	89 e5                	mov    %esp,%ebp
      f4:	83 ec 18             	sub    $0x18,%esp
  int pid;

  printf(stdout, "exitiput test\n");
      f7:	a1 ac 64 00 00       	mov    0x64ac,%eax
      fc:	83 ec 08             	sub    $0x8,%esp
      ff:	68 c2 45 00 00       	push   $0x45c2
     104:	50                   	push   %eax
     105:	e8 6c 40 00 00       	call   4176 <printf>
     10a:	83 c4 10             	add    $0x10,%esp

  pid = fork();
     10d:	e8 e0 3e 00 00       	call   3ff2 <fork>
     112:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(pid < 0){
     115:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     119:	79 1b                	jns    136 <exitiputtest+0x45>
    printf(stdout, "fork failed\n");
     11b:	a1 ac 64 00 00       	mov    0x64ac,%eax
     120:	83 ec 08             	sub    $0x8,%esp
     123:	68 d1 45 00 00       	push   $0x45d1
     128:	50                   	push   %eax
     129:	e8 48 40 00 00       	call   4176 <printf>
     12e:	83 c4 10             	add    $0x10,%esp
    exit();
     131:	e8 c4 3e 00 00       	call   3ffa <exit>
  }
  if(pid == 0){
     136:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     13a:	0f 85 92 00 00 00    	jne    1d2 <exitiputtest+0xe1>
    if(mkdir("iputdir") < 0){
     140:	83 ec 0c             	sub    $0xc,%esp
     143:	68 51 45 00 00       	push   $0x4551
     148:	e8 15 3f 00 00       	call   4062 <mkdir>
     14d:	83 c4 10             	add    $0x10,%esp
     150:	85 c0                	test   %eax,%eax
     152:	79 1b                	jns    16f <exitiputtest+0x7e>
      printf(stdout, "mkdir failed\n");
     154:	a1 ac 64 00 00       	mov    0x64ac,%eax
     159:	83 ec 08             	sub    $0x8,%esp
     15c:	68 59 45 00 00       	push   $0x4559
     161:	50                   	push   %eax
     162:	e8 0f 40 00 00       	call   4176 <printf>
     167:	83 c4 10             	add    $0x10,%esp
      exit();
     16a:	e8 8b 3e 00 00       	call   3ffa <exit>
    }
    if(chdir("iputdir") < 0){
     16f:	83 ec 0c             	sub    $0xc,%esp
     172:	68 51 45 00 00       	push   $0x4551
     177:	e8 ee 3e 00 00       	call   406a <chdir>
     17c:	83 c4 10             	add    $0x10,%esp
     17f:	85 c0                	test   %eax,%eax
     181:	79 1b                	jns    19e <exitiputtest+0xad>
      printf(stdout, "child chdir failed\n");
     183:	a1 ac 64 00 00       	mov    0x64ac,%eax
     188:	83 ec 08             	sub    $0x8,%esp
     18b:	68 de 45 00 00       	push   $0x45de
     190:	50                   	push   %eax
     191:	e8 e0 3f 00 00       	call   4176 <printf>
     196:	83 c4 10             	add    $0x10,%esp
      exit();
     199:	e8 5c 3e 00 00       	call   3ffa <exit>
    }
    if(unlink("../iputdir") < 0){
     19e:	83 ec 0c             	sub    $0xc,%esp
     1a1:	68 7d 45 00 00       	push   $0x457d
     1a6:	e8 9f 3e 00 00       	call   404a <unlink>
     1ab:	83 c4 10             	add    $0x10,%esp
     1ae:	85 c0                	test   %eax,%eax
     1b0:	79 1b                	jns    1cd <exitiputtest+0xdc>
      printf(stdout, "unlink ../iputdir failed\n");
     1b2:	a1 ac 64 00 00       	mov    0x64ac,%eax
     1b7:	83 ec 08             	sub    $0x8,%esp
     1ba:	68 88 45 00 00       	push   $0x4588
     1bf:	50                   	push   %eax
     1c0:	e8 b1 3f 00 00       	call   4176 <printf>
     1c5:	83 c4 10             	add    $0x10,%esp
      exit();
     1c8:	e8 2d 3e 00 00       	call   3ffa <exit>
    }
    exit();
     1cd:	e8 28 3e 00 00       	call   3ffa <exit>
  }
  wait();
     1d2:	e8 2b 3e 00 00       	call   4002 <wait>
  printf(stdout, "exitiput test ok\n");
     1d7:	a1 ac 64 00 00       	mov    0x64ac,%eax
     1dc:	83 ec 08             	sub    $0x8,%esp
     1df:	68 f2 45 00 00       	push   $0x45f2
     1e4:	50                   	push   %eax
     1e5:	e8 8c 3f 00 00       	call   4176 <printf>
     1ea:	83 c4 10             	add    $0x10,%esp
}
     1ed:	90                   	nop
     1ee:	c9                   	leave
     1ef:	c3                   	ret

000001f0 <openiputtest>:
//      for(i = 0; i < 10000; i++)
//        yield();
//    }
void
openiputtest(void)
{
     1f0:	55                   	push   %ebp
     1f1:	89 e5                	mov    %esp,%ebp
     1f3:	83 ec 18             	sub    $0x18,%esp
  int pid;

  printf(stdout, "openiput test\n");
     1f6:	a1 ac 64 00 00       	mov    0x64ac,%eax
     1fb:	83 ec 08             	sub    $0x8,%esp
     1fe:	68 04 46 00 00       	push   $0x4604
     203:	50                   	push   %eax
     204:	e8 6d 3f 00 00       	call   4176 <printf>
     209:	83 c4 10             	add    $0x10,%esp
  if(mkdir("oidir") < 0){
     20c:	83 ec 0c             	sub    $0xc,%esp
     20f:	68 13 46 00 00       	push   $0x4613
     214:	e8 49 3e 00 00       	call   4062 <mkdir>
     219:	83 c4 10             	add    $0x10,%esp
     21c:	85 c0                	test   %eax,%eax
     21e:	79 1b                	jns    23b <openiputtest+0x4b>
    printf(stdout, "mkdir oidir failed\n");
     220:	a1 ac 64 00 00       	mov    0x64ac,%eax
     225:	83 ec 08             	sub    $0x8,%esp
     228:	68 19 46 00 00       	push   $0x4619
     22d:	50                   	push   %eax
     22e:	e8 43 3f 00 00       	call   4176 <printf>
     233:	83 c4 10             	add    $0x10,%esp
    exit();
     236:	e8 bf 3d 00 00       	call   3ffa <exit>
  }
  pid = fork();
     23b:	e8 b2 3d 00 00       	call   3ff2 <fork>
     240:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(pid < 0){
     243:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     247:	79 1b                	jns    264 <openiputtest+0x74>
    printf(stdout, "fork failed\n");
     249:	a1 ac 64 00 00       	mov    0x64ac,%eax
     24e:	83 ec 08             	sub    $0x8,%esp
     251:	68 d1 45 00 00       	push   $0x45d1
     256:	50                   	push   %eax
     257:	e8 1a 3f 00 00       	call   4176 <printf>
     25c:	83 c4 10             	add    $0x10,%esp
    exit();
     25f:	e8 96 3d 00 00       	call   3ffa <exit>
  }
  if(pid == 0){
     264:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     268:	75 3b                	jne    2a5 <openiputtest+0xb5>
    int fd = open("oidir", O_RDWR);
     26a:	83 ec 08             	sub    $0x8,%esp
     26d:	6a 02                	push   $0x2
     26f:	68 13 46 00 00       	push   $0x4613
     274:	e8 c1 3d 00 00       	call   403a <open>
     279:	83 c4 10             	add    $0x10,%esp
     27c:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(fd >= 0){
     27f:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
     283:	78 1b                	js     2a0 <openiputtest+0xb0>
      printf(stdout, "open directory for write succeeded\n");
     285:	a1 ac 64 00 00       	mov    0x64ac,%eax
     28a:	83 ec 08             	sub    $0x8,%esp
     28d:	68 30 46 00 00       	push   $0x4630
     292:	50                   	push   %eax
     293:	e8 de 3e 00 00       	call   4176 <printf>
     298:	83 c4 10             	add    $0x10,%esp
      exit();
     29b:	e8 5a 3d 00 00       	call   3ffa <exit>
    }
    exit();
     2a0:	e8 55 3d 00 00       	call   3ffa <exit>
  }
  sleep(1);
     2a5:	83 ec 0c             	sub    $0xc,%esp
     2a8:	6a 01                	push   $0x1
     2aa:	e8 db 3d 00 00       	call   408a <sleep>
     2af:	83 c4 10             	add    $0x10,%esp
  if(unlink("oidir") != 0){
     2b2:	83 ec 0c             	sub    $0xc,%esp
     2b5:	68 13 46 00 00       	push   $0x4613
     2ba:	e8 8b 3d 00 00       	call   404a <unlink>
     2bf:	83 c4 10             	add    $0x10,%esp
     2c2:	85 c0                	test   %eax,%eax
     2c4:	74 1b                	je     2e1 <openiputtest+0xf1>
    printf(stdout, "unlink failed\n");
     2c6:	a1 ac 64 00 00       	mov    0x64ac,%eax
     2cb:	83 ec 08             	sub    $0x8,%esp
     2ce:	68 54 46 00 00       	push   $0x4654
     2d3:	50                   	push   %eax
     2d4:	e8 9d 3e 00 00       	call   4176 <printf>
     2d9:	83 c4 10             	add    $0x10,%esp
    exit();
     2dc:	e8 19 3d 00 00       	call   3ffa <exit>
  }
  wait();
     2e1:	e8 1c 3d 00 00       	call   4002 <wait>
  printf(stdout, "openiput test ok\n");
     2e6:	a1 ac 64 00 00       	mov    0x64ac,%eax
     2eb:	83 ec 08             	sub    $0x8,%esp
     2ee:	68 63 46 00 00       	push   $0x4663
     2f3:	50                   	push   %eax
     2f4:	e8 7d 3e 00 00       	call   4176 <printf>
     2f9:	83 c4 10             	add    $0x10,%esp
}
     2fc:	90                   	nop
     2fd:	c9                   	leave
     2fe:	c3                   	ret

000002ff <opentest>:

// simple file system tests

void
opentest(void)
{
     2ff:	55                   	push   %ebp
     300:	89 e5                	mov    %esp,%ebp
     302:	83 ec 18             	sub    $0x18,%esp
  int fd;

  printf(stdout, "open test\n");
     305:	a1 ac 64 00 00       	mov    0x64ac,%eax
     30a:	83 ec 08             	sub    $0x8,%esp
     30d:	68 75 46 00 00       	push   $0x4675
     312:	50                   	push   %eax
     313:	e8 5e 3e 00 00       	call   4176 <printf>
     318:	83 c4 10             	add    $0x10,%esp
  fd = open("echo", 0);
     31b:	83 ec 08             	sub    $0x8,%esp
     31e:	6a 00                	push   $0x0
     320:	68 30 45 00 00       	push   $0x4530
     325:	e8 10 3d 00 00       	call   403a <open>
     32a:	83 c4 10             	add    $0x10,%esp
     32d:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
     330:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     334:	79 1b                	jns    351 <opentest+0x52>
    printf(stdout, "open echo failed!\n");
     336:	a1 ac 64 00 00       	mov    0x64ac,%eax
     33b:	83 ec 08             	sub    $0x8,%esp
     33e:	68 80 46 00 00       	push   $0x4680
     343:	50                   	push   %eax
     344:	e8 2d 3e 00 00       	call   4176 <printf>
     349:	83 c4 10             	add    $0x10,%esp
    exit();
     34c:	e8 a9 3c 00 00       	call   3ffa <exit>
  }
  close(fd);
     351:	83 ec 0c             	sub    $0xc,%esp
     354:	ff 75 f4             	push   -0xc(%ebp)
     357:	e8 c6 3c 00 00       	call   4022 <close>
     35c:	83 c4 10             	add    $0x10,%esp
  fd = open("doesnotexist", 0);
     35f:	83 ec 08             	sub    $0x8,%esp
     362:	6a 00                	push   $0x0
     364:	68 93 46 00 00       	push   $0x4693
     369:	e8 cc 3c 00 00       	call   403a <open>
     36e:	83 c4 10             	add    $0x10,%esp
     371:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd >= 0){
     374:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     378:	78 1b                	js     395 <opentest+0x96>
    printf(stdout, "open doesnotexist succeeded!\n");
     37a:	a1 ac 64 00 00       	mov    0x64ac,%eax
     37f:	83 ec 08             	sub    $0x8,%esp
     382:	68 a0 46 00 00       	push   $0x46a0
     387:	50                   	push   %eax
     388:	e8 e9 3d 00 00       	call   4176 <printf>
     38d:	83 c4 10             	add    $0x10,%esp
    exit();
     390:	e8 65 3c 00 00       	call   3ffa <exit>
  }
  printf(stdout, "open test ok\n");
     395:	a1 ac 64 00 00       	mov    0x64ac,%eax
     39a:	83 ec 08             	sub    $0x8,%esp
     39d:	68 be 46 00 00       	push   $0x46be
     3a2:	50                   	push   %eax
     3a3:	e8 ce 3d 00 00       	call   4176 <printf>
     3a8:	83 c4 10             	add    $0x10,%esp
}
     3ab:	90                   	nop
     3ac:	c9                   	leave
     3ad:	c3                   	ret

000003ae <writetest>:

void
writetest(void)
{
     3ae:	55                   	push   %ebp
     3af:	89 e5                	mov    %esp,%ebp
     3b1:	83 ec 18             	sub    $0x18,%esp
  int fd;
  int i;

  printf(stdout, "small file test\n");
     3b4:	a1 ac 64 00 00       	mov    0x64ac,%eax
     3b9:	83 ec 08             	sub    $0x8,%esp
     3bc:	68 cc 46 00 00       	push   $0x46cc
     3c1:	50                   	push   %eax
     3c2:	e8 af 3d 00 00       	call   4176 <printf>
     3c7:	83 c4 10             	add    $0x10,%esp
  fd = open("small", O_CREATE|O_RDWR);
     3ca:	83 ec 08             	sub    $0x8,%esp
     3cd:	68 02 02 00 00       	push   $0x202
     3d2:	68 dd 46 00 00       	push   $0x46dd
     3d7:	e8 5e 3c 00 00       	call   403a <open>
     3dc:	83 c4 10             	add    $0x10,%esp
     3df:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(fd >= 0){
     3e2:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
     3e6:	78 22                	js     40a <writetest+0x5c>
    printf(stdout, "creat small succeeded; ok\n");
     3e8:	a1 ac 64 00 00       	mov    0x64ac,%eax
     3ed:	83 ec 08             	sub    $0x8,%esp
     3f0:	68 e3 46 00 00       	push   $0x46e3
     3f5:	50                   	push   %eax
     3f6:	e8 7b 3d 00 00       	call   4176 <printf>
     3fb:	83 c4 10             	add    $0x10,%esp
  } else {
    printf(stdout, "error: creat small failed!\n");
    exit();
  }
  for(i = 0; i < 100; i++){
     3fe:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
     405:	e9 8f 00 00 00       	jmp    499 <writetest+0xeb>
    printf(stdout, "error: creat small failed!\n");
     40a:	a1 ac 64 00 00       	mov    0x64ac,%eax
     40f:	83 ec 08             	sub    $0x8,%esp
     412:	68 fe 46 00 00       	push   $0x46fe
     417:	50                   	push   %eax
     418:	e8 59 3d 00 00       	call   4176 <printf>
     41d:	83 c4 10             	add    $0x10,%esp
    exit();
     420:	e8 d5 3b 00 00       	call   3ffa <exit>
    if(write(fd, "aaaaaaaaaa", 10) != 10){
     425:	83 ec 04             	sub    $0x4,%esp
     428:	6a 0a                	push   $0xa
     42a:	68 1a 47 00 00       	push   $0x471a
     42f:	ff 75 f0             	push   -0x10(%ebp)
     432:	e8 e3 3b 00 00       	call   401a <write>
     437:	83 c4 10             	add    $0x10,%esp
     43a:	83 f8 0a             	cmp    $0xa,%eax
     43d:	74 1e                	je     45d <writetest+0xaf>
      printf(stdout, "error: write aa %d new file failed\n", i);
     43f:	a1 ac 64 00 00       	mov    0x64ac,%eax
     444:	83 ec 04             	sub    $0x4,%esp
     447:	ff 75 f4             	push   -0xc(%ebp)
     44a:	68 28 47 00 00       	push   $0x4728
     44f:	50                   	push   %eax
     450:	e8 21 3d 00 00       	call   4176 <printf>
     455:	83 c4 10             	add    $0x10,%esp
      exit();
     458:	e8 9d 3b 00 00       	call   3ffa <exit>
    }
    if(write(fd, "bbbbbbbbbb", 10) != 10){
     45d:	83 ec 04             	sub    $0x4,%esp
     460:	6a 0a                	push   $0xa
     462:	68 4c 47 00 00       	push   $0x474c
     467:	ff 75 f0             	push   -0x10(%ebp)
     46a:	e8 ab 3b 00 00       	call   401a <write>
     46f:	83 c4 10             	add    $0x10,%esp
     472:	83 f8 0a             	cmp    $0xa,%eax
     475:	74 1e                	je     495 <writetest+0xe7>
      printf(stdout, "error: write bb %d new file failed\n", i);
     477:	a1 ac 64 00 00       	mov    0x64ac,%eax
     47c:	83 ec 04             	sub    $0x4,%esp
     47f:	ff 75 f4             	push   -0xc(%ebp)
     482:	68 58 47 00 00       	push   $0x4758
     487:	50                   	push   %eax
     488:	e8 e9 3c 00 00       	call   4176 <printf>
     48d:	83 c4 10             	add    $0x10,%esp
      exit();
     490:	e8 65 3b 00 00       	call   3ffa <exit>
  for(i = 0; i < 100; i++){
     495:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
     499:	83 7d f4 63          	cmpl   $0x63,-0xc(%ebp)
     49d:	7e 86                	jle    425 <writetest+0x77>
    }
  }
  printf(stdout, "writes ok\n");
     49f:	a1 ac 64 00 00       	mov    0x64ac,%eax
     4a4:	83 ec 08             	sub    $0x8,%esp
     4a7:	68 7c 47 00 00       	push   $0x477c
     4ac:	50                   	push   %eax
     4ad:	e8 c4 3c 00 00       	call   4176 <printf>
     4b2:	83 c4 10             	add    $0x10,%esp
  close(fd);
     4b5:	83 ec 0c             	sub    $0xc,%esp
     4b8:	ff 75 f0             	push   -0x10(%ebp)
     4bb:	e8 62 3b 00 00       	call   4022 <close>
     4c0:	83 c4 10             	add    $0x10,%esp
  fd = open("small", O_RDONLY);
     4c3:	83 ec 08             	sub    $0x8,%esp
     4c6:	6a 00                	push   $0x0
     4c8:	68 dd 46 00 00       	push   $0x46dd
     4cd:	e8 68 3b 00 00       	call   403a <open>
     4d2:	83 c4 10             	add    $0x10,%esp
     4d5:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(fd >= 0){
     4d8:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
     4dc:	78 3c                	js     51a <writetest+0x16c>
    printf(stdout, "open small succeeded ok\n");
     4de:	a1 ac 64 00 00       	mov    0x64ac,%eax
     4e3:	83 ec 08             	sub    $0x8,%esp
     4e6:	68 87 47 00 00       	push   $0x4787
     4eb:	50                   	push   %eax
     4ec:	e8 85 3c 00 00       	call   4176 <printf>
     4f1:	83 c4 10             	add    $0x10,%esp
  } else {
    printf(stdout, "error: open small failed!\n");
    exit();
  }
  i = read(fd, buf, 2000);
     4f4:	83 ec 04             	sub    $0x4,%esp
     4f7:	68 d0 07 00 00       	push   $0x7d0
     4fc:	68 e0 64 00 00       	push   $0x64e0
     501:	ff 75 f0             	push   -0x10(%ebp)
     504:	e8 09 3b 00 00       	call   4012 <read>
     509:	83 c4 10             	add    $0x10,%esp
     50c:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(i == 2000){
     50f:	81 7d f4 d0 07 00 00 	cmpl   $0x7d0,-0xc(%ebp)
     516:	75 57                	jne    56f <writetest+0x1c1>
     518:	eb 1b                	jmp    535 <writetest+0x187>
    printf(stdout, "error: open small failed!\n");
     51a:	a1 ac 64 00 00       	mov    0x64ac,%eax
     51f:	83 ec 08             	sub    $0x8,%esp
     522:	68 a0 47 00 00       	push   $0x47a0
     527:	50                   	push   %eax
     528:	e8 49 3c 00 00       	call   4176 <printf>
     52d:	83 c4 10             	add    $0x10,%esp
    exit();
     530:	e8 c5 3a 00 00       	call   3ffa <exit>
    printf(stdout, "read succeeded ok\n");
     535:	a1 ac 64 00 00       	mov    0x64ac,%eax
     53a:	83 ec 08             	sub    $0x8,%esp
     53d:	68 bb 47 00 00       	push   $0x47bb
     542:	50                   	push   %eax
     543:	e8 2e 3c 00 00       	call   4176 <printf>
     548:	83 c4 10             	add    $0x10,%esp
  } else {
    printf(stdout, "read failed\n");
    exit();
  }
  close(fd);
     54b:	83 ec 0c             	sub    $0xc,%esp
     54e:	ff 75 f0             	push   -0x10(%ebp)
     551:	e8 cc 3a 00 00       	call   4022 <close>
     556:	83 c4 10             	add    $0x10,%esp

  if(unlink("small") < 0){
     559:	83 ec 0c             	sub    $0xc,%esp
     55c:	68 dd 46 00 00       	push   $0x46dd
     561:	e8 e4 3a 00 00       	call   404a <unlink>
     566:	83 c4 10             	add    $0x10,%esp
     569:	85 c0                	test   %eax,%eax
     56b:	79 38                	jns    5a5 <writetest+0x1f7>
     56d:	eb 1b                	jmp    58a <writetest+0x1dc>
    printf(stdout, "read failed\n");
     56f:	a1 ac 64 00 00       	mov    0x64ac,%eax
     574:	83 ec 08             	sub    $0x8,%esp
     577:	68 ce 47 00 00       	push   $0x47ce
     57c:	50                   	push   %eax
     57d:	e8 f4 3b 00 00       	call   4176 <printf>
     582:	83 c4 10             	add    $0x10,%esp
    exit();
     585:	e8 70 3a 00 00       	call   3ffa <exit>
    printf(stdout, "unlink small failed\n");
     58a:	a1 ac 64 00 00       	mov    0x64ac,%eax
     58f:	83 ec 08             	sub    $0x8,%esp
     592:	68 db 47 00 00       	push   $0x47db
     597:	50                   	push   %eax
     598:	e8 d9 3b 00 00       	call   4176 <printf>
     59d:	83 c4 10             	add    $0x10,%esp
    exit();
     5a0:	e8 55 3a 00 00       	call   3ffa <exit>
  }
  printf(stdout, "small file test ok\n");
     5a5:	a1 ac 64 00 00       	mov    0x64ac,%eax
     5aa:	83 ec 08             	sub    $0x8,%esp
     5ad:	68 f0 47 00 00       	push   $0x47f0
     5b2:	50                   	push   %eax
     5b3:	e8 be 3b 00 00       	call   4176 <printf>
     5b8:	83 c4 10             	add    $0x10,%esp
}
     5bb:	90                   	nop
     5bc:	c9                   	leave
     5bd:	c3                   	ret

000005be <writetest1>:

void
writetest1(void)
{
     5be:	55                   	push   %ebp
     5bf:	89 e5                	mov    %esp,%ebp
     5c1:	83 ec 18             	sub    $0x18,%esp
  int i, fd, n;

  printf(stdout, "big files test\n");
     5c4:	a1 ac 64 00 00       	mov    0x64ac,%eax
     5c9:	83 ec 08             	sub    $0x8,%esp
     5cc:	68 04 48 00 00       	push   $0x4804
     5d1:	50                   	push   %eax
     5d2:	e8 9f 3b 00 00       	call   4176 <printf>
     5d7:	83 c4 10             	add    $0x10,%esp

  fd = open("big", O_CREATE|O_RDWR);
     5da:	83 ec 08             	sub    $0x8,%esp
     5dd:	68 02 02 00 00       	push   $0x202
     5e2:	68 14 48 00 00       	push   $0x4814
     5e7:	e8 4e 3a 00 00       	call   403a <open>
     5ec:	83 c4 10             	add    $0x10,%esp
     5ef:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if(fd < 0){
     5f2:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
     5f6:	79 1b                	jns    613 <writetest1+0x55>
    printf(stdout, "error: creat big failed!\n");
     5f8:	a1 ac 64 00 00       	mov    0x64ac,%eax
     5fd:	83 ec 08             	sub    $0x8,%esp
     600:	68 18 48 00 00       	push   $0x4818
     605:	50                   	push   %eax
     606:	e8 6b 3b 00 00       	call   4176 <printf>
     60b:	83 c4 10             	add    $0x10,%esp
    exit();
     60e:	e8 e7 39 00 00       	call   3ffa <exit>
  }

  for(i = 0; i < MAXFILE; i++){
     613:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
     61a:	eb 4b                	jmp    667 <writetest1+0xa9>
    ((int*)buf)[0] = i;
     61c:	ba e0 64 00 00       	mov    $0x64e0,%edx
     621:	8b 45 f4             	mov    -0xc(%ebp),%eax
     624:	89 02                	mov    %eax,(%edx)
    if(write(fd, buf, 512) != 512){
     626:	83 ec 04             	sub    $0x4,%esp
     629:	68 00 02 00 00       	push   $0x200
     62e:	68 e0 64 00 00       	push   $0x64e0
     633:	ff 75 ec             	push   -0x14(%ebp)
     636:	e8 df 39 00 00       	call   401a <write>
     63b:	83 c4 10             	add    $0x10,%esp
     63e:	3d 00 02 00 00       	cmp    $0x200,%eax
     643:	74 1e                	je     663 <writetest1+0xa5>
      printf(stdout, "error: write big file failed\n", i);
     645:	a1 ac 64 00 00       	mov    0x64ac,%eax
     64a:	83 ec 04             	sub    $0x4,%esp
     64d:	ff 75 f4             	push   -0xc(%ebp)
     650:	68 32 48 00 00       	push   $0x4832
     655:	50                   	push   %eax
     656:	e8 1b 3b 00 00       	call   4176 <printf>
     65b:	83 c4 10             	add    $0x10,%esp
      exit();
     65e:	e8 97 39 00 00       	call   3ffa <exit>
  for(i = 0; i < MAXFILE; i++){
     663:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
     667:	8b 45 f4             	mov    -0xc(%ebp),%eax
     66a:	3d 8b 00 00 00       	cmp    $0x8b,%eax
     66f:	76 ab                	jbe    61c <writetest1+0x5e>
    }
  }

  close(fd);
     671:	83 ec 0c             	sub    $0xc,%esp
     674:	ff 75 ec             	push   -0x14(%ebp)
     677:	e8 a6 39 00 00       	call   4022 <close>
     67c:	83 c4 10             	add    $0x10,%esp

  fd = open("big", O_RDONLY);
     67f:	83 ec 08             	sub    $0x8,%esp
     682:	6a 00                	push   $0x0
     684:	68 14 48 00 00       	push   $0x4814
     689:	e8 ac 39 00 00       	call   403a <open>
     68e:	83 c4 10             	add    $0x10,%esp
     691:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if(fd < 0){
     694:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
     698:	79 1b                	jns    6b5 <writetest1+0xf7>
    printf(stdout, "error: open big failed!\n");
     69a:	a1 ac 64 00 00       	mov    0x64ac,%eax
     69f:	83 ec 08             	sub    $0x8,%esp
     6a2:	68 50 48 00 00       	push   $0x4850
     6a7:	50                   	push   %eax
     6a8:	e8 c9 3a 00 00       	call   4176 <printf>
     6ad:	83 c4 10             	add    $0x10,%esp
    exit();
     6b0:	e8 45 39 00 00       	call   3ffa <exit>
  }

  n = 0;
     6b5:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  for(;;){
    i = read(fd, buf, 512);
     6bc:	83 ec 04             	sub    $0x4,%esp
     6bf:	68 00 02 00 00       	push   $0x200
     6c4:	68 e0 64 00 00       	push   $0x64e0
     6c9:	ff 75 ec             	push   -0x14(%ebp)
     6cc:	e8 41 39 00 00       	call   4012 <read>
     6d1:	83 c4 10             	add    $0x10,%esp
     6d4:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(i == 0){
     6d7:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     6db:	75 27                	jne    704 <writetest1+0x146>
      if(n == MAXFILE - 1){
     6dd:	81 7d f0 8b 00 00 00 	cmpl   $0x8b,-0x10(%ebp)
     6e4:	75 7d                	jne    763 <writetest1+0x1a5>
        printf(stdout, "read only %d blocks from big", n);
     6e6:	a1 ac 64 00 00       	mov    0x64ac,%eax
     6eb:	83 ec 04             	sub    $0x4,%esp
     6ee:	ff 75 f0             	push   -0x10(%ebp)
     6f1:	68 69 48 00 00       	push   $0x4869
     6f6:	50                   	push   %eax
     6f7:	e8 7a 3a 00 00       	call   4176 <printf>
     6fc:	83 c4 10             	add    $0x10,%esp
        exit();
     6ff:	e8 f6 38 00 00       	call   3ffa <exit>
      }
      break;
    } else if(i != 512){
     704:	81 7d f4 00 02 00 00 	cmpl   $0x200,-0xc(%ebp)
     70b:	74 1e                	je     72b <writetest1+0x16d>
      printf(stdout, "read failed %d\n", i);
     70d:	a1 ac 64 00 00       	mov    0x64ac,%eax
     712:	83 ec 04             	sub    $0x4,%esp
     715:	ff 75 f4             	push   -0xc(%ebp)
     718:	68 86 48 00 00       	push   $0x4886
     71d:	50                   	push   %eax
     71e:	e8 53 3a 00 00       	call   4176 <printf>
     723:	83 c4 10             	add    $0x10,%esp
      exit();
     726:	e8 cf 38 00 00       	call   3ffa <exit>
    }
    if(((int*)buf)[0] != n){
     72b:	b8 e0 64 00 00       	mov    $0x64e0,%eax
     730:	8b 00                	mov    (%eax),%eax
     732:	39 45 f0             	cmp    %eax,-0x10(%ebp)
     735:	74 23                	je     75a <writetest1+0x19c>
      printf(stdout, "read content of block %d is %d\n",
             n, ((int*)buf)[0]);
     737:	b8 e0 64 00 00       	mov    $0x64e0,%eax
      printf(stdout, "read content of block %d is %d\n",
     73c:	8b 10                	mov    (%eax),%edx
     73e:	a1 ac 64 00 00       	mov    0x64ac,%eax
     743:	52                   	push   %edx
     744:	ff 75 f0             	push   -0x10(%ebp)
     747:	68 98 48 00 00       	push   $0x4898
     74c:	50                   	push   %eax
     74d:	e8 24 3a 00 00       	call   4176 <printf>
     752:	83 c4 10             	add    $0x10,%esp
      exit();
     755:	e8 a0 38 00 00       	call   3ffa <exit>
    }
    n++;
     75a:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    i = read(fd, buf, 512);
     75e:	e9 59 ff ff ff       	jmp    6bc <writetest1+0xfe>
      break;
     763:	90                   	nop
  }
  close(fd);
     764:	83 ec 0c             	sub    $0xc,%esp
     767:	ff 75 ec             	push   -0x14(%ebp)
     76a:	e8 b3 38 00 00       	call   4022 <close>
     76f:	83 c4 10             	add    $0x10,%esp
  if(unlink("big") < 0){
     772:	83 ec 0c             	sub    $0xc,%esp
     775:	68 14 48 00 00       	push   $0x4814
     77a:	e8 cb 38 00 00       	call   404a <unlink>
     77f:	83 c4 10             	add    $0x10,%esp
     782:	85 c0                	test   %eax,%eax
     784:	79 1b                	jns    7a1 <writetest1+0x1e3>
    printf(stdout, "unlink big failed\n");
     786:	a1 ac 64 00 00       	mov    0x64ac,%eax
     78b:	83 ec 08             	sub    $0x8,%esp
     78e:	68 b8 48 00 00       	push   $0x48b8
     793:	50                   	push   %eax
     794:	e8 dd 39 00 00       	call   4176 <printf>
     799:	83 c4 10             	add    $0x10,%esp
    exit();
     79c:	e8 59 38 00 00       	call   3ffa <exit>
  }
  printf(stdout, "big files ok\n");
     7a1:	a1 ac 64 00 00       	mov    0x64ac,%eax
     7a6:	83 ec 08             	sub    $0x8,%esp
     7a9:	68 cb 48 00 00       	push   $0x48cb
     7ae:	50                   	push   %eax
     7af:	e8 c2 39 00 00       	call   4176 <printf>
     7b4:	83 c4 10             	add    $0x10,%esp
}
     7b7:	90                   	nop
     7b8:	c9                   	leave
     7b9:	c3                   	ret

000007ba <createtest>:

void
createtest(void)
{
     7ba:	55                   	push   %ebp
     7bb:	89 e5                	mov    %esp,%ebp
     7bd:	83 ec 18             	sub    $0x18,%esp
  int i, fd;

  printf(stdout, "many creates, followed by unlink test\n");
     7c0:	a1 ac 64 00 00       	mov    0x64ac,%eax
     7c5:	83 ec 08             	sub    $0x8,%esp
     7c8:	68 dc 48 00 00       	push   $0x48dc
     7cd:	50                   	push   %eax
     7ce:	e8 a3 39 00 00       	call   4176 <printf>
     7d3:	83 c4 10             	add    $0x10,%esp

  name[0] = 'a';
     7d6:	c6 05 e0 84 00 00 61 	movb   $0x61,0x84e0
  name[2] = '\0';
     7dd:	c6 05 e2 84 00 00 00 	movb   $0x0,0x84e2
  for(i = 0; i < 52; i++){
     7e4:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
     7eb:	eb 35                	jmp    822 <createtest+0x68>
    name[1] = '0' + i;
     7ed:	8b 45 f4             	mov    -0xc(%ebp),%eax
     7f0:	83 c0 30             	add    $0x30,%eax
     7f3:	a2 e1 84 00 00       	mov    %al,0x84e1
    fd = open(name, O_CREATE|O_RDWR);
     7f8:	83 ec 08             	sub    $0x8,%esp
     7fb:	68 02 02 00 00       	push   $0x202
     800:	68 e0 84 00 00       	push   $0x84e0
     805:	e8 30 38 00 00       	call   403a <open>
     80a:	83 c4 10             	add    $0x10,%esp
     80d:	89 45 f0             	mov    %eax,-0x10(%ebp)
    close(fd);
     810:	83 ec 0c             	sub    $0xc,%esp
     813:	ff 75 f0             	push   -0x10(%ebp)
     816:	e8 07 38 00 00       	call   4022 <close>
     81b:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < 52; i++){
     81e:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
     822:	83 7d f4 33          	cmpl   $0x33,-0xc(%ebp)
     826:	7e c5                	jle    7ed <createtest+0x33>
  }
  name[0] = 'a';
     828:	c6 05 e0 84 00 00 61 	movb   $0x61,0x84e0
  name[2] = '\0';
     82f:	c6 05 e2 84 00 00 00 	movb   $0x0,0x84e2
  for(i = 0; i < 52; i++){
     836:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
     83d:	eb 1f                	jmp    85e <createtest+0xa4>
    name[1] = '0' + i;
     83f:	8b 45 f4             	mov    -0xc(%ebp),%eax
     842:	83 c0 30             	add    $0x30,%eax
     845:	a2 e1 84 00 00       	mov    %al,0x84e1
    unlink(name);
     84a:	83 ec 0c             	sub    $0xc,%esp
     84d:	68 e0 84 00 00       	push   $0x84e0
     852:	e8 f3 37 00 00       	call   404a <unlink>
     857:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < 52; i++){
     85a:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
     85e:	83 7d f4 33          	cmpl   $0x33,-0xc(%ebp)
     862:	7e db                	jle    83f <createtest+0x85>
  }
  printf(stdout, "many creates, followed by unlink; ok\n");
     864:	a1 ac 64 00 00       	mov    0x64ac,%eax
     869:	83 ec 08             	sub    $0x8,%esp
     86c:	68 04 49 00 00       	push   $0x4904
     871:	50                   	push   %eax
     872:	e8 ff 38 00 00       	call   4176 <printf>
     877:	83 c4 10             	add    $0x10,%esp
}
     87a:	90                   	nop
     87b:	c9                   	leave
     87c:	c3                   	ret

0000087d <dirtest>:

void dirtest(void)
{
     87d:	55                   	push   %ebp
     87e:	89 e5                	mov    %esp,%ebp
     880:	83 ec 08             	sub    $0x8,%esp
  printf(stdout, "mkdir test\n");
     883:	a1 ac 64 00 00       	mov    0x64ac,%eax
     888:	83 ec 08             	sub    $0x8,%esp
     88b:	68 2a 49 00 00       	push   $0x492a
     890:	50                   	push   %eax
     891:	e8 e0 38 00 00       	call   4176 <printf>
     896:	83 c4 10             	add    $0x10,%esp

  if(mkdir("dir0") < 0){
     899:	83 ec 0c             	sub    $0xc,%esp
     89c:	68 36 49 00 00       	push   $0x4936
     8a1:	e8 bc 37 00 00       	call   4062 <mkdir>
     8a6:	83 c4 10             	add    $0x10,%esp
     8a9:	85 c0                	test   %eax,%eax
     8ab:	79 1b                	jns    8c8 <dirtest+0x4b>
    printf(stdout, "mkdir failed\n");
     8ad:	a1 ac 64 00 00       	mov    0x64ac,%eax
     8b2:	83 ec 08             	sub    $0x8,%esp
     8b5:	68 59 45 00 00       	push   $0x4559
     8ba:	50                   	push   %eax
     8bb:	e8 b6 38 00 00       	call   4176 <printf>
     8c0:	83 c4 10             	add    $0x10,%esp
    exit();
     8c3:	e8 32 37 00 00       	call   3ffa <exit>
  }

  if(chdir("dir0") < 0){
     8c8:	83 ec 0c             	sub    $0xc,%esp
     8cb:	68 36 49 00 00       	push   $0x4936
     8d0:	e8 95 37 00 00       	call   406a <chdir>
     8d5:	83 c4 10             	add    $0x10,%esp
     8d8:	85 c0                	test   %eax,%eax
     8da:	79 1b                	jns    8f7 <dirtest+0x7a>
    printf(stdout, "chdir dir0 failed\n");
     8dc:	a1 ac 64 00 00       	mov    0x64ac,%eax
     8e1:	83 ec 08             	sub    $0x8,%esp
     8e4:	68 3b 49 00 00       	push   $0x493b
     8e9:	50                   	push   %eax
     8ea:	e8 87 38 00 00       	call   4176 <printf>
     8ef:	83 c4 10             	add    $0x10,%esp
    exit();
     8f2:	e8 03 37 00 00       	call   3ffa <exit>
  }

  if(chdir("..") < 0){
     8f7:	83 ec 0c             	sub    $0xc,%esp
     8fa:	68 4e 49 00 00       	push   $0x494e
     8ff:	e8 66 37 00 00       	call   406a <chdir>
     904:	83 c4 10             	add    $0x10,%esp
     907:	85 c0                	test   %eax,%eax
     909:	79 1b                	jns    926 <dirtest+0xa9>
    printf(stdout, "chdir .. failed\n");
     90b:	a1 ac 64 00 00       	mov    0x64ac,%eax
     910:	83 ec 08             	sub    $0x8,%esp
     913:	68 51 49 00 00       	push   $0x4951
     918:	50                   	push   %eax
     919:	e8 58 38 00 00       	call   4176 <printf>
     91e:	83 c4 10             	add    $0x10,%esp
    exit();
     921:	e8 d4 36 00 00       	call   3ffa <exit>
  }

  if(unlink("dir0") < 0){
     926:	83 ec 0c             	sub    $0xc,%esp
     929:	68 36 49 00 00       	push   $0x4936
     92e:	e8 17 37 00 00       	call   404a <unlink>
     933:	83 c4 10             	add    $0x10,%esp
     936:	85 c0                	test   %eax,%eax
     938:	79 1b                	jns    955 <dirtest+0xd8>
    printf(stdout, "unlink dir0 failed\n");
     93a:	a1 ac 64 00 00       	mov    0x64ac,%eax
     93f:	83 ec 08             	sub    $0x8,%esp
     942:	68 62 49 00 00       	push   $0x4962
     947:	50                   	push   %eax
     948:	e8 29 38 00 00       	call   4176 <printf>
     94d:	83 c4 10             	add    $0x10,%esp
    exit();
     950:	e8 a5 36 00 00       	call   3ffa <exit>
  }
  printf(stdout, "mkdir test ok\n");
     955:	a1 ac 64 00 00       	mov    0x64ac,%eax
     95a:	83 ec 08             	sub    $0x8,%esp
     95d:	68 76 49 00 00       	push   $0x4976
     962:	50                   	push   %eax
     963:	e8 0e 38 00 00       	call   4176 <printf>
     968:	83 c4 10             	add    $0x10,%esp
}
     96b:	90                   	nop
     96c:	c9                   	leave
     96d:	c3                   	ret

0000096e <exectest>:

void
exectest(void)
{
     96e:	55                   	push   %ebp
     96f:	89 e5                	mov    %esp,%ebp
     971:	83 ec 08             	sub    $0x8,%esp
  printf(stdout, "exec test\n");
     974:	a1 ac 64 00 00       	mov    0x64ac,%eax
     979:	83 ec 08             	sub    $0x8,%esp
     97c:	68 85 49 00 00       	push   $0x4985
     981:	50                   	push   %eax
     982:	e8 ef 37 00 00       	call   4176 <printf>
     987:	83 c4 10             	add    $0x10,%esp
  if(exec("echo", echoargv) < 0){
     98a:	83 ec 08             	sub    $0x8,%esp
     98d:	68 98 64 00 00       	push   $0x6498
     992:	68 30 45 00 00       	push   $0x4530
     997:	e8 96 36 00 00       	call   4032 <exec>
     99c:	83 c4 10             	add    $0x10,%esp
     99f:	85 c0                	test   %eax,%eax
     9a1:	79 1b                	jns    9be <exectest+0x50>
    printf(stdout, "exec echo failed\n");
     9a3:	a1 ac 64 00 00       	mov    0x64ac,%eax
     9a8:	83 ec 08             	sub    $0x8,%esp
     9ab:	68 90 49 00 00       	push   $0x4990
     9b0:	50                   	push   %eax
     9b1:	e8 c0 37 00 00       	call   4176 <printf>
     9b6:	83 c4 10             	add    $0x10,%esp
    exit();
     9b9:	e8 3c 36 00 00       	call   3ffa <exit>
  }
}
     9be:	90                   	nop
     9bf:	c9                   	leave
     9c0:	c3                   	ret

000009c1 <pipe1>:

// simple fork and pipe read/write

void
pipe1(void)
{
     9c1:	55                   	push   %ebp
     9c2:	89 e5                	mov    %esp,%ebp
     9c4:	83 ec 28             	sub    $0x28,%esp
  int fds[2], pid;
  int seq, i, n, cc, total;

  if(pipe(fds) != 0){
     9c7:	83 ec 0c             	sub    $0xc,%esp
     9ca:	8d 45 d8             	lea    -0x28(%ebp),%eax
     9cd:	50                   	push   %eax
     9ce:	e8 37 36 00 00       	call   400a <pipe>
     9d3:	83 c4 10             	add    $0x10,%esp
     9d6:	85 c0                	test   %eax,%eax
     9d8:	74 17                	je     9f1 <pipe1+0x30>
    printf(1, "pipe() failed\n");
     9da:	83 ec 08             	sub    $0x8,%esp
     9dd:	68 a2 49 00 00       	push   $0x49a2
     9e2:	6a 01                	push   $0x1
     9e4:	e8 8d 37 00 00       	call   4176 <printf>
     9e9:	83 c4 10             	add    $0x10,%esp
    exit();
     9ec:	e8 09 36 00 00       	call   3ffa <exit>
  }
  pid = fork();
     9f1:	e8 fc 35 00 00       	call   3ff2 <fork>
     9f6:	89 45 e0             	mov    %eax,-0x20(%ebp)
  seq = 0;
     9f9:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  if(pid == 0){
     a00:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
     a04:	0f 85 89 00 00 00    	jne    a93 <pipe1+0xd2>
    close(fds[0]);
     a0a:	8b 45 d8             	mov    -0x28(%ebp),%eax
     a0d:	83 ec 0c             	sub    $0xc,%esp
     a10:	50                   	push   %eax
     a11:	e8 0c 36 00 00       	call   4022 <close>
     a16:	83 c4 10             	add    $0x10,%esp
    for(n = 0; n < 5; n++){
     a19:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
     a20:	eb 66                	jmp    a88 <pipe1+0xc7>
      for(i = 0; i < 1033; i++)
     a22:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
     a29:	eb 19                	jmp    a44 <pipe1+0x83>
        buf[i] = seq++;
     a2b:	8b 45 f4             	mov    -0xc(%ebp),%eax
     a2e:	8d 50 01             	lea    0x1(%eax),%edx
     a31:	89 55 f4             	mov    %edx,-0xc(%ebp)
     a34:	89 c2                	mov    %eax,%edx
     a36:	8b 45 f0             	mov    -0x10(%ebp),%eax
     a39:	05 e0 64 00 00       	add    $0x64e0,%eax
     a3e:	88 10                	mov    %dl,(%eax)
      for(i = 0; i < 1033; i++)
     a40:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
     a44:	81 7d f0 08 04 00 00 	cmpl   $0x408,-0x10(%ebp)
     a4b:	7e de                	jle    a2b <pipe1+0x6a>
      if(write(fds[1], buf, 1033) != 1033){
     a4d:	8b 45 dc             	mov    -0x24(%ebp),%eax
     a50:	83 ec 04             	sub    $0x4,%esp
     a53:	68 09 04 00 00       	push   $0x409
     a58:	68 e0 64 00 00       	push   $0x64e0
     a5d:	50                   	push   %eax
     a5e:	e8 b7 35 00 00       	call   401a <write>
     a63:	83 c4 10             	add    $0x10,%esp
     a66:	3d 09 04 00 00       	cmp    $0x409,%eax
     a6b:	74 17                	je     a84 <pipe1+0xc3>
        printf(1, "pipe1 oops 1\n");
     a6d:	83 ec 08             	sub    $0x8,%esp
     a70:	68 b1 49 00 00       	push   $0x49b1
     a75:	6a 01                	push   $0x1
     a77:	e8 fa 36 00 00       	call   4176 <printf>
     a7c:	83 c4 10             	add    $0x10,%esp
        exit();
     a7f:	e8 76 35 00 00       	call   3ffa <exit>
    for(n = 0; n < 5; n++){
     a84:	83 45 ec 01          	addl   $0x1,-0x14(%ebp)
     a88:	83 7d ec 04          	cmpl   $0x4,-0x14(%ebp)
     a8c:	7e 94                	jle    a22 <pipe1+0x61>
      }
    }
    exit();
     a8e:	e8 67 35 00 00       	call   3ffa <exit>
  } else if(pid > 0){
     a93:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
     a97:	0f 8e f4 00 00 00    	jle    b91 <pipe1+0x1d0>
    close(fds[1]);
     a9d:	8b 45 dc             	mov    -0x24(%ebp),%eax
     aa0:	83 ec 0c             	sub    $0xc,%esp
     aa3:	50                   	push   %eax
     aa4:	e8 79 35 00 00       	call   4022 <close>
     aa9:	83 c4 10             	add    $0x10,%esp
    total = 0;
     aac:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
    cc = 1;
     ab3:	c7 45 e8 01 00 00 00 	movl   $0x1,-0x18(%ebp)
    while((n = read(fds[0], buf, cc)) > 0){
     aba:	eb 66                	jmp    b22 <pipe1+0x161>
      for(i = 0; i < n; i++){
     abc:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
     ac3:	eb 3b                	jmp    b00 <pipe1+0x13f>
        if((buf[i] & 0xff) != (seq++ & 0xff)){
     ac5:	8b 45 f0             	mov    -0x10(%ebp),%eax
     ac8:	05 e0 64 00 00       	add    $0x64e0,%eax
     acd:	0f b6 00             	movzbl (%eax),%eax
     ad0:	0f be c8             	movsbl %al,%ecx
     ad3:	8b 45 f4             	mov    -0xc(%ebp),%eax
     ad6:	8d 50 01             	lea    0x1(%eax),%edx
     ad9:	89 55 f4             	mov    %edx,-0xc(%ebp)
     adc:	31 c8                	xor    %ecx,%eax
     ade:	0f b6 c0             	movzbl %al,%eax
     ae1:	85 c0                	test   %eax,%eax
     ae3:	74 17                	je     afc <pipe1+0x13b>
          printf(1, "pipe1 oops 2\n");
     ae5:	83 ec 08             	sub    $0x8,%esp
     ae8:	68 bf 49 00 00       	push   $0x49bf
     aed:	6a 01                	push   $0x1
     aef:	e8 82 36 00 00       	call   4176 <printf>
     af4:	83 c4 10             	add    $0x10,%esp
     af7:	e9 ac 00 00 00       	jmp    ba8 <pipe1+0x1e7>
      for(i = 0; i < n; i++){
     afc:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
     b00:	8b 45 f0             	mov    -0x10(%ebp),%eax
     b03:	3b 45 ec             	cmp    -0x14(%ebp),%eax
     b06:	7c bd                	jl     ac5 <pipe1+0x104>
          return;
        }
      }
      total += n;
     b08:	8b 45 ec             	mov    -0x14(%ebp),%eax
     b0b:	01 45 e4             	add    %eax,-0x1c(%ebp)
      cc = cc * 2;
     b0e:	d1 65 e8             	shll   $1,-0x18(%ebp)
      if(cc > sizeof(buf))
     b11:	8b 45 e8             	mov    -0x18(%ebp),%eax
     b14:	3d 00 20 00 00       	cmp    $0x2000,%eax
     b19:	76 07                	jbe    b22 <pipe1+0x161>
        cc = sizeof(buf);
     b1b:	c7 45 e8 00 20 00 00 	movl   $0x2000,-0x18(%ebp)
    while((n = read(fds[0], buf, cc)) > 0){
     b22:	8b 45 d8             	mov    -0x28(%ebp),%eax
     b25:	83 ec 04             	sub    $0x4,%esp
     b28:	ff 75 e8             	push   -0x18(%ebp)
     b2b:	68 e0 64 00 00       	push   $0x64e0
     b30:	50                   	push   %eax
     b31:	e8 dc 34 00 00       	call   4012 <read>
     b36:	83 c4 10             	add    $0x10,%esp
     b39:	89 45 ec             	mov    %eax,-0x14(%ebp)
     b3c:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
     b40:	0f 8f 76 ff ff ff    	jg     abc <pipe1+0xfb>
    }
    if(total != 5 * 1033){
     b46:	81 7d e4 2d 14 00 00 	cmpl   $0x142d,-0x1c(%ebp)
     b4d:	74 1a                	je     b69 <pipe1+0x1a8>
      printf(1, "pipe1 oops 3 total %d\n", total);
     b4f:	83 ec 04             	sub    $0x4,%esp
     b52:	ff 75 e4             	push   -0x1c(%ebp)
     b55:	68 cd 49 00 00       	push   $0x49cd
     b5a:	6a 01                	push   $0x1
     b5c:	e8 15 36 00 00       	call   4176 <printf>
     b61:	83 c4 10             	add    $0x10,%esp
      exit();
     b64:	e8 91 34 00 00       	call   3ffa <exit>
    }
    close(fds[0]);
     b69:	8b 45 d8             	mov    -0x28(%ebp),%eax
     b6c:	83 ec 0c             	sub    $0xc,%esp
     b6f:	50                   	push   %eax
     b70:	e8 ad 34 00 00       	call   4022 <close>
     b75:	83 c4 10             	add    $0x10,%esp
    wait();
     b78:	e8 85 34 00 00       	call   4002 <wait>
  } else {
    printf(1, "fork() failed\n");
    exit();
  }
  printf(1, "pipe1 ok\n");
     b7d:	83 ec 08             	sub    $0x8,%esp
     b80:	68 f3 49 00 00       	push   $0x49f3
     b85:	6a 01                	push   $0x1
     b87:	e8 ea 35 00 00       	call   4176 <printf>
     b8c:	83 c4 10             	add    $0x10,%esp
     b8f:	eb 17                	jmp    ba8 <pipe1+0x1e7>
    printf(1, "fork() failed\n");
     b91:	83 ec 08             	sub    $0x8,%esp
     b94:	68 e4 49 00 00       	push   $0x49e4
     b99:	6a 01                	push   $0x1
     b9b:	e8 d6 35 00 00       	call   4176 <printf>
     ba0:	83 c4 10             	add    $0x10,%esp
    exit();
     ba3:	e8 52 34 00 00       	call   3ffa <exit>
}
     ba8:	c9                   	leave
     ba9:	c3                   	ret

00000baa <preempt>:

// meant to be run w/ at most two CPUs
void
preempt(void)
{
     baa:	55                   	push   %ebp
     bab:	89 e5                	mov    %esp,%ebp
     bad:	83 ec 28             	sub    $0x28,%esp
  int pid1, pid2, pid3;
  int pfds[2];

  printf(1, "preempt: ");
     bb0:	83 ec 08             	sub    $0x8,%esp
     bb3:	68 fd 49 00 00       	push   $0x49fd
     bb8:	6a 01                	push   $0x1
     bba:	e8 b7 35 00 00       	call   4176 <printf>
     bbf:	83 c4 10             	add    $0x10,%esp
  pid1 = fork();
     bc2:	e8 2b 34 00 00       	call   3ff2 <fork>
     bc7:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(pid1 == 0)
     bca:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     bce:	75 03                	jne    bd3 <preempt+0x29>
    for(;;)
     bd0:	90                   	nop
     bd1:	eb fd                	jmp    bd0 <preempt+0x26>
      ;

  pid2 = fork();
     bd3:	e8 1a 34 00 00       	call   3ff2 <fork>
     bd8:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(pid2 == 0)
     bdb:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
     bdf:	75 03                	jne    be4 <preempt+0x3a>
    for(;;)
     be1:	90                   	nop
     be2:	eb fd                	jmp    be1 <preempt+0x37>
      ;

  pipe(pfds);
     be4:	83 ec 0c             	sub    $0xc,%esp
     be7:	8d 45 e4             	lea    -0x1c(%ebp),%eax
     bea:	50                   	push   %eax
     beb:	e8 1a 34 00 00       	call   400a <pipe>
     bf0:	83 c4 10             	add    $0x10,%esp
  pid3 = fork();
     bf3:	e8 fa 33 00 00       	call   3ff2 <fork>
     bf8:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if(pid3 == 0){
     bfb:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
     bff:	75 4e                	jne    c4f <preempt+0xa5>
    close(pfds[0]);
     c01:	8b 45 e4             	mov    -0x1c(%ebp),%eax
     c04:	83 ec 0c             	sub    $0xc,%esp
     c07:	50                   	push   %eax
     c08:	e8 15 34 00 00       	call   4022 <close>
     c0d:	83 c4 10             	add    $0x10,%esp
    if(write(pfds[1], "x", 1) != 1)
     c10:	8b 45 e8             	mov    -0x18(%ebp),%eax
     c13:	83 ec 04             	sub    $0x4,%esp
     c16:	6a 01                	push   $0x1
     c18:	68 07 4a 00 00       	push   $0x4a07
     c1d:	50                   	push   %eax
     c1e:	e8 f7 33 00 00       	call   401a <write>
     c23:	83 c4 10             	add    $0x10,%esp
     c26:	83 f8 01             	cmp    $0x1,%eax
     c29:	74 12                	je     c3d <preempt+0x93>
      printf(1, "preempt write error");
     c2b:	83 ec 08             	sub    $0x8,%esp
     c2e:	68 09 4a 00 00       	push   $0x4a09
     c33:	6a 01                	push   $0x1
     c35:	e8 3c 35 00 00       	call   4176 <printf>
     c3a:	83 c4 10             	add    $0x10,%esp
    close(pfds[1]);
     c3d:	8b 45 e8             	mov    -0x18(%ebp),%eax
     c40:	83 ec 0c             	sub    $0xc,%esp
     c43:	50                   	push   %eax
     c44:	e8 d9 33 00 00       	call   4022 <close>
     c49:	83 c4 10             	add    $0x10,%esp
    for(;;)
     c4c:	90                   	nop
     c4d:	eb fd                	jmp    c4c <preempt+0xa2>
      ;
  }

  close(pfds[1]);
     c4f:	8b 45 e8             	mov    -0x18(%ebp),%eax
     c52:	83 ec 0c             	sub    $0xc,%esp
     c55:	50                   	push   %eax
     c56:	e8 c7 33 00 00       	call   4022 <close>
     c5b:	83 c4 10             	add    $0x10,%esp
  if(read(pfds[0], buf, sizeof(buf)) != 1){
     c5e:	8b 45 e4             	mov    -0x1c(%ebp),%eax
     c61:	83 ec 04             	sub    $0x4,%esp
     c64:	68 00 20 00 00       	push   $0x2000
     c69:	68 e0 64 00 00       	push   $0x64e0
     c6e:	50                   	push   %eax
     c6f:	e8 9e 33 00 00       	call   4012 <read>
     c74:	83 c4 10             	add    $0x10,%esp
     c77:	83 f8 01             	cmp    $0x1,%eax
     c7a:	74 14                	je     c90 <preempt+0xe6>
    printf(1, "preempt read error");
     c7c:	83 ec 08             	sub    $0x8,%esp
     c7f:	68 1d 4a 00 00       	push   $0x4a1d
     c84:	6a 01                	push   $0x1
     c86:	e8 eb 34 00 00       	call   4176 <printf>
     c8b:	83 c4 10             	add    $0x10,%esp
     c8e:	eb 7e                	jmp    d0e <preempt+0x164>
    return;
  }
  close(pfds[0]);
     c90:	8b 45 e4             	mov    -0x1c(%ebp),%eax
     c93:	83 ec 0c             	sub    $0xc,%esp
     c96:	50                   	push   %eax
     c97:	e8 86 33 00 00       	call   4022 <close>
     c9c:	83 c4 10             	add    $0x10,%esp
  printf(1, "kill... ");
     c9f:	83 ec 08             	sub    $0x8,%esp
     ca2:	68 30 4a 00 00       	push   $0x4a30
     ca7:	6a 01                	push   $0x1
     ca9:	e8 c8 34 00 00       	call   4176 <printf>
     cae:	83 c4 10             	add    $0x10,%esp
  kill(pid1);
     cb1:	83 ec 0c             	sub    $0xc,%esp
     cb4:	ff 75 f4             	push   -0xc(%ebp)
     cb7:	e8 6e 33 00 00       	call   402a <kill>
     cbc:	83 c4 10             	add    $0x10,%esp
  kill(pid2);
     cbf:	83 ec 0c             	sub    $0xc,%esp
     cc2:	ff 75 f0             	push   -0x10(%ebp)
     cc5:	e8 60 33 00 00       	call   402a <kill>
     cca:	83 c4 10             	add    $0x10,%esp
  kill(pid3);
     ccd:	83 ec 0c             	sub    $0xc,%esp
     cd0:	ff 75 ec             	push   -0x14(%ebp)
     cd3:	e8 52 33 00 00       	call   402a <kill>
     cd8:	83 c4 10             	add    $0x10,%esp
  printf(1, "wait... ");
     cdb:	83 ec 08             	sub    $0x8,%esp
     cde:	68 39 4a 00 00       	push   $0x4a39
     ce3:	6a 01                	push   $0x1
     ce5:	e8 8c 34 00 00       	call   4176 <printf>
     cea:	83 c4 10             	add    $0x10,%esp
  wait();
     ced:	e8 10 33 00 00       	call   4002 <wait>
  wait();
     cf2:	e8 0b 33 00 00       	call   4002 <wait>
  wait();
     cf7:	e8 06 33 00 00       	call   4002 <wait>
  printf(1, "preempt ok\n");
     cfc:	83 ec 08             	sub    $0x8,%esp
     cff:	68 42 4a 00 00       	push   $0x4a42
     d04:	6a 01                	push   $0x1
     d06:	e8 6b 34 00 00       	call   4176 <printf>
     d0b:	83 c4 10             	add    $0x10,%esp
}
     d0e:	c9                   	leave
     d0f:	c3                   	ret

00000d10 <exitwait>:

// try to find any races between exit and wait
void
exitwait(void)
{
     d10:	55                   	push   %ebp
     d11:	89 e5                	mov    %esp,%ebp
     d13:	83 ec 18             	sub    $0x18,%esp
  int i, pid;

  for(i = 0; i < 100; i++){
     d16:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
     d1d:	eb 4f                	jmp    d6e <exitwait+0x5e>
    pid = fork();
     d1f:	e8 ce 32 00 00       	call   3ff2 <fork>
     d24:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(pid < 0){
     d27:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
     d2b:	79 14                	jns    d41 <exitwait+0x31>
      printf(1, "fork failed\n");
     d2d:	83 ec 08             	sub    $0x8,%esp
     d30:	68 d1 45 00 00       	push   $0x45d1
     d35:	6a 01                	push   $0x1
     d37:	e8 3a 34 00 00       	call   4176 <printf>
     d3c:	83 c4 10             	add    $0x10,%esp
      return;
     d3f:	eb 45                	jmp    d86 <exitwait+0x76>
    }
    if(pid){
     d41:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
     d45:	74 1e                	je     d65 <exitwait+0x55>
      if(wait() != pid){
     d47:	e8 b6 32 00 00       	call   4002 <wait>
     d4c:	39 45 f0             	cmp    %eax,-0x10(%ebp)
     d4f:	74 19                	je     d6a <exitwait+0x5a>
        printf(1, "wait wrong pid\n");
     d51:	83 ec 08             	sub    $0x8,%esp
     d54:	68 4e 4a 00 00       	push   $0x4a4e
     d59:	6a 01                	push   $0x1
     d5b:	e8 16 34 00 00       	call   4176 <printf>
     d60:	83 c4 10             	add    $0x10,%esp
        return;
     d63:	eb 21                	jmp    d86 <exitwait+0x76>
      }
    } else {
      exit();
     d65:	e8 90 32 00 00       	call   3ffa <exit>
  for(i = 0; i < 100; i++){
     d6a:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
     d6e:	83 7d f4 63          	cmpl   $0x63,-0xc(%ebp)
     d72:	7e ab                	jle    d1f <exitwait+0xf>
    }
  }
  printf(1, "exitwait ok\n");
     d74:	83 ec 08             	sub    $0x8,%esp
     d77:	68 5e 4a 00 00       	push   $0x4a5e
     d7c:	6a 01                	push   $0x1
     d7e:	e8 f3 33 00 00       	call   4176 <printf>
     d83:	83 c4 10             	add    $0x10,%esp
}
     d86:	c9                   	leave
     d87:	c3                   	ret

00000d88 <mem>:

void
mem(void)
{
     d88:	55                   	push   %ebp
     d89:	89 e5                	mov    %esp,%ebp
     d8b:	83 ec 18             	sub    $0x18,%esp
  void *m1, *m2;
  int pid, ppid;

  printf(1, "mem test\n");
     d8e:	83 ec 08             	sub    $0x8,%esp
     d91:	68 6b 4a 00 00       	push   $0x4a6b
     d96:	6a 01                	push   $0x1
     d98:	e8 d9 33 00 00       	call   4176 <printf>
     d9d:	83 c4 10             	add    $0x10,%esp
  ppid = getpid();
     da0:	e8 d5 32 00 00       	call   407a <getpid>
     da5:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if((pid = fork()) == 0){
     da8:	e8 45 32 00 00       	call   3ff2 <fork>
     dad:	89 45 ec             	mov    %eax,-0x14(%ebp)
     db0:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
     db4:	0f 85 b7 00 00 00    	jne    e71 <mem+0xe9>
    m1 = 0;
     dba:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    while((m2 = malloc(10001)) != 0){
     dc1:	eb 0e                	jmp    dd1 <mem+0x49>
      *(char**)m2 = m1;
     dc3:	8b 45 e8             	mov    -0x18(%ebp),%eax
     dc6:	8b 55 f4             	mov    -0xc(%ebp),%edx
     dc9:	89 10                	mov    %edx,(%eax)
      m1 = m2;
     dcb:	8b 45 e8             	mov    -0x18(%ebp),%eax
     dce:	89 45 f4             	mov    %eax,-0xc(%ebp)
    while((m2 = malloc(10001)) != 0){
     dd1:	83 ec 0c             	sub    $0xc,%esp
     dd4:	68 11 27 00 00       	push   $0x2711
     dd9:	e8 6c 36 00 00       	call   444a <malloc>
     dde:	83 c4 10             	add    $0x10,%esp
     de1:	89 45 e8             	mov    %eax,-0x18(%ebp)
     de4:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
     de8:	75 d9                	jne    dc3 <mem+0x3b>
    }
    while(m1){
     dea:	eb 1c                	jmp    e08 <mem+0x80>
      m2 = *(char**)m1;
     dec:	8b 45 f4             	mov    -0xc(%ebp),%eax
     def:	8b 00                	mov    (%eax),%eax
     df1:	89 45 e8             	mov    %eax,-0x18(%ebp)
      free(m1);
     df4:	83 ec 0c             	sub    $0xc,%esp
     df7:	ff 75 f4             	push   -0xc(%ebp)
     dfa:	e8 09 35 00 00       	call   4308 <free>
     dff:	83 c4 10             	add    $0x10,%esp
      m1 = m2;
     e02:	8b 45 e8             	mov    -0x18(%ebp),%eax
     e05:	89 45 f4             	mov    %eax,-0xc(%ebp)
    while(m1){
     e08:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     e0c:	75 de                	jne    dec <mem+0x64>
    }
    m1 = malloc(1024*20);
     e0e:	83 ec 0c             	sub    $0xc,%esp
     e11:	68 00 50 00 00       	push   $0x5000
     e16:	e8 2f 36 00 00       	call   444a <malloc>
     e1b:	83 c4 10             	add    $0x10,%esp
     e1e:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(m1 == 0){
     e21:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
     e25:	75 25                	jne    e4c <mem+0xc4>
      printf(1, "couldn't allocate mem?!!\n");
     e27:	83 ec 08             	sub    $0x8,%esp
     e2a:	68 75 4a 00 00       	push   $0x4a75
     e2f:	6a 01                	push   $0x1
     e31:	e8 40 33 00 00       	call   4176 <printf>
     e36:	83 c4 10             	add    $0x10,%esp
      kill(ppid);
     e39:	83 ec 0c             	sub    $0xc,%esp
     e3c:	ff 75 f0             	push   -0x10(%ebp)
     e3f:	e8 e6 31 00 00       	call   402a <kill>
     e44:	83 c4 10             	add    $0x10,%esp
      exit();
     e47:	e8 ae 31 00 00       	call   3ffa <exit>
    }
    free(m1);
     e4c:	83 ec 0c             	sub    $0xc,%esp
     e4f:	ff 75 f4             	push   -0xc(%ebp)
     e52:	e8 b1 34 00 00       	call   4308 <free>
     e57:	83 c4 10             	add    $0x10,%esp
    printf(1, "mem ok\n");
     e5a:	83 ec 08             	sub    $0x8,%esp
     e5d:	68 8f 4a 00 00       	push   $0x4a8f
     e62:	6a 01                	push   $0x1
     e64:	e8 0d 33 00 00       	call   4176 <printf>
     e69:	83 c4 10             	add    $0x10,%esp
    exit();
     e6c:	e8 89 31 00 00       	call   3ffa <exit>
  } else {
    wait();
     e71:	e8 8c 31 00 00       	call   4002 <wait>
  }
}
     e76:	90                   	nop
     e77:	c9                   	leave
     e78:	c3                   	ret

00000e79 <sharedfd>:

// two processes write to the same file descriptor
// is the offset shared? does inode locking work?
void
sharedfd(void)
{
     e79:	55                   	push   %ebp
     e7a:	89 e5                	mov    %esp,%ebp
     e7c:	83 ec 38             	sub    $0x38,%esp
  int fd, pid, i, n, nc, np;
  char buf[10];

  printf(1, "sharedfd test\n");
     e7f:	83 ec 08             	sub    $0x8,%esp
     e82:	68 97 4a 00 00       	push   $0x4a97
     e87:	6a 01                	push   $0x1
     e89:	e8 e8 32 00 00       	call   4176 <printf>
     e8e:	83 c4 10             	add    $0x10,%esp

  unlink("sharedfd");
     e91:	83 ec 0c             	sub    $0xc,%esp
     e94:	68 a6 4a 00 00       	push   $0x4aa6
     e99:	e8 ac 31 00 00       	call   404a <unlink>
     e9e:	83 c4 10             	add    $0x10,%esp
  fd = open("sharedfd", O_CREATE|O_RDWR);
     ea1:	83 ec 08             	sub    $0x8,%esp
     ea4:	68 02 02 00 00       	push   $0x202
     ea9:	68 a6 4a 00 00       	push   $0x4aa6
     eae:	e8 87 31 00 00       	call   403a <open>
     eb3:	83 c4 10             	add    $0x10,%esp
     eb6:	89 45 e8             	mov    %eax,-0x18(%ebp)
  if(fd < 0){
     eb9:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
     ebd:	79 17                	jns    ed6 <sharedfd+0x5d>
    printf(1, "fstests: cannot open sharedfd for writing");
     ebf:	83 ec 08             	sub    $0x8,%esp
     ec2:	68 b0 4a 00 00       	push   $0x4ab0
     ec7:	6a 01                	push   $0x1
     ec9:	e8 a8 32 00 00       	call   4176 <printf>
     ece:	83 c4 10             	add    $0x10,%esp
    return;
     ed1:	e9 84 01 00 00       	jmp    105a <sharedfd+0x1e1>
  }
  pid = fork();
     ed6:	e8 17 31 00 00       	call   3ff2 <fork>
     edb:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  memset(buf, pid==0?'c':'p', sizeof(buf));
     ede:	83 7d e4 00          	cmpl   $0x0,-0x1c(%ebp)
     ee2:	75 07                	jne    eeb <sharedfd+0x72>
     ee4:	b8 63 00 00 00       	mov    $0x63,%eax
     ee9:	eb 05                	jmp    ef0 <sharedfd+0x77>
     eeb:	b8 70 00 00 00       	mov    $0x70,%eax
     ef0:	83 ec 04             	sub    $0x4,%esp
     ef3:	6a 0a                	push   $0xa
     ef5:	50                   	push   %eax
     ef6:	8d 45 d6             	lea    -0x2a(%ebp),%eax
     ef9:	50                   	push   %eax
     efa:	e8 60 2f 00 00       	call   3e5f <memset>
     eff:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < 1000; i++){
     f02:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
     f09:	eb 31                	jmp    f3c <sharedfd+0xc3>
    if(write(fd, buf, sizeof(buf)) != sizeof(buf)){
     f0b:	83 ec 04             	sub    $0x4,%esp
     f0e:	6a 0a                	push   $0xa
     f10:	8d 45 d6             	lea    -0x2a(%ebp),%eax
     f13:	50                   	push   %eax
     f14:	ff 75 e8             	push   -0x18(%ebp)
     f17:	e8 fe 30 00 00       	call   401a <write>
     f1c:	83 c4 10             	add    $0x10,%esp
     f1f:	83 f8 0a             	cmp    $0xa,%eax
     f22:	74 14                	je     f38 <sharedfd+0xbf>
      printf(1, "fstests: write sharedfd failed\n");
     f24:	83 ec 08             	sub    $0x8,%esp
     f27:	68 dc 4a 00 00       	push   $0x4adc
     f2c:	6a 01                	push   $0x1
     f2e:	e8 43 32 00 00       	call   4176 <printf>
     f33:	83 c4 10             	add    $0x10,%esp
      break;
     f36:	eb 0d                	jmp    f45 <sharedfd+0xcc>
  for(i = 0; i < 1000; i++){
     f38:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
     f3c:	81 7d f4 e7 03 00 00 	cmpl   $0x3e7,-0xc(%ebp)
     f43:	7e c6                	jle    f0b <sharedfd+0x92>
    }
  }
  if(pid == 0)
     f45:	83 7d e4 00          	cmpl   $0x0,-0x1c(%ebp)
     f49:	75 05                	jne    f50 <sharedfd+0xd7>
    exit();
     f4b:	e8 aa 30 00 00       	call   3ffa <exit>
  else
    wait();
     f50:	e8 ad 30 00 00       	call   4002 <wait>
  close(fd);
     f55:	83 ec 0c             	sub    $0xc,%esp
     f58:	ff 75 e8             	push   -0x18(%ebp)
     f5b:	e8 c2 30 00 00       	call   4022 <close>
     f60:	83 c4 10             	add    $0x10,%esp
  fd = open("sharedfd", 0);
     f63:	83 ec 08             	sub    $0x8,%esp
     f66:	6a 00                	push   $0x0
     f68:	68 a6 4a 00 00       	push   $0x4aa6
     f6d:	e8 c8 30 00 00       	call   403a <open>
     f72:	83 c4 10             	add    $0x10,%esp
     f75:	89 45 e8             	mov    %eax,-0x18(%ebp)
  if(fd < 0){
     f78:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
     f7c:	79 17                	jns    f95 <sharedfd+0x11c>
    printf(1, "fstests: cannot open sharedfd for reading\n");
     f7e:	83 ec 08             	sub    $0x8,%esp
     f81:	68 fc 4a 00 00       	push   $0x4afc
     f86:	6a 01                	push   $0x1
     f88:	e8 e9 31 00 00       	call   4176 <printf>
     f8d:	83 c4 10             	add    $0x10,%esp
    return;
     f90:	e9 c5 00 00 00       	jmp    105a <sharedfd+0x1e1>
  }
  nc = np = 0;
     f95:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
     f9c:	8b 45 ec             	mov    -0x14(%ebp),%eax
     f9f:	89 45 f0             	mov    %eax,-0x10(%ebp)
  while((n = read(fd, buf, sizeof(buf))) > 0){
     fa2:	eb 3b                	jmp    fdf <sharedfd+0x166>
    for(i = 0; i < sizeof(buf); i++){
     fa4:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
     fab:	eb 2a                	jmp    fd7 <sharedfd+0x15e>
      if(buf[i] == 'c')
     fad:	8d 55 d6             	lea    -0x2a(%ebp),%edx
     fb0:	8b 45 f4             	mov    -0xc(%ebp),%eax
     fb3:	01 d0                	add    %edx,%eax
     fb5:	0f b6 00             	movzbl (%eax),%eax
     fb8:	3c 63                	cmp    $0x63,%al
     fba:	75 04                	jne    fc0 <sharedfd+0x147>
        nc++;
     fbc:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
      if(buf[i] == 'p')
     fc0:	8d 55 d6             	lea    -0x2a(%ebp),%edx
     fc3:	8b 45 f4             	mov    -0xc(%ebp),%eax
     fc6:	01 d0                	add    %edx,%eax
     fc8:	0f b6 00             	movzbl (%eax),%eax
     fcb:	3c 70                	cmp    $0x70,%al
     fcd:	75 04                	jne    fd3 <sharedfd+0x15a>
        np++;
     fcf:	83 45 ec 01          	addl   $0x1,-0x14(%ebp)
    for(i = 0; i < sizeof(buf); i++){
     fd3:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
     fd7:	8b 45 f4             	mov    -0xc(%ebp),%eax
     fda:	83 f8 09             	cmp    $0x9,%eax
     fdd:	76 ce                	jbe    fad <sharedfd+0x134>
  while((n = read(fd, buf, sizeof(buf))) > 0){
     fdf:	83 ec 04             	sub    $0x4,%esp
     fe2:	6a 0a                	push   $0xa
     fe4:	8d 45 d6             	lea    -0x2a(%ebp),%eax
     fe7:	50                   	push   %eax
     fe8:	ff 75 e8             	push   -0x18(%ebp)
     feb:	e8 22 30 00 00       	call   4012 <read>
     ff0:	83 c4 10             	add    $0x10,%esp
     ff3:	89 45 e0             	mov    %eax,-0x20(%ebp)
     ff6:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
     ffa:	7f a8                	jg     fa4 <sharedfd+0x12b>
    }
  }
  close(fd);
     ffc:	83 ec 0c             	sub    $0xc,%esp
     fff:	ff 75 e8             	push   -0x18(%ebp)
    1002:	e8 1b 30 00 00       	call   4022 <close>
    1007:	83 c4 10             	add    $0x10,%esp
  unlink("sharedfd");
    100a:	83 ec 0c             	sub    $0xc,%esp
    100d:	68 a6 4a 00 00       	push   $0x4aa6
    1012:	e8 33 30 00 00       	call   404a <unlink>
    1017:	83 c4 10             	add    $0x10,%esp
  if(nc == 10000 && np == 10000){
    101a:	81 7d f0 10 27 00 00 	cmpl   $0x2710,-0x10(%ebp)
    1021:	75 1d                	jne    1040 <sharedfd+0x1c7>
    1023:	81 7d ec 10 27 00 00 	cmpl   $0x2710,-0x14(%ebp)
    102a:	75 14                	jne    1040 <sharedfd+0x1c7>
    printf(1, "sharedfd ok\n");
    102c:	83 ec 08             	sub    $0x8,%esp
    102f:	68 27 4b 00 00       	push   $0x4b27
    1034:	6a 01                	push   $0x1
    1036:	e8 3b 31 00 00       	call   4176 <printf>
    103b:	83 c4 10             	add    $0x10,%esp
    103e:	eb 1a                	jmp    105a <sharedfd+0x1e1>
  } else {
    printf(1, "sharedfd oops %d %d\n", nc, np);
    1040:	ff 75 ec             	push   -0x14(%ebp)
    1043:	ff 75 f0             	push   -0x10(%ebp)
    1046:	68 34 4b 00 00       	push   $0x4b34
    104b:	6a 01                	push   $0x1
    104d:	e8 24 31 00 00       	call   4176 <printf>
    1052:	83 c4 10             	add    $0x10,%esp
    exit();
    1055:	e8 a0 2f 00 00       	call   3ffa <exit>
  }
}
    105a:	c9                   	leave
    105b:	c3                   	ret

0000105c <fourfiles>:

// four processes write different files at the same
// time, to test block allocation.
void
fourfiles(void)
{
    105c:	55                   	push   %ebp
    105d:	89 e5                	mov    %esp,%ebp
    105f:	83 ec 38             	sub    $0x38,%esp
  int fd, pid, i, j, n, total, pi;
  char *names[] = { "f0", "f1", "f2", "f3" };
    1062:	c7 45 c8 49 4b 00 00 	movl   $0x4b49,-0x38(%ebp)
    1069:	c7 45 cc 4c 4b 00 00 	movl   $0x4b4c,-0x34(%ebp)
    1070:	c7 45 d0 4f 4b 00 00 	movl   $0x4b4f,-0x30(%ebp)
    1077:	c7 45 d4 52 4b 00 00 	movl   $0x4b52,-0x2c(%ebp)
  char *fname;

  printf(1, "fourfiles test\n");
    107e:	83 ec 08             	sub    $0x8,%esp
    1081:	68 55 4b 00 00       	push   $0x4b55
    1086:	6a 01                	push   $0x1
    1088:	e8 e9 30 00 00       	call   4176 <printf>
    108d:	83 c4 10             	add    $0x10,%esp

  for(pi = 0; pi < 4; pi++){
    1090:	c7 45 e8 00 00 00 00 	movl   $0x0,-0x18(%ebp)
    1097:	e9 f0 00 00 00       	jmp    118c <fourfiles+0x130>
    fname = names[pi];
    109c:	8b 45 e8             	mov    -0x18(%ebp),%eax
    109f:	8b 44 85 c8          	mov    -0x38(%ebp,%eax,4),%eax
    10a3:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    unlink(fname);
    10a6:	83 ec 0c             	sub    $0xc,%esp
    10a9:	ff 75 e4             	push   -0x1c(%ebp)
    10ac:	e8 99 2f 00 00       	call   404a <unlink>
    10b1:	83 c4 10             	add    $0x10,%esp

    pid = fork();
    10b4:	e8 39 2f 00 00       	call   3ff2 <fork>
    10b9:	89 45 d8             	mov    %eax,-0x28(%ebp)
    if(pid < 0){
    10bc:	83 7d d8 00          	cmpl   $0x0,-0x28(%ebp)
    10c0:	79 17                	jns    10d9 <fourfiles+0x7d>
      printf(1, "fork failed\n");
    10c2:	83 ec 08             	sub    $0x8,%esp
    10c5:	68 d1 45 00 00       	push   $0x45d1
    10ca:	6a 01                	push   $0x1
    10cc:	e8 a5 30 00 00       	call   4176 <printf>
    10d1:	83 c4 10             	add    $0x10,%esp
      exit();
    10d4:	e8 21 2f 00 00       	call   3ffa <exit>
    }

    if(pid == 0){
    10d9:	83 7d d8 00          	cmpl   $0x0,-0x28(%ebp)
    10dd:	0f 85 a5 00 00 00    	jne    1188 <fourfiles+0x12c>
      fd = open(fname, O_CREATE | O_RDWR);
    10e3:	83 ec 08             	sub    $0x8,%esp
    10e6:	68 02 02 00 00       	push   $0x202
    10eb:	ff 75 e4             	push   -0x1c(%ebp)
    10ee:	e8 47 2f 00 00       	call   403a <open>
    10f3:	83 c4 10             	add    $0x10,%esp
    10f6:	89 45 e0             	mov    %eax,-0x20(%ebp)
      if(fd < 0){
    10f9:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
    10fd:	79 17                	jns    1116 <fourfiles+0xba>
        printf(1, "create failed\n");
    10ff:	83 ec 08             	sub    $0x8,%esp
    1102:	68 65 4b 00 00       	push   $0x4b65
    1107:	6a 01                	push   $0x1
    1109:	e8 68 30 00 00       	call   4176 <printf>
    110e:	83 c4 10             	add    $0x10,%esp
        exit();
    1111:	e8 e4 2e 00 00       	call   3ffa <exit>
      }

      memset(buf, '0'+pi, 512);
    1116:	8b 45 e8             	mov    -0x18(%ebp),%eax
    1119:	83 c0 30             	add    $0x30,%eax
    111c:	83 ec 04             	sub    $0x4,%esp
    111f:	68 00 02 00 00       	push   $0x200
    1124:	50                   	push   %eax
    1125:	68 e0 64 00 00       	push   $0x64e0
    112a:	e8 30 2d 00 00       	call   3e5f <memset>
    112f:	83 c4 10             	add    $0x10,%esp
      for(i = 0; i < 12; i++){
    1132:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    1139:	eb 42                	jmp    117d <fourfiles+0x121>
        if((n = write(fd, buf, 500)) != 500){
    113b:	83 ec 04             	sub    $0x4,%esp
    113e:	68 f4 01 00 00       	push   $0x1f4
    1143:	68 e0 64 00 00       	push   $0x64e0
    1148:	ff 75 e0             	push   -0x20(%ebp)
    114b:	e8 ca 2e 00 00       	call   401a <write>
    1150:	83 c4 10             	add    $0x10,%esp
    1153:	89 45 dc             	mov    %eax,-0x24(%ebp)
    1156:	81 7d dc f4 01 00 00 	cmpl   $0x1f4,-0x24(%ebp)
    115d:	74 1a                	je     1179 <fourfiles+0x11d>
          printf(1, "write failed %d\n", n);
    115f:	83 ec 04             	sub    $0x4,%esp
    1162:	ff 75 dc             	push   -0x24(%ebp)
    1165:	68 74 4b 00 00       	push   $0x4b74
    116a:	6a 01                	push   $0x1
    116c:	e8 05 30 00 00       	call   4176 <printf>
    1171:	83 c4 10             	add    $0x10,%esp
          exit();
    1174:	e8 81 2e 00 00       	call   3ffa <exit>
      for(i = 0; i < 12; i++){
    1179:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    117d:	83 7d f4 0b          	cmpl   $0xb,-0xc(%ebp)
    1181:	7e b8                	jle    113b <fourfiles+0xdf>
        }
      }
      exit();
    1183:	e8 72 2e 00 00       	call   3ffa <exit>
  for(pi = 0; pi < 4; pi++){
    1188:	83 45 e8 01          	addl   $0x1,-0x18(%ebp)
    118c:	83 7d e8 03          	cmpl   $0x3,-0x18(%ebp)
    1190:	0f 8e 06 ff ff ff    	jle    109c <fourfiles+0x40>
    }
  }

  for(pi = 0; pi < 4; pi++){
    1196:	c7 45 e8 00 00 00 00 	movl   $0x0,-0x18(%ebp)
    119d:	eb 09                	jmp    11a8 <fourfiles+0x14c>
    wait();
    119f:	e8 5e 2e 00 00       	call   4002 <wait>
  for(pi = 0; pi < 4; pi++){
    11a4:	83 45 e8 01          	addl   $0x1,-0x18(%ebp)
    11a8:	83 7d e8 03          	cmpl   $0x3,-0x18(%ebp)
    11ac:	7e f1                	jle    119f <fourfiles+0x143>
  }

  for(i = 0; i < 2; i++){
    11ae:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    11b5:	e9 d4 00 00 00       	jmp    128e <fourfiles+0x232>
    fname = names[i];
    11ba:	8b 45 f4             	mov    -0xc(%ebp),%eax
    11bd:	8b 44 85 c8          	mov    -0x38(%ebp,%eax,4),%eax
    11c1:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    fd = open(fname, 0);
    11c4:	83 ec 08             	sub    $0x8,%esp
    11c7:	6a 00                	push   $0x0
    11c9:	ff 75 e4             	push   -0x1c(%ebp)
    11cc:	e8 69 2e 00 00       	call   403a <open>
    11d1:	83 c4 10             	add    $0x10,%esp
    11d4:	89 45 e0             	mov    %eax,-0x20(%ebp)
    total = 0;
    11d7:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
    while((n = read(fd, buf, sizeof(buf))) > 0){
    11de:	eb 4a                	jmp    122a <fourfiles+0x1ce>
      for(j = 0; j < n; j++){
    11e0:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    11e7:	eb 33                	jmp    121c <fourfiles+0x1c0>
        if(buf[j] != '0'+i){
    11e9:	8b 45 f0             	mov    -0x10(%ebp),%eax
    11ec:	05 e0 64 00 00       	add    $0x64e0,%eax
    11f1:	0f b6 00             	movzbl (%eax),%eax
    11f4:	0f be d0             	movsbl %al,%edx
    11f7:	8b 45 f4             	mov    -0xc(%ebp),%eax
    11fa:	83 c0 30             	add    $0x30,%eax
    11fd:	39 c2                	cmp    %eax,%edx
    11ff:	74 17                	je     1218 <fourfiles+0x1bc>
          printf(1, "wrong char\n");
    1201:	83 ec 08             	sub    $0x8,%esp
    1204:	68 85 4b 00 00       	push   $0x4b85
    1209:	6a 01                	push   $0x1
    120b:	e8 66 2f 00 00       	call   4176 <printf>
    1210:	83 c4 10             	add    $0x10,%esp
          exit();
    1213:	e8 e2 2d 00 00       	call   3ffa <exit>
      for(j = 0; j < n; j++){
    1218:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    121c:	8b 45 f0             	mov    -0x10(%ebp),%eax
    121f:	3b 45 dc             	cmp    -0x24(%ebp),%eax
    1222:	7c c5                	jl     11e9 <fourfiles+0x18d>
        }
      }
      total += n;
    1224:	8b 45 dc             	mov    -0x24(%ebp),%eax
    1227:	01 45 ec             	add    %eax,-0x14(%ebp)
    while((n = read(fd, buf, sizeof(buf))) > 0){
    122a:	83 ec 04             	sub    $0x4,%esp
    122d:	68 00 20 00 00       	push   $0x2000
    1232:	68 e0 64 00 00       	push   $0x64e0
    1237:	ff 75 e0             	push   -0x20(%ebp)
    123a:	e8 d3 2d 00 00       	call   4012 <read>
    123f:	83 c4 10             	add    $0x10,%esp
    1242:	89 45 dc             	mov    %eax,-0x24(%ebp)
    1245:	83 7d dc 00          	cmpl   $0x0,-0x24(%ebp)
    1249:	7f 95                	jg     11e0 <fourfiles+0x184>
    }
    close(fd);
    124b:	83 ec 0c             	sub    $0xc,%esp
    124e:	ff 75 e0             	push   -0x20(%ebp)
    1251:	e8 cc 2d 00 00       	call   4022 <close>
    1256:	83 c4 10             	add    $0x10,%esp
    if(total != 12*500){
    1259:	81 7d ec 70 17 00 00 	cmpl   $0x1770,-0x14(%ebp)
    1260:	74 1a                	je     127c <fourfiles+0x220>
      printf(1, "wrong length %d\n", total);
    1262:	83 ec 04             	sub    $0x4,%esp
    1265:	ff 75 ec             	push   -0x14(%ebp)
    1268:	68 91 4b 00 00       	push   $0x4b91
    126d:	6a 01                	push   $0x1
    126f:	e8 02 2f 00 00       	call   4176 <printf>
    1274:	83 c4 10             	add    $0x10,%esp
      exit();
    1277:	e8 7e 2d 00 00       	call   3ffa <exit>
    }
    unlink(fname);
    127c:	83 ec 0c             	sub    $0xc,%esp
    127f:	ff 75 e4             	push   -0x1c(%ebp)
    1282:	e8 c3 2d 00 00       	call   404a <unlink>
    1287:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < 2; i++){
    128a:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    128e:	83 7d f4 01          	cmpl   $0x1,-0xc(%ebp)
    1292:	0f 8e 22 ff ff ff    	jle    11ba <fourfiles+0x15e>
  }

  printf(1, "fourfiles ok\n");
    1298:	83 ec 08             	sub    $0x8,%esp
    129b:	68 a2 4b 00 00       	push   $0x4ba2
    12a0:	6a 01                	push   $0x1
    12a2:	e8 cf 2e 00 00       	call   4176 <printf>
    12a7:	83 c4 10             	add    $0x10,%esp
}
    12aa:	90                   	nop
    12ab:	c9                   	leave
    12ac:	c3                   	ret

000012ad <createdelete>:

// four processes create and delete different files in same directory
void
createdelete(void)
{
    12ad:	55                   	push   %ebp
    12ae:	89 e5                	mov    %esp,%ebp
    12b0:	83 ec 38             	sub    $0x38,%esp
  enum { N = 20 };
  int pid, i, fd, pi;
  char name[32];

  printf(1, "createdelete test\n");
    12b3:	83 ec 08             	sub    $0x8,%esp
    12b6:	68 b0 4b 00 00       	push   $0x4bb0
    12bb:	6a 01                	push   $0x1
    12bd:	e8 b4 2e 00 00       	call   4176 <printf>
    12c2:	83 c4 10             	add    $0x10,%esp

  for(pi = 0; pi < 4; pi++){
    12c5:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    12cc:	e9 f6 00 00 00       	jmp    13c7 <createdelete+0x11a>
    pid = fork();
    12d1:	e8 1c 2d 00 00       	call   3ff2 <fork>
    12d6:	89 45 e8             	mov    %eax,-0x18(%ebp)
    if(pid < 0){
    12d9:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    12dd:	79 17                	jns    12f6 <createdelete+0x49>
      printf(1, "fork failed\n");
    12df:	83 ec 08             	sub    $0x8,%esp
    12e2:	68 d1 45 00 00       	push   $0x45d1
    12e7:	6a 01                	push   $0x1
    12e9:	e8 88 2e 00 00       	call   4176 <printf>
    12ee:	83 c4 10             	add    $0x10,%esp
      exit();
    12f1:	e8 04 2d 00 00       	call   3ffa <exit>
    }

    if(pid == 0){
    12f6:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    12fa:	0f 85 c3 00 00 00    	jne    13c3 <createdelete+0x116>
      name[0] = 'p' + pi;
    1300:	8b 45 f0             	mov    -0x10(%ebp),%eax
    1303:	83 c0 70             	add    $0x70,%eax
    1306:	88 45 c8             	mov    %al,-0x38(%ebp)
      name[2] = '\0';
    1309:	c6 45 ca 00          	movb   $0x0,-0x36(%ebp)
      for(i = 0; i < N; i++){
    130d:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    1314:	e9 9b 00 00 00       	jmp    13b4 <createdelete+0x107>
        name[1] = '0' + i;
    1319:	8b 45 f4             	mov    -0xc(%ebp),%eax
    131c:	83 c0 30             	add    $0x30,%eax
    131f:	88 45 c9             	mov    %al,-0x37(%ebp)
        fd = open(name, O_CREATE | O_RDWR);
    1322:	83 ec 08             	sub    $0x8,%esp
    1325:	68 02 02 00 00       	push   $0x202
    132a:	8d 45 c8             	lea    -0x38(%ebp),%eax
    132d:	50                   	push   %eax
    132e:	e8 07 2d 00 00       	call   403a <open>
    1333:	83 c4 10             	add    $0x10,%esp
    1336:	89 45 ec             	mov    %eax,-0x14(%ebp)
        if(fd < 0){
    1339:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    133d:	79 17                	jns    1356 <createdelete+0xa9>
          printf(1, "create failed\n");
    133f:	83 ec 08             	sub    $0x8,%esp
    1342:	68 65 4b 00 00       	push   $0x4b65
    1347:	6a 01                	push   $0x1
    1349:	e8 28 2e 00 00       	call   4176 <printf>
    134e:	83 c4 10             	add    $0x10,%esp
          exit();
    1351:	e8 a4 2c 00 00       	call   3ffa <exit>
        }
        close(fd);
    1356:	83 ec 0c             	sub    $0xc,%esp
    1359:	ff 75 ec             	push   -0x14(%ebp)
    135c:	e8 c1 2c 00 00       	call   4022 <close>
    1361:	83 c4 10             	add    $0x10,%esp
        if(i > 0 && (i % 2 ) == 0){
    1364:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    1368:	7e 46                	jle    13b0 <createdelete+0x103>
    136a:	8b 45 f4             	mov    -0xc(%ebp),%eax
    136d:	83 e0 01             	and    $0x1,%eax
    1370:	85 c0                	test   %eax,%eax
    1372:	75 3c                	jne    13b0 <createdelete+0x103>
          name[1] = '0' + (i / 2);
    1374:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1377:	89 c2                	mov    %eax,%edx
    1379:	c1 ea 1f             	shr    $0x1f,%edx
    137c:	01 d0                	add    %edx,%eax
    137e:	d1 f8                	sar    $1,%eax
    1380:	83 c0 30             	add    $0x30,%eax
    1383:	88 45 c9             	mov    %al,-0x37(%ebp)
          if(unlink(name) < 0){
    1386:	83 ec 0c             	sub    $0xc,%esp
    1389:	8d 45 c8             	lea    -0x38(%ebp),%eax
    138c:	50                   	push   %eax
    138d:	e8 b8 2c 00 00       	call   404a <unlink>
    1392:	83 c4 10             	add    $0x10,%esp
    1395:	85 c0                	test   %eax,%eax
    1397:	79 17                	jns    13b0 <createdelete+0x103>
            printf(1, "unlink failed\n");
    1399:	83 ec 08             	sub    $0x8,%esp
    139c:	68 54 46 00 00       	push   $0x4654
    13a1:	6a 01                	push   $0x1
    13a3:	e8 ce 2d 00 00       	call   4176 <printf>
    13a8:	83 c4 10             	add    $0x10,%esp
            exit();
    13ab:	e8 4a 2c 00 00       	call   3ffa <exit>
      for(i = 0; i < N; i++){
    13b0:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    13b4:	83 7d f4 13          	cmpl   $0x13,-0xc(%ebp)
    13b8:	0f 8e 5b ff ff ff    	jle    1319 <createdelete+0x6c>
          }
        }
      }
      exit();
    13be:	e8 37 2c 00 00       	call   3ffa <exit>
  for(pi = 0; pi < 4; pi++){
    13c3:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    13c7:	83 7d f0 03          	cmpl   $0x3,-0x10(%ebp)
    13cb:	0f 8e 00 ff ff ff    	jle    12d1 <createdelete+0x24>
    }
  }

  for(pi = 0; pi < 4; pi++){
    13d1:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    13d8:	eb 09                	jmp    13e3 <createdelete+0x136>
    wait();
    13da:	e8 23 2c 00 00       	call   4002 <wait>
  for(pi = 0; pi < 4; pi++){
    13df:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    13e3:	83 7d f0 03          	cmpl   $0x3,-0x10(%ebp)
    13e7:	7e f1                	jle    13da <createdelete+0x12d>
  }

  name[0] = name[1] = name[2] = 0;
    13e9:	c6 45 ca 00          	movb   $0x0,-0x36(%ebp)
    13ed:	0f b6 45 ca          	movzbl -0x36(%ebp),%eax
    13f1:	88 45 c9             	mov    %al,-0x37(%ebp)
    13f4:	0f b6 45 c9          	movzbl -0x37(%ebp),%eax
    13f8:	88 45 c8             	mov    %al,-0x38(%ebp)
  for(i = 0; i < N; i++){
    13fb:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    1402:	e9 b2 00 00 00       	jmp    14b9 <createdelete+0x20c>
    for(pi = 0; pi < 4; pi++){
    1407:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    140e:	e9 98 00 00 00       	jmp    14ab <createdelete+0x1fe>
      name[0] = 'p' + pi;
    1413:	8b 45 f0             	mov    -0x10(%ebp),%eax
    1416:	83 c0 70             	add    $0x70,%eax
    1419:	88 45 c8             	mov    %al,-0x38(%ebp)
      name[1] = '0' + i;
    141c:	8b 45 f4             	mov    -0xc(%ebp),%eax
    141f:	83 c0 30             	add    $0x30,%eax
    1422:	88 45 c9             	mov    %al,-0x37(%ebp)
      fd = open(name, 0);
    1425:	83 ec 08             	sub    $0x8,%esp
    1428:	6a 00                	push   $0x0
    142a:	8d 45 c8             	lea    -0x38(%ebp),%eax
    142d:	50                   	push   %eax
    142e:	e8 07 2c 00 00       	call   403a <open>
    1433:	83 c4 10             	add    $0x10,%esp
    1436:	89 45 ec             	mov    %eax,-0x14(%ebp)
      if((i == 0 || i >= N/2) && fd < 0){
    1439:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    143d:	74 06                	je     1445 <createdelete+0x198>
    143f:	83 7d f4 09          	cmpl   $0x9,-0xc(%ebp)
    1443:	7e 21                	jle    1466 <createdelete+0x1b9>
    1445:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    1449:	79 1b                	jns    1466 <createdelete+0x1b9>
        printf(1, "oops createdelete %s didn't exist\n", name);
    144b:	83 ec 04             	sub    $0x4,%esp
    144e:	8d 45 c8             	lea    -0x38(%ebp),%eax
    1451:	50                   	push   %eax
    1452:	68 c4 4b 00 00       	push   $0x4bc4
    1457:	6a 01                	push   $0x1
    1459:	e8 18 2d 00 00       	call   4176 <printf>
    145e:	83 c4 10             	add    $0x10,%esp
        exit();
    1461:	e8 94 2b 00 00       	call   3ffa <exit>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    1466:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    146a:	7e 27                	jle    1493 <createdelete+0x1e6>
    146c:	83 7d f4 09          	cmpl   $0x9,-0xc(%ebp)
    1470:	7f 21                	jg     1493 <createdelete+0x1e6>
    1472:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    1476:	78 1b                	js     1493 <createdelete+0x1e6>
        printf(1, "oops createdelete %s did exist\n", name);
    1478:	83 ec 04             	sub    $0x4,%esp
    147b:	8d 45 c8             	lea    -0x38(%ebp),%eax
    147e:	50                   	push   %eax
    147f:	68 e8 4b 00 00       	push   $0x4be8
    1484:	6a 01                	push   $0x1
    1486:	e8 eb 2c 00 00       	call   4176 <printf>
    148b:	83 c4 10             	add    $0x10,%esp
        exit();
    148e:	e8 67 2b 00 00       	call   3ffa <exit>
      }
      if(fd >= 0)
    1493:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    1497:	78 0e                	js     14a7 <createdelete+0x1fa>
        close(fd);
    1499:	83 ec 0c             	sub    $0xc,%esp
    149c:	ff 75 ec             	push   -0x14(%ebp)
    149f:	e8 7e 2b 00 00       	call   4022 <close>
    14a4:	83 c4 10             	add    $0x10,%esp
    for(pi = 0; pi < 4; pi++){
    14a7:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    14ab:	83 7d f0 03          	cmpl   $0x3,-0x10(%ebp)
    14af:	0f 8e 5e ff ff ff    	jle    1413 <createdelete+0x166>
  for(i = 0; i < N; i++){
    14b5:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    14b9:	83 7d f4 13          	cmpl   $0x13,-0xc(%ebp)
    14bd:	0f 8e 44 ff ff ff    	jle    1407 <createdelete+0x15a>
    }
  }

  for(i = 0; i < N; i++){
    14c3:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    14ca:	eb 38                	jmp    1504 <createdelete+0x257>
    for(pi = 0; pi < 4; pi++){
    14cc:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    14d3:	eb 25                	jmp    14fa <createdelete+0x24d>
      name[0] = 'p' + i;
    14d5:	8b 45 f4             	mov    -0xc(%ebp),%eax
    14d8:	83 c0 70             	add    $0x70,%eax
    14db:	88 45 c8             	mov    %al,-0x38(%ebp)
      name[1] = '0' + i;
    14de:	8b 45 f4             	mov    -0xc(%ebp),%eax
    14e1:	83 c0 30             	add    $0x30,%eax
    14e4:	88 45 c9             	mov    %al,-0x37(%ebp)
      unlink(name);
    14e7:	83 ec 0c             	sub    $0xc,%esp
    14ea:	8d 45 c8             	lea    -0x38(%ebp),%eax
    14ed:	50                   	push   %eax
    14ee:	e8 57 2b 00 00       	call   404a <unlink>
    14f3:	83 c4 10             	add    $0x10,%esp
    for(pi = 0; pi < 4; pi++){
    14f6:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    14fa:	83 7d f0 03          	cmpl   $0x3,-0x10(%ebp)
    14fe:	7e d5                	jle    14d5 <createdelete+0x228>
  for(i = 0; i < N; i++){
    1500:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    1504:	83 7d f4 13          	cmpl   $0x13,-0xc(%ebp)
    1508:	7e c2                	jle    14cc <createdelete+0x21f>
    }
  }

  printf(1, "createdelete ok\n");
    150a:	83 ec 08             	sub    $0x8,%esp
    150d:	68 08 4c 00 00       	push   $0x4c08
    1512:	6a 01                	push   $0x1
    1514:	e8 5d 2c 00 00       	call   4176 <printf>
    1519:	83 c4 10             	add    $0x10,%esp
}
    151c:	90                   	nop
    151d:	c9                   	leave
    151e:	c3                   	ret

0000151f <unlinkread>:

// can I unlink a file and still read it?
void
unlinkread(void)
{
    151f:	55                   	push   %ebp
    1520:	89 e5                	mov    %esp,%ebp
    1522:	83 ec 18             	sub    $0x18,%esp
  int fd, fd1;

  printf(1, "unlinkread test\n");
    1525:	83 ec 08             	sub    $0x8,%esp
    1528:	68 19 4c 00 00       	push   $0x4c19
    152d:	6a 01                	push   $0x1
    152f:	e8 42 2c 00 00       	call   4176 <printf>
    1534:	83 c4 10             	add    $0x10,%esp
  fd = open("unlinkread", O_CREATE | O_RDWR);
    1537:	83 ec 08             	sub    $0x8,%esp
    153a:	68 02 02 00 00       	push   $0x202
    153f:	68 2a 4c 00 00       	push   $0x4c2a
    1544:	e8 f1 2a 00 00       	call   403a <open>
    1549:	83 c4 10             	add    $0x10,%esp
    154c:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    154f:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    1553:	79 17                	jns    156c <unlinkread+0x4d>
    printf(1, "create unlinkread failed\n");
    1555:	83 ec 08             	sub    $0x8,%esp
    1558:	68 35 4c 00 00       	push   $0x4c35
    155d:	6a 01                	push   $0x1
    155f:	e8 12 2c 00 00       	call   4176 <printf>
    1564:	83 c4 10             	add    $0x10,%esp
    exit();
    1567:	e8 8e 2a 00 00       	call   3ffa <exit>
  }
  write(fd, "hello", 5);
    156c:	83 ec 04             	sub    $0x4,%esp
    156f:	6a 05                	push   $0x5
    1571:	68 4f 4c 00 00       	push   $0x4c4f
    1576:	ff 75 f4             	push   -0xc(%ebp)
    1579:	e8 9c 2a 00 00       	call   401a <write>
    157e:	83 c4 10             	add    $0x10,%esp
  close(fd);
    1581:	83 ec 0c             	sub    $0xc,%esp
    1584:	ff 75 f4             	push   -0xc(%ebp)
    1587:	e8 96 2a 00 00       	call   4022 <close>
    158c:	83 c4 10             	add    $0x10,%esp

  fd = open("unlinkread", O_RDWR);
    158f:	83 ec 08             	sub    $0x8,%esp
    1592:	6a 02                	push   $0x2
    1594:	68 2a 4c 00 00       	push   $0x4c2a
    1599:	e8 9c 2a 00 00       	call   403a <open>
    159e:	83 c4 10             	add    $0x10,%esp
    15a1:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    15a4:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    15a8:	79 17                	jns    15c1 <unlinkread+0xa2>
    printf(1, "open unlinkread failed\n");
    15aa:	83 ec 08             	sub    $0x8,%esp
    15ad:	68 55 4c 00 00       	push   $0x4c55
    15b2:	6a 01                	push   $0x1
    15b4:	e8 bd 2b 00 00       	call   4176 <printf>
    15b9:	83 c4 10             	add    $0x10,%esp
    exit();
    15bc:	e8 39 2a 00 00       	call   3ffa <exit>
  }
  if(unlink("unlinkread") != 0){
    15c1:	83 ec 0c             	sub    $0xc,%esp
    15c4:	68 2a 4c 00 00       	push   $0x4c2a
    15c9:	e8 7c 2a 00 00       	call   404a <unlink>
    15ce:	83 c4 10             	add    $0x10,%esp
    15d1:	85 c0                	test   %eax,%eax
    15d3:	74 17                	je     15ec <unlinkread+0xcd>
    printf(1, "unlink unlinkread failed\n");
    15d5:	83 ec 08             	sub    $0x8,%esp
    15d8:	68 6d 4c 00 00       	push   $0x4c6d
    15dd:	6a 01                	push   $0x1
    15df:	e8 92 2b 00 00       	call   4176 <printf>
    15e4:	83 c4 10             	add    $0x10,%esp
    exit();
    15e7:	e8 0e 2a 00 00       	call   3ffa <exit>
  }

  fd1 = open("unlinkread", O_CREATE | O_RDWR);
    15ec:	83 ec 08             	sub    $0x8,%esp
    15ef:	68 02 02 00 00       	push   $0x202
    15f4:	68 2a 4c 00 00       	push   $0x4c2a
    15f9:	e8 3c 2a 00 00       	call   403a <open>
    15fe:	83 c4 10             	add    $0x10,%esp
    1601:	89 45 f0             	mov    %eax,-0x10(%ebp)
  write(fd1, "yyy", 3);
    1604:	83 ec 04             	sub    $0x4,%esp
    1607:	6a 03                	push   $0x3
    1609:	68 87 4c 00 00       	push   $0x4c87
    160e:	ff 75 f0             	push   -0x10(%ebp)
    1611:	e8 04 2a 00 00       	call   401a <write>
    1616:	83 c4 10             	add    $0x10,%esp
  close(fd1);
    1619:	83 ec 0c             	sub    $0xc,%esp
    161c:	ff 75 f0             	push   -0x10(%ebp)
    161f:	e8 fe 29 00 00       	call   4022 <close>
    1624:	83 c4 10             	add    $0x10,%esp

  if(read(fd, buf, sizeof(buf)) != 5){
    1627:	83 ec 04             	sub    $0x4,%esp
    162a:	68 00 20 00 00       	push   $0x2000
    162f:	68 e0 64 00 00       	push   $0x64e0
    1634:	ff 75 f4             	push   -0xc(%ebp)
    1637:	e8 d6 29 00 00       	call   4012 <read>
    163c:	83 c4 10             	add    $0x10,%esp
    163f:	83 f8 05             	cmp    $0x5,%eax
    1642:	74 17                	je     165b <unlinkread+0x13c>
    printf(1, "unlinkread read failed");
    1644:	83 ec 08             	sub    $0x8,%esp
    1647:	68 8b 4c 00 00       	push   $0x4c8b
    164c:	6a 01                	push   $0x1
    164e:	e8 23 2b 00 00       	call   4176 <printf>
    1653:	83 c4 10             	add    $0x10,%esp
    exit();
    1656:	e8 9f 29 00 00       	call   3ffa <exit>
  }
  if(buf[0] != 'h'){
    165b:	0f b6 05 e0 64 00 00 	movzbl 0x64e0,%eax
    1662:	3c 68                	cmp    $0x68,%al
    1664:	74 17                	je     167d <unlinkread+0x15e>
    printf(1, "unlinkread wrong data\n");
    1666:	83 ec 08             	sub    $0x8,%esp
    1669:	68 a2 4c 00 00       	push   $0x4ca2
    166e:	6a 01                	push   $0x1
    1670:	e8 01 2b 00 00       	call   4176 <printf>
    1675:	83 c4 10             	add    $0x10,%esp
    exit();
    1678:	e8 7d 29 00 00       	call   3ffa <exit>
  }
  if(write(fd, buf, 10) != 10){
    167d:	83 ec 04             	sub    $0x4,%esp
    1680:	6a 0a                	push   $0xa
    1682:	68 e0 64 00 00       	push   $0x64e0
    1687:	ff 75 f4             	push   -0xc(%ebp)
    168a:	e8 8b 29 00 00       	call   401a <write>
    168f:	83 c4 10             	add    $0x10,%esp
    1692:	83 f8 0a             	cmp    $0xa,%eax
    1695:	74 17                	je     16ae <unlinkread+0x18f>
    printf(1, "unlinkread write failed\n");
    1697:	83 ec 08             	sub    $0x8,%esp
    169a:	68 b9 4c 00 00       	push   $0x4cb9
    169f:	6a 01                	push   $0x1
    16a1:	e8 d0 2a 00 00       	call   4176 <printf>
    16a6:	83 c4 10             	add    $0x10,%esp
    exit();
    16a9:	e8 4c 29 00 00       	call   3ffa <exit>
  }
  close(fd);
    16ae:	83 ec 0c             	sub    $0xc,%esp
    16b1:	ff 75 f4             	push   -0xc(%ebp)
    16b4:	e8 69 29 00 00       	call   4022 <close>
    16b9:	83 c4 10             	add    $0x10,%esp
  unlink("unlinkread");
    16bc:	83 ec 0c             	sub    $0xc,%esp
    16bf:	68 2a 4c 00 00       	push   $0x4c2a
    16c4:	e8 81 29 00 00       	call   404a <unlink>
    16c9:	83 c4 10             	add    $0x10,%esp
  printf(1, "unlinkread ok\n");
    16cc:	83 ec 08             	sub    $0x8,%esp
    16cf:	68 d2 4c 00 00       	push   $0x4cd2
    16d4:	6a 01                	push   $0x1
    16d6:	e8 9b 2a 00 00       	call   4176 <printf>
    16db:	83 c4 10             	add    $0x10,%esp
}
    16de:	90                   	nop
    16df:	c9                   	leave
    16e0:	c3                   	ret

000016e1 <linktest>:

void
linktest(void)
{
    16e1:	55                   	push   %ebp
    16e2:	89 e5                	mov    %esp,%ebp
    16e4:	83 ec 18             	sub    $0x18,%esp
  int fd;

  printf(1, "linktest\n");
    16e7:	83 ec 08             	sub    $0x8,%esp
    16ea:	68 e1 4c 00 00       	push   $0x4ce1
    16ef:	6a 01                	push   $0x1
    16f1:	e8 80 2a 00 00       	call   4176 <printf>
    16f6:	83 c4 10             	add    $0x10,%esp

  unlink("lf1");
    16f9:	83 ec 0c             	sub    $0xc,%esp
    16fc:	68 eb 4c 00 00       	push   $0x4ceb
    1701:	e8 44 29 00 00       	call   404a <unlink>
    1706:	83 c4 10             	add    $0x10,%esp
  unlink("lf2");
    1709:	83 ec 0c             	sub    $0xc,%esp
    170c:	68 ef 4c 00 00       	push   $0x4cef
    1711:	e8 34 29 00 00       	call   404a <unlink>
    1716:	83 c4 10             	add    $0x10,%esp

  fd = open("lf1", O_CREATE|O_RDWR);
    1719:	83 ec 08             	sub    $0x8,%esp
    171c:	68 02 02 00 00       	push   $0x202
    1721:	68 eb 4c 00 00       	push   $0x4ceb
    1726:	e8 0f 29 00 00       	call   403a <open>
    172b:	83 c4 10             	add    $0x10,%esp
    172e:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    1731:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    1735:	79 17                	jns    174e <linktest+0x6d>
    printf(1, "create lf1 failed\n");
    1737:	83 ec 08             	sub    $0x8,%esp
    173a:	68 f3 4c 00 00       	push   $0x4cf3
    173f:	6a 01                	push   $0x1
    1741:	e8 30 2a 00 00       	call   4176 <printf>
    1746:	83 c4 10             	add    $0x10,%esp
    exit();
    1749:	e8 ac 28 00 00       	call   3ffa <exit>
  }
  if(write(fd, "hello", 5) != 5){
    174e:	83 ec 04             	sub    $0x4,%esp
    1751:	6a 05                	push   $0x5
    1753:	68 4f 4c 00 00       	push   $0x4c4f
    1758:	ff 75 f4             	push   -0xc(%ebp)
    175b:	e8 ba 28 00 00       	call   401a <write>
    1760:	83 c4 10             	add    $0x10,%esp
    1763:	83 f8 05             	cmp    $0x5,%eax
    1766:	74 17                	je     177f <linktest+0x9e>
    printf(1, "write lf1 failed\n");
    1768:	83 ec 08             	sub    $0x8,%esp
    176b:	68 06 4d 00 00       	push   $0x4d06
    1770:	6a 01                	push   $0x1
    1772:	e8 ff 29 00 00       	call   4176 <printf>
    1777:	83 c4 10             	add    $0x10,%esp
    exit();
    177a:	e8 7b 28 00 00       	call   3ffa <exit>
  }
  close(fd);
    177f:	83 ec 0c             	sub    $0xc,%esp
    1782:	ff 75 f4             	push   -0xc(%ebp)
    1785:	e8 98 28 00 00       	call   4022 <close>
    178a:	83 c4 10             	add    $0x10,%esp

  if(link("lf1", "lf2") < 0){
    178d:	83 ec 08             	sub    $0x8,%esp
    1790:	68 ef 4c 00 00       	push   $0x4cef
    1795:	68 eb 4c 00 00       	push   $0x4ceb
    179a:	e8 bb 28 00 00       	call   405a <link>
    179f:	83 c4 10             	add    $0x10,%esp
    17a2:	85 c0                	test   %eax,%eax
    17a4:	79 17                	jns    17bd <linktest+0xdc>
    printf(1, "link lf1 lf2 failed\n");
    17a6:	83 ec 08             	sub    $0x8,%esp
    17a9:	68 18 4d 00 00       	push   $0x4d18
    17ae:	6a 01                	push   $0x1
    17b0:	e8 c1 29 00 00       	call   4176 <printf>
    17b5:	83 c4 10             	add    $0x10,%esp
    exit();
    17b8:	e8 3d 28 00 00       	call   3ffa <exit>
  }
  unlink("lf1");
    17bd:	83 ec 0c             	sub    $0xc,%esp
    17c0:	68 eb 4c 00 00       	push   $0x4ceb
    17c5:	e8 80 28 00 00       	call   404a <unlink>
    17ca:	83 c4 10             	add    $0x10,%esp

  if(open("lf1", 0) >= 0){
    17cd:	83 ec 08             	sub    $0x8,%esp
    17d0:	6a 00                	push   $0x0
    17d2:	68 eb 4c 00 00       	push   $0x4ceb
    17d7:	e8 5e 28 00 00       	call   403a <open>
    17dc:	83 c4 10             	add    $0x10,%esp
    17df:	85 c0                	test   %eax,%eax
    17e1:	78 17                	js     17fa <linktest+0x119>
    printf(1, "unlinked lf1 but it is still there!\n");
    17e3:	83 ec 08             	sub    $0x8,%esp
    17e6:	68 30 4d 00 00       	push   $0x4d30
    17eb:	6a 01                	push   $0x1
    17ed:	e8 84 29 00 00       	call   4176 <printf>
    17f2:	83 c4 10             	add    $0x10,%esp
    exit();
    17f5:	e8 00 28 00 00       	call   3ffa <exit>
  }

  fd = open("lf2", 0);
    17fa:	83 ec 08             	sub    $0x8,%esp
    17fd:	6a 00                	push   $0x0
    17ff:	68 ef 4c 00 00       	push   $0x4cef
    1804:	e8 31 28 00 00       	call   403a <open>
    1809:	83 c4 10             	add    $0x10,%esp
    180c:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    180f:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    1813:	79 17                	jns    182c <linktest+0x14b>
    printf(1, "open lf2 failed\n");
    1815:	83 ec 08             	sub    $0x8,%esp
    1818:	68 55 4d 00 00       	push   $0x4d55
    181d:	6a 01                	push   $0x1
    181f:	e8 52 29 00 00       	call   4176 <printf>
    1824:	83 c4 10             	add    $0x10,%esp
    exit();
    1827:	e8 ce 27 00 00       	call   3ffa <exit>
  }
  if(read(fd, buf, sizeof(buf)) != 5){
    182c:	83 ec 04             	sub    $0x4,%esp
    182f:	68 00 20 00 00       	push   $0x2000
    1834:	68 e0 64 00 00       	push   $0x64e0
    1839:	ff 75 f4             	push   -0xc(%ebp)
    183c:	e8 d1 27 00 00       	call   4012 <read>
    1841:	83 c4 10             	add    $0x10,%esp
    1844:	83 f8 05             	cmp    $0x5,%eax
    1847:	74 17                	je     1860 <linktest+0x17f>
    printf(1, "read lf2 failed\n");
    1849:	83 ec 08             	sub    $0x8,%esp
    184c:	68 66 4d 00 00       	push   $0x4d66
    1851:	6a 01                	push   $0x1
    1853:	e8 1e 29 00 00       	call   4176 <printf>
    1858:	83 c4 10             	add    $0x10,%esp
    exit();
    185b:	e8 9a 27 00 00       	call   3ffa <exit>
  }
  close(fd);
    1860:	83 ec 0c             	sub    $0xc,%esp
    1863:	ff 75 f4             	push   -0xc(%ebp)
    1866:	e8 b7 27 00 00       	call   4022 <close>
    186b:	83 c4 10             	add    $0x10,%esp

  if(link("lf2", "lf2") >= 0){
    186e:	83 ec 08             	sub    $0x8,%esp
    1871:	68 ef 4c 00 00       	push   $0x4cef
    1876:	68 ef 4c 00 00       	push   $0x4cef
    187b:	e8 da 27 00 00       	call   405a <link>
    1880:	83 c4 10             	add    $0x10,%esp
    1883:	85 c0                	test   %eax,%eax
    1885:	78 17                	js     189e <linktest+0x1bd>
    printf(1, "link lf2 lf2 succeeded! oops\n");
    1887:	83 ec 08             	sub    $0x8,%esp
    188a:	68 77 4d 00 00       	push   $0x4d77
    188f:	6a 01                	push   $0x1
    1891:	e8 e0 28 00 00       	call   4176 <printf>
    1896:	83 c4 10             	add    $0x10,%esp
    exit();
    1899:	e8 5c 27 00 00       	call   3ffa <exit>
  }

  unlink("lf2");
    189e:	83 ec 0c             	sub    $0xc,%esp
    18a1:	68 ef 4c 00 00       	push   $0x4cef
    18a6:	e8 9f 27 00 00       	call   404a <unlink>
    18ab:	83 c4 10             	add    $0x10,%esp
  if(link("lf2", "lf1") >= 0){
    18ae:	83 ec 08             	sub    $0x8,%esp
    18b1:	68 eb 4c 00 00       	push   $0x4ceb
    18b6:	68 ef 4c 00 00       	push   $0x4cef
    18bb:	e8 9a 27 00 00       	call   405a <link>
    18c0:	83 c4 10             	add    $0x10,%esp
    18c3:	85 c0                	test   %eax,%eax
    18c5:	78 17                	js     18de <linktest+0x1fd>
    printf(1, "link non-existant succeeded! oops\n");
    18c7:	83 ec 08             	sub    $0x8,%esp
    18ca:	68 98 4d 00 00       	push   $0x4d98
    18cf:	6a 01                	push   $0x1
    18d1:	e8 a0 28 00 00       	call   4176 <printf>
    18d6:	83 c4 10             	add    $0x10,%esp
    exit();
    18d9:	e8 1c 27 00 00       	call   3ffa <exit>
  }

  if(link(".", "lf1") >= 0){
    18de:	83 ec 08             	sub    $0x8,%esp
    18e1:	68 eb 4c 00 00       	push   $0x4ceb
    18e6:	68 bb 4d 00 00       	push   $0x4dbb
    18eb:	e8 6a 27 00 00       	call   405a <link>
    18f0:	83 c4 10             	add    $0x10,%esp
    18f3:	85 c0                	test   %eax,%eax
    18f5:	78 17                	js     190e <linktest+0x22d>
    printf(1, "link . lf1 succeeded! oops\n");
    18f7:	83 ec 08             	sub    $0x8,%esp
    18fa:	68 bd 4d 00 00       	push   $0x4dbd
    18ff:	6a 01                	push   $0x1
    1901:	e8 70 28 00 00       	call   4176 <printf>
    1906:	83 c4 10             	add    $0x10,%esp
    exit();
    1909:	e8 ec 26 00 00       	call   3ffa <exit>
  }

  printf(1, "linktest ok\n");
    190e:	83 ec 08             	sub    $0x8,%esp
    1911:	68 d9 4d 00 00       	push   $0x4dd9
    1916:	6a 01                	push   $0x1
    1918:	e8 59 28 00 00       	call   4176 <printf>
    191d:	83 c4 10             	add    $0x10,%esp
}
    1920:	90                   	nop
    1921:	c9                   	leave
    1922:	c3                   	ret

00001923 <concreate>:

// test concurrent create/link/unlink of the same file
void
concreate(void)
{
    1923:	55                   	push   %ebp
    1924:	89 e5                	mov    %esp,%ebp
    1926:	83 ec 58             	sub    $0x58,%esp
  struct {
    ushort inum;
    char name[14];
  } de;

  printf(1, "concreate test\n");
    1929:	83 ec 08             	sub    $0x8,%esp
    192c:	68 e6 4d 00 00       	push   $0x4de6
    1931:	6a 01                	push   $0x1
    1933:	e8 3e 28 00 00       	call   4176 <printf>
    1938:	83 c4 10             	add    $0x10,%esp
  file[0] = 'C';
    193b:	c6 45 e5 43          	movb   $0x43,-0x1b(%ebp)
  file[2] = '\0';
    193f:	c6 45 e7 00          	movb   $0x0,-0x19(%ebp)
  for(i = 0; i < 40; i++){
    1943:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    194a:	e9 fc 00 00 00       	jmp    1a4b <concreate+0x128>
    file[1] = '0' + i;
    194f:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1952:	83 c0 30             	add    $0x30,%eax
    1955:	88 45 e6             	mov    %al,-0x1a(%ebp)
    unlink(file);
    1958:	83 ec 0c             	sub    $0xc,%esp
    195b:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    195e:	50                   	push   %eax
    195f:	e8 e6 26 00 00       	call   404a <unlink>
    1964:	83 c4 10             	add    $0x10,%esp
    pid = fork();
    1967:	e8 86 26 00 00       	call   3ff2 <fork>
    196c:	89 45 e8             	mov    %eax,-0x18(%ebp)
    if(pid && (i % 3) == 1){
    196f:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    1973:	74 3b                	je     19b0 <concreate+0x8d>
    1975:	8b 4d f4             	mov    -0xc(%ebp),%ecx
    1978:	ba 56 55 55 55       	mov    $0x55555556,%edx
    197d:	89 c8                	mov    %ecx,%eax
    197f:	f7 ea                	imul   %edx
    1981:	89 c8                	mov    %ecx,%eax
    1983:	c1 f8 1f             	sar    $0x1f,%eax
    1986:	29 c2                	sub    %eax,%edx
    1988:	89 d0                	mov    %edx,%eax
    198a:	01 c0                	add    %eax,%eax
    198c:	01 d0                	add    %edx,%eax
    198e:	29 c1                	sub    %eax,%ecx
    1990:	89 ca                	mov    %ecx,%edx
    1992:	83 fa 01             	cmp    $0x1,%edx
    1995:	75 19                	jne    19b0 <concreate+0x8d>
      link("C0", file);
    1997:	83 ec 08             	sub    $0x8,%esp
    199a:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    199d:	50                   	push   %eax
    199e:	68 f6 4d 00 00       	push   $0x4df6
    19a3:	e8 b2 26 00 00       	call   405a <link>
    19a8:	83 c4 10             	add    $0x10,%esp
    19ab:	e9 87 00 00 00       	jmp    1a37 <concreate+0x114>
    } else if(pid == 0 && (i % 5) == 1){
    19b0:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    19b4:	75 3b                	jne    19f1 <concreate+0xce>
    19b6:	8b 4d f4             	mov    -0xc(%ebp),%ecx
    19b9:	ba 67 66 66 66       	mov    $0x66666667,%edx
    19be:	89 c8                	mov    %ecx,%eax
    19c0:	f7 ea                	imul   %edx
    19c2:	d1 fa                	sar    $1,%edx
    19c4:	89 c8                	mov    %ecx,%eax
    19c6:	c1 f8 1f             	sar    $0x1f,%eax
    19c9:	29 c2                	sub    %eax,%edx
    19cb:	89 d0                	mov    %edx,%eax
    19cd:	c1 e0 02             	shl    $0x2,%eax
    19d0:	01 d0                	add    %edx,%eax
    19d2:	29 c1                	sub    %eax,%ecx
    19d4:	89 ca                	mov    %ecx,%edx
    19d6:	83 fa 01             	cmp    $0x1,%edx
    19d9:	75 16                	jne    19f1 <concreate+0xce>
      link("C0", file);
    19db:	83 ec 08             	sub    $0x8,%esp
    19de:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    19e1:	50                   	push   %eax
    19e2:	68 f6 4d 00 00       	push   $0x4df6
    19e7:	e8 6e 26 00 00       	call   405a <link>
    19ec:	83 c4 10             	add    $0x10,%esp
    19ef:	eb 46                	jmp    1a37 <concreate+0x114>
    } else {
      fd = open(file, O_CREATE | O_RDWR);
    19f1:	83 ec 08             	sub    $0x8,%esp
    19f4:	68 02 02 00 00       	push   $0x202
    19f9:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    19fc:	50                   	push   %eax
    19fd:	e8 38 26 00 00       	call   403a <open>
    1a02:	83 c4 10             	add    $0x10,%esp
    1a05:	89 45 ec             	mov    %eax,-0x14(%ebp)
      if(fd < 0){
    1a08:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    1a0c:	79 1b                	jns    1a29 <concreate+0x106>
        printf(1, "concreate create %s failed\n", file);
    1a0e:	83 ec 04             	sub    $0x4,%esp
    1a11:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1a14:	50                   	push   %eax
    1a15:	68 f9 4d 00 00       	push   $0x4df9
    1a1a:	6a 01                	push   $0x1
    1a1c:	e8 55 27 00 00       	call   4176 <printf>
    1a21:	83 c4 10             	add    $0x10,%esp
        exit();
    1a24:	e8 d1 25 00 00       	call   3ffa <exit>
      }
      close(fd);
    1a29:	83 ec 0c             	sub    $0xc,%esp
    1a2c:	ff 75 ec             	push   -0x14(%ebp)
    1a2f:	e8 ee 25 00 00       	call   4022 <close>
    1a34:	83 c4 10             	add    $0x10,%esp
    }
    if(pid == 0)
    1a37:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    1a3b:	75 05                	jne    1a42 <concreate+0x11f>
      exit();
    1a3d:	e8 b8 25 00 00       	call   3ffa <exit>
    else
      wait();
    1a42:	e8 bb 25 00 00       	call   4002 <wait>
  for(i = 0; i < 40; i++){
    1a47:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    1a4b:	83 7d f4 27          	cmpl   $0x27,-0xc(%ebp)
    1a4f:	0f 8e fa fe ff ff    	jle    194f <concreate+0x2c>
  }

  memset(fa, 0, sizeof(fa));
    1a55:	83 ec 04             	sub    $0x4,%esp
    1a58:	6a 28                	push   $0x28
    1a5a:	6a 00                	push   $0x0
    1a5c:	8d 45 bd             	lea    -0x43(%ebp),%eax
    1a5f:	50                   	push   %eax
    1a60:	e8 fa 23 00 00       	call   3e5f <memset>
    1a65:	83 c4 10             	add    $0x10,%esp
  fd = open(".", 0);
    1a68:	83 ec 08             	sub    $0x8,%esp
    1a6b:	6a 00                	push   $0x0
    1a6d:	68 bb 4d 00 00       	push   $0x4dbb
    1a72:	e8 c3 25 00 00       	call   403a <open>
    1a77:	83 c4 10             	add    $0x10,%esp
    1a7a:	89 45 ec             	mov    %eax,-0x14(%ebp)
  n = 0;
    1a7d:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  while(read(fd, &de, sizeof(de)) > 0){
    1a84:	e9 99 00 00 00       	jmp    1b22 <concreate+0x1ff>
    if(de.inum == 0)
    1a89:	0f b7 45 ac          	movzwl -0x54(%ebp),%eax
    1a8d:	66 85 c0             	test   %ax,%ax
    1a90:	0f 84 8b 00 00 00    	je     1b21 <concreate+0x1fe>
      continue;
    if(de.name[0] == 'C' && de.name[2] == '\0'){
    1a96:	0f b6 45 ae          	movzbl -0x52(%ebp),%eax
    1a9a:	3c 43                	cmp    $0x43,%al
    1a9c:	0f 85 80 00 00 00    	jne    1b22 <concreate+0x1ff>
    1aa2:	0f b6 45 b0          	movzbl -0x50(%ebp),%eax
    1aa6:	84 c0                	test   %al,%al
    1aa8:	75 78                	jne    1b22 <concreate+0x1ff>
      i = de.name[1] - '0';
    1aaa:	0f b6 45 af          	movzbl -0x51(%ebp),%eax
    1aae:	0f be c0             	movsbl %al,%eax
    1ab1:	83 e8 30             	sub    $0x30,%eax
    1ab4:	89 45 f4             	mov    %eax,-0xc(%ebp)
      if(i < 0 || i >= sizeof(fa)){
    1ab7:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    1abb:	78 08                	js     1ac5 <concreate+0x1a2>
    1abd:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1ac0:	83 f8 27             	cmp    $0x27,%eax
    1ac3:	76 1e                	jbe    1ae3 <concreate+0x1c0>
        printf(1, "concreate weird file %s\n", de.name);
    1ac5:	83 ec 04             	sub    $0x4,%esp
    1ac8:	8d 45 ac             	lea    -0x54(%ebp),%eax
    1acb:	83 c0 02             	add    $0x2,%eax
    1ace:	50                   	push   %eax
    1acf:	68 15 4e 00 00       	push   $0x4e15
    1ad4:	6a 01                	push   $0x1
    1ad6:	e8 9b 26 00 00       	call   4176 <printf>
    1adb:	83 c4 10             	add    $0x10,%esp
        exit();
    1ade:	e8 17 25 00 00       	call   3ffa <exit>
      }
      if(fa[i]){
    1ae3:	8d 55 bd             	lea    -0x43(%ebp),%edx
    1ae6:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1ae9:	01 d0                	add    %edx,%eax
    1aeb:	0f b6 00             	movzbl (%eax),%eax
    1aee:	84 c0                	test   %al,%al
    1af0:	74 1e                	je     1b10 <concreate+0x1ed>
        printf(1, "concreate duplicate file %s\n", de.name);
    1af2:	83 ec 04             	sub    $0x4,%esp
    1af5:	8d 45 ac             	lea    -0x54(%ebp),%eax
    1af8:	83 c0 02             	add    $0x2,%eax
    1afb:	50                   	push   %eax
    1afc:	68 2e 4e 00 00       	push   $0x4e2e
    1b01:	6a 01                	push   $0x1
    1b03:	e8 6e 26 00 00       	call   4176 <printf>
    1b08:	83 c4 10             	add    $0x10,%esp
        exit();
    1b0b:	e8 ea 24 00 00       	call   3ffa <exit>
      }
      fa[i] = 1;
    1b10:	8d 55 bd             	lea    -0x43(%ebp),%edx
    1b13:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1b16:	01 d0                	add    %edx,%eax
    1b18:	c6 00 01             	movb   $0x1,(%eax)
      n++;
    1b1b:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    1b1f:	eb 01                	jmp    1b22 <concreate+0x1ff>
      continue;
    1b21:	90                   	nop
  while(read(fd, &de, sizeof(de)) > 0){
    1b22:	83 ec 04             	sub    $0x4,%esp
    1b25:	6a 10                	push   $0x10
    1b27:	8d 45 ac             	lea    -0x54(%ebp),%eax
    1b2a:	50                   	push   %eax
    1b2b:	ff 75 ec             	push   -0x14(%ebp)
    1b2e:	e8 df 24 00 00       	call   4012 <read>
    1b33:	83 c4 10             	add    $0x10,%esp
    1b36:	85 c0                	test   %eax,%eax
    1b38:	0f 8f 4b ff ff ff    	jg     1a89 <concreate+0x166>
    }
  }
  close(fd);
    1b3e:	83 ec 0c             	sub    $0xc,%esp
    1b41:	ff 75 ec             	push   -0x14(%ebp)
    1b44:	e8 d9 24 00 00       	call   4022 <close>
    1b49:	83 c4 10             	add    $0x10,%esp

  if(n != 40){
    1b4c:	83 7d f0 28          	cmpl   $0x28,-0x10(%ebp)
    1b50:	74 17                	je     1b69 <concreate+0x246>
    printf(1, "concreate not enough files in directory listing\n");
    1b52:	83 ec 08             	sub    $0x8,%esp
    1b55:	68 4c 4e 00 00       	push   $0x4e4c
    1b5a:	6a 01                	push   $0x1
    1b5c:	e8 15 26 00 00       	call   4176 <printf>
    1b61:	83 c4 10             	add    $0x10,%esp
    exit();
    1b64:	e8 91 24 00 00       	call   3ffa <exit>
  }

  for(i = 0; i < 40; i++){
    1b69:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    1b70:	e9 43 01 00 00       	jmp    1cb8 <concreate+0x395>
    file[1] = '0' + i;
    1b75:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1b78:	83 c0 30             	add    $0x30,%eax
    1b7b:	88 45 e6             	mov    %al,-0x1a(%ebp)
    pid = fork();
    1b7e:	e8 6f 24 00 00       	call   3ff2 <fork>
    1b83:	89 45 e8             	mov    %eax,-0x18(%ebp)
    if(pid < 0){
    1b86:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    1b8a:	79 17                	jns    1ba3 <concreate+0x280>
      printf(1, "fork failed\n");
    1b8c:	83 ec 08             	sub    $0x8,%esp
    1b8f:	68 d1 45 00 00       	push   $0x45d1
    1b94:	6a 01                	push   $0x1
    1b96:	e8 db 25 00 00       	call   4176 <printf>
    1b9b:	83 c4 10             	add    $0x10,%esp
      exit();
    1b9e:	e8 57 24 00 00       	call   3ffa <exit>
    }
    if(((i % 3) == 0 && pid == 0) ||
    1ba3:	8b 4d f4             	mov    -0xc(%ebp),%ecx
    1ba6:	ba 56 55 55 55       	mov    $0x55555556,%edx
    1bab:	89 c8                	mov    %ecx,%eax
    1bad:	f7 ea                	imul   %edx
    1baf:	89 c8                	mov    %ecx,%eax
    1bb1:	c1 f8 1f             	sar    $0x1f,%eax
    1bb4:	29 c2                	sub    %eax,%edx
    1bb6:	89 d0                	mov    %edx,%eax
    1bb8:	01 c0                	add    %eax,%eax
    1bba:	01 d0                	add    %edx,%eax
    1bbc:	29 c1                	sub    %eax,%ecx
    1bbe:	89 ca                	mov    %ecx,%edx
    1bc0:	85 d2                	test   %edx,%edx
    1bc2:	75 06                	jne    1bca <concreate+0x2a7>
    1bc4:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    1bc8:	74 28                	je     1bf2 <concreate+0x2cf>
       ((i % 3) == 1 && pid != 0)){
    1bca:	8b 4d f4             	mov    -0xc(%ebp),%ecx
    1bcd:	ba 56 55 55 55       	mov    $0x55555556,%edx
    1bd2:	89 c8                	mov    %ecx,%eax
    1bd4:	f7 ea                	imul   %edx
    1bd6:	89 c8                	mov    %ecx,%eax
    1bd8:	c1 f8 1f             	sar    $0x1f,%eax
    1bdb:	29 c2                	sub    %eax,%edx
    1bdd:	89 d0                	mov    %edx,%eax
    1bdf:	01 c0                	add    %eax,%eax
    1be1:	01 d0                	add    %edx,%eax
    1be3:	29 c1                	sub    %eax,%ecx
    1be5:	89 ca                	mov    %ecx,%edx
    if(((i % 3) == 0 && pid == 0) ||
    1be7:	83 fa 01             	cmp    $0x1,%edx
    1bea:	75 7c                	jne    1c68 <concreate+0x345>
       ((i % 3) == 1 && pid != 0)){
    1bec:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    1bf0:	74 76                	je     1c68 <concreate+0x345>
      close(open(file, 0));
    1bf2:	83 ec 08             	sub    $0x8,%esp
    1bf5:	6a 00                	push   $0x0
    1bf7:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1bfa:	50                   	push   %eax
    1bfb:	e8 3a 24 00 00       	call   403a <open>
    1c00:	83 c4 10             	add    $0x10,%esp
    1c03:	83 ec 0c             	sub    $0xc,%esp
    1c06:	50                   	push   %eax
    1c07:	e8 16 24 00 00       	call   4022 <close>
    1c0c:	83 c4 10             	add    $0x10,%esp
      close(open(file, 0));
    1c0f:	83 ec 08             	sub    $0x8,%esp
    1c12:	6a 00                	push   $0x0
    1c14:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1c17:	50                   	push   %eax
    1c18:	e8 1d 24 00 00       	call   403a <open>
    1c1d:	83 c4 10             	add    $0x10,%esp
    1c20:	83 ec 0c             	sub    $0xc,%esp
    1c23:	50                   	push   %eax
    1c24:	e8 f9 23 00 00       	call   4022 <close>
    1c29:	83 c4 10             	add    $0x10,%esp
      close(open(file, 0));
    1c2c:	83 ec 08             	sub    $0x8,%esp
    1c2f:	6a 00                	push   $0x0
    1c31:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1c34:	50                   	push   %eax
    1c35:	e8 00 24 00 00       	call   403a <open>
    1c3a:	83 c4 10             	add    $0x10,%esp
    1c3d:	83 ec 0c             	sub    $0xc,%esp
    1c40:	50                   	push   %eax
    1c41:	e8 dc 23 00 00       	call   4022 <close>
    1c46:	83 c4 10             	add    $0x10,%esp
      close(open(file, 0));
    1c49:	83 ec 08             	sub    $0x8,%esp
    1c4c:	6a 00                	push   $0x0
    1c4e:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1c51:	50                   	push   %eax
    1c52:	e8 e3 23 00 00       	call   403a <open>
    1c57:	83 c4 10             	add    $0x10,%esp
    1c5a:	83 ec 0c             	sub    $0xc,%esp
    1c5d:	50                   	push   %eax
    1c5e:	e8 bf 23 00 00       	call   4022 <close>
    1c63:	83 c4 10             	add    $0x10,%esp
    1c66:	eb 3c                	jmp    1ca4 <concreate+0x381>
    } else {
      unlink(file);
    1c68:	83 ec 0c             	sub    $0xc,%esp
    1c6b:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1c6e:	50                   	push   %eax
    1c6f:	e8 d6 23 00 00       	call   404a <unlink>
    1c74:	83 c4 10             	add    $0x10,%esp
      unlink(file);
    1c77:	83 ec 0c             	sub    $0xc,%esp
    1c7a:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1c7d:	50                   	push   %eax
    1c7e:	e8 c7 23 00 00       	call   404a <unlink>
    1c83:	83 c4 10             	add    $0x10,%esp
      unlink(file);
    1c86:	83 ec 0c             	sub    $0xc,%esp
    1c89:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1c8c:	50                   	push   %eax
    1c8d:	e8 b8 23 00 00       	call   404a <unlink>
    1c92:	83 c4 10             	add    $0x10,%esp
      unlink(file);
    1c95:	83 ec 0c             	sub    $0xc,%esp
    1c98:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1c9b:	50                   	push   %eax
    1c9c:	e8 a9 23 00 00       	call   404a <unlink>
    1ca1:	83 c4 10             	add    $0x10,%esp
    }
    if(pid == 0)
    1ca4:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    1ca8:	75 05                	jne    1caf <concreate+0x38c>
      exit();
    1caa:	e8 4b 23 00 00       	call   3ffa <exit>
    else
      wait();
    1caf:	e8 4e 23 00 00       	call   4002 <wait>
  for(i = 0; i < 40; i++){
    1cb4:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    1cb8:	83 7d f4 27          	cmpl   $0x27,-0xc(%ebp)
    1cbc:	0f 8e b3 fe ff ff    	jle    1b75 <concreate+0x252>
  }

  printf(1, "concreate ok\n");
    1cc2:	83 ec 08             	sub    $0x8,%esp
    1cc5:	68 7d 4e 00 00       	push   $0x4e7d
    1cca:	6a 01                	push   $0x1
    1ccc:	e8 a5 24 00 00       	call   4176 <printf>
    1cd1:	83 c4 10             	add    $0x10,%esp
}
    1cd4:	90                   	nop
    1cd5:	c9                   	leave
    1cd6:	c3                   	ret

00001cd7 <linkunlink>:

// another concurrent link/unlink/create test,
// to look for deadlocks.
void
linkunlink()
{
    1cd7:	55                   	push   %ebp
    1cd8:	89 e5                	mov    %esp,%ebp
    1cda:	83 ec 18             	sub    $0x18,%esp
  int pid, i;

  printf(1, "linkunlink test\n");
    1cdd:	83 ec 08             	sub    $0x8,%esp
    1ce0:	68 8b 4e 00 00       	push   $0x4e8b
    1ce5:	6a 01                	push   $0x1
    1ce7:	e8 8a 24 00 00       	call   4176 <printf>
    1cec:	83 c4 10             	add    $0x10,%esp

  unlink("x");
    1cef:	83 ec 0c             	sub    $0xc,%esp
    1cf2:	68 07 4a 00 00       	push   $0x4a07
    1cf7:	e8 4e 23 00 00       	call   404a <unlink>
    1cfc:	83 c4 10             	add    $0x10,%esp
  pid = fork();
    1cff:	e8 ee 22 00 00       	call   3ff2 <fork>
    1d04:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if(pid < 0){
    1d07:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    1d0b:	79 17                	jns    1d24 <linkunlink+0x4d>
    printf(1, "fork failed\n");
    1d0d:	83 ec 08             	sub    $0x8,%esp
    1d10:	68 d1 45 00 00       	push   $0x45d1
    1d15:	6a 01                	push   $0x1
    1d17:	e8 5a 24 00 00       	call   4176 <printf>
    1d1c:	83 c4 10             	add    $0x10,%esp
    exit();
    1d1f:	e8 d6 22 00 00       	call   3ffa <exit>
  }

  unsigned int x = (pid ? 1 : 97);
    1d24:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    1d28:	74 09                	je     1d33 <linkunlink+0x5c>
    1d2a:	c7 45 f0 01 00 00 00 	movl   $0x1,-0x10(%ebp)
    1d31:	eb 07                	jmp    1d3a <linkunlink+0x63>
    1d33:	c7 45 f0 61 00 00 00 	movl   $0x61,-0x10(%ebp)
  for(i = 0; i < 100; i++){
    1d3a:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    1d41:	e9 98 00 00 00       	jmp    1dde <linkunlink+0x107>
    x = x * 1103515245 + 12345;
    1d46:	8b 45 f0             	mov    -0x10(%ebp),%eax
    1d49:	69 c0 6d 4e c6 41    	imul   $0x41c64e6d,%eax,%eax
    1d4f:	05 39 30 00 00       	add    $0x3039,%eax
    1d54:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if((x % 3) == 0){
    1d57:	8b 4d f0             	mov    -0x10(%ebp),%ecx
    1d5a:	ba ab aa aa aa       	mov    $0xaaaaaaab,%edx
    1d5f:	89 c8                	mov    %ecx,%eax
    1d61:	f7 e2                	mul    %edx
    1d63:	d1 ea                	shr    $1,%edx
    1d65:	89 d0                	mov    %edx,%eax
    1d67:	01 c0                	add    %eax,%eax
    1d69:	01 d0                	add    %edx,%eax
    1d6b:	29 c1                	sub    %eax,%ecx
    1d6d:	89 ca                	mov    %ecx,%edx
    1d6f:	85 d2                	test   %edx,%edx
    1d71:	75 23                	jne    1d96 <linkunlink+0xbf>
      close(open("x", O_RDWR | O_CREATE));
    1d73:	83 ec 08             	sub    $0x8,%esp
    1d76:	68 02 02 00 00       	push   $0x202
    1d7b:	68 07 4a 00 00       	push   $0x4a07
    1d80:	e8 b5 22 00 00       	call   403a <open>
    1d85:	83 c4 10             	add    $0x10,%esp
    1d88:	83 ec 0c             	sub    $0xc,%esp
    1d8b:	50                   	push   %eax
    1d8c:	e8 91 22 00 00       	call   4022 <close>
    1d91:	83 c4 10             	add    $0x10,%esp
    1d94:	eb 44                	jmp    1dda <linkunlink+0x103>
    } else if((x % 3) == 1){
    1d96:	8b 4d f0             	mov    -0x10(%ebp),%ecx
    1d99:	ba ab aa aa aa       	mov    $0xaaaaaaab,%edx
    1d9e:	89 c8                	mov    %ecx,%eax
    1da0:	f7 e2                	mul    %edx
    1da2:	d1 ea                	shr    $1,%edx
    1da4:	89 d0                	mov    %edx,%eax
    1da6:	01 c0                	add    %eax,%eax
    1da8:	01 d0                	add    %edx,%eax
    1daa:	29 c1                	sub    %eax,%ecx
    1dac:	89 ca                	mov    %ecx,%edx
    1dae:	83 fa 01             	cmp    $0x1,%edx
    1db1:	75 17                	jne    1dca <linkunlink+0xf3>
      link("cat", "x");
    1db3:	83 ec 08             	sub    $0x8,%esp
    1db6:	68 07 4a 00 00       	push   $0x4a07
    1dbb:	68 9c 4e 00 00       	push   $0x4e9c
    1dc0:	e8 95 22 00 00       	call   405a <link>
    1dc5:	83 c4 10             	add    $0x10,%esp
    1dc8:	eb 10                	jmp    1dda <linkunlink+0x103>
    } else {
      unlink("x");
    1dca:	83 ec 0c             	sub    $0xc,%esp
    1dcd:	68 07 4a 00 00       	push   $0x4a07
    1dd2:	e8 73 22 00 00       	call   404a <unlink>
    1dd7:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < 100; i++){
    1dda:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    1dde:	83 7d f4 63          	cmpl   $0x63,-0xc(%ebp)
    1de2:	0f 8e 5e ff ff ff    	jle    1d46 <linkunlink+0x6f>
    }
  }

  if(pid)
    1de8:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    1dec:	74 07                	je     1df5 <linkunlink+0x11e>
    wait();
    1dee:	e8 0f 22 00 00       	call   4002 <wait>
    1df3:	eb 05                	jmp    1dfa <linkunlink+0x123>
  else
    exit();
    1df5:	e8 00 22 00 00       	call   3ffa <exit>

  printf(1, "linkunlink ok\n");
    1dfa:	83 ec 08             	sub    $0x8,%esp
    1dfd:	68 a0 4e 00 00       	push   $0x4ea0
    1e02:	6a 01                	push   $0x1
    1e04:	e8 6d 23 00 00       	call   4176 <printf>
    1e09:	83 c4 10             	add    $0x10,%esp
}
    1e0c:	90                   	nop
    1e0d:	c9                   	leave
    1e0e:	c3                   	ret

00001e0f <bigdir>:

// directory that uses indirect blocks
void
bigdir(void)
{
    1e0f:	55                   	push   %ebp
    1e10:	89 e5                	mov    %esp,%ebp
    1e12:	83 ec 28             	sub    $0x28,%esp
  int i, fd;
  char name[10];

  printf(1, "bigdir test\n");
    1e15:	83 ec 08             	sub    $0x8,%esp
    1e18:	68 af 4e 00 00       	push   $0x4eaf
    1e1d:	6a 01                	push   $0x1
    1e1f:	e8 52 23 00 00       	call   4176 <printf>
    1e24:	83 c4 10             	add    $0x10,%esp
  unlink("bd");
    1e27:	83 ec 0c             	sub    $0xc,%esp
    1e2a:	68 bc 4e 00 00       	push   $0x4ebc
    1e2f:	e8 16 22 00 00       	call   404a <unlink>
    1e34:	83 c4 10             	add    $0x10,%esp

  fd = open("bd", O_CREATE);
    1e37:	83 ec 08             	sub    $0x8,%esp
    1e3a:	68 00 02 00 00       	push   $0x200
    1e3f:	68 bc 4e 00 00       	push   $0x4ebc
    1e44:	e8 f1 21 00 00       	call   403a <open>
    1e49:	83 c4 10             	add    $0x10,%esp
    1e4c:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(fd < 0){
    1e4f:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    1e53:	79 17                	jns    1e6c <bigdir+0x5d>
    printf(1, "bigdir create failed\n");
    1e55:	83 ec 08             	sub    $0x8,%esp
    1e58:	68 bf 4e 00 00       	push   $0x4ebf
    1e5d:	6a 01                	push   $0x1
    1e5f:	e8 12 23 00 00       	call   4176 <printf>
    1e64:	83 c4 10             	add    $0x10,%esp
    exit();
    1e67:	e8 8e 21 00 00       	call   3ffa <exit>
  }
  close(fd);
    1e6c:	83 ec 0c             	sub    $0xc,%esp
    1e6f:	ff 75 f0             	push   -0x10(%ebp)
    1e72:	e8 ab 21 00 00       	call   4022 <close>
    1e77:	83 c4 10             	add    $0x10,%esp

  for(i = 0; i < 500; i++){
    1e7a:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    1e81:	eb 69                	jmp    1eec <bigdir+0xdd>
    name[0] = 'x';
    1e83:	c6 45 e6 78          	movb   $0x78,-0x1a(%ebp)
    name[1] = '0' + (i / 64);
    1e87:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1e8a:	8d 50 3f             	lea    0x3f(%eax),%edx
    1e8d:	85 c0                	test   %eax,%eax
    1e8f:	0f 48 c2             	cmovs  %edx,%eax
    1e92:	c1 f8 06             	sar    $0x6,%eax
    1e95:	83 c0 30             	add    $0x30,%eax
    1e98:	88 45 e7             	mov    %al,-0x19(%ebp)
    name[2] = '0' + (i % 64);
    1e9b:	8b 55 f4             	mov    -0xc(%ebp),%edx
    1e9e:	89 d0                	mov    %edx,%eax
    1ea0:	c1 f8 1f             	sar    $0x1f,%eax
    1ea3:	c1 e8 1a             	shr    $0x1a,%eax
    1ea6:	01 c2                	add    %eax,%edx
    1ea8:	83 e2 3f             	and    $0x3f,%edx
    1eab:	29 c2                	sub    %eax,%edx
    1ead:	89 d0                	mov    %edx,%eax
    1eaf:	83 c0 30             	add    $0x30,%eax
    1eb2:	88 45 e8             	mov    %al,-0x18(%ebp)
    name[3] = '\0';
    1eb5:	c6 45 e9 00          	movb   $0x0,-0x17(%ebp)
    if(link("bd", name) != 0){
    1eb9:	83 ec 08             	sub    $0x8,%esp
    1ebc:	8d 45 e6             	lea    -0x1a(%ebp),%eax
    1ebf:	50                   	push   %eax
    1ec0:	68 bc 4e 00 00       	push   $0x4ebc
    1ec5:	e8 90 21 00 00       	call   405a <link>
    1eca:	83 c4 10             	add    $0x10,%esp
    1ecd:	85 c0                	test   %eax,%eax
    1ecf:	74 17                	je     1ee8 <bigdir+0xd9>
      printf(1, "bigdir link failed\n");
    1ed1:	83 ec 08             	sub    $0x8,%esp
    1ed4:	68 d5 4e 00 00       	push   $0x4ed5
    1ed9:	6a 01                	push   $0x1
    1edb:	e8 96 22 00 00       	call   4176 <printf>
    1ee0:	83 c4 10             	add    $0x10,%esp
      exit();
    1ee3:	e8 12 21 00 00       	call   3ffa <exit>
  for(i = 0; i < 500; i++){
    1ee8:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    1eec:	81 7d f4 f3 01 00 00 	cmpl   $0x1f3,-0xc(%ebp)
    1ef3:	7e 8e                	jle    1e83 <bigdir+0x74>
    }
  }

  unlink("bd");
    1ef5:	83 ec 0c             	sub    $0xc,%esp
    1ef8:	68 bc 4e 00 00       	push   $0x4ebc
    1efd:	e8 48 21 00 00       	call   404a <unlink>
    1f02:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < 500; i++){
    1f05:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    1f0c:	eb 64                	jmp    1f72 <bigdir+0x163>
    name[0] = 'x';
    1f0e:	c6 45 e6 78          	movb   $0x78,-0x1a(%ebp)
    name[1] = '0' + (i / 64);
    1f12:	8b 45 f4             	mov    -0xc(%ebp),%eax
    1f15:	8d 50 3f             	lea    0x3f(%eax),%edx
    1f18:	85 c0                	test   %eax,%eax
    1f1a:	0f 48 c2             	cmovs  %edx,%eax
    1f1d:	c1 f8 06             	sar    $0x6,%eax
    1f20:	83 c0 30             	add    $0x30,%eax
    1f23:	88 45 e7             	mov    %al,-0x19(%ebp)
    name[2] = '0' + (i % 64);
    1f26:	8b 55 f4             	mov    -0xc(%ebp),%edx
    1f29:	89 d0                	mov    %edx,%eax
    1f2b:	c1 f8 1f             	sar    $0x1f,%eax
    1f2e:	c1 e8 1a             	shr    $0x1a,%eax
    1f31:	01 c2                	add    %eax,%edx
    1f33:	83 e2 3f             	and    $0x3f,%edx
    1f36:	29 c2                	sub    %eax,%edx
    1f38:	89 d0                	mov    %edx,%eax
    1f3a:	83 c0 30             	add    $0x30,%eax
    1f3d:	88 45 e8             	mov    %al,-0x18(%ebp)
    name[3] = '\0';
    1f40:	c6 45 e9 00          	movb   $0x0,-0x17(%ebp)
    if(unlink(name) != 0){
    1f44:	83 ec 0c             	sub    $0xc,%esp
    1f47:	8d 45 e6             	lea    -0x1a(%ebp),%eax
    1f4a:	50                   	push   %eax
    1f4b:	e8 fa 20 00 00       	call   404a <unlink>
    1f50:	83 c4 10             	add    $0x10,%esp
    1f53:	85 c0                	test   %eax,%eax
    1f55:	74 17                	je     1f6e <bigdir+0x15f>
      printf(1, "bigdir unlink failed");
    1f57:	83 ec 08             	sub    $0x8,%esp
    1f5a:	68 e9 4e 00 00       	push   $0x4ee9
    1f5f:	6a 01                	push   $0x1
    1f61:	e8 10 22 00 00       	call   4176 <printf>
    1f66:	83 c4 10             	add    $0x10,%esp
      exit();
    1f69:	e8 8c 20 00 00       	call   3ffa <exit>
  for(i = 0; i < 500; i++){
    1f6e:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    1f72:	81 7d f4 f3 01 00 00 	cmpl   $0x1f3,-0xc(%ebp)
    1f79:	7e 93                	jle    1f0e <bigdir+0xff>
    }
  }

  printf(1, "bigdir ok\n");
    1f7b:	83 ec 08             	sub    $0x8,%esp
    1f7e:	68 fe 4e 00 00       	push   $0x4efe
    1f83:	6a 01                	push   $0x1
    1f85:	e8 ec 21 00 00       	call   4176 <printf>
    1f8a:	83 c4 10             	add    $0x10,%esp
}
    1f8d:	90                   	nop
    1f8e:	c9                   	leave
    1f8f:	c3                   	ret

00001f90 <subdir>:

void
subdir(void)
{
    1f90:	55                   	push   %ebp
    1f91:	89 e5                	mov    %esp,%ebp
    1f93:	83 ec 18             	sub    $0x18,%esp
  int fd, cc;

  printf(1, "subdir test\n");
    1f96:	83 ec 08             	sub    $0x8,%esp
    1f99:	68 09 4f 00 00       	push   $0x4f09
    1f9e:	6a 01                	push   $0x1
    1fa0:	e8 d1 21 00 00       	call   4176 <printf>
    1fa5:	83 c4 10             	add    $0x10,%esp

  unlink("ff");
    1fa8:	83 ec 0c             	sub    $0xc,%esp
    1fab:	68 16 4f 00 00       	push   $0x4f16
    1fb0:	e8 95 20 00 00       	call   404a <unlink>
    1fb5:	83 c4 10             	add    $0x10,%esp
  if(mkdir("dd") != 0){
    1fb8:	83 ec 0c             	sub    $0xc,%esp
    1fbb:	68 19 4f 00 00       	push   $0x4f19
    1fc0:	e8 9d 20 00 00       	call   4062 <mkdir>
    1fc5:	83 c4 10             	add    $0x10,%esp
    1fc8:	85 c0                	test   %eax,%eax
    1fca:	74 17                	je     1fe3 <subdir+0x53>
    printf(1, "subdir mkdir dd failed\n");
    1fcc:	83 ec 08             	sub    $0x8,%esp
    1fcf:	68 1c 4f 00 00       	push   $0x4f1c
    1fd4:	6a 01                	push   $0x1
    1fd6:	e8 9b 21 00 00       	call   4176 <printf>
    1fdb:	83 c4 10             	add    $0x10,%esp
    exit();
    1fde:	e8 17 20 00 00       	call   3ffa <exit>
  }

  fd = open("dd/ff", O_CREATE | O_RDWR);
    1fe3:	83 ec 08             	sub    $0x8,%esp
    1fe6:	68 02 02 00 00       	push   $0x202
    1feb:	68 34 4f 00 00       	push   $0x4f34
    1ff0:	e8 45 20 00 00       	call   403a <open>
    1ff5:	83 c4 10             	add    $0x10,%esp
    1ff8:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    1ffb:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    1fff:	79 17                	jns    2018 <subdir+0x88>
    printf(1, "create dd/ff failed\n");
    2001:	83 ec 08             	sub    $0x8,%esp
    2004:	68 3a 4f 00 00       	push   $0x4f3a
    2009:	6a 01                	push   $0x1
    200b:	e8 66 21 00 00       	call   4176 <printf>
    2010:	83 c4 10             	add    $0x10,%esp
    exit();
    2013:	e8 e2 1f 00 00       	call   3ffa <exit>
  }
  write(fd, "ff", 2);
    2018:	83 ec 04             	sub    $0x4,%esp
    201b:	6a 02                	push   $0x2
    201d:	68 16 4f 00 00       	push   $0x4f16
    2022:	ff 75 f4             	push   -0xc(%ebp)
    2025:	e8 f0 1f 00 00       	call   401a <write>
    202a:	83 c4 10             	add    $0x10,%esp
  close(fd);
    202d:	83 ec 0c             	sub    $0xc,%esp
    2030:	ff 75 f4             	push   -0xc(%ebp)
    2033:	e8 ea 1f 00 00       	call   4022 <close>
    2038:	83 c4 10             	add    $0x10,%esp

  if(unlink("dd") >= 0){
    203b:	83 ec 0c             	sub    $0xc,%esp
    203e:	68 19 4f 00 00       	push   $0x4f19
    2043:	e8 02 20 00 00       	call   404a <unlink>
    2048:	83 c4 10             	add    $0x10,%esp
    204b:	85 c0                	test   %eax,%eax
    204d:	78 17                	js     2066 <subdir+0xd6>
    printf(1, "unlink dd (non-empty dir) succeeded!\n");
    204f:	83 ec 08             	sub    $0x8,%esp
    2052:	68 50 4f 00 00       	push   $0x4f50
    2057:	6a 01                	push   $0x1
    2059:	e8 18 21 00 00       	call   4176 <printf>
    205e:	83 c4 10             	add    $0x10,%esp
    exit();
    2061:	e8 94 1f 00 00       	call   3ffa <exit>
  }

  if(mkdir("/dd/dd") != 0){
    2066:	83 ec 0c             	sub    $0xc,%esp
    2069:	68 76 4f 00 00       	push   $0x4f76
    206e:	e8 ef 1f 00 00       	call   4062 <mkdir>
    2073:	83 c4 10             	add    $0x10,%esp
    2076:	85 c0                	test   %eax,%eax
    2078:	74 17                	je     2091 <subdir+0x101>
    printf(1, "subdir mkdir dd/dd failed\n");
    207a:	83 ec 08             	sub    $0x8,%esp
    207d:	68 7d 4f 00 00       	push   $0x4f7d
    2082:	6a 01                	push   $0x1
    2084:	e8 ed 20 00 00       	call   4176 <printf>
    2089:	83 c4 10             	add    $0x10,%esp
    exit();
    208c:	e8 69 1f 00 00       	call   3ffa <exit>
  }

  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    2091:	83 ec 08             	sub    $0x8,%esp
    2094:	68 02 02 00 00       	push   $0x202
    2099:	68 98 4f 00 00       	push   $0x4f98
    209e:	e8 97 1f 00 00       	call   403a <open>
    20a3:	83 c4 10             	add    $0x10,%esp
    20a6:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    20a9:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    20ad:	79 17                	jns    20c6 <subdir+0x136>
    printf(1, "create dd/dd/ff failed\n");
    20af:	83 ec 08             	sub    $0x8,%esp
    20b2:	68 a1 4f 00 00       	push   $0x4fa1
    20b7:	6a 01                	push   $0x1
    20b9:	e8 b8 20 00 00       	call   4176 <printf>
    20be:	83 c4 10             	add    $0x10,%esp
    exit();
    20c1:	e8 34 1f 00 00       	call   3ffa <exit>
  }
  write(fd, "FF", 2);
    20c6:	83 ec 04             	sub    $0x4,%esp
    20c9:	6a 02                	push   $0x2
    20cb:	68 b9 4f 00 00       	push   $0x4fb9
    20d0:	ff 75 f4             	push   -0xc(%ebp)
    20d3:	e8 42 1f 00 00       	call   401a <write>
    20d8:	83 c4 10             	add    $0x10,%esp
  close(fd);
    20db:	83 ec 0c             	sub    $0xc,%esp
    20de:	ff 75 f4             	push   -0xc(%ebp)
    20e1:	e8 3c 1f 00 00       	call   4022 <close>
    20e6:	83 c4 10             	add    $0x10,%esp

  fd = open("dd/dd/../ff", 0);
    20e9:	83 ec 08             	sub    $0x8,%esp
    20ec:	6a 00                	push   $0x0
    20ee:	68 bc 4f 00 00       	push   $0x4fbc
    20f3:	e8 42 1f 00 00       	call   403a <open>
    20f8:	83 c4 10             	add    $0x10,%esp
    20fb:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    20fe:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    2102:	79 17                	jns    211b <subdir+0x18b>
    printf(1, "open dd/dd/../ff failed\n");
    2104:	83 ec 08             	sub    $0x8,%esp
    2107:	68 c8 4f 00 00       	push   $0x4fc8
    210c:	6a 01                	push   $0x1
    210e:	e8 63 20 00 00       	call   4176 <printf>
    2113:	83 c4 10             	add    $0x10,%esp
    exit();
    2116:	e8 df 1e 00 00       	call   3ffa <exit>
  }
  cc = read(fd, buf, sizeof(buf));
    211b:	83 ec 04             	sub    $0x4,%esp
    211e:	68 00 20 00 00       	push   $0x2000
    2123:	68 e0 64 00 00       	push   $0x64e0
    2128:	ff 75 f4             	push   -0xc(%ebp)
    212b:	e8 e2 1e 00 00       	call   4012 <read>
    2130:	83 c4 10             	add    $0x10,%esp
    2133:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(cc != 2 || buf[0] != 'f'){
    2136:	83 7d f0 02          	cmpl   $0x2,-0x10(%ebp)
    213a:	75 0b                	jne    2147 <subdir+0x1b7>
    213c:	0f b6 05 e0 64 00 00 	movzbl 0x64e0,%eax
    2143:	3c 66                	cmp    $0x66,%al
    2145:	74 17                	je     215e <subdir+0x1ce>
    printf(1, "dd/dd/../ff wrong content\n");
    2147:	83 ec 08             	sub    $0x8,%esp
    214a:	68 e1 4f 00 00       	push   $0x4fe1
    214f:	6a 01                	push   $0x1
    2151:	e8 20 20 00 00       	call   4176 <printf>
    2156:	83 c4 10             	add    $0x10,%esp
    exit();
    2159:	e8 9c 1e 00 00       	call   3ffa <exit>
  }
  close(fd);
    215e:	83 ec 0c             	sub    $0xc,%esp
    2161:	ff 75 f4             	push   -0xc(%ebp)
    2164:	e8 b9 1e 00 00       	call   4022 <close>
    2169:	83 c4 10             	add    $0x10,%esp

  if(link("dd/dd/ff", "dd/dd/ffff") != 0){
    216c:	83 ec 08             	sub    $0x8,%esp
    216f:	68 fc 4f 00 00       	push   $0x4ffc
    2174:	68 98 4f 00 00       	push   $0x4f98
    2179:	e8 dc 1e 00 00       	call   405a <link>
    217e:	83 c4 10             	add    $0x10,%esp
    2181:	85 c0                	test   %eax,%eax
    2183:	74 17                	je     219c <subdir+0x20c>
    printf(1, "link dd/dd/ff dd/dd/ffff failed\n");
    2185:	83 ec 08             	sub    $0x8,%esp
    2188:	68 08 50 00 00       	push   $0x5008
    218d:	6a 01                	push   $0x1
    218f:	e8 e2 1f 00 00       	call   4176 <printf>
    2194:	83 c4 10             	add    $0x10,%esp
    exit();
    2197:	e8 5e 1e 00 00       	call   3ffa <exit>
  }

  if(unlink("dd/dd/ff") != 0){
    219c:	83 ec 0c             	sub    $0xc,%esp
    219f:	68 98 4f 00 00       	push   $0x4f98
    21a4:	e8 a1 1e 00 00       	call   404a <unlink>
    21a9:	83 c4 10             	add    $0x10,%esp
    21ac:	85 c0                	test   %eax,%eax
    21ae:	74 17                	je     21c7 <subdir+0x237>
    printf(1, "unlink dd/dd/ff failed\n");
    21b0:	83 ec 08             	sub    $0x8,%esp
    21b3:	68 29 50 00 00       	push   $0x5029
    21b8:	6a 01                	push   $0x1
    21ba:	e8 b7 1f 00 00       	call   4176 <printf>
    21bf:	83 c4 10             	add    $0x10,%esp
    exit();
    21c2:	e8 33 1e 00 00       	call   3ffa <exit>
  }
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    21c7:	83 ec 08             	sub    $0x8,%esp
    21ca:	6a 00                	push   $0x0
    21cc:	68 98 4f 00 00       	push   $0x4f98
    21d1:	e8 64 1e 00 00       	call   403a <open>
    21d6:	83 c4 10             	add    $0x10,%esp
    21d9:	85 c0                	test   %eax,%eax
    21db:	78 17                	js     21f4 <subdir+0x264>
    printf(1, "open (unlinked) dd/dd/ff succeeded\n");
    21dd:	83 ec 08             	sub    $0x8,%esp
    21e0:	68 44 50 00 00       	push   $0x5044
    21e5:	6a 01                	push   $0x1
    21e7:	e8 8a 1f 00 00       	call   4176 <printf>
    21ec:	83 c4 10             	add    $0x10,%esp
    exit();
    21ef:	e8 06 1e 00 00       	call   3ffa <exit>
  }

  if(chdir("dd") != 0){
    21f4:	83 ec 0c             	sub    $0xc,%esp
    21f7:	68 19 4f 00 00       	push   $0x4f19
    21fc:	e8 69 1e 00 00       	call   406a <chdir>
    2201:	83 c4 10             	add    $0x10,%esp
    2204:	85 c0                	test   %eax,%eax
    2206:	74 17                	je     221f <subdir+0x28f>
    printf(1, "chdir dd failed\n");
    2208:	83 ec 08             	sub    $0x8,%esp
    220b:	68 68 50 00 00       	push   $0x5068
    2210:	6a 01                	push   $0x1
    2212:	e8 5f 1f 00 00       	call   4176 <printf>
    2217:	83 c4 10             	add    $0x10,%esp
    exit();
    221a:	e8 db 1d 00 00       	call   3ffa <exit>
  }
  if(chdir("dd/../../dd") != 0){
    221f:	83 ec 0c             	sub    $0xc,%esp
    2222:	68 79 50 00 00       	push   $0x5079
    2227:	e8 3e 1e 00 00       	call   406a <chdir>
    222c:	83 c4 10             	add    $0x10,%esp
    222f:	85 c0                	test   %eax,%eax
    2231:	74 17                	je     224a <subdir+0x2ba>
    printf(1, "chdir dd/../../dd failed\n");
    2233:	83 ec 08             	sub    $0x8,%esp
    2236:	68 85 50 00 00       	push   $0x5085
    223b:	6a 01                	push   $0x1
    223d:	e8 34 1f 00 00       	call   4176 <printf>
    2242:	83 c4 10             	add    $0x10,%esp
    exit();
    2245:	e8 b0 1d 00 00       	call   3ffa <exit>
  }
  if(chdir("dd/../../../dd") != 0){
    224a:	83 ec 0c             	sub    $0xc,%esp
    224d:	68 9f 50 00 00       	push   $0x509f
    2252:	e8 13 1e 00 00       	call   406a <chdir>
    2257:	83 c4 10             	add    $0x10,%esp
    225a:	85 c0                	test   %eax,%eax
    225c:	74 17                	je     2275 <subdir+0x2e5>
    printf(1, "chdir dd/../../dd failed\n");
    225e:	83 ec 08             	sub    $0x8,%esp
    2261:	68 85 50 00 00       	push   $0x5085
    2266:	6a 01                	push   $0x1
    2268:	e8 09 1f 00 00       	call   4176 <printf>
    226d:	83 c4 10             	add    $0x10,%esp
    exit();
    2270:	e8 85 1d 00 00       	call   3ffa <exit>
  }
  if(chdir("./..") != 0){
    2275:	83 ec 0c             	sub    $0xc,%esp
    2278:	68 ae 50 00 00       	push   $0x50ae
    227d:	e8 e8 1d 00 00       	call   406a <chdir>
    2282:	83 c4 10             	add    $0x10,%esp
    2285:	85 c0                	test   %eax,%eax
    2287:	74 17                	je     22a0 <subdir+0x310>
    printf(1, "chdir ./.. failed\n");
    2289:	83 ec 08             	sub    $0x8,%esp
    228c:	68 b3 50 00 00       	push   $0x50b3
    2291:	6a 01                	push   $0x1
    2293:	e8 de 1e 00 00       	call   4176 <printf>
    2298:	83 c4 10             	add    $0x10,%esp
    exit();
    229b:	e8 5a 1d 00 00       	call   3ffa <exit>
  }

  fd = open("dd/dd/ffff", 0);
    22a0:	83 ec 08             	sub    $0x8,%esp
    22a3:	6a 00                	push   $0x0
    22a5:	68 fc 4f 00 00       	push   $0x4ffc
    22aa:	e8 8b 1d 00 00       	call   403a <open>
    22af:	83 c4 10             	add    $0x10,%esp
    22b2:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    22b5:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    22b9:	79 17                	jns    22d2 <subdir+0x342>
    printf(1, "open dd/dd/ffff failed\n");
    22bb:	83 ec 08             	sub    $0x8,%esp
    22be:	68 c6 50 00 00       	push   $0x50c6
    22c3:	6a 01                	push   $0x1
    22c5:	e8 ac 1e 00 00       	call   4176 <printf>
    22ca:	83 c4 10             	add    $0x10,%esp
    exit();
    22cd:	e8 28 1d 00 00       	call   3ffa <exit>
  }
  if(read(fd, buf, sizeof(buf)) != 2){
    22d2:	83 ec 04             	sub    $0x4,%esp
    22d5:	68 00 20 00 00       	push   $0x2000
    22da:	68 e0 64 00 00       	push   $0x64e0
    22df:	ff 75 f4             	push   -0xc(%ebp)
    22e2:	e8 2b 1d 00 00       	call   4012 <read>
    22e7:	83 c4 10             	add    $0x10,%esp
    22ea:	83 f8 02             	cmp    $0x2,%eax
    22ed:	74 17                	je     2306 <subdir+0x376>
    printf(1, "read dd/dd/ffff wrong len\n");
    22ef:	83 ec 08             	sub    $0x8,%esp
    22f2:	68 de 50 00 00       	push   $0x50de
    22f7:	6a 01                	push   $0x1
    22f9:	e8 78 1e 00 00       	call   4176 <printf>
    22fe:	83 c4 10             	add    $0x10,%esp
    exit();
    2301:	e8 f4 1c 00 00       	call   3ffa <exit>
  }
  close(fd);
    2306:	83 ec 0c             	sub    $0xc,%esp
    2309:	ff 75 f4             	push   -0xc(%ebp)
    230c:	e8 11 1d 00 00       	call   4022 <close>
    2311:	83 c4 10             	add    $0x10,%esp

  if(open("dd/dd/ff", O_RDONLY) >= 0){
    2314:	83 ec 08             	sub    $0x8,%esp
    2317:	6a 00                	push   $0x0
    2319:	68 98 4f 00 00       	push   $0x4f98
    231e:	e8 17 1d 00 00       	call   403a <open>
    2323:	83 c4 10             	add    $0x10,%esp
    2326:	85 c0                	test   %eax,%eax
    2328:	78 17                	js     2341 <subdir+0x3b1>
    printf(1, "open (unlinked) dd/dd/ff succeeded!\n");
    232a:	83 ec 08             	sub    $0x8,%esp
    232d:	68 fc 50 00 00       	push   $0x50fc
    2332:	6a 01                	push   $0x1
    2334:	e8 3d 1e 00 00       	call   4176 <printf>
    2339:	83 c4 10             	add    $0x10,%esp
    exit();
    233c:	e8 b9 1c 00 00       	call   3ffa <exit>
  }

  if(open("dd/ff/ff", O_CREATE|O_RDWR) >= 0){
    2341:	83 ec 08             	sub    $0x8,%esp
    2344:	68 02 02 00 00       	push   $0x202
    2349:	68 21 51 00 00       	push   $0x5121
    234e:	e8 e7 1c 00 00       	call   403a <open>
    2353:	83 c4 10             	add    $0x10,%esp
    2356:	85 c0                	test   %eax,%eax
    2358:	78 17                	js     2371 <subdir+0x3e1>
    printf(1, "create dd/ff/ff succeeded!\n");
    235a:	83 ec 08             	sub    $0x8,%esp
    235d:	68 2a 51 00 00       	push   $0x512a
    2362:	6a 01                	push   $0x1
    2364:	e8 0d 1e 00 00       	call   4176 <printf>
    2369:	83 c4 10             	add    $0x10,%esp
    exit();
    236c:	e8 89 1c 00 00       	call   3ffa <exit>
  }
  if(open("dd/xx/ff", O_CREATE|O_RDWR) >= 0){
    2371:	83 ec 08             	sub    $0x8,%esp
    2374:	68 02 02 00 00       	push   $0x202
    2379:	68 46 51 00 00       	push   $0x5146
    237e:	e8 b7 1c 00 00       	call   403a <open>
    2383:	83 c4 10             	add    $0x10,%esp
    2386:	85 c0                	test   %eax,%eax
    2388:	78 17                	js     23a1 <subdir+0x411>
    printf(1, "create dd/xx/ff succeeded!\n");
    238a:	83 ec 08             	sub    $0x8,%esp
    238d:	68 4f 51 00 00       	push   $0x514f
    2392:	6a 01                	push   $0x1
    2394:	e8 dd 1d 00 00       	call   4176 <printf>
    2399:	83 c4 10             	add    $0x10,%esp
    exit();
    239c:	e8 59 1c 00 00       	call   3ffa <exit>
  }
  if(open("dd", O_CREATE) >= 0){
    23a1:	83 ec 08             	sub    $0x8,%esp
    23a4:	68 00 02 00 00       	push   $0x200
    23a9:	68 19 4f 00 00       	push   $0x4f19
    23ae:	e8 87 1c 00 00       	call   403a <open>
    23b3:	83 c4 10             	add    $0x10,%esp
    23b6:	85 c0                	test   %eax,%eax
    23b8:	78 17                	js     23d1 <subdir+0x441>
    printf(1, "create dd succeeded!\n");
    23ba:	83 ec 08             	sub    $0x8,%esp
    23bd:	68 6b 51 00 00       	push   $0x516b
    23c2:	6a 01                	push   $0x1
    23c4:	e8 ad 1d 00 00       	call   4176 <printf>
    23c9:	83 c4 10             	add    $0x10,%esp
    exit();
    23cc:	e8 29 1c 00 00       	call   3ffa <exit>
  }
  if(open("dd", O_RDWR) >= 0){
    23d1:	83 ec 08             	sub    $0x8,%esp
    23d4:	6a 02                	push   $0x2
    23d6:	68 19 4f 00 00       	push   $0x4f19
    23db:	e8 5a 1c 00 00       	call   403a <open>
    23e0:	83 c4 10             	add    $0x10,%esp
    23e3:	85 c0                	test   %eax,%eax
    23e5:	78 17                	js     23fe <subdir+0x46e>
    printf(1, "open dd rdwr succeeded!\n");
    23e7:	83 ec 08             	sub    $0x8,%esp
    23ea:	68 81 51 00 00       	push   $0x5181
    23ef:	6a 01                	push   $0x1
    23f1:	e8 80 1d 00 00       	call   4176 <printf>
    23f6:	83 c4 10             	add    $0x10,%esp
    exit();
    23f9:	e8 fc 1b 00 00       	call   3ffa <exit>
  }
  if(open("dd", O_WRONLY) >= 0){
    23fe:	83 ec 08             	sub    $0x8,%esp
    2401:	6a 01                	push   $0x1
    2403:	68 19 4f 00 00       	push   $0x4f19
    2408:	e8 2d 1c 00 00       	call   403a <open>
    240d:	83 c4 10             	add    $0x10,%esp
    2410:	85 c0                	test   %eax,%eax
    2412:	78 17                	js     242b <subdir+0x49b>
    printf(1, "open dd wronly succeeded!\n");
    2414:	83 ec 08             	sub    $0x8,%esp
    2417:	68 9a 51 00 00       	push   $0x519a
    241c:	6a 01                	push   $0x1
    241e:	e8 53 1d 00 00       	call   4176 <printf>
    2423:	83 c4 10             	add    $0x10,%esp
    exit();
    2426:	e8 cf 1b 00 00       	call   3ffa <exit>
  }
  if(link("dd/ff/ff", "dd/dd/xx") == 0){
    242b:	83 ec 08             	sub    $0x8,%esp
    242e:	68 b5 51 00 00       	push   $0x51b5
    2433:	68 21 51 00 00       	push   $0x5121
    2438:	e8 1d 1c 00 00       	call   405a <link>
    243d:	83 c4 10             	add    $0x10,%esp
    2440:	85 c0                	test   %eax,%eax
    2442:	75 17                	jne    245b <subdir+0x4cb>
    printf(1, "link dd/ff/ff dd/dd/xx succeeded!\n");
    2444:	83 ec 08             	sub    $0x8,%esp
    2447:	68 c0 51 00 00       	push   $0x51c0
    244c:	6a 01                	push   $0x1
    244e:	e8 23 1d 00 00       	call   4176 <printf>
    2453:	83 c4 10             	add    $0x10,%esp
    exit();
    2456:	e8 9f 1b 00 00       	call   3ffa <exit>
  }
  if(link("dd/xx/ff", "dd/dd/xx") == 0){
    245b:	83 ec 08             	sub    $0x8,%esp
    245e:	68 b5 51 00 00       	push   $0x51b5
    2463:	68 46 51 00 00       	push   $0x5146
    2468:	e8 ed 1b 00 00       	call   405a <link>
    246d:	83 c4 10             	add    $0x10,%esp
    2470:	85 c0                	test   %eax,%eax
    2472:	75 17                	jne    248b <subdir+0x4fb>
    printf(1, "link dd/xx/ff dd/dd/xx succeeded!\n");
    2474:	83 ec 08             	sub    $0x8,%esp
    2477:	68 e4 51 00 00       	push   $0x51e4
    247c:	6a 01                	push   $0x1
    247e:	e8 f3 1c 00 00       	call   4176 <printf>
    2483:	83 c4 10             	add    $0x10,%esp
    exit();
    2486:	e8 6f 1b 00 00       	call   3ffa <exit>
  }
  if(link("dd/ff", "dd/dd/ffff") == 0){
    248b:	83 ec 08             	sub    $0x8,%esp
    248e:	68 fc 4f 00 00       	push   $0x4ffc
    2493:	68 34 4f 00 00       	push   $0x4f34
    2498:	e8 bd 1b 00 00       	call   405a <link>
    249d:	83 c4 10             	add    $0x10,%esp
    24a0:	85 c0                	test   %eax,%eax
    24a2:	75 17                	jne    24bb <subdir+0x52b>
    printf(1, "link dd/ff dd/dd/ffff succeeded!\n");
    24a4:	83 ec 08             	sub    $0x8,%esp
    24a7:	68 08 52 00 00       	push   $0x5208
    24ac:	6a 01                	push   $0x1
    24ae:	e8 c3 1c 00 00       	call   4176 <printf>
    24b3:	83 c4 10             	add    $0x10,%esp
    exit();
    24b6:	e8 3f 1b 00 00       	call   3ffa <exit>
  }
  if(mkdir("dd/ff/ff") == 0){
    24bb:	83 ec 0c             	sub    $0xc,%esp
    24be:	68 21 51 00 00       	push   $0x5121
    24c3:	e8 9a 1b 00 00       	call   4062 <mkdir>
    24c8:	83 c4 10             	add    $0x10,%esp
    24cb:	85 c0                	test   %eax,%eax
    24cd:	75 17                	jne    24e6 <subdir+0x556>
    printf(1, "mkdir dd/ff/ff succeeded!\n");
    24cf:	83 ec 08             	sub    $0x8,%esp
    24d2:	68 2a 52 00 00       	push   $0x522a
    24d7:	6a 01                	push   $0x1
    24d9:	e8 98 1c 00 00       	call   4176 <printf>
    24de:	83 c4 10             	add    $0x10,%esp
    exit();
    24e1:	e8 14 1b 00 00       	call   3ffa <exit>
  }
  if(mkdir("dd/xx/ff") == 0){
    24e6:	83 ec 0c             	sub    $0xc,%esp
    24e9:	68 46 51 00 00       	push   $0x5146
    24ee:	e8 6f 1b 00 00       	call   4062 <mkdir>
    24f3:	83 c4 10             	add    $0x10,%esp
    24f6:	85 c0                	test   %eax,%eax
    24f8:	75 17                	jne    2511 <subdir+0x581>
    printf(1, "mkdir dd/xx/ff succeeded!\n");
    24fa:	83 ec 08             	sub    $0x8,%esp
    24fd:	68 45 52 00 00       	push   $0x5245
    2502:	6a 01                	push   $0x1
    2504:	e8 6d 1c 00 00       	call   4176 <printf>
    2509:	83 c4 10             	add    $0x10,%esp
    exit();
    250c:	e8 e9 1a 00 00       	call   3ffa <exit>
  }
  if(mkdir("dd/dd/ffff") == 0){
    2511:	83 ec 0c             	sub    $0xc,%esp
    2514:	68 fc 4f 00 00       	push   $0x4ffc
    2519:	e8 44 1b 00 00       	call   4062 <mkdir>
    251e:	83 c4 10             	add    $0x10,%esp
    2521:	85 c0                	test   %eax,%eax
    2523:	75 17                	jne    253c <subdir+0x5ac>
    printf(1, "mkdir dd/dd/ffff succeeded!\n");
    2525:	83 ec 08             	sub    $0x8,%esp
    2528:	68 60 52 00 00       	push   $0x5260
    252d:	6a 01                	push   $0x1
    252f:	e8 42 1c 00 00       	call   4176 <printf>
    2534:	83 c4 10             	add    $0x10,%esp
    exit();
    2537:	e8 be 1a 00 00       	call   3ffa <exit>
  }
  if(unlink("dd/xx/ff") == 0){
    253c:	83 ec 0c             	sub    $0xc,%esp
    253f:	68 46 51 00 00       	push   $0x5146
    2544:	e8 01 1b 00 00       	call   404a <unlink>
    2549:	83 c4 10             	add    $0x10,%esp
    254c:	85 c0                	test   %eax,%eax
    254e:	75 17                	jne    2567 <subdir+0x5d7>
    printf(1, "unlink dd/xx/ff succeeded!\n");
    2550:	83 ec 08             	sub    $0x8,%esp
    2553:	68 7d 52 00 00       	push   $0x527d
    2558:	6a 01                	push   $0x1
    255a:	e8 17 1c 00 00       	call   4176 <printf>
    255f:	83 c4 10             	add    $0x10,%esp
    exit();
    2562:	e8 93 1a 00 00       	call   3ffa <exit>
  }
  if(unlink("dd/ff/ff") == 0){
    2567:	83 ec 0c             	sub    $0xc,%esp
    256a:	68 21 51 00 00       	push   $0x5121
    256f:	e8 d6 1a 00 00       	call   404a <unlink>
    2574:	83 c4 10             	add    $0x10,%esp
    2577:	85 c0                	test   %eax,%eax
    2579:	75 17                	jne    2592 <subdir+0x602>
    printf(1, "unlink dd/ff/ff succeeded!\n");
    257b:	83 ec 08             	sub    $0x8,%esp
    257e:	68 99 52 00 00       	push   $0x5299
    2583:	6a 01                	push   $0x1
    2585:	e8 ec 1b 00 00       	call   4176 <printf>
    258a:	83 c4 10             	add    $0x10,%esp
    exit();
    258d:	e8 68 1a 00 00       	call   3ffa <exit>
  }
  if(chdir("dd/ff") == 0){
    2592:	83 ec 0c             	sub    $0xc,%esp
    2595:	68 34 4f 00 00       	push   $0x4f34
    259a:	e8 cb 1a 00 00       	call   406a <chdir>
    259f:	83 c4 10             	add    $0x10,%esp
    25a2:	85 c0                	test   %eax,%eax
    25a4:	75 17                	jne    25bd <subdir+0x62d>
    printf(1, "chdir dd/ff succeeded!\n");
    25a6:	83 ec 08             	sub    $0x8,%esp
    25a9:	68 b5 52 00 00       	push   $0x52b5
    25ae:	6a 01                	push   $0x1
    25b0:	e8 c1 1b 00 00       	call   4176 <printf>
    25b5:	83 c4 10             	add    $0x10,%esp
    exit();
    25b8:	e8 3d 1a 00 00       	call   3ffa <exit>
  }
  if(chdir("dd/xx") == 0){
    25bd:	83 ec 0c             	sub    $0xc,%esp
    25c0:	68 cd 52 00 00       	push   $0x52cd
    25c5:	e8 a0 1a 00 00       	call   406a <chdir>
    25ca:	83 c4 10             	add    $0x10,%esp
    25cd:	85 c0                	test   %eax,%eax
    25cf:	75 17                	jne    25e8 <subdir+0x658>
    printf(1, "chdir dd/xx succeeded!\n");
    25d1:	83 ec 08             	sub    $0x8,%esp
    25d4:	68 d3 52 00 00       	push   $0x52d3
    25d9:	6a 01                	push   $0x1
    25db:	e8 96 1b 00 00       	call   4176 <printf>
    25e0:	83 c4 10             	add    $0x10,%esp
    exit();
    25e3:	e8 12 1a 00 00       	call   3ffa <exit>
  }

  if(unlink("dd/dd/ffff") != 0){
    25e8:	83 ec 0c             	sub    $0xc,%esp
    25eb:	68 fc 4f 00 00       	push   $0x4ffc
    25f0:	e8 55 1a 00 00       	call   404a <unlink>
    25f5:	83 c4 10             	add    $0x10,%esp
    25f8:	85 c0                	test   %eax,%eax
    25fa:	74 17                	je     2613 <subdir+0x683>
    printf(1, "unlink dd/dd/ff failed\n");
    25fc:	83 ec 08             	sub    $0x8,%esp
    25ff:	68 29 50 00 00       	push   $0x5029
    2604:	6a 01                	push   $0x1
    2606:	e8 6b 1b 00 00       	call   4176 <printf>
    260b:	83 c4 10             	add    $0x10,%esp
    exit();
    260e:	e8 e7 19 00 00       	call   3ffa <exit>
  }
  if(unlink("dd/ff") != 0){
    2613:	83 ec 0c             	sub    $0xc,%esp
    2616:	68 34 4f 00 00       	push   $0x4f34
    261b:	e8 2a 1a 00 00       	call   404a <unlink>
    2620:	83 c4 10             	add    $0x10,%esp
    2623:	85 c0                	test   %eax,%eax
    2625:	74 17                	je     263e <subdir+0x6ae>
    printf(1, "unlink dd/ff failed\n");
    2627:	83 ec 08             	sub    $0x8,%esp
    262a:	68 eb 52 00 00       	push   $0x52eb
    262f:	6a 01                	push   $0x1
    2631:	e8 40 1b 00 00       	call   4176 <printf>
    2636:	83 c4 10             	add    $0x10,%esp
    exit();
    2639:	e8 bc 19 00 00       	call   3ffa <exit>
  }
  if(unlink("dd") == 0){
    263e:	83 ec 0c             	sub    $0xc,%esp
    2641:	68 19 4f 00 00       	push   $0x4f19
    2646:	e8 ff 19 00 00       	call   404a <unlink>
    264b:	83 c4 10             	add    $0x10,%esp
    264e:	85 c0                	test   %eax,%eax
    2650:	75 17                	jne    2669 <subdir+0x6d9>
    printf(1, "unlink non-empty dd succeeded!\n");
    2652:	83 ec 08             	sub    $0x8,%esp
    2655:	68 00 53 00 00       	push   $0x5300
    265a:	6a 01                	push   $0x1
    265c:	e8 15 1b 00 00       	call   4176 <printf>
    2661:	83 c4 10             	add    $0x10,%esp
    exit();
    2664:	e8 91 19 00 00       	call   3ffa <exit>
  }
  if(unlink("dd/dd") < 0){
    2669:	83 ec 0c             	sub    $0xc,%esp
    266c:	68 20 53 00 00       	push   $0x5320
    2671:	e8 d4 19 00 00       	call   404a <unlink>
    2676:	83 c4 10             	add    $0x10,%esp
    2679:	85 c0                	test   %eax,%eax
    267b:	79 17                	jns    2694 <subdir+0x704>
    printf(1, "unlink dd/dd failed\n");
    267d:	83 ec 08             	sub    $0x8,%esp
    2680:	68 26 53 00 00       	push   $0x5326
    2685:	6a 01                	push   $0x1
    2687:	e8 ea 1a 00 00       	call   4176 <printf>
    268c:	83 c4 10             	add    $0x10,%esp
    exit();
    268f:	e8 66 19 00 00       	call   3ffa <exit>
  }
  if(unlink("dd") < 0){
    2694:	83 ec 0c             	sub    $0xc,%esp
    2697:	68 19 4f 00 00       	push   $0x4f19
    269c:	e8 a9 19 00 00       	call   404a <unlink>
    26a1:	83 c4 10             	add    $0x10,%esp
    26a4:	85 c0                	test   %eax,%eax
    26a6:	79 17                	jns    26bf <subdir+0x72f>
    printf(1, "unlink dd failed\n");
    26a8:	83 ec 08             	sub    $0x8,%esp
    26ab:	68 3b 53 00 00       	push   $0x533b
    26b0:	6a 01                	push   $0x1
    26b2:	e8 bf 1a 00 00       	call   4176 <printf>
    26b7:	83 c4 10             	add    $0x10,%esp
    exit();
    26ba:	e8 3b 19 00 00       	call   3ffa <exit>
  }

  printf(1, "subdir ok\n");
    26bf:	83 ec 08             	sub    $0x8,%esp
    26c2:	68 4d 53 00 00       	push   $0x534d
    26c7:	6a 01                	push   $0x1
    26c9:	e8 a8 1a 00 00       	call   4176 <printf>
    26ce:	83 c4 10             	add    $0x10,%esp
}
    26d1:	90                   	nop
    26d2:	c9                   	leave
    26d3:	c3                   	ret

000026d4 <bigwrite>:

// test writes that are larger than the log.
void
bigwrite(void)
{
    26d4:	55                   	push   %ebp
    26d5:	89 e5                	mov    %esp,%ebp
    26d7:	83 ec 18             	sub    $0x18,%esp
  int fd, sz;

  printf(1, "bigwrite test\n");
    26da:	83 ec 08             	sub    $0x8,%esp
    26dd:	68 58 53 00 00       	push   $0x5358
    26e2:	6a 01                	push   $0x1
    26e4:	e8 8d 1a 00 00       	call   4176 <printf>
    26e9:	83 c4 10             	add    $0x10,%esp

  unlink("bigwrite");
    26ec:	83 ec 0c             	sub    $0xc,%esp
    26ef:	68 67 53 00 00       	push   $0x5367
    26f4:	e8 51 19 00 00       	call   404a <unlink>
    26f9:	83 c4 10             	add    $0x10,%esp
  for(sz = 499; sz < 12*512; sz += 471){
    26fc:	c7 45 f4 f3 01 00 00 	movl   $0x1f3,-0xc(%ebp)
    2703:	e9 a8 00 00 00       	jmp    27b0 <bigwrite+0xdc>
    fd = open("bigwrite", O_CREATE | O_RDWR);
    2708:	83 ec 08             	sub    $0x8,%esp
    270b:	68 02 02 00 00       	push   $0x202
    2710:	68 67 53 00 00       	push   $0x5367
    2715:	e8 20 19 00 00       	call   403a <open>
    271a:	83 c4 10             	add    $0x10,%esp
    271d:	89 45 ec             	mov    %eax,-0x14(%ebp)
    if(fd < 0){
    2720:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    2724:	79 17                	jns    273d <bigwrite+0x69>
      printf(1, "cannot create bigwrite\n");
    2726:	83 ec 08             	sub    $0x8,%esp
    2729:	68 70 53 00 00       	push   $0x5370
    272e:	6a 01                	push   $0x1
    2730:	e8 41 1a 00 00       	call   4176 <printf>
    2735:	83 c4 10             	add    $0x10,%esp
      exit();
    2738:	e8 bd 18 00 00       	call   3ffa <exit>
    }
    int i;
    for(i = 0; i < 2; i++){
    273d:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    2744:	eb 3f                	jmp    2785 <bigwrite+0xb1>
      int cc = write(fd, buf, sz);
    2746:	83 ec 04             	sub    $0x4,%esp
    2749:	ff 75 f4             	push   -0xc(%ebp)
    274c:	68 e0 64 00 00       	push   $0x64e0
    2751:	ff 75 ec             	push   -0x14(%ebp)
    2754:	e8 c1 18 00 00       	call   401a <write>
    2759:	83 c4 10             	add    $0x10,%esp
    275c:	89 45 e8             	mov    %eax,-0x18(%ebp)
      if(cc != sz){
    275f:	8b 45 e8             	mov    -0x18(%ebp),%eax
    2762:	3b 45 f4             	cmp    -0xc(%ebp),%eax
    2765:	74 1a                	je     2781 <bigwrite+0xad>
        printf(1, "write(%d) ret %d\n", sz, cc);
    2767:	ff 75 e8             	push   -0x18(%ebp)
    276a:	ff 75 f4             	push   -0xc(%ebp)
    276d:	68 88 53 00 00       	push   $0x5388
    2772:	6a 01                	push   $0x1
    2774:	e8 fd 19 00 00       	call   4176 <printf>
    2779:	83 c4 10             	add    $0x10,%esp
        exit();
    277c:	e8 79 18 00 00       	call   3ffa <exit>
    for(i = 0; i < 2; i++){
    2781:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    2785:	83 7d f0 01          	cmpl   $0x1,-0x10(%ebp)
    2789:	7e bb                	jle    2746 <bigwrite+0x72>
      }
    }
    close(fd);
    278b:	83 ec 0c             	sub    $0xc,%esp
    278e:	ff 75 ec             	push   -0x14(%ebp)
    2791:	e8 8c 18 00 00       	call   4022 <close>
    2796:	83 c4 10             	add    $0x10,%esp
    unlink("bigwrite");
    2799:	83 ec 0c             	sub    $0xc,%esp
    279c:	68 67 53 00 00       	push   $0x5367
    27a1:	e8 a4 18 00 00       	call   404a <unlink>
    27a6:	83 c4 10             	add    $0x10,%esp
  for(sz = 499; sz < 12*512; sz += 471){
    27a9:	81 45 f4 d7 01 00 00 	addl   $0x1d7,-0xc(%ebp)
    27b0:	81 7d f4 ff 17 00 00 	cmpl   $0x17ff,-0xc(%ebp)
    27b7:	0f 8e 4b ff ff ff    	jle    2708 <bigwrite+0x34>
  }

  printf(1, "bigwrite ok\n");
    27bd:	83 ec 08             	sub    $0x8,%esp
    27c0:	68 9a 53 00 00       	push   $0x539a
    27c5:	6a 01                	push   $0x1
    27c7:	e8 aa 19 00 00       	call   4176 <printf>
    27cc:	83 c4 10             	add    $0x10,%esp
}
    27cf:	90                   	nop
    27d0:	c9                   	leave
    27d1:	c3                   	ret

000027d2 <bigfile>:

void
bigfile(void)
{
    27d2:	55                   	push   %ebp
    27d3:	89 e5                	mov    %esp,%ebp
    27d5:	83 ec 18             	sub    $0x18,%esp
  int fd, i, total, cc;

  printf(1, "bigfile test\n");
    27d8:	83 ec 08             	sub    $0x8,%esp
    27db:	68 a7 53 00 00       	push   $0x53a7
    27e0:	6a 01                	push   $0x1
    27e2:	e8 8f 19 00 00       	call   4176 <printf>
    27e7:	83 c4 10             	add    $0x10,%esp

  unlink("bigfile");
    27ea:	83 ec 0c             	sub    $0xc,%esp
    27ed:	68 b5 53 00 00       	push   $0x53b5
    27f2:	e8 53 18 00 00       	call   404a <unlink>
    27f7:	83 c4 10             	add    $0x10,%esp
  fd = open("bigfile", O_CREATE | O_RDWR);
    27fa:	83 ec 08             	sub    $0x8,%esp
    27fd:	68 02 02 00 00       	push   $0x202
    2802:	68 b5 53 00 00       	push   $0x53b5
    2807:	e8 2e 18 00 00       	call   403a <open>
    280c:	83 c4 10             	add    $0x10,%esp
    280f:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if(fd < 0){
    2812:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    2816:	79 17                	jns    282f <bigfile+0x5d>
    printf(1, "cannot create bigfile");
    2818:	83 ec 08             	sub    $0x8,%esp
    281b:	68 bd 53 00 00       	push   $0x53bd
    2820:	6a 01                	push   $0x1
    2822:	e8 4f 19 00 00       	call   4176 <printf>
    2827:	83 c4 10             	add    $0x10,%esp
    exit();
    282a:	e8 cb 17 00 00       	call   3ffa <exit>
  }
  for(i = 0; i < 20; i++){
    282f:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    2836:	eb 52                	jmp    288a <bigfile+0xb8>
    memset(buf, i, 600);
    2838:	83 ec 04             	sub    $0x4,%esp
    283b:	68 58 02 00 00       	push   $0x258
    2840:	ff 75 f4             	push   -0xc(%ebp)
    2843:	68 e0 64 00 00       	push   $0x64e0
    2848:	e8 12 16 00 00       	call   3e5f <memset>
    284d:	83 c4 10             	add    $0x10,%esp
    if(write(fd, buf, 600) != 600){
    2850:	83 ec 04             	sub    $0x4,%esp
    2853:	68 58 02 00 00       	push   $0x258
    2858:	68 e0 64 00 00       	push   $0x64e0
    285d:	ff 75 ec             	push   -0x14(%ebp)
    2860:	e8 b5 17 00 00       	call   401a <write>
    2865:	83 c4 10             	add    $0x10,%esp
    2868:	3d 58 02 00 00       	cmp    $0x258,%eax
    286d:	74 17                	je     2886 <bigfile+0xb4>
      printf(1, "write bigfile failed\n");
    286f:	83 ec 08             	sub    $0x8,%esp
    2872:	68 d3 53 00 00       	push   $0x53d3
    2877:	6a 01                	push   $0x1
    2879:	e8 f8 18 00 00       	call   4176 <printf>
    287e:	83 c4 10             	add    $0x10,%esp
      exit();
    2881:	e8 74 17 00 00       	call   3ffa <exit>
  for(i = 0; i < 20; i++){
    2886:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    288a:	83 7d f4 13          	cmpl   $0x13,-0xc(%ebp)
    288e:	7e a8                	jle    2838 <bigfile+0x66>
    }
  }
  close(fd);
    2890:	83 ec 0c             	sub    $0xc,%esp
    2893:	ff 75 ec             	push   -0x14(%ebp)
    2896:	e8 87 17 00 00       	call   4022 <close>
    289b:	83 c4 10             	add    $0x10,%esp

  fd = open("bigfile", 0);
    289e:	83 ec 08             	sub    $0x8,%esp
    28a1:	6a 00                	push   $0x0
    28a3:	68 b5 53 00 00       	push   $0x53b5
    28a8:	e8 8d 17 00 00       	call   403a <open>
    28ad:	83 c4 10             	add    $0x10,%esp
    28b0:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if(fd < 0){
    28b3:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    28b7:	79 17                	jns    28d0 <bigfile+0xfe>
    printf(1, "cannot open bigfile\n");
    28b9:	83 ec 08             	sub    $0x8,%esp
    28bc:	68 e9 53 00 00       	push   $0x53e9
    28c1:	6a 01                	push   $0x1
    28c3:	e8 ae 18 00 00       	call   4176 <printf>
    28c8:	83 c4 10             	add    $0x10,%esp
    exit();
    28cb:	e8 2a 17 00 00       	call   3ffa <exit>
  }
  total = 0;
    28d0:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  for(i = 0; ; i++){
    28d7:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    cc = read(fd, buf, 300);
    28de:	83 ec 04             	sub    $0x4,%esp
    28e1:	68 2c 01 00 00       	push   $0x12c
    28e6:	68 e0 64 00 00       	push   $0x64e0
    28eb:	ff 75 ec             	push   -0x14(%ebp)
    28ee:	e8 1f 17 00 00       	call   4012 <read>
    28f3:	83 c4 10             	add    $0x10,%esp
    28f6:	89 45 e8             	mov    %eax,-0x18(%ebp)
    if(cc < 0){
    28f9:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    28fd:	79 17                	jns    2916 <bigfile+0x144>
      printf(1, "read bigfile failed\n");
    28ff:	83 ec 08             	sub    $0x8,%esp
    2902:	68 fe 53 00 00       	push   $0x53fe
    2907:	6a 01                	push   $0x1
    2909:	e8 68 18 00 00       	call   4176 <printf>
    290e:	83 c4 10             	add    $0x10,%esp
      exit();
    2911:	e8 e4 16 00 00       	call   3ffa <exit>
    }
    if(cc == 0)
    2916:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    291a:	74 7a                	je     2996 <bigfile+0x1c4>
      break;
    if(cc != 300){
    291c:	81 7d e8 2c 01 00 00 	cmpl   $0x12c,-0x18(%ebp)
    2923:	74 17                	je     293c <bigfile+0x16a>
      printf(1, "short read bigfile\n");
    2925:	83 ec 08             	sub    $0x8,%esp
    2928:	68 13 54 00 00       	push   $0x5413
    292d:	6a 01                	push   $0x1
    292f:	e8 42 18 00 00       	call   4176 <printf>
    2934:	83 c4 10             	add    $0x10,%esp
      exit();
    2937:	e8 be 16 00 00       	call   3ffa <exit>
    }
    if(buf[0] != i/2 || buf[299] != i/2){
    293c:	0f b6 05 e0 64 00 00 	movzbl 0x64e0,%eax
    2943:	0f be d0             	movsbl %al,%edx
    2946:	8b 45 f4             	mov    -0xc(%ebp),%eax
    2949:	89 c1                	mov    %eax,%ecx
    294b:	c1 e9 1f             	shr    $0x1f,%ecx
    294e:	01 c8                	add    %ecx,%eax
    2950:	d1 f8                	sar    $1,%eax
    2952:	39 c2                	cmp    %eax,%edx
    2954:	75 1a                	jne    2970 <bigfile+0x19e>
    2956:	0f b6 05 0b 66 00 00 	movzbl 0x660b,%eax
    295d:	0f be d0             	movsbl %al,%edx
    2960:	8b 45 f4             	mov    -0xc(%ebp),%eax
    2963:	89 c1                	mov    %eax,%ecx
    2965:	c1 e9 1f             	shr    $0x1f,%ecx
    2968:	01 c8                	add    %ecx,%eax
    296a:	d1 f8                	sar    $1,%eax
    296c:	39 c2                	cmp    %eax,%edx
    296e:	74 17                	je     2987 <bigfile+0x1b5>
      printf(1, "read bigfile wrong data\n");
    2970:	83 ec 08             	sub    $0x8,%esp
    2973:	68 27 54 00 00       	push   $0x5427
    2978:	6a 01                	push   $0x1
    297a:	e8 f7 17 00 00       	call   4176 <printf>
    297f:	83 c4 10             	add    $0x10,%esp
      exit();
    2982:	e8 73 16 00 00       	call   3ffa <exit>
    }
    total += cc;
    2987:	8b 45 e8             	mov    -0x18(%ebp),%eax
    298a:	01 45 f0             	add    %eax,-0x10(%ebp)
  for(i = 0; ; i++){
    298d:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    cc = read(fd, buf, 300);
    2991:	e9 48 ff ff ff       	jmp    28de <bigfile+0x10c>
      break;
    2996:	90                   	nop
  }
  close(fd);
    2997:	83 ec 0c             	sub    $0xc,%esp
    299a:	ff 75 ec             	push   -0x14(%ebp)
    299d:	e8 80 16 00 00       	call   4022 <close>
    29a2:	83 c4 10             	add    $0x10,%esp
  if(total != 20*600){
    29a5:	81 7d f0 e0 2e 00 00 	cmpl   $0x2ee0,-0x10(%ebp)
    29ac:	74 17                	je     29c5 <bigfile+0x1f3>
    printf(1, "read bigfile wrong total\n");
    29ae:	83 ec 08             	sub    $0x8,%esp
    29b1:	68 40 54 00 00       	push   $0x5440
    29b6:	6a 01                	push   $0x1
    29b8:	e8 b9 17 00 00       	call   4176 <printf>
    29bd:	83 c4 10             	add    $0x10,%esp
    exit();
    29c0:	e8 35 16 00 00       	call   3ffa <exit>
  }
  unlink("bigfile");
    29c5:	83 ec 0c             	sub    $0xc,%esp
    29c8:	68 b5 53 00 00       	push   $0x53b5
    29cd:	e8 78 16 00 00       	call   404a <unlink>
    29d2:	83 c4 10             	add    $0x10,%esp

  printf(1, "bigfile test ok\n");
    29d5:	83 ec 08             	sub    $0x8,%esp
    29d8:	68 5a 54 00 00       	push   $0x545a
    29dd:	6a 01                	push   $0x1
    29df:	e8 92 17 00 00       	call   4176 <printf>
    29e4:	83 c4 10             	add    $0x10,%esp
}
    29e7:	90                   	nop
    29e8:	c9                   	leave
    29e9:	c3                   	ret

000029ea <fourteen>:

void
fourteen(void)
{
    29ea:	55                   	push   %ebp
    29eb:	89 e5                	mov    %esp,%ebp
    29ed:	83 ec 18             	sub    $0x18,%esp
  int fd;

  // DIRSIZ is 14.
  printf(1, "fourteen test\n");
    29f0:	83 ec 08             	sub    $0x8,%esp
    29f3:	68 6b 54 00 00       	push   $0x546b
    29f8:	6a 01                	push   $0x1
    29fa:	e8 77 17 00 00       	call   4176 <printf>
    29ff:	83 c4 10             	add    $0x10,%esp

  if(mkdir("12345678901234") != 0){
    2a02:	83 ec 0c             	sub    $0xc,%esp
    2a05:	68 7a 54 00 00       	push   $0x547a
    2a0a:	e8 53 16 00 00       	call   4062 <mkdir>
    2a0f:	83 c4 10             	add    $0x10,%esp
    2a12:	85 c0                	test   %eax,%eax
    2a14:	74 17                	je     2a2d <fourteen+0x43>
    printf(1, "mkdir 12345678901234 failed\n");
    2a16:	83 ec 08             	sub    $0x8,%esp
    2a19:	68 89 54 00 00       	push   $0x5489
    2a1e:	6a 01                	push   $0x1
    2a20:	e8 51 17 00 00       	call   4176 <printf>
    2a25:	83 c4 10             	add    $0x10,%esp
    exit();
    2a28:	e8 cd 15 00 00       	call   3ffa <exit>
  }
  if(mkdir("12345678901234/123456789012345") != 0){
    2a2d:	83 ec 0c             	sub    $0xc,%esp
    2a30:	68 a8 54 00 00       	push   $0x54a8
    2a35:	e8 28 16 00 00       	call   4062 <mkdir>
    2a3a:	83 c4 10             	add    $0x10,%esp
    2a3d:	85 c0                	test   %eax,%eax
    2a3f:	74 17                	je     2a58 <fourteen+0x6e>
    printf(1, "mkdir 12345678901234/123456789012345 failed\n");
    2a41:	83 ec 08             	sub    $0x8,%esp
    2a44:	68 c8 54 00 00       	push   $0x54c8
    2a49:	6a 01                	push   $0x1
    2a4b:	e8 26 17 00 00       	call   4176 <printf>
    2a50:	83 c4 10             	add    $0x10,%esp
    exit();
    2a53:	e8 a2 15 00 00       	call   3ffa <exit>
  }
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    2a58:	83 ec 08             	sub    $0x8,%esp
    2a5b:	68 00 02 00 00       	push   $0x200
    2a60:	68 f8 54 00 00       	push   $0x54f8
    2a65:	e8 d0 15 00 00       	call   403a <open>
    2a6a:	83 c4 10             	add    $0x10,%esp
    2a6d:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    2a70:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    2a74:	79 17                	jns    2a8d <fourteen+0xa3>
    printf(1, "create 123456789012345/123456789012345/123456789012345 failed\n");
    2a76:	83 ec 08             	sub    $0x8,%esp
    2a79:	68 28 55 00 00       	push   $0x5528
    2a7e:	6a 01                	push   $0x1
    2a80:	e8 f1 16 00 00       	call   4176 <printf>
    2a85:	83 c4 10             	add    $0x10,%esp
    exit();
    2a88:	e8 6d 15 00 00       	call   3ffa <exit>
  }
  close(fd);
    2a8d:	83 ec 0c             	sub    $0xc,%esp
    2a90:	ff 75 f4             	push   -0xc(%ebp)
    2a93:	e8 8a 15 00 00       	call   4022 <close>
    2a98:	83 c4 10             	add    $0x10,%esp
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    2a9b:	83 ec 08             	sub    $0x8,%esp
    2a9e:	6a 00                	push   $0x0
    2aa0:	68 68 55 00 00       	push   $0x5568
    2aa5:	e8 90 15 00 00       	call   403a <open>
    2aaa:	83 c4 10             	add    $0x10,%esp
    2aad:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    2ab0:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    2ab4:	79 17                	jns    2acd <fourteen+0xe3>
    printf(1, "open 12345678901234/12345678901234/12345678901234 failed\n");
    2ab6:	83 ec 08             	sub    $0x8,%esp
    2ab9:	68 98 55 00 00       	push   $0x5598
    2abe:	6a 01                	push   $0x1
    2ac0:	e8 b1 16 00 00       	call   4176 <printf>
    2ac5:	83 c4 10             	add    $0x10,%esp
    exit();
    2ac8:	e8 2d 15 00 00       	call   3ffa <exit>
  }
  close(fd);
    2acd:	83 ec 0c             	sub    $0xc,%esp
    2ad0:	ff 75 f4             	push   -0xc(%ebp)
    2ad3:	e8 4a 15 00 00       	call   4022 <close>
    2ad8:	83 c4 10             	add    $0x10,%esp

  if(mkdir("12345678901234/12345678901234") == 0){
    2adb:	83 ec 0c             	sub    $0xc,%esp
    2ade:	68 d2 55 00 00       	push   $0x55d2
    2ae3:	e8 7a 15 00 00       	call   4062 <mkdir>
    2ae8:	83 c4 10             	add    $0x10,%esp
    2aeb:	85 c0                	test   %eax,%eax
    2aed:	75 17                	jne    2b06 <fourteen+0x11c>
    printf(1, "mkdir 12345678901234/12345678901234 succeeded!\n");
    2aef:	83 ec 08             	sub    $0x8,%esp
    2af2:	68 f0 55 00 00       	push   $0x55f0
    2af7:	6a 01                	push   $0x1
    2af9:	e8 78 16 00 00       	call   4176 <printf>
    2afe:	83 c4 10             	add    $0x10,%esp
    exit();
    2b01:	e8 f4 14 00 00       	call   3ffa <exit>
  }
  if(mkdir("123456789012345/12345678901234") == 0){
    2b06:	83 ec 0c             	sub    $0xc,%esp
    2b09:	68 20 56 00 00       	push   $0x5620
    2b0e:	e8 4f 15 00 00       	call   4062 <mkdir>
    2b13:	83 c4 10             	add    $0x10,%esp
    2b16:	85 c0                	test   %eax,%eax
    2b18:	75 17                	jne    2b31 <fourteen+0x147>
    printf(1, "mkdir 12345678901234/123456789012345 succeeded!\n");
    2b1a:	83 ec 08             	sub    $0x8,%esp
    2b1d:	68 40 56 00 00       	push   $0x5640
    2b22:	6a 01                	push   $0x1
    2b24:	e8 4d 16 00 00       	call   4176 <printf>
    2b29:	83 c4 10             	add    $0x10,%esp
    exit();
    2b2c:	e8 c9 14 00 00       	call   3ffa <exit>
  }

  printf(1, "fourteen ok\n");
    2b31:	83 ec 08             	sub    $0x8,%esp
    2b34:	68 71 56 00 00       	push   $0x5671
    2b39:	6a 01                	push   $0x1
    2b3b:	e8 36 16 00 00       	call   4176 <printf>
    2b40:	83 c4 10             	add    $0x10,%esp
}
    2b43:	90                   	nop
    2b44:	c9                   	leave
    2b45:	c3                   	ret

00002b46 <rmdot>:

void
rmdot(void)
{
    2b46:	55                   	push   %ebp
    2b47:	89 e5                	mov    %esp,%ebp
    2b49:	83 ec 08             	sub    $0x8,%esp
  printf(1, "rmdot test\n");
    2b4c:	83 ec 08             	sub    $0x8,%esp
    2b4f:	68 7e 56 00 00       	push   $0x567e
    2b54:	6a 01                	push   $0x1
    2b56:	e8 1b 16 00 00       	call   4176 <printf>
    2b5b:	83 c4 10             	add    $0x10,%esp
  if(mkdir("dots") != 0){
    2b5e:	83 ec 0c             	sub    $0xc,%esp
    2b61:	68 8a 56 00 00       	push   $0x568a
    2b66:	e8 f7 14 00 00       	call   4062 <mkdir>
    2b6b:	83 c4 10             	add    $0x10,%esp
    2b6e:	85 c0                	test   %eax,%eax
    2b70:	74 17                	je     2b89 <rmdot+0x43>
    printf(1, "mkdir dots failed\n");
    2b72:	83 ec 08             	sub    $0x8,%esp
    2b75:	68 8f 56 00 00       	push   $0x568f
    2b7a:	6a 01                	push   $0x1
    2b7c:	e8 f5 15 00 00       	call   4176 <printf>
    2b81:	83 c4 10             	add    $0x10,%esp
    exit();
    2b84:	e8 71 14 00 00       	call   3ffa <exit>
  }
  if(chdir("dots") != 0){
    2b89:	83 ec 0c             	sub    $0xc,%esp
    2b8c:	68 8a 56 00 00       	push   $0x568a
    2b91:	e8 d4 14 00 00       	call   406a <chdir>
    2b96:	83 c4 10             	add    $0x10,%esp
    2b99:	85 c0                	test   %eax,%eax
    2b9b:	74 17                	je     2bb4 <rmdot+0x6e>
    printf(1, "chdir dots failed\n");
    2b9d:	83 ec 08             	sub    $0x8,%esp
    2ba0:	68 a2 56 00 00       	push   $0x56a2
    2ba5:	6a 01                	push   $0x1
    2ba7:	e8 ca 15 00 00       	call   4176 <printf>
    2bac:	83 c4 10             	add    $0x10,%esp
    exit();
    2baf:	e8 46 14 00 00       	call   3ffa <exit>
  }
  if(unlink(".") == 0){
    2bb4:	83 ec 0c             	sub    $0xc,%esp
    2bb7:	68 bb 4d 00 00       	push   $0x4dbb
    2bbc:	e8 89 14 00 00       	call   404a <unlink>
    2bc1:	83 c4 10             	add    $0x10,%esp
    2bc4:	85 c0                	test   %eax,%eax
    2bc6:	75 17                	jne    2bdf <rmdot+0x99>
    printf(1, "rm . worked!\n");
    2bc8:	83 ec 08             	sub    $0x8,%esp
    2bcb:	68 b5 56 00 00       	push   $0x56b5
    2bd0:	6a 01                	push   $0x1
    2bd2:	e8 9f 15 00 00       	call   4176 <printf>
    2bd7:	83 c4 10             	add    $0x10,%esp
    exit();
    2bda:	e8 1b 14 00 00       	call   3ffa <exit>
  }
  if(unlink("..") == 0){
    2bdf:	83 ec 0c             	sub    $0xc,%esp
    2be2:	68 4e 49 00 00       	push   $0x494e
    2be7:	e8 5e 14 00 00       	call   404a <unlink>
    2bec:	83 c4 10             	add    $0x10,%esp
    2bef:	85 c0                	test   %eax,%eax
    2bf1:	75 17                	jne    2c0a <rmdot+0xc4>
    printf(1, "rm .. worked!\n");
    2bf3:	83 ec 08             	sub    $0x8,%esp
    2bf6:	68 c3 56 00 00       	push   $0x56c3
    2bfb:	6a 01                	push   $0x1
    2bfd:	e8 74 15 00 00       	call   4176 <printf>
    2c02:	83 c4 10             	add    $0x10,%esp
    exit();
    2c05:	e8 f0 13 00 00       	call   3ffa <exit>
  }
  if(chdir("/") != 0){
    2c0a:	83 ec 0c             	sub    $0xc,%esp
    2c0d:	68 a2 45 00 00       	push   $0x45a2
    2c12:	e8 53 14 00 00       	call   406a <chdir>
    2c17:	83 c4 10             	add    $0x10,%esp
    2c1a:	85 c0                	test   %eax,%eax
    2c1c:	74 17                	je     2c35 <rmdot+0xef>
    printf(1, "chdir / failed\n");
    2c1e:	83 ec 08             	sub    $0x8,%esp
    2c21:	68 a4 45 00 00       	push   $0x45a4
    2c26:	6a 01                	push   $0x1
    2c28:	e8 49 15 00 00       	call   4176 <printf>
    2c2d:	83 c4 10             	add    $0x10,%esp
    exit();
    2c30:	e8 c5 13 00 00       	call   3ffa <exit>
  }
  if(unlink("dots/.") == 0){
    2c35:	83 ec 0c             	sub    $0xc,%esp
    2c38:	68 d2 56 00 00       	push   $0x56d2
    2c3d:	e8 08 14 00 00       	call   404a <unlink>
    2c42:	83 c4 10             	add    $0x10,%esp
    2c45:	85 c0                	test   %eax,%eax
    2c47:	75 17                	jne    2c60 <rmdot+0x11a>
    printf(1, "unlink dots/. worked!\n");
    2c49:	83 ec 08             	sub    $0x8,%esp
    2c4c:	68 d9 56 00 00       	push   $0x56d9
    2c51:	6a 01                	push   $0x1
    2c53:	e8 1e 15 00 00       	call   4176 <printf>
    2c58:	83 c4 10             	add    $0x10,%esp
    exit();
    2c5b:	e8 9a 13 00 00       	call   3ffa <exit>
  }
  if(unlink("dots/..") == 0){
    2c60:	83 ec 0c             	sub    $0xc,%esp
    2c63:	68 f0 56 00 00       	push   $0x56f0
    2c68:	e8 dd 13 00 00       	call   404a <unlink>
    2c6d:	83 c4 10             	add    $0x10,%esp
    2c70:	85 c0                	test   %eax,%eax
    2c72:	75 17                	jne    2c8b <rmdot+0x145>
    printf(1, "unlink dots/.. worked!\n");
    2c74:	83 ec 08             	sub    $0x8,%esp
    2c77:	68 f8 56 00 00       	push   $0x56f8
    2c7c:	6a 01                	push   $0x1
    2c7e:	e8 f3 14 00 00       	call   4176 <printf>
    2c83:	83 c4 10             	add    $0x10,%esp
    exit();
    2c86:	e8 6f 13 00 00       	call   3ffa <exit>
  }
  if(unlink("dots") != 0){
    2c8b:	83 ec 0c             	sub    $0xc,%esp
    2c8e:	68 8a 56 00 00       	push   $0x568a
    2c93:	e8 b2 13 00 00       	call   404a <unlink>
    2c98:	83 c4 10             	add    $0x10,%esp
    2c9b:	85 c0                	test   %eax,%eax
    2c9d:	74 17                	je     2cb6 <rmdot+0x170>
    printf(1, "unlink dots failed!\n");
    2c9f:	83 ec 08             	sub    $0x8,%esp
    2ca2:	68 10 57 00 00       	push   $0x5710
    2ca7:	6a 01                	push   $0x1
    2ca9:	e8 c8 14 00 00       	call   4176 <printf>
    2cae:	83 c4 10             	add    $0x10,%esp
    exit();
    2cb1:	e8 44 13 00 00       	call   3ffa <exit>
  }
  printf(1, "rmdot ok\n");
    2cb6:	83 ec 08             	sub    $0x8,%esp
    2cb9:	68 25 57 00 00       	push   $0x5725
    2cbe:	6a 01                	push   $0x1
    2cc0:	e8 b1 14 00 00       	call   4176 <printf>
    2cc5:	83 c4 10             	add    $0x10,%esp
}
    2cc8:	90                   	nop
    2cc9:	c9                   	leave
    2cca:	c3                   	ret

00002ccb <dirfile>:

void
dirfile(void)
{
    2ccb:	55                   	push   %ebp
    2ccc:	89 e5                	mov    %esp,%ebp
    2cce:	83 ec 18             	sub    $0x18,%esp
  int fd;

  printf(1, "dir vs file\n");
    2cd1:	83 ec 08             	sub    $0x8,%esp
    2cd4:	68 2f 57 00 00       	push   $0x572f
    2cd9:	6a 01                	push   $0x1
    2cdb:	e8 96 14 00 00       	call   4176 <printf>
    2ce0:	83 c4 10             	add    $0x10,%esp

  fd = open("dirfile", O_CREATE);
    2ce3:	83 ec 08             	sub    $0x8,%esp
    2ce6:	68 00 02 00 00       	push   $0x200
    2ceb:	68 3c 57 00 00       	push   $0x573c
    2cf0:	e8 45 13 00 00       	call   403a <open>
    2cf5:	83 c4 10             	add    $0x10,%esp
    2cf8:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0){
    2cfb:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    2cff:	79 17                	jns    2d18 <dirfile+0x4d>
    printf(1, "create dirfile failed\n");
    2d01:	83 ec 08             	sub    $0x8,%esp
    2d04:	68 44 57 00 00       	push   $0x5744
    2d09:	6a 01                	push   $0x1
    2d0b:	e8 66 14 00 00       	call   4176 <printf>
    2d10:	83 c4 10             	add    $0x10,%esp
    exit();
    2d13:	e8 e2 12 00 00       	call   3ffa <exit>
  }
  close(fd);
    2d18:	83 ec 0c             	sub    $0xc,%esp
    2d1b:	ff 75 f4             	push   -0xc(%ebp)
    2d1e:	e8 ff 12 00 00       	call   4022 <close>
    2d23:	83 c4 10             	add    $0x10,%esp
  if(chdir("dirfile") == 0){
    2d26:	83 ec 0c             	sub    $0xc,%esp
    2d29:	68 3c 57 00 00       	push   $0x573c
    2d2e:	e8 37 13 00 00       	call   406a <chdir>
    2d33:	83 c4 10             	add    $0x10,%esp
    2d36:	85 c0                	test   %eax,%eax
    2d38:	75 17                	jne    2d51 <dirfile+0x86>
    printf(1, "chdir dirfile succeeded!\n");
    2d3a:	83 ec 08             	sub    $0x8,%esp
    2d3d:	68 5b 57 00 00       	push   $0x575b
    2d42:	6a 01                	push   $0x1
    2d44:	e8 2d 14 00 00       	call   4176 <printf>
    2d49:	83 c4 10             	add    $0x10,%esp
    exit();
    2d4c:	e8 a9 12 00 00       	call   3ffa <exit>
  }
  fd = open("dirfile/xx", 0);
    2d51:	83 ec 08             	sub    $0x8,%esp
    2d54:	6a 00                	push   $0x0
    2d56:	68 75 57 00 00       	push   $0x5775
    2d5b:	e8 da 12 00 00       	call   403a <open>
    2d60:	83 c4 10             	add    $0x10,%esp
    2d63:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd >= 0){
    2d66:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    2d6a:	78 17                	js     2d83 <dirfile+0xb8>
    printf(1, "create dirfile/xx succeeded!\n");
    2d6c:	83 ec 08             	sub    $0x8,%esp
    2d6f:	68 80 57 00 00       	push   $0x5780
    2d74:	6a 01                	push   $0x1
    2d76:	e8 fb 13 00 00       	call   4176 <printf>
    2d7b:	83 c4 10             	add    $0x10,%esp
    exit();
    2d7e:	e8 77 12 00 00       	call   3ffa <exit>
  }
  fd = open("dirfile/xx", O_CREATE);
    2d83:	83 ec 08             	sub    $0x8,%esp
    2d86:	68 00 02 00 00       	push   $0x200
    2d8b:	68 75 57 00 00       	push   $0x5775
    2d90:	e8 a5 12 00 00       	call   403a <open>
    2d95:	83 c4 10             	add    $0x10,%esp
    2d98:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd >= 0){
    2d9b:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    2d9f:	78 17                	js     2db8 <dirfile+0xed>
    printf(1, "create dirfile/xx succeeded!\n");
    2da1:	83 ec 08             	sub    $0x8,%esp
    2da4:	68 80 57 00 00       	push   $0x5780
    2da9:	6a 01                	push   $0x1
    2dab:	e8 c6 13 00 00       	call   4176 <printf>
    2db0:	83 c4 10             	add    $0x10,%esp
    exit();
    2db3:	e8 42 12 00 00       	call   3ffa <exit>
  }
  if(mkdir("dirfile/xx") == 0){
    2db8:	83 ec 0c             	sub    $0xc,%esp
    2dbb:	68 75 57 00 00       	push   $0x5775
    2dc0:	e8 9d 12 00 00       	call   4062 <mkdir>
    2dc5:	83 c4 10             	add    $0x10,%esp
    2dc8:	85 c0                	test   %eax,%eax
    2dca:	75 17                	jne    2de3 <dirfile+0x118>
    printf(1, "mkdir dirfile/xx succeeded!\n");
    2dcc:	83 ec 08             	sub    $0x8,%esp
    2dcf:	68 9e 57 00 00       	push   $0x579e
    2dd4:	6a 01                	push   $0x1
    2dd6:	e8 9b 13 00 00       	call   4176 <printf>
    2ddb:	83 c4 10             	add    $0x10,%esp
    exit();
    2dde:	e8 17 12 00 00       	call   3ffa <exit>
  }
  if(unlink("dirfile/xx") == 0){
    2de3:	83 ec 0c             	sub    $0xc,%esp
    2de6:	68 75 57 00 00       	push   $0x5775
    2deb:	e8 5a 12 00 00       	call   404a <unlink>
    2df0:	83 c4 10             	add    $0x10,%esp
    2df3:	85 c0                	test   %eax,%eax
    2df5:	75 17                	jne    2e0e <dirfile+0x143>
    printf(1, "unlink dirfile/xx succeeded!\n");
    2df7:	83 ec 08             	sub    $0x8,%esp
    2dfa:	68 bb 57 00 00       	push   $0x57bb
    2dff:	6a 01                	push   $0x1
    2e01:	e8 70 13 00 00       	call   4176 <printf>
    2e06:	83 c4 10             	add    $0x10,%esp
    exit();
    2e09:	e8 ec 11 00 00       	call   3ffa <exit>
  }
  if(link("README", "dirfile/xx") == 0){
    2e0e:	83 ec 08             	sub    $0x8,%esp
    2e11:	68 75 57 00 00       	push   $0x5775
    2e16:	68 d9 57 00 00       	push   $0x57d9
    2e1b:	e8 3a 12 00 00       	call   405a <link>
    2e20:	83 c4 10             	add    $0x10,%esp
    2e23:	85 c0                	test   %eax,%eax
    2e25:	75 17                	jne    2e3e <dirfile+0x173>
    printf(1, "link to dirfile/xx succeeded!\n");
    2e27:	83 ec 08             	sub    $0x8,%esp
    2e2a:	68 e0 57 00 00       	push   $0x57e0
    2e2f:	6a 01                	push   $0x1
    2e31:	e8 40 13 00 00       	call   4176 <printf>
    2e36:	83 c4 10             	add    $0x10,%esp
    exit();
    2e39:	e8 bc 11 00 00       	call   3ffa <exit>
  }
  if(unlink("dirfile") != 0){
    2e3e:	83 ec 0c             	sub    $0xc,%esp
    2e41:	68 3c 57 00 00       	push   $0x573c
    2e46:	e8 ff 11 00 00       	call   404a <unlink>
    2e4b:	83 c4 10             	add    $0x10,%esp
    2e4e:	85 c0                	test   %eax,%eax
    2e50:	74 17                	je     2e69 <dirfile+0x19e>
    printf(1, "unlink dirfile failed!\n");
    2e52:	83 ec 08             	sub    $0x8,%esp
    2e55:	68 ff 57 00 00       	push   $0x57ff
    2e5a:	6a 01                	push   $0x1
    2e5c:	e8 15 13 00 00       	call   4176 <printf>
    2e61:	83 c4 10             	add    $0x10,%esp
    exit();
    2e64:	e8 91 11 00 00       	call   3ffa <exit>
  }

  fd = open(".", O_RDWR);
    2e69:	83 ec 08             	sub    $0x8,%esp
    2e6c:	6a 02                	push   $0x2
    2e6e:	68 bb 4d 00 00       	push   $0x4dbb
    2e73:	e8 c2 11 00 00       	call   403a <open>
    2e78:	83 c4 10             	add    $0x10,%esp
    2e7b:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd >= 0){
    2e7e:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    2e82:	78 17                	js     2e9b <dirfile+0x1d0>
    printf(1, "open . for writing succeeded!\n");
    2e84:	83 ec 08             	sub    $0x8,%esp
    2e87:	68 18 58 00 00       	push   $0x5818
    2e8c:	6a 01                	push   $0x1
    2e8e:	e8 e3 12 00 00       	call   4176 <printf>
    2e93:	83 c4 10             	add    $0x10,%esp
    exit();
    2e96:	e8 5f 11 00 00       	call   3ffa <exit>
  }
  fd = open(".", 0);
    2e9b:	83 ec 08             	sub    $0x8,%esp
    2e9e:	6a 00                	push   $0x0
    2ea0:	68 bb 4d 00 00       	push   $0x4dbb
    2ea5:	e8 90 11 00 00       	call   403a <open>
    2eaa:	83 c4 10             	add    $0x10,%esp
    2ead:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(write(fd, "x", 1) > 0){
    2eb0:	83 ec 04             	sub    $0x4,%esp
    2eb3:	6a 01                	push   $0x1
    2eb5:	68 07 4a 00 00       	push   $0x4a07
    2eba:	ff 75 f4             	push   -0xc(%ebp)
    2ebd:	e8 58 11 00 00       	call   401a <write>
    2ec2:	83 c4 10             	add    $0x10,%esp
    2ec5:	85 c0                	test   %eax,%eax
    2ec7:	7e 17                	jle    2ee0 <dirfile+0x215>
    printf(1, "write . succeeded!\n");
    2ec9:	83 ec 08             	sub    $0x8,%esp
    2ecc:	68 37 58 00 00       	push   $0x5837
    2ed1:	6a 01                	push   $0x1
    2ed3:	e8 9e 12 00 00       	call   4176 <printf>
    2ed8:	83 c4 10             	add    $0x10,%esp
    exit();
    2edb:	e8 1a 11 00 00       	call   3ffa <exit>
  }
  close(fd);
    2ee0:	83 ec 0c             	sub    $0xc,%esp
    2ee3:	ff 75 f4             	push   -0xc(%ebp)
    2ee6:	e8 37 11 00 00       	call   4022 <close>
    2eeb:	83 c4 10             	add    $0x10,%esp

  printf(1, "dir vs file OK\n");
    2eee:	83 ec 08             	sub    $0x8,%esp
    2ef1:	68 4b 58 00 00       	push   $0x584b
    2ef6:	6a 01                	push   $0x1
    2ef8:	e8 79 12 00 00       	call   4176 <printf>
    2efd:	83 c4 10             	add    $0x10,%esp
}
    2f00:	90                   	nop
    2f01:	c9                   	leave
    2f02:	c3                   	ret

00002f03 <iref>:

// test that iput() is called at the end of _namei()
void
iref(void)
{
    2f03:	55                   	push   %ebp
    2f04:	89 e5                	mov    %esp,%ebp
    2f06:	83 ec 18             	sub    $0x18,%esp
  int i, fd;

  printf(1, "empty file name\n");
    2f09:	83 ec 08             	sub    $0x8,%esp
    2f0c:	68 5b 58 00 00       	push   $0x585b
    2f11:	6a 01                	push   $0x1
    2f13:	e8 5e 12 00 00       	call   4176 <printf>
    2f18:	83 c4 10             	add    $0x10,%esp

  // the 50 is NINODE
  for(i = 0; i < 50 + 1; i++){
    2f1b:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    2f22:	e9 e7 00 00 00       	jmp    300e <iref+0x10b>
    if(mkdir("irefd") != 0){
    2f27:	83 ec 0c             	sub    $0xc,%esp
    2f2a:	68 6c 58 00 00       	push   $0x586c
    2f2f:	e8 2e 11 00 00       	call   4062 <mkdir>
    2f34:	83 c4 10             	add    $0x10,%esp
    2f37:	85 c0                	test   %eax,%eax
    2f39:	74 17                	je     2f52 <iref+0x4f>
      printf(1, "mkdir irefd failed\n");
    2f3b:	83 ec 08             	sub    $0x8,%esp
    2f3e:	68 72 58 00 00       	push   $0x5872
    2f43:	6a 01                	push   $0x1
    2f45:	e8 2c 12 00 00       	call   4176 <printf>
    2f4a:	83 c4 10             	add    $0x10,%esp
      exit();
    2f4d:	e8 a8 10 00 00       	call   3ffa <exit>
    }
    if(chdir("irefd") != 0){
    2f52:	83 ec 0c             	sub    $0xc,%esp
    2f55:	68 6c 58 00 00       	push   $0x586c
    2f5a:	e8 0b 11 00 00       	call   406a <chdir>
    2f5f:	83 c4 10             	add    $0x10,%esp
    2f62:	85 c0                	test   %eax,%eax
    2f64:	74 17                	je     2f7d <iref+0x7a>
      printf(1, "chdir irefd failed\n");
    2f66:	83 ec 08             	sub    $0x8,%esp
    2f69:	68 86 58 00 00       	push   $0x5886
    2f6e:	6a 01                	push   $0x1
    2f70:	e8 01 12 00 00       	call   4176 <printf>
    2f75:	83 c4 10             	add    $0x10,%esp
      exit();
    2f78:	e8 7d 10 00 00       	call   3ffa <exit>
    }

    mkdir("");
    2f7d:	83 ec 0c             	sub    $0xc,%esp
    2f80:	68 9a 58 00 00       	push   $0x589a
    2f85:	e8 d8 10 00 00       	call   4062 <mkdir>
    2f8a:	83 c4 10             	add    $0x10,%esp
    link("README", "");
    2f8d:	83 ec 08             	sub    $0x8,%esp
    2f90:	68 9a 58 00 00       	push   $0x589a
    2f95:	68 d9 57 00 00       	push   $0x57d9
    2f9a:	e8 bb 10 00 00       	call   405a <link>
    2f9f:	83 c4 10             	add    $0x10,%esp
    fd = open("", O_CREATE);
    2fa2:	83 ec 08             	sub    $0x8,%esp
    2fa5:	68 00 02 00 00       	push   $0x200
    2faa:	68 9a 58 00 00       	push   $0x589a
    2faf:	e8 86 10 00 00       	call   403a <open>
    2fb4:	83 c4 10             	add    $0x10,%esp
    2fb7:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(fd >= 0)
    2fba:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    2fbe:	78 0e                	js     2fce <iref+0xcb>
      close(fd);
    2fc0:	83 ec 0c             	sub    $0xc,%esp
    2fc3:	ff 75 f0             	push   -0x10(%ebp)
    2fc6:	e8 57 10 00 00       	call   4022 <close>
    2fcb:	83 c4 10             	add    $0x10,%esp
    fd = open("xx", O_CREATE);
    2fce:	83 ec 08             	sub    $0x8,%esp
    2fd1:	68 00 02 00 00       	push   $0x200
    2fd6:	68 9b 58 00 00       	push   $0x589b
    2fdb:	e8 5a 10 00 00       	call   403a <open>
    2fe0:	83 c4 10             	add    $0x10,%esp
    2fe3:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(fd >= 0)
    2fe6:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    2fea:	78 0e                	js     2ffa <iref+0xf7>
      close(fd);
    2fec:	83 ec 0c             	sub    $0xc,%esp
    2fef:	ff 75 f0             	push   -0x10(%ebp)
    2ff2:	e8 2b 10 00 00       	call   4022 <close>
    2ff7:	83 c4 10             	add    $0x10,%esp
    unlink("xx");
    2ffa:	83 ec 0c             	sub    $0xc,%esp
    2ffd:	68 9b 58 00 00       	push   $0x589b
    3002:	e8 43 10 00 00       	call   404a <unlink>
    3007:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < 50 + 1; i++){
    300a:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    300e:	83 7d f4 32          	cmpl   $0x32,-0xc(%ebp)
    3012:	0f 8e 0f ff ff ff    	jle    2f27 <iref+0x24>
  }

  chdir("/");
    3018:	83 ec 0c             	sub    $0xc,%esp
    301b:	68 a2 45 00 00       	push   $0x45a2
    3020:	e8 45 10 00 00       	call   406a <chdir>
    3025:	83 c4 10             	add    $0x10,%esp
  printf(1, "empty file name OK\n");
    3028:	83 ec 08             	sub    $0x8,%esp
    302b:	68 9e 58 00 00       	push   $0x589e
    3030:	6a 01                	push   $0x1
    3032:	e8 3f 11 00 00       	call   4176 <printf>
    3037:	83 c4 10             	add    $0x10,%esp
}
    303a:	90                   	nop
    303b:	c9                   	leave
    303c:	c3                   	ret

0000303d <forktest>:
// test that fork fails gracefully
// the forktest binary also does this, but it runs out of proc entries first.
// inside the bigger usertests binary, we run out of memory first.
void
forktest(void)
{
    303d:	55                   	push   %ebp
    303e:	89 e5                	mov    %esp,%ebp
    3040:	83 ec 18             	sub    $0x18,%esp
  int n, pid;

  printf(1, "fork test\n");
    3043:	83 ec 08             	sub    $0x8,%esp
    3046:	68 b2 58 00 00       	push   $0x58b2
    304b:	6a 01                	push   $0x1
    304d:	e8 24 11 00 00       	call   4176 <printf>
    3052:	83 c4 10             	add    $0x10,%esp

  for(n=0; n<1000; n++){
    3055:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    305c:	eb 1d                	jmp    307b <forktest+0x3e>
    pid = fork();
    305e:	e8 8f 0f 00 00       	call   3ff2 <fork>
    3063:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(pid < 0)
    3066:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    306a:	78 1a                	js     3086 <forktest+0x49>
      break;
    if(pid == 0)
    306c:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    3070:	75 05                	jne    3077 <forktest+0x3a>
      exit();
    3072:	e8 83 0f 00 00       	call   3ffa <exit>
  for(n=0; n<1000; n++){
    3077:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    307b:	81 7d f4 e7 03 00 00 	cmpl   $0x3e7,-0xc(%ebp)
    3082:	7e da                	jle    305e <forktest+0x21>
    3084:	eb 01                	jmp    3087 <forktest+0x4a>
      break;
    3086:	90                   	nop
  }

  if(n == 1000){
    3087:	81 7d f4 e8 03 00 00 	cmpl   $0x3e8,-0xc(%ebp)
    308e:	75 3b                	jne    30cb <forktest+0x8e>
    printf(1, "fork claimed to work 1000 times!\n");
    3090:	83 ec 08             	sub    $0x8,%esp
    3093:	68 c0 58 00 00       	push   $0x58c0
    3098:	6a 01                	push   $0x1
    309a:	e8 d7 10 00 00       	call   4176 <printf>
    309f:	83 c4 10             	add    $0x10,%esp
    exit();
    30a2:	e8 53 0f 00 00       	call   3ffa <exit>
  }

  for(; n > 0; n--){
    if(wait() < 0){
    30a7:	e8 56 0f 00 00       	call   4002 <wait>
    30ac:	85 c0                	test   %eax,%eax
    30ae:	79 17                	jns    30c7 <forktest+0x8a>
      printf(1, "wait stopped early\n");
    30b0:	83 ec 08             	sub    $0x8,%esp
    30b3:	68 e2 58 00 00       	push   $0x58e2
    30b8:	6a 01                	push   $0x1
    30ba:	e8 b7 10 00 00       	call   4176 <printf>
    30bf:	83 c4 10             	add    $0x10,%esp
      exit();
    30c2:	e8 33 0f 00 00       	call   3ffa <exit>
  for(; n > 0; n--){
    30c7:	83 6d f4 01          	subl   $0x1,-0xc(%ebp)
    30cb:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    30cf:	7f d6                	jg     30a7 <forktest+0x6a>
    }
  }

  if(wait() != -1){
    30d1:	e8 2c 0f 00 00       	call   4002 <wait>
    30d6:	83 f8 ff             	cmp    $0xffffffff,%eax
    30d9:	74 17                	je     30f2 <forktest+0xb5>
    printf(1, "wait got too many\n");
    30db:	83 ec 08             	sub    $0x8,%esp
    30de:	68 f6 58 00 00       	push   $0x58f6
    30e3:	6a 01                	push   $0x1
    30e5:	e8 8c 10 00 00       	call   4176 <printf>
    30ea:	83 c4 10             	add    $0x10,%esp
    exit();
    30ed:	e8 08 0f 00 00       	call   3ffa <exit>
  }

  printf(1, "fork test OK\n");
    30f2:	83 ec 08             	sub    $0x8,%esp
    30f5:	68 09 59 00 00       	push   $0x5909
    30fa:	6a 01                	push   $0x1
    30fc:	e8 75 10 00 00       	call   4176 <printf>
    3101:	83 c4 10             	add    $0x10,%esp
}
    3104:	90                   	nop
    3105:	c9                   	leave
    3106:	c3                   	ret

00003107 <sbrktest>:

void
sbrktest(void)
{
    3107:	55                   	push   %ebp
    3108:	89 e5                	mov    %esp,%ebp
    310a:	83 ec 68             	sub    $0x68,%esp
  int fds[2], pid, pids[10], ppid;
  char *a, *b, *c, *lastaddr, *oldbrk, *p, scratch;
  uint amt;

  printf(stdout, "sbrk test\n");
    310d:	a1 ac 64 00 00       	mov    0x64ac,%eax
    3112:	83 ec 08             	sub    $0x8,%esp
    3115:	68 17 59 00 00       	push   $0x5917
    311a:	50                   	push   %eax
    311b:	e8 56 10 00 00       	call   4176 <printf>
    3120:	83 c4 10             	add    $0x10,%esp
  oldbrk = sbrk(0);
    3123:	83 ec 0c             	sub    $0xc,%esp
    3126:	6a 00                	push   $0x0
    3128:	e8 55 0f 00 00       	call   4082 <sbrk>
    312d:	83 c4 10             	add    $0x10,%esp
    3130:	89 45 ec             	mov    %eax,-0x14(%ebp)

  // can one sbrk() less than a page?
  a = sbrk(0);
    3133:	83 ec 0c             	sub    $0xc,%esp
    3136:	6a 00                	push   $0x0
    3138:	e8 45 0f 00 00       	call   4082 <sbrk>
    313d:	83 c4 10             	add    $0x10,%esp
    3140:	89 45 f4             	mov    %eax,-0xc(%ebp)
  int i;
  for(i = 0; i < 5000; i++){
    3143:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    314a:	eb 4f                	jmp    319b <sbrktest+0x94>
    b = sbrk(1);
    314c:	83 ec 0c             	sub    $0xc,%esp
    314f:	6a 01                	push   $0x1
    3151:	e8 2c 0f 00 00       	call   4082 <sbrk>
    3156:	83 c4 10             	add    $0x10,%esp
    3159:	89 45 d0             	mov    %eax,-0x30(%ebp)
    if(b != a){
    315c:	8b 45 d0             	mov    -0x30(%ebp),%eax
    315f:	3b 45 f4             	cmp    -0xc(%ebp),%eax
    3162:	74 24                	je     3188 <sbrktest+0x81>
      printf(stdout, "sbrk test failed %d %x %x\n", i, a, b);
    3164:	a1 ac 64 00 00       	mov    0x64ac,%eax
    3169:	83 ec 0c             	sub    $0xc,%esp
    316c:	ff 75 d0             	push   -0x30(%ebp)
    316f:	ff 75 f4             	push   -0xc(%ebp)
    3172:	ff 75 f0             	push   -0x10(%ebp)
    3175:	68 22 59 00 00       	push   $0x5922
    317a:	50                   	push   %eax
    317b:	e8 f6 0f 00 00       	call   4176 <printf>
    3180:	83 c4 20             	add    $0x20,%esp
      exit();
    3183:	e8 72 0e 00 00       	call   3ffa <exit>
    }
    *b = 1;
    3188:	8b 45 d0             	mov    -0x30(%ebp),%eax
    318b:	c6 00 01             	movb   $0x1,(%eax)
    a = b + 1;
    318e:	8b 45 d0             	mov    -0x30(%ebp),%eax
    3191:	83 c0 01             	add    $0x1,%eax
    3194:	89 45 f4             	mov    %eax,-0xc(%ebp)
  for(i = 0; i < 5000; i++){
    3197:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    319b:	81 7d f0 87 13 00 00 	cmpl   $0x1387,-0x10(%ebp)
    31a2:	7e a8                	jle    314c <sbrktest+0x45>
  }
  pid = fork();
    31a4:	e8 49 0e 00 00       	call   3ff2 <fork>
    31a9:	89 45 e8             	mov    %eax,-0x18(%ebp)
  if(pid < 0){
    31ac:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    31b0:	79 1b                	jns    31cd <sbrktest+0xc6>
    printf(stdout, "sbrk test fork failed\n");
    31b2:	a1 ac 64 00 00       	mov    0x64ac,%eax
    31b7:	83 ec 08             	sub    $0x8,%esp
    31ba:	68 3d 59 00 00       	push   $0x593d
    31bf:	50                   	push   %eax
    31c0:	e8 b1 0f 00 00       	call   4176 <printf>
    31c5:	83 c4 10             	add    $0x10,%esp
    exit();
    31c8:	e8 2d 0e 00 00       	call   3ffa <exit>
  }
  c = sbrk(1);
    31cd:	83 ec 0c             	sub    $0xc,%esp
    31d0:	6a 01                	push   $0x1
    31d2:	e8 ab 0e 00 00       	call   4082 <sbrk>
    31d7:	83 c4 10             	add    $0x10,%esp
    31da:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  c = sbrk(1);
    31dd:	83 ec 0c             	sub    $0xc,%esp
    31e0:	6a 01                	push   $0x1
    31e2:	e8 9b 0e 00 00       	call   4082 <sbrk>
    31e7:	83 c4 10             	add    $0x10,%esp
    31ea:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(c != a + 1){
    31ed:	8b 45 f4             	mov    -0xc(%ebp),%eax
    31f0:	83 c0 01             	add    $0x1,%eax
    31f3:	39 45 e4             	cmp    %eax,-0x1c(%ebp)
    31f6:	74 1b                	je     3213 <sbrktest+0x10c>
    printf(stdout, "sbrk test failed post-fork\n");
    31f8:	a1 ac 64 00 00       	mov    0x64ac,%eax
    31fd:	83 ec 08             	sub    $0x8,%esp
    3200:	68 54 59 00 00       	push   $0x5954
    3205:	50                   	push   %eax
    3206:	e8 6b 0f 00 00       	call   4176 <printf>
    320b:	83 c4 10             	add    $0x10,%esp
    exit();
    320e:	e8 e7 0d 00 00       	call   3ffa <exit>
  }
  if(pid == 0)
    3213:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    3217:	75 05                	jne    321e <sbrktest+0x117>
    exit();
    3219:	e8 dc 0d 00 00       	call   3ffa <exit>
  wait();
    321e:	e8 df 0d 00 00       	call   4002 <wait>

  // can one grow address space to something big?
#define BIG (100*1024*1024)
  a = sbrk(0);
    3223:	83 ec 0c             	sub    $0xc,%esp
    3226:	6a 00                	push   $0x0
    3228:	e8 55 0e 00 00       	call   4082 <sbrk>
    322d:	83 c4 10             	add    $0x10,%esp
    3230:	89 45 f4             	mov    %eax,-0xc(%ebp)
  amt = (BIG) - (uint)a;
    3233:	8b 45 f4             	mov    -0xc(%ebp),%eax
    3236:	ba 00 00 40 06       	mov    $0x6400000,%edx
    323b:	29 c2                	sub    %eax,%edx
    323d:	89 55 e0             	mov    %edx,-0x20(%ebp)
  p = sbrk(amt);
    3240:	8b 45 e0             	mov    -0x20(%ebp),%eax
    3243:	83 ec 0c             	sub    $0xc,%esp
    3246:	50                   	push   %eax
    3247:	e8 36 0e 00 00       	call   4082 <sbrk>
    324c:	83 c4 10             	add    $0x10,%esp
    324f:	89 45 dc             	mov    %eax,-0x24(%ebp)
  if (p != a) {
    3252:	8b 45 dc             	mov    -0x24(%ebp),%eax
    3255:	3b 45 f4             	cmp    -0xc(%ebp),%eax
    3258:	74 1b                	je     3275 <sbrktest+0x16e>
    printf(stdout, "sbrk test failed to grow big address space; enough phys mem?\n");
    325a:	a1 ac 64 00 00       	mov    0x64ac,%eax
    325f:	83 ec 08             	sub    $0x8,%esp
    3262:	68 70 59 00 00       	push   $0x5970
    3267:	50                   	push   %eax
    3268:	e8 09 0f 00 00       	call   4176 <printf>
    326d:	83 c4 10             	add    $0x10,%esp
    exit();
    3270:	e8 85 0d 00 00       	call   3ffa <exit>
  }
  lastaddr = (char*) (BIG-1);
    3275:	c7 45 d8 ff ff 3f 06 	movl   $0x63fffff,-0x28(%ebp)
  *lastaddr = 99;
    327c:	8b 45 d8             	mov    -0x28(%ebp),%eax
    327f:	c6 00 63             	movb   $0x63,(%eax)

  // can one de-allocate?
  a = sbrk(0);
    3282:	83 ec 0c             	sub    $0xc,%esp
    3285:	6a 00                	push   $0x0
    3287:	e8 f6 0d 00 00       	call   4082 <sbrk>
    328c:	83 c4 10             	add    $0x10,%esp
    328f:	89 45 f4             	mov    %eax,-0xc(%ebp)
  c = sbrk(-4096);
    3292:	83 ec 0c             	sub    $0xc,%esp
    3295:	68 00 f0 ff ff       	push   $0xfffff000
    329a:	e8 e3 0d 00 00       	call   4082 <sbrk>
    329f:	83 c4 10             	add    $0x10,%esp
    32a2:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(c == (char*)0xffffffff){
    32a5:	83 7d e4 ff          	cmpl   $0xffffffff,-0x1c(%ebp)
    32a9:	75 1b                	jne    32c6 <sbrktest+0x1bf>
    printf(stdout, "sbrk could not deallocate\n");
    32ab:	a1 ac 64 00 00       	mov    0x64ac,%eax
    32b0:	83 ec 08             	sub    $0x8,%esp
    32b3:	68 ae 59 00 00       	push   $0x59ae
    32b8:	50                   	push   %eax
    32b9:	e8 b8 0e 00 00       	call   4176 <printf>
    32be:	83 c4 10             	add    $0x10,%esp
    exit();
    32c1:	e8 34 0d 00 00       	call   3ffa <exit>
  }
  c = sbrk(0);
    32c6:	83 ec 0c             	sub    $0xc,%esp
    32c9:	6a 00                	push   $0x0
    32cb:	e8 b2 0d 00 00       	call   4082 <sbrk>
    32d0:	83 c4 10             	add    $0x10,%esp
    32d3:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(c != a - 4096){
    32d6:	8b 45 f4             	mov    -0xc(%ebp),%eax
    32d9:	2d 00 10 00 00       	sub    $0x1000,%eax
    32de:	39 45 e4             	cmp    %eax,-0x1c(%ebp)
    32e1:	74 1e                	je     3301 <sbrktest+0x1fa>
    printf(stdout, "sbrk deallocation produced wrong address, a %x c %x\n", a, c);
    32e3:	a1 ac 64 00 00       	mov    0x64ac,%eax
    32e8:	ff 75 e4             	push   -0x1c(%ebp)
    32eb:	ff 75 f4             	push   -0xc(%ebp)
    32ee:	68 cc 59 00 00       	push   $0x59cc
    32f3:	50                   	push   %eax
    32f4:	e8 7d 0e 00 00       	call   4176 <printf>
    32f9:	83 c4 10             	add    $0x10,%esp
    exit();
    32fc:	e8 f9 0c 00 00       	call   3ffa <exit>
  }

  // can one re-allocate that page?
  a = sbrk(0);
    3301:	83 ec 0c             	sub    $0xc,%esp
    3304:	6a 00                	push   $0x0
    3306:	e8 77 0d 00 00       	call   4082 <sbrk>
    330b:	83 c4 10             	add    $0x10,%esp
    330e:	89 45 f4             	mov    %eax,-0xc(%ebp)
  c = sbrk(4096);
    3311:	83 ec 0c             	sub    $0xc,%esp
    3314:	68 00 10 00 00       	push   $0x1000
    3319:	e8 64 0d 00 00       	call   4082 <sbrk>
    331e:	83 c4 10             	add    $0x10,%esp
    3321:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(c != a || sbrk(0) != a + 4096){
    3324:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    3327:	3b 45 f4             	cmp    -0xc(%ebp),%eax
    332a:	75 1a                	jne    3346 <sbrktest+0x23f>
    332c:	83 ec 0c             	sub    $0xc,%esp
    332f:	6a 00                	push   $0x0
    3331:	e8 4c 0d 00 00       	call   4082 <sbrk>
    3336:	83 c4 10             	add    $0x10,%esp
    3339:	8b 55 f4             	mov    -0xc(%ebp),%edx
    333c:	81 c2 00 10 00 00    	add    $0x1000,%edx
    3342:	39 d0                	cmp    %edx,%eax
    3344:	74 1e                	je     3364 <sbrktest+0x25d>
    printf(stdout, "sbrk re-allocation failed, a %x c %x\n", a, c);
    3346:	a1 ac 64 00 00       	mov    0x64ac,%eax
    334b:	ff 75 e4             	push   -0x1c(%ebp)
    334e:	ff 75 f4             	push   -0xc(%ebp)
    3351:	68 04 5a 00 00       	push   $0x5a04
    3356:	50                   	push   %eax
    3357:	e8 1a 0e 00 00       	call   4176 <printf>
    335c:	83 c4 10             	add    $0x10,%esp
    exit();
    335f:	e8 96 0c 00 00       	call   3ffa <exit>
  }
  if(*lastaddr == 99){
    3364:	8b 45 d8             	mov    -0x28(%ebp),%eax
    3367:	0f b6 00             	movzbl (%eax),%eax
    336a:	3c 63                	cmp    $0x63,%al
    336c:	75 1b                	jne    3389 <sbrktest+0x282>
    // should be zero
    printf(stdout, "sbrk de-allocation didn't really deallocate\n");
    336e:	a1 ac 64 00 00       	mov    0x64ac,%eax
    3373:	83 ec 08             	sub    $0x8,%esp
    3376:	68 2c 5a 00 00       	push   $0x5a2c
    337b:	50                   	push   %eax
    337c:	e8 f5 0d 00 00       	call   4176 <printf>
    3381:	83 c4 10             	add    $0x10,%esp
    exit();
    3384:	e8 71 0c 00 00       	call   3ffa <exit>
  }

  a = sbrk(0);
    3389:	83 ec 0c             	sub    $0xc,%esp
    338c:	6a 00                	push   $0x0
    338e:	e8 ef 0c 00 00       	call   4082 <sbrk>
    3393:	83 c4 10             	add    $0x10,%esp
    3396:	89 45 f4             	mov    %eax,-0xc(%ebp)
  c = sbrk(-(sbrk(0) - oldbrk));
    3399:	83 ec 0c             	sub    $0xc,%esp
    339c:	6a 00                	push   $0x0
    339e:	e8 df 0c 00 00       	call   4082 <sbrk>
    33a3:	83 c4 10             	add    $0x10,%esp
    33a6:	8b 55 ec             	mov    -0x14(%ebp),%edx
    33a9:	29 c2                	sub    %eax,%edx
    33ab:	83 ec 0c             	sub    $0xc,%esp
    33ae:	52                   	push   %edx
    33af:	e8 ce 0c 00 00       	call   4082 <sbrk>
    33b4:	83 c4 10             	add    $0x10,%esp
    33b7:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(c != a){
    33ba:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    33bd:	3b 45 f4             	cmp    -0xc(%ebp),%eax
    33c0:	74 1e                	je     33e0 <sbrktest+0x2d9>
    printf(stdout, "sbrk downsize failed, a %x c %x\n", a, c);
    33c2:	a1 ac 64 00 00       	mov    0x64ac,%eax
    33c7:	ff 75 e4             	push   -0x1c(%ebp)
    33ca:	ff 75 f4             	push   -0xc(%ebp)
    33cd:	68 5c 5a 00 00       	push   $0x5a5c
    33d2:	50                   	push   %eax
    33d3:	e8 9e 0d 00 00       	call   4176 <printf>
    33d8:	83 c4 10             	add    $0x10,%esp
    exit();
    33db:	e8 1a 0c 00 00       	call   3ffa <exit>
  }

  // can we read the kernel's memory?
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    33e0:	c7 45 f4 00 00 00 80 	movl   $0x80000000,-0xc(%ebp)
    33e7:	eb 76                	jmp    345f <sbrktest+0x358>
    ppid = getpid();
    33e9:	e8 8c 0c 00 00       	call   407a <getpid>
    33ee:	89 45 d4             	mov    %eax,-0x2c(%ebp)
    pid = fork();
    33f1:	e8 fc 0b 00 00       	call   3ff2 <fork>
    33f6:	89 45 e8             	mov    %eax,-0x18(%ebp)
    if(pid < 0){
    33f9:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    33fd:	79 1b                	jns    341a <sbrktest+0x313>
      printf(stdout, "fork failed\n");
    33ff:	a1 ac 64 00 00       	mov    0x64ac,%eax
    3404:	83 ec 08             	sub    $0x8,%esp
    3407:	68 d1 45 00 00       	push   $0x45d1
    340c:	50                   	push   %eax
    340d:	e8 64 0d 00 00       	call   4176 <printf>
    3412:	83 c4 10             	add    $0x10,%esp
      exit();
    3415:	e8 e0 0b 00 00       	call   3ffa <exit>
    }
    if(pid == 0){
    341a:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    341e:	75 33                	jne    3453 <sbrktest+0x34c>
      printf(stdout, "oops could read %x = %x\n", a, *a);
    3420:	8b 45 f4             	mov    -0xc(%ebp),%eax
    3423:	0f b6 00             	movzbl (%eax),%eax
    3426:	0f be d0             	movsbl %al,%edx
    3429:	a1 ac 64 00 00       	mov    0x64ac,%eax
    342e:	52                   	push   %edx
    342f:	ff 75 f4             	push   -0xc(%ebp)
    3432:	68 7d 5a 00 00       	push   $0x5a7d
    3437:	50                   	push   %eax
    3438:	e8 39 0d 00 00       	call   4176 <printf>
    343d:	83 c4 10             	add    $0x10,%esp
      kill(ppid);
    3440:	83 ec 0c             	sub    $0xc,%esp
    3443:	ff 75 d4             	push   -0x2c(%ebp)
    3446:	e8 df 0b 00 00       	call   402a <kill>
    344b:	83 c4 10             	add    $0x10,%esp
      exit();
    344e:	e8 a7 0b 00 00       	call   3ffa <exit>
    }
    wait();
    3453:	e8 aa 0b 00 00       	call   4002 <wait>
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    3458:	81 45 f4 50 c3 00 00 	addl   $0xc350,-0xc(%ebp)
    345f:	81 7d f4 7f 84 1e 80 	cmpl   $0x801e847f,-0xc(%ebp)
    3466:	76 81                	jbe    33e9 <sbrktest+0x2e2>
  }

  // if we run the system out of memory, does it clean up the last
  // failed allocation?
  if(pipe(fds) != 0){
    3468:	83 ec 0c             	sub    $0xc,%esp
    346b:	8d 45 c8             	lea    -0x38(%ebp),%eax
    346e:	50                   	push   %eax
    346f:	e8 96 0b 00 00       	call   400a <pipe>
    3474:	83 c4 10             	add    $0x10,%esp
    3477:	85 c0                	test   %eax,%eax
    3479:	74 17                	je     3492 <sbrktest+0x38b>
    printf(1, "pipe() failed\n");
    347b:	83 ec 08             	sub    $0x8,%esp
    347e:	68 a2 49 00 00       	push   $0x49a2
    3483:	6a 01                	push   $0x1
    3485:	e8 ec 0c 00 00       	call   4176 <printf>
    348a:	83 c4 10             	add    $0x10,%esp
    exit();
    348d:	e8 68 0b 00 00       	call   3ffa <exit>
  }
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3492:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    3499:	e9 86 00 00 00       	jmp    3524 <sbrktest+0x41d>
    if((pids[i] = fork()) == 0){
    349e:	e8 4f 0b 00 00       	call   3ff2 <fork>
    34a3:	8b 55 f0             	mov    -0x10(%ebp),%edx
    34a6:	89 44 95 a0          	mov    %eax,-0x60(%ebp,%edx,4)
    34aa:	8b 45 f0             	mov    -0x10(%ebp),%eax
    34ad:	8b 44 85 a0          	mov    -0x60(%ebp,%eax,4),%eax
    34b1:	85 c0                	test   %eax,%eax
    34b3:	75 4a                	jne    34ff <sbrktest+0x3f8>
      // allocate a lot of memory
      sbrk(BIG - (uint)sbrk(0));
    34b5:	83 ec 0c             	sub    $0xc,%esp
    34b8:	6a 00                	push   $0x0
    34ba:	e8 c3 0b 00 00       	call   4082 <sbrk>
    34bf:	83 c4 10             	add    $0x10,%esp
    34c2:	89 c2                	mov    %eax,%edx
    34c4:	b8 00 00 40 06       	mov    $0x6400000,%eax
    34c9:	29 d0                	sub    %edx,%eax
    34cb:	83 ec 0c             	sub    $0xc,%esp
    34ce:	50                   	push   %eax
    34cf:	e8 ae 0b 00 00       	call   4082 <sbrk>
    34d4:	83 c4 10             	add    $0x10,%esp
      write(fds[1], "x", 1);
    34d7:	8b 45 cc             	mov    -0x34(%ebp),%eax
    34da:	83 ec 04             	sub    $0x4,%esp
    34dd:	6a 01                	push   $0x1
    34df:	68 07 4a 00 00       	push   $0x4a07
    34e4:	50                   	push   %eax
    34e5:	e8 30 0b 00 00       	call   401a <write>
    34ea:	83 c4 10             	add    $0x10,%esp
      // sit around until killed
      for(;;) sleep(1000);
    34ed:	83 ec 0c             	sub    $0xc,%esp
    34f0:	68 e8 03 00 00       	push   $0x3e8
    34f5:	e8 90 0b 00 00       	call   408a <sleep>
    34fa:	83 c4 10             	add    $0x10,%esp
    34fd:	eb ee                	jmp    34ed <sbrktest+0x3e6>
    }
    if(pids[i] != -1)
    34ff:	8b 45 f0             	mov    -0x10(%ebp),%eax
    3502:	8b 44 85 a0          	mov    -0x60(%ebp,%eax,4),%eax
    3506:	83 f8 ff             	cmp    $0xffffffff,%eax
    3509:	74 15                	je     3520 <sbrktest+0x419>
      read(fds[0], &scratch, 1);
    350b:	8b 45 c8             	mov    -0x38(%ebp),%eax
    350e:	83 ec 04             	sub    $0x4,%esp
    3511:	6a 01                	push   $0x1
    3513:	8d 55 9f             	lea    -0x61(%ebp),%edx
    3516:	52                   	push   %edx
    3517:	50                   	push   %eax
    3518:	e8 f5 0a 00 00       	call   4012 <read>
    351d:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3520:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    3524:	8b 45 f0             	mov    -0x10(%ebp),%eax
    3527:	83 f8 09             	cmp    $0x9,%eax
    352a:	0f 86 6e ff ff ff    	jbe    349e <sbrktest+0x397>
  }
  // if those failed allocations freed up the pages they did allocate,
  // we'll be able to allocate here
  c = sbrk(4096);
    3530:	83 ec 0c             	sub    $0xc,%esp
    3533:	68 00 10 00 00       	push   $0x1000
    3538:	e8 45 0b 00 00       	call   4082 <sbrk>
    353d:	83 c4 10             	add    $0x10,%esp
    3540:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3543:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    354a:	eb 2b                	jmp    3577 <sbrktest+0x470>
    if(pids[i] == -1)
    354c:	8b 45 f0             	mov    -0x10(%ebp),%eax
    354f:	8b 44 85 a0          	mov    -0x60(%ebp,%eax,4),%eax
    3553:	83 f8 ff             	cmp    $0xffffffff,%eax
    3556:	74 1a                	je     3572 <sbrktest+0x46b>
      continue;
    kill(pids[i]);
    3558:	8b 45 f0             	mov    -0x10(%ebp),%eax
    355b:	8b 44 85 a0          	mov    -0x60(%ebp,%eax,4),%eax
    355f:	83 ec 0c             	sub    $0xc,%esp
    3562:	50                   	push   %eax
    3563:	e8 c2 0a 00 00       	call   402a <kill>
    3568:	83 c4 10             	add    $0x10,%esp
    wait();
    356b:	e8 92 0a 00 00       	call   4002 <wait>
    3570:	eb 01                	jmp    3573 <sbrktest+0x46c>
      continue;
    3572:	90                   	nop
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3573:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    3577:	8b 45 f0             	mov    -0x10(%ebp),%eax
    357a:	83 f8 09             	cmp    $0x9,%eax
    357d:	76 cd                	jbe    354c <sbrktest+0x445>
  }
  if(c == (char*)0xffffffff){
    357f:	83 7d e4 ff          	cmpl   $0xffffffff,-0x1c(%ebp)
    3583:	75 1b                	jne    35a0 <sbrktest+0x499>
    printf(stdout, "failed sbrk leaked memory\n");
    3585:	a1 ac 64 00 00       	mov    0x64ac,%eax
    358a:	83 ec 08             	sub    $0x8,%esp
    358d:	68 96 5a 00 00       	push   $0x5a96
    3592:	50                   	push   %eax
    3593:	e8 de 0b 00 00       	call   4176 <printf>
    3598:	83 c4 10             	add    $0x10,%esp
    exit();
    359b:	e8 5a 0a 00 00       	call   3ffa <exit>
  }

  if(sbrk(0) > oldbrk)
    35a0:	83 ec 0c             	sub    $0xc,%esp
    35a3:	6a 00                	push   $0x0
    35a5:	e8 d8 0a 00 00       	call   4082 <sbrk>
    35aa:	83 c4 10             	add    $0x10,%esp
    35ad:	39 45 ec             	cmp    %eax,-0x14(%ebp)
    35b0:	73 1e                	jae    35d0 <sbrktest+0x4c9>
    sbrk(-(sbrk(0) - oldbrk));
    35b2:	83 ec 0c             	sub    $0xc,%esp
    35b5:	6a 00                	push   $0x0
    35b7:	e8 c6 0a 00 00       	call   4082 <sbrk>
    35bc:	83 c4 10             	add    $0x10,%esp
    35bf:	8b 55 ec             	mov    -0x14(%ebp),%edx
    35c2:	29 c2                	sub    %eax,%edx
    35c4:	83 ec 0c             	sub    $0xc,%esp
    35c7:	52                   	push   %edx
    35c8:	e8 b5 0a 00 00       	call   4082 <sbrk>
    35cd:	83 c4 10             	add    $0x10,%esp

  printf(stdout, "sbrk test OK\n");
    35d0:	a1 ac 64 00 00       	mov    0x64ac,%eax
    35d5:	83 ec 08             	sub    $0x8,%esp
    35d8:	68 b1 5a 00 00       	push   $0x5ab1
    35dd:	50                   	push   %eax
    35de:	e8 93 0b 00 00       	call   4176 <printf>
    35e3:	83 c4 10             	add    $0x10,%esp
}
    35e6:	90                   	nop
    35e7:	c9                   	leave
    35e8:	c3                   	ret

000035e9 <validateint>:

void
validateint(int *p)
{
    35e9:	55                   	push   %ebp
    35ea:	89 e5                	mov    %esp,%ebp
    35ec:	53                   	push   %ebx
    35ed:	83 ec 10             	sub    $0x10,%esp
  int res;
  asm("mov %%esp, %%ebx\n\t"
    35f0:	b8 0d 00 00 00       	mov    $0xd,%eax
    35f5:	8b 55 08             	mov    0x8(%ebp),%edx
    35f8:	89 d1                	mov    %edx,%ecx
    35fa:	89 e3                	mov    %esp,%ebx
    35fc:	89 cc                	mov    %ecx,%esp
    35fe:	cd 40                	int    $0x40
    3600:	89 dc                	mov    %ebx,%esp
    3602:	89 45 f8             	mov    %eax,-0x8(%ebp)
      "int %2\n\t"
      "mov %%ebx, %%esp" :
      "=a" (res) :
      "a" (SYS_sleep), "n" (T_SYSCALL), "c" (p) :
      "ebx");
}
    3605:	90                   	nop
    3606:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    3609:	c9                   	leave
    360a:	c3                   	ret

0000360b <validatetest>:

void
validatetest(void)
{
    360b:	55                   	push   %ebp
    360c:	89 e5                	mov    %esp,%ebp
    360e:	83 ec 18             	sub    $0x18,%esp
  int hi, pid;
  uint p;

  printf(stdout, "validate test\n");
    3611:	a1 ac 64 00 00       	mov    0x64ac,%eax
    3616:	83 ec 08             	sub    $0x8,%esp
    3619:	68 bf 5a 00 00       	push   $0x5abf
    361e:	50                   	push   %eax
    361f:	e8 52 0b 00 00       	call   4176 <printf>
    3624:	83 c4 10             	add    $0x10,%esp
  hi = 1100*1024;
    3627:	c7 45 f0 00 30 11 00 	movl   $0x113000,-0x10(%ebp)

  for(p = 0; p <= (uint)hi; p += 4096){
    362e:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    3635:	e9 8a 00 00 00       	jmp    36c4 <validatetest+0xb9>
    if((pid = fork()) == 0){
    363a:	e8 b3 09 00 00       	call   3ff2 <fork>
    363f:	89 45 ec             	mov    %eax,-0x14(%ebp)
    3642:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    3646:	75 14                	jne    365c <validatetest+0x51>
      // try to crash the kernel by passing in a badly placed integer
      validateint((int*)p);
    3648:	8b 45 f4             	mov    -0xc(%ebp),%eax
    364b:	83 ec 0c             	sub    $0xc,%esp
    364e:	50                   	push   %eax
    364f:	e8 95 ff ff ff       	call   35e9 <validateint>
    3654:	83 c4 10             	add    $0x10,%esp
      exit();
    3657:	e8 9e 09 00 00       	call   3ffa <exit>
    }
    sleep(0);
    365c:	83 ec 0c             	sub    $0xc,%esp
    365f:	6a 00                	push   $0x0
    3661:	e8 24 0a 00 00       	call   408a <sleep>
    3666:	83 c4 10             	add    $0x10,%esp
    sleep(0);
    3669:	83 ec 0c             	sub    $0xc,%esp
    366c:	6a 00                	push   $0x0
    366e:	e8 17 0a 00 00       	call   408a <sleep>
    3673:	83 c4 10             	add    $0x10,%esp
    kill(pid);
    3676:	83 ec 0c             	sub    $0xc,%esp
    3679:	ff 75 ec             	push   -0x14(%ebp)
    367c:	e8 a9 09 00 00       	call   402a <kill>
    3681:	83 c4 10             	add    $0x10,%esp
    wait();
    3684:	e8 79 09 00 00       	call   4002 <wait>

    // try to crash the kernel by passing in a bad string pointer
    if(link("nosuchfile", (char*)p) != -1){
    3689:	8b 45 f4             	mov    -0xc(%ebp),%eax
    368c:	83 ec 08             	sub    $0x8,%esp
    368f:	50                   	push   %eax
    3690:	68 ce 5a 00 00       	push   $0x5ace
    3695:	e8 c0 09 00 00       	call   405a <link>
    369a:	83 c4 10             	add    $0x10,%esp
    369d:	83 f8 ff             	cmp    $0xffffffff,%eax
    36a0:	74 1b                	je     36bd <validatetest+0xb2>
      printf(stdout, "link should not succeed\n");
    36a2:	a1 ac 64 00 00       	mov    0x64ac,%eax
    36a7:	83 ec 08             	sub    $0x8,%esp
    36aa:	68 d9 5a 00 00       	push   $0x5ad9
    36af:	50                   	push   %eax
    36b0:	e8 c1 0a 00 00       	call   4176 <printf>
    36b5:	83 c4 10             	add    $0x10,%esp
      exit();
    36b8:	e8 3d 09 00 00       	call   3ffa <exit>
  for(p = 0; p <= (uint)hi; p += 4096){
    36bd:	81 45 f4 00 10 00 00 	addl   $0x1000,-0xc(%ebp)
    36c4:	8b 45 f0             	mov    -0x10(%ebp),%eax
    36c7:	3b 45 f4             	cmp    -0xc(%ebp),%eax
    36ca:	0f 83 6a ff ff ff    	jae    363a <validatetest+0x2f>
    }
  }

  printf(stdout, "validate ok\n");
    36d0:	a1 ac 64 00 00       	mov    0x64ac,%eax
    36d5:	83 ec 08             	sub    $0x8,%esp
    36d8:	68 f2 5a 00 00       	push   $0x5af2
    36dd:	50                   	push   %eax
    36de:	e8 93 0a 00 00       	call   4176 <printf>
    36e3:	83 c4 10             	add    $0x10,%esp
}
    36e6:	90                   	nop
    36e7:	c9                   	leave
    36e8:	c3                   	ret

000036e9 <bsstest>:

// does unintialized data start out zero?
char uninit[10000];
void
bsstest(void)
{
    36e9:	55                   	push   %ebp
    36ea:	89 e5                	mov    %esp,%ebp
    36ec:	83 ec 18             	sub    $0x18,%esp
  int i;

  printf(stdout, "bss test\n");
    36ef:	a1 ac 64 00 00       	mov    0x64ac,%eax
    36f4:	83 ec 08             	sub    $0x8,%esp
    36f7:	68 ff 5a 00 00       	push   $0x5aff
    36fc:	50                   	push   %eax
    36fd:	e8 74 0a 00 00       	call   4176 <printf>
    3702:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < sizeof(uninit); i++){
    3705:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    370c:	eb 2e                	jmp    373c <bsstest+0x53>
    if(uninit[i] != '\0'){
    370e:	8b 45 f4             	mov    -0xc(%ebp),%eax
    3711:	05 00 85 00 00       	add    $0x8500,%eax
    3716:	0f b6 00             	movzbl (%eax),%eax
    3719:	84 c0                	test   %al,%al
    371b:	74 1b                	je     3738 <bsstest+0x4f>
      printf(stdout, "bss test failed\n");
    371d:	a1 ac 64 00 00       	mov    0x64ac,%eax
    3722:	83 ec 08             	sub    $0x8,%esp
    3725:	68 09 5b 00 00       	push   $0x5b09
    372a:	50                   	push   %eax
    372b:	e8 46 0a 00 00       	call   4176 <printf>
    3730:	83 c4 10             	add    $0x10,%esp
      exit();
    3733:	e8 c2 08 00 00       	call   3ffa <exit>
  for(i = 0; i < sizeof(uninit); i++){
    3738:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    373c:	8b 45 f4             	mov    -0xc(%ebp),%eax
    373f:	3d 0f 27 00 00       	cmp    $0x270f,%eax
    3744:	76 c8                	jbe    370e <bsstest+0x25>
    }
  }
  printf(stdout, "bss test ok\n");
    3746:	a1 ac 64 00 00       	mov    0x64ac,%eax
    374b:	83 ec 08             	sub    $0x8,%esp
    374e:	68 1a 5b 00 00       	push   $0x5b1a
    3753:	50                   	push   %eax
    3754:	e8 1d 0a 00 00       	call   4176 <printf>
    3759:	83 c4 10             	add    $0x10,%esp
}
    375c:	90                   	nop
    375d:	c9                   	leave
    375e:	c3                   	ret

0000375f <bigargtest>:
// does exec return an error if the arguments
// are larger than a page? or does it write
// below the stack and wreck the instructions/data?
void
bigargtest(void)
{
    375f:	55                   	push   %ebp
    3760:	89 e5                	mov    %esp,%ebp
    3762:	83 ec 18             	sub    $0x18,%esp
  int pid, fd;

  unlink("bigarg-ok");
    3765:	83 ec 0c             	sub    $0xc,%esp
    3768:	68 27 5b 00 00       	push   $0x5b27
    376d:	e8 d8 08 00 00       	call   404a <unlink>
    3772:	83 c4 10             	add    $0x10,%esp
  pid = fork();
    3775:	e8 78 08 00 00       	call   3ff2 <fork>
    377a:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(pid == 0){
    377d:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    3781:	0f 85 97 00 00 00    	jne    381e <bigargtest+0xbf>
    static char *args[MAXARG];
    int i;
    for(i = 0; i < MAXARG-1; i++)
    3787:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    378e:	eb 12                	jmp    37a2 <bigargtest+0x43>
      args[i] = "bigargs test: failed\n                                                                                                                                                                                                       ";
    3790:	8b 45 f4             	mov    -0xc(%ebp),%eax
    3793:	c7 04 85 20 ac 00 00 	movl   $0x5b34,0xac20(,%eax,4)
    379a:	34 5b 00 00 
    for(i = 0; i < MAXARG-1; i++)
    379e:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    37a2:	83 7d f4 1e          	cmpl   $0x1e,-0xc(%ebp)
    37a6:	7e e8                	jle    3790 <bigargtest+0x31>
    args[MAXARG-1] = 0;
    37a8:	c7 05 9c ac 00 00 00 	movl   $0x0,0xac9c
    37af:	00 00 00 
    printf(stdout, "bigarg test\n");
    37b2:	a1 ac 64 00 00       	mov    0x64ac,%eax
    37b7:	83 ec 08             	sub    $0x8,%esp
    37ba:	68 11 5c 00 00       	push   $0x5c11
    37bf:	50                   	push   %eax
    37c0:	e8 b1 09 00 00       	call   4176 <printf>
    37c5:	83 c4 10             	add    $0x10,%esp
    exec("echo", args);
    37c8:	83 ec 08             	sub    $0x8,%esp
    37cb:	68 20 ac 00 00       	push   $0xac20
    37d0:	68 30 45 00 00       	push   $0x4530
    37d5:	e8 58 08 00 00       	call   4032 <exec>
    37da:	83 c4 10             	add    $0x10,%esp
    printf(stdout, "bigarg test ok\n");
    37dd:	a1 ac 64 00 00       	mov    0x64ac,%eax
    37e2:	83 ec 08             	sub    $0x8,%esp
    37e5:	68 1e 5c 00 00       	push   $0x5c1e
    37ea:	50                   	push   %eax
    37eb:	e8 86 09 00 00       	call   4176 <printf>
    37f0:	83 c4 10             	add    $0x10,%esp
    fd = open("bigarg-ok", O_CREATE);
    37f3:	83 ec 08             	sub    $0x8,%esp
    37f6:	68 00 02 00 00       	push   $0x200
    37fb:	68 27 5b 00 00       	push   $0x5b27
    3800:	e8 35 08 00 00       	call   403a <open>
    3805:	83 c4 10             	add    $0x10,%esp
    3808:	89 45 ec             	mov    %eax,-0x14(%ebp)
    close(fd);
    380b:	83 ec 0c             	sub    $0xc,%esp
    380e:	ff 75 ec             	push   -0x14(%ebp)
    3811:	e8 0c 08 00 00       	call   4022 <close>
    3816:	83 c4 10             	add    $0x10,%esp
    exit();
    3819:	e8 dc 07 00 00       	call   3ffa <exit>
  } else if(pid < 0){
    381e:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    3822:	79 1b                	jns    383f <bigargtest+0xe0>
    printf(stdout, "bigargtest: fork failed\n");
    3824:	a1 ac 64 00 00       	mov    0x64ac,%eax
    3829:	83 ec 08             	sub    $0x8,%esp
    382c:	68 2e 5c 00 00       	push   $0x5c2e
    3831:	50                   	push   %eax
    3832:	e8 3f 09 00 00       	call   4176 <printf>
    3837:	83 c4 10             	add    $0x10,%esp
    exit();
    383a:	e8 bb 07 00 00       	call   3ffa <exit>
  }
  wait();
    383f:	e8 be 07 00 00       	call   4002 <wait>
  fd = open("bigarg-ok", 0);
    3844:	83 ec 08             	sub    $0x8,%esp
    3847:	6a 00                	push   $0x0
    3849:	68 27 5b 00 00       	push   $0x5b27
    384e:	e8 e7 07 00 00       	call   403a <open>
    3853:	83 c4 10             	add    $0x10,%esp
    3856:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if(fd < 0){
    3859:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    385d:	79 1b                	jns    387a <bigargtest+0x11b>
    printf(stdout, "bigarg test failed!\n");
    385f:	a1 ac 64 00 00       	mov    0x64ac,%eax
    3864:	83 ec 08             	sub    $0x8,%esp
    3867:	68 47 5c 00 00       	push   $0x5c47
    386c:	50                   	push   %eax
    386d:	e8 04 09 00 00       	call   4176 <printf>
    3872:	83 c4 10             	add    $0x10,%esp
    exit();
    3875:	e8 80 07 00 00       	call   3ffa <exit>
  }
  close(fd);
    387a:	83 ec 0c             	sub    $0xc,%esp
    387d:	ff 75 ec             	push   -0x14(%ebp)
    3880:	e8 9d 07 00 00       	call   4022 <close>
    3885:	83 c4 10             	add    $0x10,%esp
  unlink("bigarg-ok");
    3888:	83 ec 0c             	sub    $0xc,%esp
    388b:	68 27 5b 00 00       	push   $0x5b27
    3890:	e8 b5 07 00 00       	call   404a <unlink>
    3895:	83 c4 10             	add    $0x10,%esp
}
    3898:	90                   	nop
    3899:	c9                   	leave
    389a:	c3                   	ret

0000389b <fsfull>:

// what happens when the file system runs out of blocks?
// answer: balloc panics, so this test is not useful.
void
fsfull()
{
    389b:	55                   	push   %ebp
    389c:	89 e5                	mov    %esp,%ebp
    389e:	53                   	push   %ebx
    389f:	83 ec 64             	sub    $0x64,%esp
  int nfiles;
  int fsblocks = 0;
    38a2:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)

  printf(1, "fsfull test\n");
    38a9:	83 ec 08             	sub    $0x8,%esp
    38ac:	68 5c 5c 00 00       	push   $0x5c5c
    38b1:	6a 01                	push   $0x1
    38b3:	e8 be 08 00 00       	call   4176 <printf>
    38b8:	83 c4 10             	add    $0x10,%esp

  for(nfiles = 0; ; nfiles++){
    38bb:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    char name[64];
    name[0] = 'f';
    38c2:	c6 45 a4 66          	movb   $0x66,-0x5c(%ebp)
    name[1] = '0' + nfiles / 1000;
    38c6:	8b 4d f4             	mov    -0xc(%ebp),%ecx
    38c9:	ba d3 4d 62 10       	mov    $0x10624dd3,%edx
    38ce:	89 c8                	mov    %ecx,%eax
    38d0:	f7 ea                	imul   %edx
    38d2:	c1 fa 06             	sar    $0x6,%edx
    38d5:	89 c8                	mov    %ecx,%eax
    38d7:	c1 f8 1f             	sar    $0x1f,%eax
    38da:	29 c2                	sub    %eax,%edx
    38dc:	89 d0                	mov    %edx,%eax
    38de:	83 c0 30             	add    $0x30,%eax
    38e1:	88 45 a5             	mov    %al,-0x5b(%ebp)
    name[2] = '0' + (nfiles % 1000) / 100;
    38e4:	8b 5d f4             	mov    -0xc(%ebp),%ebx
    38e7:	ba d3 4d 62 10       	mov    $0x10624dd3,%edx
    38ec:	89 d8                	mov    %ebx,%eax
    38ee:	f7 ea                	imul   %edx
    38f0:	c1 fa 06             	sar    $0x6,%edx
    38f3:	89 d8                	mov    %ebx,%eax
    38f5:	c1 f8 1f             	sar    $0x1f,%eax
    38f8:	89 d1                	mov    %edx,%ecx
    38fa:	29 c1                	sub    %eax,%ecx
    38fc:	69 c1 e8 03 00 00    	imul   $0x3e8,%ecx,%eax
    3902:	29 c3                	sub    %eax,%ebx
    3904:	89 d9                	mov    %ebx,%ecx
    3906:	ba 1f 85 eb 51       	mov    $0x51eb851f,%edx
    390b:	89 c8                	mov    %ecx,%eax
    390d:	f7 ea                	imul   %edx
    390f:	c1 fa 05             	sar    $0x5,%edx
    3912:	89 c8                	mov    %ecx,%eax
    3914:	c1 f8 1f             	sar    $0x1f,%eax
    3917:	29 c2                	sub    %eax,%edx
    3919:	89 d0                	mov    %edx,%eax
    391b:	83 c0 30             	add    $0x30,%eax
    391e:	88 45 a6             	mov    %al,-0x5a(%ebp)
    name[3] = '0' + (nfiles % 100) / 10;
    3921:	8b 5d f4             	mov    -0xc(%ebp),%ebx
    3924:	ba 1f 85 eb 51       	mov    $0x51eb851f,%edx
    3929:	89 d8                	mov    %ebx,%eax
    392b:	f7 ea                	imul   %edx
    392d:	c1 fa 05             	sar    $0x5,%edx
    3930:	89 d8                	mov    %ebx,%eax
    3932:	c1 f8 1f             	sar    $0x1f,%eax
    3935:	89 d1                	mov    %edx,%ecx
    3937:	29 c1                	sub    %eax,%ecx
    3939:	6b c1 64             	imul   $0x64,%ecx,%eax
    393c:	29 c3                	sub    %eax,%ebx
    393e:	89 d9                	mov    %ebx,%ecx
    3940:	ba 67 66 66 66       	mov    $0x66666667,%edx
    3945:	89 c8                	mov    %ecx,%eax
    3947:	f7 ea                	imul   %edx
    3949:	c1 fa 02             	sar    $0x2,%edx
    394c:	89 c8                	mov    %ecx,%eax
    394e:	c1 f8 1f             	sar    $0x1f,%eax
    3951:	29 c2                	sub    %eax,%edx
    3953:	89 d0                	mov    %edx,%eax
    3955:	83 c0 30             	add    $0x30,%eax
    3958:	88 45 a7             	mov    %al,-0x59(%ebp)
    name[4] = '0' + (nfiles % 10);
    395b:	8b 4d f4             	mov    -0xc(%ebp),%ecx
    395e:	ba 67 66 66 66       	mov    $0x66666667,%edx
    3963:	89 c8                	mov    %ecx,%eax
    3965:	f7 ea                	imul   %edx
    3967:	c1 fa 02             	sar    $0x2,%edx
    396a:	89 c8                	mov    %ecx,%eax
    396c:	c1 f8 1f             	sar    $0x1f,%eax
    396f:	29 c2                	sub    %eax,%edx
    3971:	89 d0                	mov    %edx,%eax
    3973:	c1 e0 02             	shl    $0x2,%eax
    3976:	01 d0                	add    %edx,%eax
    3978:	01 c0                	add    %eax,%eax
    397a:	29 c1                	sub    %eax,%ecx
    397c:	89 ca                	mov    %ecx,%edx
    397e:	89 d0                	mov    %edx,%eax
    3980:	83 c0 30             	add    $0x30,%eax
    3983:	88 45 a8             	mov    %al,-0x58(%ebp)
    name[5] = '\0';
    3986:	c6 45 a9 00          	movb   $0x0,-0x57(%ebp)
    printf(1, "writing %s\n", name);
    398a:	83 ec 04             	sub    $0x4,%esp
    398d:	8d 45 a4             	lea    -0x5c(%ebp),%eax
    3990:	50                   	push   %eax
    3991:	68 69 5c 00 00       	push   $0x5c69
    3996:	6a 01                	push   $0x1
    3998:	e8 d9 07 00 00       	call   4176 <printf>
    399d:	83 c4 10             	add    $0x10,%esp
    int fd = open(name, O_CREATE|O_RDWR);
    39a0:	83 ec 08             	sub    $0x8,%esp
    39a3:	68 02 02 00 00       	push   $0x202
    39a8:	8d 45 a4             	lea    -0x5c(%ebp),%eax
    39ab:	50                   	push   %eax
    39ac:	e8 89 06 00 00       	call   403a <open>
    39b1:	83 c4 10             	add    $0x10,%esp
    39b4:	89 45 e8             	mov    %eax,-0x18(%ebp)
    if(fd < 0){
    39b7:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
    39bb:	79 18                	jns    39d5 <fsfull+0x13a>
      printf(1, "open %s failed\n", name);
    39bd:	83 ec 04             	sub    $0x4,%esp
    39c0:	8d 45 a4             	lea    -0x5c(%ebp),%eax
    39c3:	50                   	push   %eax
    39c4:	68 75 5c 00 00       	push   $0x5c75
    39c9:	6a 01                	push   $0x1
    39cb:	e8 a6 07 00 00       	call   4176 <printf>
    39d0:	83 c4 10             	add    $0x10,%esp
      break;
    39d3:	eb 6b                	jmp    3a40 <fsfull+0x1a5>
    }
    int total = 0;
    39d5:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
    while(1){
      int cc = write(fd, buf, 512);
    39dc:	83 ec 04             	sub    $0x4,%esp
    39df:	68 00 02 00 00       	push   $0x200
    39e4:	68 e0 64 00 00       	push   $0x64e0
    39e9:	ff 75 e8             	push   -0x18(%ebp)
    39ec:	e8 29 06 00 00       	call   401a <write>
    39f1:	83 c4 10             	add    $0x10,%esp
    39f4:	89 45 e4             	mov    %eax,-0x1c(%ebp)
      if(cc < 512)
    39f7:	81 7d e4 ff 01 00 00 	cmpl   $0x1ff,-0x1c(%ebp)
    39fe:	7e 0c                	jle    3a0c <fsfull+0x171>
        break;
      total += cc;
    3a00:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    3a03:	01 45 ec             	add    %eax,-0x14(%ebp)
      fsblocks++;
    3a06:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    while(1){
    3a0a:	eb d0                	jmp    39dc <fsfull+0x141>
        break;
    3a0c:	90                   	nop
    }
    printf(1, "wrote %d bytes\n", total);
    3a0d:	83 ec 04             	sub    $0x4,%esp
    3a10:	ff 75 ec             	push   -0x14(%ebp)
    3a13:	68 85 5c 00 00       	push   $0x5c85
    3a18:	6a 01                	push   $0x1
    3a1a:	e8 57 07 00 00       	call   4176 <printf>
    3a1f:	83 c4 10             	add    $0x10,%esp
    close(fd);
    3a22:	83 ec 0c             	sub    $0xc,%esp
    3a25:	ff 75 e8             	push   -0x18(%ebp)
    3a28:	e8 f5 05 00 00       	call   4022 <close>
    3a2d:	83 c4 10             	add    $0x10,%esp
    if(total == 0)
    3a30:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    3a34:	74 09                	je     3a3f <fsfull+0x1a4>
  for(nfiles = 0; ; nfiles++){
    3a36:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
    3a3a:	e9 83 fe ff ff       	jmp    38c2 <fsfull+0x27>
      break;
    3a3f:	90                   	nop
  }

  while(nfiles >= 0){
    3a40:	e9 db 00 00 00       	jmp    3b20 <fsfull+0x285>
    char name[64];
    name[0] = 'f';
    3a45:	c6 45 a4 66          	movb   $0x66,-0x5c(%ebp)
    name[1] = '0' + nfiles / 1000;
    3a49:	8b 4d f4             	mov    -0xc(%ebp),%ecx
    3a4c:	ba d3 4d 62 10       	mov    $0x10624dd3,%edx
    3a51:	89 c8                	mov    %ecx,%eax
    3a53:	f7 ea                	imul   %edx
    3a55:	c1 fa 06             	sar    $0x6,%edx
    3a58:	89 c8                	mov    %ecx,%eax
    3a5a:	c1 f8 1f             	sar    $0x1f,%eax
    3a5d:	29 c2                	sub    %eax,%edx
    3a5f:	89 d0                	mov    %edx,%eax
    3a61:	83 c0 30             	add    $0x30,%eax
    3a64:	88 45 a5             	mov    %al,-0x5b(%ebp)
    name[2] = '0' + (nfiles % 1000) / 100;
    3a67:	8b 5d f4             	mov    -0xc(%ebp),%ebx
    3a6a:	ba d3 4d 62 10       	mov    $0x10624dd3,%edx
    3a6f:	89 d8                	mov    %ebx,%eax
    3a71:	f7 ea                	imul   %edx
    3a73:	c1 fa 06             	sar    $0x6,%edx
    3a76:	89 d8                	mov    %ebx,%eax
    3a78:	c1 f8 1f             	sar    $0x1f,%eax
    3a7b:	89 d1                	mov    %edx,%ecx
    3a7d:	29 c1                	sub    %eax,%ecx
    3a7f:	69 c1 e8 03 00 00    	imul   $0x3e8,%ecx,%eax
    3a85:	29 c3                	sub    %eax,%ebx
    3a87:	89 d9                	mov    %ebx,%ecx
    3a89:	ba 1f 85 eb 51       	mov    $0x51eb851f,%edx
    3a8e:	89 c8                	mov    %ecx,%eax
    3a90:	f7 ea                	imul   %edx
    3a92:	c1 fa 05             	sar    $0x5,%edx
    3a95:	89 c8                	mov    %ecx,%eax
    3a97:	c1 f8 1f             	sar    $0x1f,%eax
    3a9a:	29 c2                	sub    %eax,%edx
    3a9c:	89 d0                	mov    %edx,%eax
    3a9e:	83 c0 30             	add    $0x30,%eax
    3aa1:	88 45 a6             	mov    %al,-0x5a(%ebp)
    name[3] = '0' + (nfiles % 100) / 10;
    3aa4:	8b 5d f4             	mov    -0xc(%ebp),%ebx
    3aa7:	ba 1f 85 eb 51       	mov    $0x51eb851f,%edx
    3aac:	89 d8                	mov    %ebx,%eax
    3aae:	f7 ea                	imul   %edx
    3ab0:	c1 fa 05             	sar    $0x5,%edx
    3ab3:	89 d8                	mov    %ebx,%eax
    3ab5:	c1 f8 1f             	sar    $0x1f,%eax
    3ab8:	89 d1                	mov    %edx,%ecx
    3aba:	29 c1                	sub    %eax,%ecx
    3abc:	6b c1 64             	imul   $0x64,%ecx,%eax
    3abf:	29 c3                	sub    %eax,%ebx
    3ac1:	89 d9                	mov    %ebx,%ecx
    3ac3:	ba 67 66 66 66       	mov    $0x66666667,%edx
    3ac8:	89 c8                	mov    %ecx,%eax
    3aca:	f7 ea                	imul   %edx
    3acc:	c1 fa 02             	sar    $0x2,%edx
    3acf:	89 c8                	mov    %ecx,%eax
    3ad1:	c1 f8 1f             	sar    $0x1f,%eax
    3ad4:	29 c2                	sub    %eax,%edx
    3ad6:	89 d0                	mov    %edx,%eax
    3ad8:	83 c0 30             	add    $0x30,%eax
    3adb:	88 45 a7             	mov    %al,-0x59(%ebp)
    name[4] = '0' + (nfiles % 10);
    3ade:	8b 4d f4             	mov    -0xc(%ebp),%ecx
    3ae1:	ba 67 66 66 66       	mov    $0x66666667,%edx
    3ae6:	89 c8                	mov    %ecx,%eax
    3ae8:	f7 ea                	imul   %edx
    3aea:	c1 fa 02             	sar    $0x2,%edx
    3aed:	89 c8                	mov    %ecx,%eax
    3aef:	c1 f8 1f             	sar    $0x1f,%eax
    3af2:	29 c2                	sub    %eax,%edx
    3af4:	89 d0                	mov    %edx,%eax
    3af6:	c1 e0 02             	shl    $0x2,%eax
    3af9:	01 d0                	add    %edx,%eax
    3afb:	01 c0                	add    %eax,%eax
    3afd:	29 c1                	sub    %eax,%ecx
    3aff:	89 ca                	mov    %ecx,%edx
    3b01:	89 d0                	mov    %edx,%eax
    3b03:	83 c0 30             	add    $0x30,%eax
    3b06:	88 45 a8             	mov    %al,-0x58(%ebp)
    name[5] = '\0';
    3b09:	c6 45 a9 00          	movb   $0x0,-0x57(%ebp)
    unlink(name);
    3b0d:	83 ec 0c             	sub    $0xc,%esp
    3b10:	8d 45 a4             	lea    -0x5c(%ebp),%eax
    3b13:	50                   	push   %eax
    3b14:	e8 31 05 00 00       	call   404a <unlink>
    3b19:	83 c4 10             	add    $0x10,%esp
    nfiles--;
    3b1c:	83 6d f4 01          	subl   $0x1,-0xc(%ebp)
  while(nfiles >= 0){
    3b20:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    3b24:	0f 89 1b ff ff ff    	jns    3a45 <fsfull+0x1aa>
  }

  printf(1, "fsfull test finished\n");
    3b2a:	83 ec 08             	sub    $0x8,%esp
    3b2d:	68 95 5c 00 00       	push   $0x5c95
    3b32:	6a 01                	push   $0x1
    3b34:	e8 3d 06 00 00       	call   4176 <printf>
    3b39:	83 c4 10             	add    $0x10,%esp
}
    3b3c:	90                   	nop
    3b3d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    3b40:	c9                   	leave
    3b41:	c3                   	ret

00003b42 <uio>:

void
uio()
{
    3b42:	55                   	push   %ebp
    3b43:	89 e5                	mov    %esp,%ebp
    3b45:	83 ec 18             	sub    $0x18,%esp
  #define RTC_ADDR 0x70
  #define RTC_DATA 0x71

  ushort port = 0;
    3b48:	66 c7 45 f6 00 00    	movw   $0x0,-0xa(%ebp)
  uchar val = 0;
    3b4e:	c6 45 f5 00          	movb   $0x0,-0xb(%ebp)
  int pid;

  printf(1, "uio test\n");
    3b52:	83 ec 08             	sub    $0x8,%esp
    3b55:	68 ab 5c 00 00       	push   $0x5cab
    3b5a:	6a 01                	push   $0x1
    3b5c:	e8 15 06 00 00       	call   4176 <printf>
    3b61:	83 c4 10             	add    $0x10,%esp
  pid = fork();
    3b64:	e8 89 04 00 00       	call   3ff2 <fork>
    3b69:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(pid == 0){
    3b6c:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    3b70:	75 3a                	jne    3bac <uio+0x6a>
    port = RTC_ADDR;
    3b72:	66 c7 45 f6 70 00    	movw   $0x70,-0xa(%ebp)
    val = 0x09;  /* year */
    3b78:	c6 45 f5 09          	movb   $0x9,-0xb(%ebp)
    /* http://wiki.osdev.org/Inline_Assembly/Examples */
    asm volatile("outb %0,%1"::"a"(val), "d" (port));
    3b7c:	0f b6 45 f5          	movzbl -0xb(%ebp),%eax
    3b80:	0f b7 55 f6          	movzwl -0xa(%ebp),%edx
    3b84:	ee                   	out    %al,(%dx)
    port = RTC_DATA;
    3b85:	66 c7 45 f6 71 00    	movw   $0x71,-0xa(%ebp)
    asm volatile("inb %1,%0" : "=a" (val) : "d" (port));
    3b8b:	0f b7 45 f6          	movzwl -0xa(%ebp),%eax
    3b8f:	89 c2                	mov    %eax,%edx
    3b91:	ec                   	in     (%dx),%al
    3b92:	88 45 f5             	mov    %al,-0xb(%ebp)
    printf(1, "uio: uio succeeded; test FAILED\n");
    3b95:	83 ec 08             	sub    $0x8,%esp
    3b98:	68 b8 5c 00 00       	push   $0x5cb8
    3b9d:	6a 01                	push   $0x1
    3b9f:	e8 d2 05 00 00       	call   4176 <printf>
    3ba4:	83 c4 10             	add    $0x10,%esp
    exit();
    3ba7:	e8 4e 04 00 00       	call   3ffa <exit>
  } else if(pid < 0){
    3bac:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    3bb0:	79 17                	jns    3bc9 <uio+0x87>
    printf (1, "fork failed\n");
    3bb2:	83 ec 08             	sub    $0x8,%esp
    3bb5:	68 d1 45 00 00       	push   $0x45d1
    3bba:	6a 01                	push   $0x1
    3bbc:	e8 b5 05 00 00       	call   4176 <printf>
    3bc1:	83 c4 10             	add    $0x10,%esp
    exit();
    3bc4:	e8 31 04 00 00       	call   3ffa <exit>
  }
  wait();
    3bc9:	e8 34 04 00 00       	call   4002 <wait>
  printf(1, "uio test done\n");
    3bce:	83 ec 08             	sub    $0x8,%esp
    3bd1:	68 d9 5c 00 00       	push   $0x5cd9
    3bd6:	6a 01                	push   $0x1
    3bd8:	e8 99 05 00 00       	call   4176 <printf>
    3bdd:	83 c4 10             	add    $0x10,%esp
}
    3be0:	90                   	nop
    3be1:	c9                   	leave
    3be2:	c3                   	ret

00003be3 <argptest>:

void argptest()
{
    3be3:	55                   	push   %ebp
    3be4:	89 e5                	mov    %esp,%ebp
    3be6:	83 ec 18             	sub    $0x18,%esp
  int fd;
  fd = open("init", O_RDONLY);
    3be9:	83 ec 08             	sub    $0x8,%esp
    3bec:	6a 00                	push   $0x0
    3bee:	68 e8 5c 00 00       	push   $0x5ce8
    3bf3:	e8 42 04 00 00       	call   403a <open>
    3bf8:	83 c4 10             	add    $0x10,%esp
    3bfb:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if (fd < 0) {
    3bfe:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    3c02:	79 17                	jns    3c1b <argptest+0x38>
    printf(2, "open failed\n");
    3c04:	83 ec 08             	sub    $0x8,%esp
    3c07:	68 ed 5c 00 00       	push   $0x5ced
    3c0c:	6a 02                	push   $0x2
    3c0e:	e8 63 05 00 00       	call   4176 <printf>
    3c13:	83 c4 10             	add    $0x10,%esp
    exit();
    3c16:	e8 df 03 00 00       	call   3ffa <exit>
  }
  read(fd, sbrk(0) - 1, -1);
    3c1b:	83 ec 0c             	sub    $0xc,%esp
    3c1e:	6a 00                	push   $0x0
    3c20:	e8 5d 04 00 00       	call   4082 <sbrk>
    3c25:	83 c4 10             	add    $0x10,%esp
    3c28:	83 e8 01             	sub    $0x1,%eax
    3c2b:	83 ec 04             	sub    $0x4,%esp
    3c2e:	6a ff                	push   $0xffffffff
    3c30:	50                   	push   %eax
    3c31:	ff 75 f4             	push   -0xc(%ebp)
    3c34:	e8 d9 03 00 00       	call   4012 <read>
    3c39:	83 c4 10             	add    $0x10,%esp
  close(fd);
    3c3c:	83 ec 0c             	sub    $0xc,%esp
    3c3f:	ff 75 f4             	push   -0xc(%ebp)
    3c42:	e8 db 03 00 00       	call   4022 <close>
    3c47:	83 c4 10             	add    $0x10,%esp
  printf(1, "arg test passed\n");
    3c4a:	83 ec 08             	sub    $0x8,%esp
    3c4d:	68 fa 5c 00 00       	push   $0x5cfa
    3c52:	6a 01                	push   $0x1
    3c54:	e8 1d 05 00 00       	call   4176 <printf>
    3c59:	83 c4 10             	add    $0x10,%esp
}
    3c5c:	90                   	nop
    3c5d:	c9                   	leave
    3c5e:	c3                   	ret

00003c5f <rand>:

unsigned long randstate = 1;
unsigned int
rand()
{
    3c5f:	55                   	push   %ebp
    3c60:	89 e5                	mov    %esp,%ebp
  randstate = randstate * 1664525 + 1013904223;
    3c62:	a1 b0 64 00 00       	mov    0x64b0,%eax
    3c67:	69 c0 0d 66 19 00    	imul   $0x19660d,%eax,%eax
    3c6d:	05 5f f3 6e 3c       	add    $0x3c6ef35f,%eax
    3c72:	a3 b0 64 00 00       	mov    %eax,0x64b0
  return randstate;
    3c77:	a1 b0 64 00 00       	mov    0x64b0,%eax
}
    3c7c:	5d                   	pop    %ebp
    3c7d:	c3                   	ret

00003c7e <main>:

int
main(int argc, char *argv[])
{
    3c7e:	8d 4c 24 04          	lea    0x4(%esp),%ecx
    3c82:	83 e4 f0             	and    $0xfffffff0,%esp
    3c85:	ff 71 fc             	push   -0x4(%ecx)
    3c88:	55                   	push   %ebp
    3c89:	89 e5                	mov    %esp,%ebp
    3c8b:	51                   	push   %ecx
    3c8c:	83 ec 04             	sub    $0x4,%esp
  printf(1, "usertests starting\n");
    3c8f:	83 ec 08             	sub    $0x8,%esp
    3c92:	68 0b 5d 00 00       	push   $0x5d0b
    3c97:	6a 01                	push   $0x1
    3c99:	e8 d8 04 00 00       	call   4176 <printf>
    3c9e:	83 c4 10             	add    $0x10,%esp

  if(open("usertests.ran", 0) >= 0){
    3ca1:	83 ec 08             	sub    $0x8,%esp
    3ca4:	6a 00                	push   $0x0
    3ca6:	68 1f 5d 00 00       	push   $0x5d1f
    3cab:	e8 8a 03 00 00       	call   403a <open>
    3cb0:	83 c4 10             	add    $0x10,%esp
    3cb3:	85 c0                	test   %eax,%eax
    3cb5:	78 17                	js     3cce <main+0x50>
    printf(1, "already ran user tests -- rebuild fs.img\n");
    3cb7:	83 ec 08             	sub    $0x8,%esp
    3cba:	68 30 5d 00 00       	push   $0x5d30
    3cbf:	6a 01                	push   $0x1
    3cc1:	e8 b0 04 00 00       	call   4176 <printf>
    3cc6:	83 c4 10             	add    $0x10,%esp
    exit();
    3cc9:	e8 2c 03 00 00       	call   3ffa <exit>
  }
  close(open("usertests.ran", O_CREATE));
    3cce:	83 ec 08             	sub    $0x8,%esp
    3cd1:	68 00 02 00 00       	push   $0x200
    3cd6:	68 1f 5d 00 00       	push   $0x5d1f
    3cdb:	e8 5a 03 00 00       	call   403a <open>
    3ce0:	83 c4 10             	add    $0x10,%esp
    3ce3:	83 ec 0c             	sub    $0xc,%esp
    3ce6:	50                   	push   %eax
    3ce7:	e8 36 03 00 00       	call   4022 <close>
    3cec:	83 c4 10             	add    $0x10,%esp

  argptest();
    3cef:	e8 ef fe ff ff       	call   3be3 <argptest>
  createdelete();
    3cf4:	e8 b4 d5 ff ff       	call   12ad <createdelete>
  linkunlink();
    3cf9:	e8 d9 df ff ff       	call   1cd7 <linkunlink>
  concreate();
    3cfe:	e8 20 dc ff ff       	call   1923 <concreate>
  fourfiles();
    3d03:	e8 54 d3 ff ff       	call   105c <fourfiles>
  sharedfd();
    3d08:	e8 6c d1 ff ff       	call   e79 <sharedfd>

  bigargtest();
    3d0d:	e8 4d fa ff ff       	call   375f <bigargtest>
  bigwrite();
    3d12:	e8 bd e9 ff ff       	call   26d4 <bigwrite>
  bigargtest();
    3d17:	e8 43 fa ff ff       	call   375f <bigargtest>
  bsstest();
    3d1c:	e8 c8 f9 ff ff       	call   36e9 <bsstest>
  sbrktest();
    3d21:	e8 e1 f3 ff ff       	call   3107 <sbrktest>
  validatetest();
    3d26:	e8 e0 f8 ff ff       	call   360b <validatetest>

  opentest();
    3d2b:	e8 cf c5 ff ff       	call   2ff <opentest>
  writetest();
    3d30:	e8 79 c6 ff ff       	call   3ae <writetest>
  writetest1();
    3d35:	e8 84 c8 ff ff       	call   5be <writetest1>
  createtest();
    3d3a:	e8 7b ca ff ff       	call   7ba <createtest>

  openiputtest();
    3d3f:	e8 ac c4 ff ff       	call   1f0 <openiputtest>
  exitiputtest();
    3d44:	e8 a8 c3 ff ff       	call   f1 <exitiputtest>
  iputtest();
    3d49:	e8 b2 c2 ff ff       	call   0 <iputtest>

  mem();
    3d4e:	e8 35 d0 ff ff       	call   d88 <mem>
  pipe1();
    3d53:	e8 69 cc ff ff       	call   9c1 <pipe1>
  preempt();
    3d58:	e8 4d ce ff ff       	call   baa <preempt>
  exitwait();
    3d5d:	e8 ae cf ff ff       	call   d10 <exitwait>

  rmdot();
    3d62:	e8 df ed ff ff       	call   2b46 <rmdot>
  fourteen();
    3d67:	e8 7e ec ff ff       	call   29ea <fourteen>
  bigfile();
    3d6c:	e8 61 ea ff ff       	call   27d2 <bigfile>
  subdir();
    3d71:	e8 1a e2 ff ff       	call   1f90 <subdir>
  linktest();
    3d76:	e8 66 d9 ff ff       	call   16e1 <linktest>
  unlinkread();
    3d7b:	e8 9f d7 ff ff       	call   151f <unlinkread>
  dirfile();
    3d80:	e8 46 ef ff ff       	call   2ccb <dirfile>
  iref();
    3d85:	e8 79 f1 ff ff       	call   2f03 <iref>
  forktest();
    3d8a:	e8 ae f2 ff ff       	call   303d <forktest>
  bigdir(); // slow
    3d8f:	e8 7b e0 ff ff       	call   1e0f <bigdir>

  uio();
    3d94:	e8 a9 fd ff ff       	call   3b42 <uio>

  exectest();
    3d99:	e8 d0 cb ff ff       	call   96e <exectest>

  exit();
    3d9e:	e8 57 02 00 00       	call   3ffa <exit>

00003da3 <stosb>:
               "cc");
}

static inline void
stosb(void *addr, int data, int cnt)
{
    3da3:	55                   	push   %ebp
    3da4:	89 e5                	mov    %esp,%ebp
    3da6:	57                   	push   %edi
    3da7:	53                   	push   %ebx
  asm volatile("cld; rep stosb" :
    3da8:	8b 4d 08             	mov    0x8(%ebp),%ecx
    3dab:	8b 55 10             	mov    0x10(%ebp),%edx
    3dae:	8b 45 0c             	mov    0xc(%ebp),%eax
    3db1:	89 cb                	mov    %ecx,%ebx
    3db3:	89 df                	mov    %ebx,%edi
    3db5:	89 d1                	mov    %edx,%ecx
    3db7:	fc                   	cld
    3db8:	f3 aa                	rep stos %al,%es:(%edi)
    3dba:	89 ca                	mov    %ecx,%edx
    3dbc:	89 fb                	mov    %edi,%ebx
    3dbe:	89 5d 08             	mov    %ebx,0x8(%ebp)
    3dc1:	89 55 10             	mov    %edx,0x10(%ebp)
               "=D" (addr), "=c" (cnt) :
               "0" (addr), "1" (cnt), "a" (data) :
               "memory", "cc");
}
    3dc4:	90                   	nop
    3dc5:	5b                   	pop    %ebx
    3dc6:	5f                   	pop    %edi
    3dc7:	5d                   	pop    %ebp
    3dc8:	c3                   	ret

00003dc9 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
    3dc9:	55                   	push   %ebp
    3dca:	89 e5                	mov    %esp,%ebp
    3dcc:	83 ec 10             	sub    $0x10,%esp
  char *os;

  os = s;
    3dcf:	8b 45 08             	mov    0x8(%ebp),%eax
    3dd2:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while((*s++ = *t++) != 0)
    3dd5:	90                   	nop
    3dd6:	8b 55 0c             	mov    0xc(%ebp),%edx
    3dd9:	8d 42 01             	lea    0x1(%edx),%eax
    3ddc:	89 45 0c             	mov    %eax,0xc(%ebp)
    3ddf:	8b 45 08             	mov    0x8(%ebp),%eax
    3de2:	8d 48 01             	lea    0x1(%eax),%ecx
    3de5:	89 4d 08             	mov    %ecx,0x8(%ebp)
    3de8:	0f b6 12             	movzbl (%edx),%edx
    3deb:	88 10                	mov    %dl,(%eax)
    3ded:	0f b6 00             	movzbl (%eax),%eax
    3df0:	84 c0                	test   %al,%al
    3df2:	75 e2                	jne    3dd6 <strcpy+0xd>
    ;
  return os;
    3df4:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
    3df7:	c9                   	leave
    3df8:	c3                   	ret

00003df9 <strcmp>:

int
strcmp(const char *p, const char *q)
{
    3df9:	55                   	push   %ebp
    3dfa:	89 e5                	mov    %esp,%ebp
  while(*p && *p == *q)
    3dfc:	eb 08                	jmp    3e06 <strcmp+0xd>
    p++, q++;
    3dfe:	83 45 08 01          	addl   $0x1,0x8(%ebp)
    3e02:	83 45 0c 01          	addl   $0x1,0xc(%ebp)
  while(*p && *p == *q)
    3e06:	8b 45 08             	mov    0x8(%ebp),%eax
    3e09:	0f b6 00             	movzbl (%eax),%eax
    3e0c:	84 c0                	test   %al,%al
    3e0e:	74 10                	je     3e20 <strcmp+0x27>
    3e10:	8b 45 08             	mov    0x8(%ebp),%eax
    3e13:	0f b6 10             	movzbl (%eax),%edx
    3e16:	8b 45 0c             	mov    0xc(%ebp),%eax
    3e19:	0f b6 00             	movzbl (%eax),%eax
    3e1c:	38 c2                	cmp    %al,%dl
    3e1e:	74 de                	je     3dfe <strcmp+0x5>
  return (uchar)*p - (uchar)*q;
    3e20:	8b 45 08             	mov    0x8(%ebp),%eax
    3e23:	0f b6 00             	movzbl (%eax),%eax
    3e26:	0f b6 d0             	movzbl %al,%edx
    3e29:	8b 45 0c             	mov    0xc(%ebp),%eax
    3e2c:	0f b6 00             	movzbl (%eax),%eax
    3e2f:	0f b6 c0             	movzbl %al,%eax
    3e32:	29 c2                	sub    %eax,%edx
    3e34:	89 d0                	mov    %edx,%eax
}
    3e36:	5d                   	pop    %ebp
    3e37:	c3                   	ret

00003e38 <strlen>:

uint
strlen(const char *s)
{
    3e38:	55                   	push   %ebp
    3e39:	89 e5                	mov    %esp,%ebp
    3e3b:	83 ec 10             	sub    $0x10,%esp
  int n;

  for(n = 0; s[n]; n++)
    3e3e:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
    3e45:	eb 04                	jmp    3e4b <strlen+0x13>
    3e47:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
    3e4b:	8b 55 fc             	mov    -0x4(%ebp),%edx
    3e4e:	8b 45 08             	mov    0x8(%ebp),%eax
    3e51:	01 d0                	add    %edx,%eax
    3e53:	0f b6 00             	movzbl (%eax),%eax
    3e56:	84 c0                	test   %al,%al
    3e58:	75 ed                	jne    3e47 <strlen+0xf>
    ;
  return n;
    3e5a:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
    3e5d:	c9                   	leave
    3e5e:	c3                   	ret

00003e5f <memset>:

void*
memset(void *dst, int c, uint n)
{
    3e5f:	55                   	push   %ebp
    3e60:	89 e5                	mov    %esp,%ebp
  stosb(dst, c, n);
    3e62:	8b 45 10             	mov    0x10(%ebp),%eax
    3e65:	50                   	push   %eax
    3e66:	ff 75 0c             	push   0xc(%ebp)
    3e69:	ff 75 08             	push   0x8(%ebp)
    3e6c:	e8 32 ff ff ff       	call   3da3 <stosb>
    3e71:	83 c4 0c             	add    $0xc,%esp
  return dst;
    3e74:	8b 45 08             	mov    0x8(%ebp),%eax
}
    3e77:	c9                   	leave
    3e78:	c3                   	ret

00003e79 <strchr>:

char*
strchr(const char *s, char c)
{
    3e79:	55                   	push   %ebp
    3e7a:	89 e5                	mov    %esp,%ebp
    3e7c:	83 ec 04             	sub    $0x4,%esp
    3e7f:	8b 45 0c             	mov    0xc(%ebp),%eax
    3e82:	88 45 fc             	mov    %al,-0x4(%ebp)
  for(; *s; s++)
    3e85:	eb 14                	jmp    3e9b <strchr+0x22>
    if(*s == c)
    3e87:	8b 45 08             	mov    0x8(%ebp),%eax
    3e8a:	0f b6 00             	movzbl (%eax),%eax
    3e8d:	38 45 fc             	cmp    %al,-0x4(%ebp)
    3e90:	75 05                	jne    3e97 <strchr+0x1e>
      return (char*)s;
    3e92:	8b 45 08             	mov    0x8(%ebp),%eax
    3e95:	eb 13                	jmp    3eaa <strchr+0x31>
  for(; *s; s++)
    3e97:	83 45 08 01          	addl   $0x1,0x8(%ebp)
    3e9b:	8b 45 08             	mov    0x8(%ebp),%eax
    3e9e:	0f b6 00             	movzbl (%eax),%eax
    3ea1:	84 c0                	test   %al,%al
    3ea3:	75 e2                	jne    3e87 <strchr+0xe>
  return 0;
    3ea5:	b8 00 00 00 00       	mov    $0x0,%eax
}
    3eaa:	c9                   	leave
    3eab:	c3                   	ret

00003eac <gets>:

char*
gets(char *buf, int max)
{
    3eac:	55                   	push   %ebp
    3ead:	89 e5                	mov    %esp,%ebp
    3eaf:	83 ec 18             	sub    $0x18,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    3eb2:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    3eb9:	eb 42                	jmp    3efd <gets+0x51>
    cc = read(0, &c, 1);
    3ebb:	83 ec 04             	sub    $0x4,%esp
    3ebe:	6a 01                	push   $0x1
    3ec0:	8d 45 ef             	lea    -0x11(%ebp),%eax
    3ec3:	50                   	push   %eax
    3ec4:	6a 00                	push   $0x0
    3ec6:	e8 47 01 00 00       	call   4012 <read>
    3ecb:	83 c4 10             	add    $0x10,%esp
    3ece:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(cc < 1)
    3ed1:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    3ed5:	7e 33                	jle    3f0a <gets+0x5e>
      break;
    buf[i++] = c;
    3ed7:	8b 45 f4             	mov    -0xc(%ebp),%eax
    3eda:	8d 50 01             	lea    0x1(%eax),%edx
    3edd:	89 55 f4             	mov    %edx,-0xc(%ebp)
    3ee0:	89 c2                	mov    %eax,%edx
    3ee2:	8b 45 08             	mov    0x8(%ebp),%eax
    3ee5:	01 c2                	add    %eax,%edx
    3ee7:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
    3eeb:	88 02                	mov    %al,(%edx)
    if(c == '\n' || c == '\r')
    3eed:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
    3ef1:	3c 0a                	cmp    $0xa,%al
    3ef3:	74 16                	je     3f0b <gets+0x5f>
    3ef5:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
    3ef9:	3c 0d                	cmp    $0xd,%al
    3efb:	74 0e                	je     3f0b <gets+0x5f>
  for(i=0; i+1 < max; ){
    3efd:	8b 45 f4             	mov    -0xc(%ebp),%eax
    3f00:	83 c0 01             	add    $0x1,%eax
    3f03:	39 45 0c             	cmp    %eax,0xc(%ebp)
    3f06:	7f b3                	jg     3ebb <gets+0xf>
    3f08:	eb 01                	jmp    3f0b <gets+0x5f>
      break;
    3f0a:	90                   	nop
      break;
  }
  buf[i] = '\0';
    3f0b:	8b 55 f4             	mov    -0xc(%ebp),%edx
    3f0e:	8b 45 08             	mov    0x8(%ebp),%eax
    3f11:	01 d0                	add    %edx,%eax
    3f13:	c6 00 00             	movb   $0x0,(%eax)
  return buf;
    3f16:	8b 45 08             	mov    0x8(%ebp),%eax
}
    3f19:	c9                   	leave
    3f1a:	c3                   	ret

00003f1b <stat>:

int
stat(const char *n, struct stat *st)
{
    3f1b:	55                   	push   %ebp
    3f1c:	89 e5                	mov    %esp,%ebp
    3f1e:	83 ec 18             	sub    $0x18,%esp
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    3f21:	83 ec 08             	sub    $0x8,%esp
    3f24:	6a 00                	push   $0x0
    3f26:	ff 75 08             	push   0x8(%ebp)
    3f29:	e8 0c 01 00 00       	call   403a <open>
    3f2e:	83 c4 10             	add    $0x10,%esp
    3f31:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0)
    3f34:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    3f38:	79 07                	jns    3f41 <stat+0x26>
    return -1;
    3f3a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    3f3f:	eb 25                	jmp    3f66 <stat+0x4b>
  r = fstat(fd, st);
    3f41:	83 ec 08             	sub    $0x8,%esp
    3f44:	ff 75 0c             	push   0xc(%ebp)
    3f47:	ff 75 f4             	push   -0xc(%ebp)
    3f4a:	e8 03 01 00 00       	call   4052 <fstat>
    3f4f:	83 c4 10             	add    $0x10,%esp
    3f52:	89 45 f0             	mov    %eax,-0x10(%ebp)
  close(fd);
    3f55:	83 ec 0c             	sub    $0xc,%esp
    3f58:	ff 75 f4             	push   -0xc(%ebp)
    3f5b:	e8 c2 00 00 00       	call   4022 <close>
    3f60:	83 c4 10             	add    $0x10,%esp
  return r;
    3f63:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
    3f66:	c9                   	leave
    3f67:	c3                   	ret

00003f68 <atoi>:

int
atoi(const char *s)
{
    3f68:	55                   	push   %ebp
    3f69:	89 e5                	mov    %esp,%ebp
    3f6b:	83 ec 10             	sub    $0x10,%esp
  int n;

  n = 0;
    3f6e:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
  while('0' <= *s && *s <= '9')
    3f75:	eb 25                	jmp    3f9c <atoi+0x34>
    n = n*10 + *s++ - '0';
    3f77:	8b 55 fc             	mov    -0x4(%ebp),%edx
    3f7a:	89 d0                	mov    %edx,%eax
    3f7c:	c1 e0 02             	shl    $0x2,%eax
    3f7f:	01 d0                	add    %edx,%eax
    3f81:	01 c0                	add    %eax,%eax
    3f83:	89 c1                	mov    %eax,%ecx
    3f85:	8b 45 08             	mov    0x8(%ebp),%eax
    3f88:	8d 50 01             	lea    0x1(%eax),%edx
    3f8b:	89 55 08             	mov    %edx,0x8(%ebp)
    3f8e:	0f b6 00             	movzbl (%eax),%eax
    3f91:	0f be c0             	movsbl %al,%eax
    3f94:	01 c8                	add    %ecx,%eax
    3f96:	83 e8 30             	sub    $0x30,%eax
    3f99:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while('0' <= *s && *s <= '9')
    3f9c:	8b 45 08             	mov    0x8(%ebp),%eax
    3f9f:	0f b6 00             	movzbl (%eax),%eax
    3fa2:	3c 2f                	cmp    $0x2f,%al
    3fa4:	7e 0a                	jle    3fb0 <atoi+0x48>
    3fa6:	8b 45 08             	mov    0x8(%ebp),%eax
    3fa9:	0f b6 00             	movzbl (%eax),%eax
    3fac:	3c 39                	cmp    $0x39,%al
    3fae:	7e c7                	jle    3f77 <atoi+0xf>
  return n;
    3fb0:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
    3fb3:	c9                   	leave
    3fb4:	c3                   	ret

00003fb5 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
    3fb5:	55                   	push   %ebp
    3fb6:	89 e5                	mov    %esp,%ebp
    3fb8:	83 ec 10             	sub    $0x10,%esp
  char *dst;
  const char *src;

  dst = vdst;
    3fbb:	8b 45 08             	mov    0x8(%ebp),%eax
    3fbe:	89 45 fc             	mov    %eax,-0x4(%ebp)
  src = vsrc;
    3fc1:	8b 45 0c             	mov    0xc(%ebp),%eax
    3fc4:	89 45 f8             	mov    %eax,-0x8(%ebp)
  while(n-- > 0)
    3fc7:	eb 17                	jmp    3fe0 <memmove+0x2b>
    *dst++ = *src++;
    3fc9:	8b 55 f8             	mov    -0x8(%ebp),%edx
    3fcc:	8d 42 01             	lea    0x1(%edx),%eax
    3fcf:	89 45 f8             	mov    %eax,-0x8(%ebp)
    3fd2:	8b 45 fc             	mov    -0x4(%ebp),%eax
    3fd5:	8d 48 01             	lea    0x1(%eax),%ecx
    3fd8:	89 4d fc             	mov    %ecx,-0x4(%ebp)
    3fdb:	0f b6 12             	movzbl (%edx),%edx
    3fde:	88 10                	mov    %dl,(%eax)
  while(n-- > 0)
    3fe0:	8b 45 10             	mov    0x10(%ebp),%eax
    3fe3:	8d 50 ff             	lea    -0x1(%eax),%edx
    3fe6:	89 55 10             	mov    %edx,0x10(%ebp)
    3fe9:	85 c0                	test   %eax,%eax
    3feb:	7f dc                	jg     3fc9 <memmove+0x14>
  return vdst;
    3fed:	8b 45 08             	mov    0x8(%ebp),%eax
}
    3ff0:	c9                   	leave
    3ff1:	c3                   	ret

00003ff2 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
    3ff2:	b8 01 00 00 00       	mov    $0x1,%eax
    3ff7:	cd 40                	int    $0x40
    3ff9:	c3                   	ret

00003ffa <exit>:
SYSCALL(exit)
    3ffa:	b8 02 00 00 00       	mov    $0x2,%eax
    3fff:	cd 40                	int    $0x40
    4001:	c3                   	ret

00004002 <wait>:
SYSCALL(wait)
    4002:	b8 03 00 00 00       	mov    $0x3,%eax
    4007:	cd 40                	int    $0x40
    4009:	c3                   	ret

0000400a <pipe>:
SYSCALL(pipe)
    400a:	b8 04 00 00 00       	mov    $0x4,%eax
    400f:	cd 40                	int    $0x40
    4011:	c3                   	ret

00004012 <read>:
SYSCALL(read)
    4012:	b8 05 00 00 00       	mov    $0x5,%eax
    4017:	cd 40                	int    $0x40
    4019:	c3                   	ret

0000401a <write>:
SYSCALL(write)
    401a:	b8 10 00 00 00       	mov    $0x10,%eax
    401f:	cd 40                	int    $0x40
    4021:	c3                   	ret

00004022 <close>:
SYSCALL(close)
    4022:	b8 15 00 00 00       	mov    $0x15,%eax
    4027:	cd 40                	int    $0x40
    4029:	c3                   	ret

0000402a <kill>:
SYSCALL(kill)
    402a:	b8 06 00 00 00       	mov    $0x6,%eax
    402f:	cd 40                	int    $0x40
    4031:	c3                   	ret

00004032 <exec>:
SYSCALL(exec)
    4032:	b8 07 00 00 00       	mov    $0x7,%eax
    4037:	cd 40                	int    $0x40
    4039:	c3                   	ret

0000403a <open>:
SYSCALL(open)
    403a:	b8 0f 00 00 00       	mov    $0xf,%eax
    403f:	cd 40                	int    $0x40
    4041:	c3                   	ret

00004042 <mknod>:
SYSCALL(mknod)
    4042:	b8 11 00 00 00       	mov    $0x11,%eax
    4047:	cd 40                	int    $0x40
    4049:	c3                   	ret

0000404a <unlink>:
SYSCALL(unlink)
    404a:	b8 12 00 00 00       	mov    $0x12,%eax
    404f:	cd 40                	int    $0x40
    4051:	c3                   	ret

00004052 <fstat>:
SYSCALL(fstat)
    4052:	b8 08 00 00 00       	mov    $0x8,%eax
    4057:	cd 40                	int    $0x40
    4059:	c3                   	ret

0000405a <link>:
SYSCALL(link)
    405a:	b8 13 00 00 00       	mov    $0x13,%eax
    405f:	cd 40                	int    $0x40
    4061:	c3                   	ret

00004062 <mkdir>:
SYSCALL(mkdir)
    4062:	b8 14 00 00 00       	mov    $0x14,%eax
    4067:	cd 40                	int    $0x40
    4069:	c3                   	ret

0000406a <chdir>:
SYSCALL(chdir)
    406a:	b8 09 00 00 00       	mov    $0x9,%eax
    406f:	cd 40                	int    $0x40
    4071:	c3                   	ret

00004072 <dup>:
SYSCALL(dup)
    4072:	b8 0a 00 00 00       	mov    $0xa,%eax
    4077:	cd 40                	int    $0x40
    4079:	c3                   	ret

0000407a <getpid>:
SYSCALL(getpid)
    407a:	b8 0b 00 00 00       	mov    $0xb,%eax
    407f:	cd 40                	int    $0x40
    4081:	c3                   	ret

00004082 <sbrk>:
SYSCALL(sbrk)
    4082:	b8 0c 00 00 00       	mov    $0xc,%eax
    4087:	cd 40                	int    $0x40
    4089:	c3                   	ret

0000408a <sleep>:
SYSCALL(sleep)
    408a:	b8 0d 00 00 00       	mov    $0xd,%eax
    408f:	cd 40                	int    $0x40
    4091:	c3                   	ret

00004092 <uptime>:
SYSCALL(uptime)
    4092:	b8 0e 00 00 00       	mov    $0xe,%eax
    4097:	cd 40                	int    $0x40
    4099:	c3                   	ret

0000409a <getparentname>:
SYSCALL(getparentname)
    409a:	b8 16 00 00 00       	mov    $0x16,%eax
    409f:	cd 40                	int    $0x40
    40a1:	c3                   	ret

000040a2 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
    40a2:	55                   	push   %ebp
    40a3:	89 e5                	mov    %esp,%ebp
    40a5:	83 ec 18             	sub    $0x18,%esp
    40a8:	8b 45 0c             	mov    0xc(%ebp),%eax
    40ab:	88 45 f4             	mov    %al,-0xc(%ebp)
  write(fd, &c, 1);
    40ae:	83 ec 04             	sub    $0x4,%esp
    40b1:	6a 01                	push   $0x1
    40b3:	8d 45 f4             	lea    -0xc(%ebp),%eax
    40b6:	50                   	push   %eax
    40b7:	ff 75 08             	push   0x8(%ebp)
    40ba:	e8 5b ff ff ff       	call   401a <write>
    40bf:	83 c4 10             	add    $0x10,%esp
}
    40c2:	90                   	nop
    40c3:	c9                   	leave
    40c4:	c3                   	ret

000040c5 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
    40c5:	55                   	push   %ebp
    40c6:	89 e5                	mov    %esp,%ebp
    40c8:	83 ec 28             	sub    $0x28,%esp
  static char digits[] = "0123456789ABCDEF";
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
    40cb:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  if(sgn && xx < 0){
    40d2:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
    40d6:	74 17                	je     40ef <printint+0x2a>
    40d8:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
    40dc:	79 11                	jns    40ef <printint+0x2a>
    neg = 1;
    40de:	c7 45 f0 01 00 00 00 	movl   $0x1,-0x10(%ebp)
    x = -xx;
    40e5:	8b 45 0c             	mov    0xc(%ebp),%eax
    40e8:	f7 d8                	neg    %eax
    40ea:	89 45 ec             	mov    %eax,-0x14(%ebp)
    40ed:	eb 06                	jmp    40f5 <printint+0x30>
  } else {
    x = xx;
    40ef:	8b 45 0c             	mov    0xc(%ebp),%eax
    40f2:	89 45 ec             	mov    %eax,-0x14(%ebp)
  }

  i = 0;
    40f5:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  do{
    buf[i++] = digits[x % base];
    40fc:	8b 4d 10             	mov    0x10(%ebp),%ecx
    40ff:	8b 45 ec             	mov    -0x14(%ebp),%eax
    4102:	ba 00 00 00 00       	mov    $0x0,%edx
    4107:	f7 f1                	div    %ecx
    4109:	89 d1                	mov    %edx,%ecx
    410b:	8b 45 f4             	mov    -0xc(%ebp),%eax
    410e:	8d 50 01             	lea    0x1(%eax),%edx
    4111:	89 55 f4             	mov    %edx,-0xc(%ebp)
    4114:	0f b6 91 b4 64 00 00 	movzbl 0x64b4(%ecx),%edx
    411b:	88 54 05 dc          	mov    %dl,-0x24(%ebp,%eax,1)
  }while((x /= base) != 0);
    411f:	8b 4d 10             	mov    0x10(%ebp),%ecx
    4122:	8b 45 ec             	mov    -0x14(%ebp),%eax
    4125:	ba 00 00 00 00       	mov    $0x0,%edx
    412a:	f7 f1                	div    %ecx
    412c:	89 45 ec             	mov    %eax,-0x14(%ebp)
    412f:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    4133:	75 c7                	jne    40fc <printint+0x37>
  if(neg)
    4135:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    4139:	74 2d                	je     4168 <printint+0xa3>
    buf[i++] = '-';
    413b:	8b 45 f4             	mov    -0xc(%ebp),%eax
    413e:	8d 50 01             	lea    0x1(%eax),%edx
    4141:	89 55 f4             	mov    %edx,-0xc(%ebp)
    4144:	c6 44 05 dc 2d       	movb   $0x2d,-0x24(%ebp,%eax,1)

  while(--i >= 0)
    4149:	eb 1d                	jmp    4168 <printint+0xa3>
    putc(fd, buf[i]);
    414b:	8d 55 dc             	lea    -0x24(%ebp),%edx
    414e:	8b 45 f4             	mov    -0xc(%ebp),%eax
    4151:	01 d0                	add    %edx,%eax
    4153:	0f b6 00             	movzbl (%eax),%eax
    4156:	0f be c0             	movsbl %al,%eax
    4159:	83 ec 08             	sub    $0x8,%esp
    415c:	50                   	push   %eax
    415d:	ff 75 08             	push   0x8(%ebp)
    4160:	e8 3d ff ff ff       	call   40a2 <putc>
    4165:	83 c4 10             	add    $0x10,%esp
  while(--i >= 0)
    4168:	83 6d f4 01          	subl   $0x1,-0xc(%ebp)
    416c:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    4170:	79 d9                	jns    414b <printint+0x86>
}
    4172:	90                   	nop
    4173:	90                   	nop
    4174:	c9                   	leave
    4175:	c3                   	ret

00004176 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
    4176:	55                   	push   %ebp
    4177:	89 e5                	mov    %esp,%ebp
    4179:	83 ec 28             	sub    $0x28,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
    417c:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  ap = (uint*)(void*)&fmt + 1;
    4183:	8d 45 0c             	lea    0xc(%ebp),%eax
    4186:	83 c0 04             	add    $0x4,%eax
    4189:	89 45 e8             	mov    %eax,-0x18(%ebp)
  for(i = 0; fmt[i]; i++){
    418c:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
    4193:	e9 59 01 00 00       	jmp    42f1 <printf+0x17b>
    c = fmt[i] & 0xff;
    4198:	8b 55 0c             	mov    0xc(%ebp),%edx
    419b:	8b 45 f0             	mov    -0x10(%ebp),%eax
    419e:	01 d0                	add    %edx,%eax
    41a0:	0f b6 00             	movzbl (%eax),%eax
    41a3:	0f be c0             	movsbl %al,%eax
    41a6:	25 ff 00 00 00       	and    $0xff,%eax
    41ab:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(state == 0){
    41ae:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
    41b2:	75 2c                	jne    41e0 <printf+0x6a>
      if(c == '%'){
    41b4:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
    41b8:	75 0c                	jne    41c6 <printf+0x50>
        state = '%';
    41ba:	c7 45 ec 25 00 00 00 	movl   $0x25,-0x14(%ebp)
    41c1:	e9 27 01 00 00       	jmp    42ed <printf+0x177>
      } else {
        putc(fd, c);
    41c6:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    41c9:	0f be c0             	movsbl %al,%eax
    41cc:	83 ec 08             	sub    $0x8,%esp
    41cf:	50                   	push   %eax
    41d0:	ff 75 08             	push   0x8(%ebp)
    41d3:	e8 ca fe ff ff       	call   40a2 <putc>
    41d8:	83 c4 10             	add    $0x10,%esp
    41db:	e9 0d 01 00 00       	jmp    42ed <printf+0x177>
      }
    } else if(state == '%'){
    41e0:	83 7d ec 25          	cmpl   $0x25,-0x14(%ebp)
    41e4:	0f 85 03 01 00 00    	jne    42ed <printf+0x177>
      if(c == 'd'){
    41ea:	83 7d e4 64          	cmpl   $0x64,-0x1c(%ebp)
    41ee:	75 1e                	jne    420e <printf+0x98>
        printint(fd, *ap, 10, 1);
    41f0:	8b 45 e8             	mov    -0x18(%ebp),%eax
    41f3:	8b 00                	mov    (%eax),%eax
    41f5:	6a 01                	push   $0x1
    41f7:	6a 0a                	push   $0xa
    41f9:	50                   	push   %eax
    41fa:	ff 75 08             	push   0x8(%ebp)
    41fd:	e8 c3 fe ff ff       	call   40c5 <printint>
    4202:	83 c4 10             	add    $0x10,%esp
        ap++;
    4205:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
    4209:	e9 d8 00 00 00       	jmp    42e6 <printf+0x170>
      } else if(c == 'x' || c == 'p'){
    420e:	83 7d e4 78          	cmpl   $0x78,-0x1c(%ebp)
    4212:	74 06                	je     421a <printf+0xa4>
    4214:	83 7d e4 70          	cmpl   $0x70,-0x1c(%ebp)
    4218:	75 1e                	jne    4238 <printf+0xc2>
        printint(fd, *ap, 16, 0);
    421a:	8b 45 e8             	mov    -0x18(%ebp),%eax
    421d:	8b 00                	mov    (%eax),%eax
    421f:	6a 00                	push   $0x0
    4221:	6a 10                	push   $0x10
    4223:	50                   	push   %eax
    4224:	ff 75 08             	push   0x8(%ebp)
    4227:	e8 99 fe ff ff       	call   40c5 <printint>
    422c:	83 c4 10             	add    $0x10,%esp
        ap++;
    422f:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
    4233:	e9 ae 00 00 00       	jmp    42e6 <printf+0x170>
      } else if(c == 's'){
    4238:	83 7d e4 73          	cmpl   $0x73,-0x1c(%ebp)
    423c:	75 43                	jne    4281 <printf+0x10b>
        s = (char*)*ap;
    423e:	8b 45 e8             	mov    -0x18(%ebp),%eax
    4241:	8b 00                	mov    (%eax),%eax
    4243:	89 45 f4             	mov    %eax,-0xc(%ebp)
        ap++;
    4246:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
        if(s == 0)
    424a:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    424e:	75 25                	jne    4275 <printf+0xff>
          s = "(null)";
    4250:	c7 45 f4 5a 5d 00 00 	movl   $0x5d5a,-0xc(%ebp)
        while(*s != 0){
    4257:	eb 1c                	jmp    4275 <printf+0xff>
          putc(fd, *s);
    4259:	8b 45 f4             	mov    -0xc(%ebp),%eax
    425c:	0f b6 00             	movzbl (%eax),%eax
    425f:	0f be c0             	movsbl %al,%eax
    4262:	83 ec 08             	sub    $0x8,%esp
    4265:	50                   	push   %eax
    4266:	ff 75 08             	push   0x8(%ebp)
    4269:	e8 34 fe ff ff       	call   40a2 <putc>
    426e:	83 c4 10             	add    $0x10,%esp
          s++;
    4271:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
        while(*s != 0){
    4275:	8b 45 f4             	mov    -0xc(%ebp),%eax
    4278:	0f b6 00             	movzbl (%eax),%eax
    427b:	84 c0                	test   %al,%al
    427d:	75 da                	jne    4259 <printf+0xe3>
    427f:	eb 65                	jmp    42e6 <printf+0x170>
        }
      } else if(c == 'c'){
    4281:	83 7d e4 63          	cmpl   $0x63,-0x1c(%ebp)
    4285:	75 1d                	jne    42a4 <printf+0x12e>
        putc(fd, *ap);
    4287:	8b 45 e8             	mov    -0x18(%ebp),%eax
    428a:	8b 00                	mov    (%eax),%eax
    428c:	0f be c0             	movsbl %al,%eax
    428f:	83 ec 08             	sub    $0x8,%esp
    4292:	50                   	push   %eax
    4293:	ff 75 08             	push   0x8(%ebp)
    4296:	e8 07 fe ff ff       	call   40a2 <putc>
    429b:	83 c4 10             	add    $0x10,%esp
        ap++;
    429e:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
    42a2:	eb 42                	jmp    42e6 <printf+0x170>
      } else if(c == '%'){
    42a4:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
    42a8:	75 17                	jne    42c1 <printf+0x14b>
        putc(fd, c);
    42aa:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    42ad:	0f be c0             	movsbl %al,%eax
    42b0:	83 ec 08             	sub    $0x8,%esp
    42b3:	50                   	push   %eax
    42b4:	ff 75 08             	push   0x8(%ebp)
    42b7:	e8 e6 fd ff ff       	call   40a2 <putc>
    42bc:	83 c4 10             	add    $0x10,%esp
    42bf:	eb 25                	jmp    42e6 <printf+0x170>
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
    42c1:	83 ec 08             	sub    $0x8,%esp
    42c4:	6a 25                	push   $0x25
    42c6:	ff 75 08             	push   0x8(%ebp)
    42c9:	e8 d4 fd ff ff       	call   40a2 <putc>
    42ce:	83 c4 10             	add    $0x10,%esp
        putc(fd, c);
    42d1:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    42d4:	0f be c0             	movsbl %al,%eax
    42d7:	83 ec 08             	sub    $0x8,%esp
    42da:	50                   	push   %eax
    42db:	ff 75 08             	push   0x8(%ebp)
    42de:	e8 bf fd ff ff       	call   40a2 <putc>
    42e3:	83 c4 10             	add    $0x10,%esp
      }
      state = 0;
    42e6:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  for(i = 0; fmt[i]; i++){
    42ed:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
    42f1:	8b 55 0c             	mov    0xc(%ebp),%edx
    42f4:	8b 45 f0             	mov    -0x10(%ebp),%eax
    42f7:	01 d0                	add    %edx,%eax
    42f9:	0f b6 00             	movzbl (%eax),%eax
    42fc:	84 c0                	test   %al,%al
    42fe:	0f 85 94 fe ff ff    	jne    4198 <printf+0x22>
    }
  }
}
    4304:	90                   	nop
    4305:	90                   	nop
    4306:	c9                   	leave
    4307:	c3                   	ret

00004308 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    4308:	55                   	push   %ebp
    4309:	89 e5                	mov    %esp,%ebp
    430b:	83 ec 10             	sub    $0x10,%esp
  Header *bp, *p;

  bp = (Header*)ap - 1;
    430e:	8b 45 08             	mov    0x8(%ebp),%eax
    4311:	83 e8 08             	sub    $0x8,%eax
    4314:	89 45 f8             	mov    %eax,-0x8(%ebp)
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    4317:	a1 a8 ac 00 00       	mov    0xaca8,%eax
    431c:	89 45 fc             	mov    %eax,-0x4(%ebp)
    431f:	eb 24                	jmp    4345 <free+0x3d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    4321:	8b 45 fc             	mov    -0x4(%ebp),%eax
    4324:	8b 00                	mov    (%eax),%eax
    4326:	39 45 fc             	cmp    %eax,-0x4(%ebp)
    4329:	72 12                	jb     433d <free+0x35>
    432b:	8b 45 f8             	mov    -0x8(%ebp),%eax
    432e:	39 45 fc             	cmp    %eax,-0x4(%ebp)
    4331:	72 24                	jb     4357 <free+0x4f>
    4333:	8b 45 fc             	mov    -0x4(%ebp),%eax
    4336:	8b 00                	mov    (%eax),%eax
    4338:	39 45 f8             	cmp    %eax,-0x8(%ebp)
    433b:	72 1a                	jb     4357 <free+0x4f>
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    433d:	8b 45 fc             	mov    -0x4(%ebp),%eax
    4340:	8b 00                	mov    (%eax),%eax
    4342:	89 45 fc             	mov    %eax,-0x4(%ebp)
    4345:	8b 45 f8             	mov    -0x8(%ebp),%eax
    4348:	39 45 fc             	cmp    %eax,-0x4(%ebp)
    434b:	73 d4                	jae    4321 <free+0x19>
    434d:	8b 45 fc             	mov    -0x4(%ebp),%eax
    4350:	8b 00                	mov    (%eax),%eax
    4352:	39 45 f8             	cmp    %eax,-0x8(%ebp)
    4355:	73 ca                	jae    4321 <free+0x19>
      break;
  if(bp + bp->s.size == p->s.ptr){
    4357:	8b 45 f8             	mov    -0x8(%ebp),%eax
    435a:	8b 40 04             	mov    0x4(%eax),%eax
    435d:	8d 14 c5 00 00 00 00 	lea    0x0(,%eax,8),%edx
    4364:	8b 45 f8             	mov    -0x8(%ebp),%eax
    4367:	01 c2                	add    %eax,%edx
    4369:	8b 45 fc             	mov    -0x4(%ebp),%eax
    436c:	8b 00                	mov    (%eax),%eax
    436e:	39 c2                	cmp    %eax,%edx
    4370:	75 24                	jne    4396 <free+0x8e>
    bp->s.size += p->s.ptr->s.size;
    4372:	8b 45 f8             	mov    -0x8(%ebp),%eax
    4375:	8b 50 04             	mov    0x4(%eax),%edx
    4378:	8b 45 fc             	mov    -0x4(%ebp),%eax
    437b:	8b 00                	mov    (%eax),%eax
    437d:	8b 40 04             	mov    0x4(%eax),%eax
    4380:	01 c2                	add    %eax,%edx
    4382:	8b 45 f8             	mov    -0x8(%ebp),%eax
    4385:	89 50 04             	mov    %edx,0x4(%eax)
    bp->s.ptr = p->s.ptr->s.ptr;
    4388:	8b 45 fc             	mov    -0x4(%ebp),%eax
    438b:	8b 00                	mov    (%eax),%eax
    438d:	8b 10                	mov    (%eax),%edx
    438f:	8b 45 f8             	mov    -0x8(%ebp),%eax
    4392:	89 10                	mov    %edx,(%eax)
    4394:	eb 0a                	jmp    43a0 <free+0x98>
  } else
    bp->s.ptr = p->s.ptr;
    4396:	8b 45 fc             	mov    -0x4(%ebp),%eax
    4399:	8b 10                	mov    (%eax),%edx
    439b:	8b 45 f8             	mov    -0x8(%ebp),%eax
    439e:	89 10                	mov    %edx,(%eax)
  if(p + p->s.size == bp){
    43a0:	8b 45 fc             	mov    -0x4(%ebp),%eax
    43a3:	8b 40 04             	mov    0x4(%eax),%eax
    43a6:	8d 14 c5 00 00 00 00 	lea    0x0(,%eax,8),%edx
    43ad:	8b 45 fc             	mov    -0x4(%ebp),%eax
    43b0:	01 d0                	add    %edx,%eax
    43b2:	39 45 f8             	cmp    %eax,-0x8(%ebp)
    43b5:	75 20                	jne    43d7 <free+0xcf>
    p->s.size += bp->s.size;
    43b7:	8b 45 fc             	mov    -0x4(%ebp),%eax
    43ba:	8b 50 04             	mov    0x4(%eax),%edx
    43bd:	8b 45 f8             	mov    -0x8(%ebp),%eax
    43c0:	8b 40 04             	mov    0x4(%eax),%eax
    43c3:	01 c2                	add    %eax,%edx
    43c5:	8b 45 fc             	mov    -0x4(%ebp),%eax
    43c8:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
    43cb:	8b 45 f8             	mov    -0x8(%ebp),%eax
    43ce:	8b 10                	mov    (%eax),%edx
    43d0:	8b 45 fc             	mov    -0x4(%ebp),%eax
    43d3:	89 10                	mov    %edx,(%eax)
    43d5:	eb 08                	jmp    43df <free+0xd7>
  } else
    p->s.ptr = bp;
    43d7:	8b 45 fc             	mov    -0x4(%ebp),%eax
    43da:	8b 55 f8             	mov    -0x8(%ebp),%edx
    43dd:	89 10                	mov    %edx,(%eax)
  freep = p;
    43df:	8b 45 fc             	mov    -0x4(%ebp),%eax
    43e2:	a3 a8 ac 00 00       	mov    %eax,0xaca8
}
    43e7:	90                   	nop
    43e8:	c9                   	leave
    43e9:	c3                   	ret

000043ea <morecore>:

static Header*
morecore(uint nu)
{
    43ea:	55                   	push   %ebp
    43eb:	89 e5                	mov    %esp,%ebp
    43ed:	83 ec 18             	sub    $0x18,%esp
  char *p;
  Header *hp;

  if(nu < 4096)
    43f0:	81 7d 08 ff 0f 00 00 	cmpl   $0xfff,0x8(%ebp)
    43f7:	77 07                	ja     4400 <morecore+0x16>
    nu = 4096;
    43f9:	c7 45 08 00 10 00 00 	movl   $0x1000,0x8(%ebp)
  p = sbrk(nu * sizeof(Header));
    4400:	8b 45 08             	mov    0x8(%ebp),%eax
    4403:	c1 e0 03             	shl    $0x3,%eax
    4406:	83 ec 0c             	sub    $0xc,%esp
    4409:	50                   	push   %eax
    440a:	e8 73 fc ff ff       	call   4082 <sbrk>
    440f:	83 c4 10             	add    $0x10,%esp
    4412:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(p == (char*)-1)
    4415:	83 7d f4 ff          	cmpl   $0xffffffff,-0xc(%ebp)
    4419:	75 07                	jne    4422 <morecore+0x38>
    return 0;
    441b:	b8 00 00 00 00       	mov    $0x0,%eax
    4420:	eb 26                	jmp    4448 <morecore+0x5e>
  hp = (Header*)p;
    4422:	8b 45 f4             	mov    -0xc(%ebp),%eax
    4425:	89 45 f0             	mov    %eax,-0x10(%ebp)
  hp->s.size = nu;
    4428:	8b 45 f0             	mov    -0x10(%ebp),%eax
    442b:	8b 55 08             	mov    0x8(%ebp),%edx
    442e:	89 50 04             	mov    %edx,0x4(%eax)
  free((void*)(hp + 1));
    4431:	8b 45 f0             	mov    -0x10(%ebp),%eax
    4434:	83 c0 08             	add    $0x8,%eax
    4437:	83 ec 0c             	sub    $0xc,%esp
    443a:	50                   	push   %eax
    443b:	e8 c8 fe ff ff       	call   4308 <free>
    4440:	83 c4 10             	add    $0x10,%esp
  return freep;
    4443:	a1 a8 ac 00 00       	mov    0xaca8,%eax
}
    4448:	c9                   	leave
    4449:	c3                   	ret

0000444a <malloc>:

void*
malloc(uint nbytes)
{
    444a:	55                   	push   %ebp
    444b:	89 e5                	mov    %esp,%ebp
    444d:	83 ec 18             	sub    $0x18,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    4450:	8b 45 08             	mov    0x8(%ebp),%eax
    4453:	83 c0 07             	add    $0x7,%eax
    4456:	c1 e8 03             	shr    $0x3,%eax
    4459:	83 c0 01             	add    $0x1,%eax
    445c:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if((prevp = freep) == 0){
    445f:	a1 a8 ac 00 00       	mov    0xaca8,%eax
    4464:	89 45 f0             	mov    %eax,-0x10(%ebp)
    4467:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
    446b:	75 23                	jne    4490 <malloc+0x46>
    base.s.ptr = freep = prevp = &base;
    446d:	c7 45 f0 a0 ac 00 00 	movl   $0xaca0,-0x10(%ebp)
    4474:	8b 45 f0             	mov    -0x10(%ebp),%eax
    4477:	a3 a8 ac 00 00       	mov    %eax,0xaca8
    447c:	a1 a8 ac 00 00       	mov    0xaca8,%eax
    4481:	a3 a0 ac 00 00       	mov    %eax,0xaca0
    base.s.size = 0;
    4486:	c7 05 a4 ac 00 00 00 	movl   $0x0,0xaca4
    448d:	00 00 00 
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    4490:	8b 45 f0             	mov    -0x10(%ebp),%eax
    4493:	8b 00                	mov    (%eax),%eax
    4495:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(p->s.size >= nunits){
    4498:	8b 45 f4             	mov    -0xc(%ebp),%eax
    449b:	8b 40 04             	mov    0x4(%eax),%eax
    449e:	3b 45 ec             	cmp    -0x14(%ebp),%eax
    44a1:	72 4d                	jb     44f0 <malloc+0xa6>
      if(p->s.size == nunits)
    44a3:	8b 45 f4             	mov    -0xc(%ebp),%eax
    44a6:	8b 40 04             	mov    0x4(%eax),%eax
    44a9:	39 45 ec             	cmp    %eax,-0x14(%ebp)
    44ac:	75 0c                	jne    44ba <malloc+0x70>
        prevp->s.ptr = p->s.ptr;
    44ae:	8b 45 f4             	mov    -0xc(%ebp),%eax
    44b1:	8b 10                	mov    (%eax),%edx
    44b3:	8b 45 f0             	mov    -0x10(%ebp),%eax
    44b6:	89 10                	mov    %edx,(%eax)
    44b8:	eb 26                	jmp    44e0 <malloc+0x96>
      else {
        p->s.size -= nunits;
    44ba:	8b 45 f4             	mov    -0xc(%ebp),%eax
    44bd:	8b 40 04             	mov    0x4(%eax),%eax
    44c0:	2b 45 ec             	sub    -0x14(%ebp),%eax
    44c3:	89 c2                	mov    %eax,%edx
    44c5:	8b 45 f4             	mov    -0xc(%ebp),%eax
    44c8:	89 50 04             	mov    %edx,0x4(%eax)
        p += p->s.size;
    44cb:	8b 45 f4             	mov    -0xc(%ebp),%eax
    44ce:	8b 40 04             	mov    0x4(%eax),%eax
    44d1:	c1 e0 03             	shl    $0x3,%eax
    44d4:	01 45 f4             	add    %eax,-0xc(%ebp)
        p->s.size = nunits;
    44d7:	8b 45 f4             	mov    -0xc(%ebp),%eax
    44da:	8b 55 ec             	mov    -0x14(%ebp),%edx
    44dd:	89 50 04             	mov    %edx,0x4(%eax)
      }
      freep = prevp;
    44e0:	8b 45 f0             	mov    -0x10(%ebp),%eax
    44e3:	a3 a8 ac 00 00       	mov    %eax,0xaca8
      return (void*)(p + 1);
    44e8:	8b 45 f4             	mov    -0xc(%ebp),%eax
    44eb:	83 c0 08             	add    $0x8,%eax
    44ee:	eb 3b                	jmp    452b <malloc+0xe1>
    }
    if(p == freep)
    44f0:	a1 a8 ac 00 00       	mov    0xaca8,%eax
    44f5:	39 45 f4             	cmp    %eax,-0xc(%ebp)
    44f8:	75 1e                	jne    4518 <malloc+0xce>
      if((p = morecore(nunits)) == 0)
    44fa:	83 ec 0c             	sub    $0xc,%esp
    44fd:	ff 75 ec             	push   -0x14(%ebp)
    4500:	e8 e5 fe ff ff       	call   43ea <morecore>
    4505:	83 c4 10             	add    $0x10,%esp
    4508:	89 45 f4             	mov    %eax,-0xc(%ebp)
    450b:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
    450f:	75 07                	jne    4518 <malloc+0xce>
        return 0;
    4511:	b8 00 00 00 00       	mov    $0x0,%eax
    4516:	eb 13                	jmp    452b <malloc+0xe1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    4518:	8b 45 f4             	mov    -0xc(%ebp),%eax
    451b:	89 45 f0             	mov    %eax,-0x10(%ebp)
    451e:	8b 45 f4             	mov    -0xc(%ebp),%eax
    4521:	8b 00                	mov    (%eax),%eax
    4523:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(p->s.size >= nunits){
    4526:	e9 6d ff ff ff       	jmp    4498 <malloc+0x4e>
  }
}
    452b:	c9                   	leave
    452c:	c3                   	ret
