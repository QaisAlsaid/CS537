
_test_1:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

#define MAX_NAME_LEN 256

int main(int argc, char* argv[]) {
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	51                   	push   %ecx
   e:	81 ec 04 02 00 00    	sub    $0x204,%esp
  char parent_name[MAX_NAME_LEN];
  char child_name[MAX_NAME_LEN];

  if (getparentname(parent_name, child_name, MAX_NAME_LEN, MAX_NAME_LEN) < 0)
  14:	68 00 01 00 00       	push   $0x100
  19:	68 00 01 00 00       	push   $0x100
  1e:	8d 85 f8 fd ff ff    	lea    -0x208(%ebp),%eax
  24:	50                   	push   %eax
  25:	8d 85 f8 fe ff ff    	lea    -0x108(%ebp),%eax
  2b:	50                   	push   %eax
  2c:	e8 4c 03 00 00       	call   37d <getparentname>
  31:	83 c4 10             	add    $0x10,%esp
  34:	85 c0                	test   %eax,%eax
  36:	79 17                	jns    4f <main+0x4f>
  {
    printf(2, "XV6_TEST_ERROR getparentname call failed!\n");
  38:	83 ec 08             	sub    $0x8,%esp
  3b:	68 10 08 00 00       	push   $0x810
  40:	6a 02                	push   $0x2
  42:	e8 12 04 00 00       	call   459 <printf>
  47:	83 c4 10             	add    $0x10,%esp
    exit();
  4a:	e8 8e 02 00 00       	call   2dd <exit>
  }

  printf(1, "XV6_TEST_OUTPUT Parent Name: %s,", parent_name);
  4f:	83 ec 04             	sub    $0x4,%esp
  52:	8d 85 f8 fe ff ff    	lea    -0x108(%ebp),%eax
  58:	50                   	push   %eax
  59:	68 3c 08 00 00       	push   $0x83c
  5e:	6a 01                	push   $0x1
  60:	e8 f4 03 00 00       	call   459 <printf>
  65:	83 c4 10             	add    $0x10,%esp
  printf(1, " Child Name: %s\n", child_name);
  68:	83 ec 04             	sub    $0x4,%esp
  6b:	8d 85 f8 fd ff ff    	lea    -0x208(%ebp),%eax
  71:	50                   	push   %eax
  72:	68 5d 08 00 00       	push   $0x85d
  77:	6a 01                	push   $0x1
  79:	e8 db 03 00 00       	call   459 <printf>
  7e:	83 c4 10             	add    $0x10,%esp
  exit();
  81:	e8 57 02 00 00       	call   2dd <exit>

00000086 <stosb>:
               "cc");
}

static inline void
stosb(void *addr, int data, int cnt)
{
  86:	55                   	push   %ebp
  87:	89 e5                	mov    %esp,%ebp
  89:	57                   	push   %edi
  8a:	53                   	push   %ebx
  asm volatile("cld; rep stosb" :
  8b:	8b 4d 08             	mov    0x8(%ebp),%ecx
  8e:	8b 55 10             	mov    0x10(%ebp),%edx
  91:	8b 45 0c             	mov    0xc(%ebp),%eax
  94:	89 cb                	mov    %ecx,%ebx
  96:	89 df                	mov    %ebx,%edi
  98:	89 d1                	mov    %edx,%ecx
  9a:	fc                   	cld
  9b:	f3 aa                	rep stos %al,%es:(%edi)
  9d:	89 ca                	mov    %ecx,%edx
  9f:	89 fb                	mov    %edi,%ebx
  a1:	89 5d 08             	mov    %ebx,0x8(%ebp)
  a4:	89 55 10             	mov    %edx,0x10(%ebp)
               "=D" (addr), "=c" (cnt) :
               "0" (addr), "1" (cnt), "a" (data) :
               "memory", "cc");
}
  a7:	90                   	nop
  a8:	5b                   	pop    %ebx
  a9:	5f                   	pop    %edi
  aa:	5d                   	pop    %ebp
  ab:	c3                   	ret

000000ac <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
  ac:	55                   	push   %ebp
  ad:	89 e5                	mov    %esp,%ebp
  af:	83 ec 10             	sub    $0x10,%esp
  char *os;

  os = s;
  b2:	8b 45 08             	mov    0x8(%ebp),%eax
  b5:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while((*s++ = *t++) != 0)
  b8:	90                   	nop
  b9:	8b 55 0c             	mov    0xc(%ebp),%edx
  bc:	8d 42 01             	lea    0x1(%edx),%eax
  bf:	89 45 0c             	mov    %eax,0xc(%ebp)
  c2:	8b 45 08             	mov    0x8(%ebp),%eax
  c5:	8d 48 01             	lea    0x1(%eax),%ecx
  c8:	89 4d 08             	mov    %ecx,0x8(%ebp)
  cb:	0f b6 12             	movzbl (%edx),%edx
  ce:	88 10                	mov    %dl,(%eax)
  d0:	0f b6 00             	movzbl (%eax),%eax
  d3:	84 c0                	test   %al,%al
  d5:	75 e2                	jne    b9 <strcpy+0xd>
    ;
  return os;
  d7:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
  da:	c9                   	leave
  db:	c3                   	ret

000000dc <strcmp>:

int
strcmp(const char *p, const char *q)
{
  dc:	55                   	push   %ebp
  dd:	89 e5                	mov    %esp,%ebp
  while(*p && *p == *q)
  df:	eb 08                	jmp    e9 <strcmp+0xd>
    p++, q++;
  e1:	83 45 08 01          	addl   $0x1,0x8(%ebp)
  e5:	83 45 0c 01          	addl   $0x1,0xc(%ebp)
  while(*p && *p == *q)
  e9:	8b 45 08             	mov    0x8(%ebp),%eax
  ec:	0f b6 00             	movzbl (%eax),%eax
  ef:	84 c0                	test   %al,%al
  f1:	74 10                	je     103 <strcmp+0x27>
  f3:	8b 45 08             	mov    0x8(%ebp),%eax
  f6:	0f b6 10             	movzbl (%eax),%edx
  f9:	8b 45 0c             	mov    0xc(%ebp),%eax
  fc:	0f b6 00             	movzbl (%eax),%eax
  ff:	38 c2                	cmp    %al,%dl
 101:	74 de                	je     e1 <strcmp+0x5>
  return (uchar)*p - (uchar)*q;
 103:	8b 45 08             	mov    0x8(%ebp),%eax
 106:	0f b6 00             	movzbl (%eax),%eax
 109:	0f b6 d0             	movzbl %al,%edx
 10c:	8b 45 0c             	mov    0xc(%ebp),%eax
 10f:	0f b6 00             	movzbl (%eax),%eax
 112:	0f b6 c0             	movzbl %al,%eax
 115:	29 c2                	sub    %eax,%edx
 117:	89 d0                	mov    %edx,%eax
}
 119:	5d                   	pop    %ebp
 11a:	c3                   	ret

0000011b <strlen>:

uint
strlen(const char *s)
{
 11b:	55                   	push   %ebp
 11c:	89 e5                	mov    %esp,%ebp
 11e:	83 ec 10             	sub    $0x10,%esp
  int n;

  for(n = 0; s[n]; n++)
 121:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
 128:	eb 04                	jmp    12e <strlen+0x13>
 12a:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
 12e:	8b 55 fc             	mov    -0x4(%ebp),%edx
 131:	8b 45 08             	mov    0x8(%ebp),%eax
 134:	01 d0                	add    %edx,%eax
 136:	0f b6 00             	movzbl (%eax),%eax
 139:	84 c0                	test   %al,%al
 13b:	75 ed                	jne    12a <strlen+0xf>
    ;
  return n;
 13d:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
 140:	c9                   	leave
 141:	c3                   	ret

00000142 <memset>:

void*
memset(void *dst, int c, uint n)
{
 142:	55                   	push   %ebp
 143:	89 e5                	mov    %esp,%ebp
  stosb(dst, c, n);
 145:	8b 45 10             	mov    0x10(%ebp),%eax
 148:	50                   	push   %eax
 149:	ff 75 0c             	push   0xc(%ebp)
 14c:	ff 75 08             	push   0x8(%ebp)
 14f:	e8 32 ff ff ff       	call   86 <stosb>
 154:	83 c4 0c             	add    $0xc,%esp
  return dst;
 157:	8b 45 08             	mov    0x8(%ebp),%eax
}
 15a:	c9                   	leave
 15b:	c3                   	ret

0000015c <strchr>:

char*
strchr(const char *s, char c)
{
 15c:	55                   	push   %ebp
 15d:	89 e5                	mov    %esp,%ebp
 15f:	83 ec 04             	sub    $0x4,%esp
 162:	8b 45 0c             	mov    0xc(%ebp),%eax
 165:	88 45 fc             	mov    %al,-0x4(%ebp)
  for(; *s; s++)
 168:	eb 14                	jmp    17e <strchr+0x22>
    if(*s == c)
 16a:	8b 45 08             	mov    0x8(%ebp),%eax
 16d:	0f b6 00             	movzbl (%eax),%eax
 170:	38 45 fc             	cmp    %al,-0x4(%ebp)
 173:	75 05                	jne    17a <strchr+0x1e>
      return (char*)s;
 175:	8b 45 08             	mov    0x8(%ebp),%eax
 178:	eb 13                	jmp    18d <strchr+0x31>
  for(; *s; s++)
 17a:	83 45 08 01          	addl   $0x1,0x8(%ebp)
 17e:	8b 45 08             	mov    0x8(%ebp),%eax
 181:	0f b6 00             	movzbl (%eax),%eax
 184:	84 c0                	test   %al,%al
 186:	75 e2                	jne    16a <strchr+0xe>
  return 0;
 188:	b8 00 00 00 00       	mov    $0x0,%eax
}
 18d:	c9                   	leave
 18e:	c3                   	ret

0000018f <gets>:

char*
gets(char *buf, int max)
{
 18f:	55                   	push   %ebp
 190:	89 e5                	mov    %esp,%ebp
 192:	83 ec 18             	sub    $0x18,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 195:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
 19c:	eb 42                	jmp    1e0 <gets+0x51>
    cc = read(0, &c, 1);
 19e:	83 ec 04             	sub    $0x4,%esp
 1a1:	6a 01                	push   $0x1
 1a3:	8d 45 ef             	lea    -0x11(%ebp),%eax
 1a6:	50                   	push   %eax
 1a7:	6a 00                	push   $0x0
 1a9:	e8 47 01 00 00       	call   2f5 <read>
 1ae:	83 c4 10             	add    $0x10,%esp
 1b1:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(cc < 1)
 1b4:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
 1b8:	7e 33                	jle    1ed <gets+0x5e>
      break;
    buf[i++] = c;
 1ba:	8b 45 f4             	mov    -0xc(%ebp),%eax
 1bd:	8d 50 01             	lea    0x1(%eax),%edx
 1c0:	89 55 f4             	mov    %edx,-0xc(%ebp)
 1c3:	89 c2                	mov    %eax,%edx
 1c5:	8b 45 08             	mov    0x8(%ebp),%eax
 1c8:	01 c2                	add    %eax,%edx
 1ca:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
 1ce:	88 02                	mov    %al,(%edx)
    if(c == '\n' || c == '\r')
 1d0:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
 1d4:	3c 0a                	cmp    $0xa,%al
 1d6:	74 16                	je     1ee <gets+0x5f>
 1d8:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
 1dc:	3c 0d                	cmp    $0xd,%al
 1de:	74 0e                	je     1ee <gets+0x5f>
  for(i=0; i+1 < max; ){
 1e0:	8b 45 f4             	mov    -0xc(%ebp),%eax
 1e3:	83 c0 01             	add    $0x1,%eax
 1e6:	39 45 0c             	cmp    %eax,0xc(%ebp)
 1e9:	7f b3                	jg     19e <gets+0xf>
 1eb:	eb 01                	jmp    1ee <gets+0x5f>
      break;
 1ed:	90                   	nop
      break;
  }
  buf[i] = '\0';
 1ee:	8b 55 f4             	mov    -0xc(%ebp),%edx
 1f1:	8b 45 08             	mov    0x8(%ebp),%eax
 1f4:	01 d0                	add    %edx,%eax
 1f6:	c6 00 00             	movb   $0x0,(%eax)
  return buf;
 1f9:	8b 45 08             	mov    0x8(%ebp),%eax
}
 1fc:	c9                   	leave
 1fd:	c3                   	ret

000001fe <stat>:

int
stat(const char *n, struct stat *st)
{
 1fe:	55                   	push   %ebp
 1ff:	89 e5                	mov    %esp,%ebp
 201:	83 ec 18             	sub    $0x18,%esp
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 204:	83 ec 08             	sub    $0x8,%esp
 207:	6a 00                	push   $0x0
 209:	ff 75 08             	push   0x8(%ebp)
 20c:	e8 0c 01 00 00       	call   31d <open>
 211:	83 c4 10             	add    $0x10,%esp
 214:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0)
 217:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 21b:	79 07                	jns    224 <stat+0x26>
    return -1;
 21d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 222:	eb 25                	jmp    249 <stat+0x4b>
  r = fstat(fd, st);
 224:	83 ec 08             	sub    $0x8,%esp
 227:	ff 75 0c             	push   0xc(%ebp)
 22a:	ff 75 f4             	push   -0xc(%ebp)
 22d:	e8 03 01 00 00       	call   335 <fstat>
 232:	83 c4 10             	add    $0x10,%esp
 235:	89 45 f0             	mov    %eax,-0x10(%ebp)
  close(fd);
 238:	83 ec 0c             	sub    $0xc,%esp
 23b:	ff 75 f4             	push   -0xc(%ebp)
 23e:	e8 c2 00 00 00       	call   305 <close>
 243:	83 c4 10             	add    $0x10,%esp
  return r;
 246:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
 249:	c9                   	leave
 24a:	c3                   	ret

0000024b <atoi>:

int
atoi(const char *s)
{
 24b:	55                   	push   %ebp
 24c:	89 e5                	mov    %esp,%ebp
 24e:	83 ec 10             	sub    $0x10,%esp
  int n;

  n = 0;
 251:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
  while('0' <= *s && *s <= '9')
 258:	eb 25                	jmp    27f <atoi+0x34>
    n = n*10 + *s++ - '0';
 25a:	8b 55 fc             	mov    -0x4(%ebp),%edx
 25d:	89 d0                	mov    %edx,%eax
 25f:	c1 e0 02             	shl    $0x2,%eax
 262:	01 d0                	add    %edx,%eax
 264:	01 c0                	add    %eax,%eax
 266:	89 c1                	mov    %eax,%ecx
 268:	8b 45 08             	mov    0x8(%ebp),%eax
 26b:	8d 50 01             	lea    0x1(%eax),%edx
 26e:	89 55 08             	mov    %edx,0x8(%ebp)
 271:	0f b6 00             	movzbl (%eax),%eax
 274:	0f be c0             	movsbl %al,%eax
 277:	01 c8                	add    %ecx,%eax
 279:	83 e8 30             	sub    $0x30,%eax
 27c:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while('0' <= *s && *s <= '9')
 27f:	8b 45 08             	mov    0x8(%ebp),%eax
 282:	0f b6 00             	movzbl (%eax),%eax
 285:	3c 2f                	cmp    $0x2f,%al
 287:	7e 0a                	jle    293 <atoi+0x48>
 289:	8b 45 08             	mov    0x8(%ebp),%eax
 28c:	0f b6 00             	movzbl (%eax),%eax
 28f:	3c 39                	cmp    $0x39,%al
 291:	7e c7                	jle    25a <atoi+0xf>
  return n;
 293:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
 296:	c9                   	leave
 297:	c3                   	ret

00000298 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 298:	55                   	push   %ebp
 299:	89 e5                	mov    %esp,%ebp
 29b:	83 ec 10             	sub    $0x10,%esp
  char *dst;
  const char *src;

  dst = vdst;
 29e:	8b 45 08             	mov    0x8(%ebp),%eax
 2a1:	89 45 fc             	mov    %eax,-0x4(%ebp)
  src = vsrc;
 2a4:	8b 45 0c             	mov    0xc(%ebp),%eax
 2a7:	89 45 f8             	mov    %eax,-0x8(%ebp)
  while(n-- > 0)
 2aa:	eb 17                	jmp    2c3 <memmove+0x2b>
    *dst++ = *src++;
 2ac:	8b 55 f8             	mov    -0x8(%ebp),%edx
 2af:	8d 42 01             	lea    0x1(%edx),%eax
 2b2:	89 45 f8             	mov    %eax,-0x8(%ebp)
 2b5:	8b 45 fc             	mov    -0x4(%ebp),%eax
 2b8:	8d 48 01             	lea    0x1(%eax),%ecx
 2bb:	89 4d fc             	mov    %ecx,-0x4(%ebp)
 2be:	0f b6 12             	movzbl (%edx),%edx
 2c1:	88 10                	mov    %dl,(%eax)
  while(n-- > 0)
 2c3:	8b 45 10             	mov    0x10(%ebp),%eax
 2c6:	8d 50 ff             	lea    -0x1(%eax),%edx
 2c9:	89 55 10             	mov    %edx,0x10(%ebp)
 2cc:	85 c0                	test   %eax,%eax
 2ce:	7f dc                	jg     2ac <memmove+0x14>
  return vdst;
 2d0:	8b 45 08             	mov    0x8(%ebp),%eax
}
 2d3:	c9                   	leave
 2d4:	c3                   	ret

000002d5 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 2d5:	b8 01 00 00 00       	mov    $0x1,%eax
 2da:	cd 40                	int    $0x40
 2dc:	c3                   	ret

000002dd <exit>:
SYSCALL(exit)
 2dd:	b8 02 00 00 00       	mov    $0x2,%eax
 2e2:	cd 40                	int    $0x40
 2e4:	c3                   	ret

000002e5 <wait>:
SYSCALL(wait)
 2e5:	b8 03 00 00 00       	mov    $0x3,%eax
 2ea:	cd 40                	int    $0x40
 2ec:	c3                   	ret

000002ed <pipe>:
SYSCALL(pipe)
 2ed:	b8 04 00 00 00       	mov    $0x4,%eax
 2f2:	cd 40                	int    $0x40
 2f4:	c3                   	ret

000002f5 <read>:
SYSCALL(read)
 2f5:	b8 05 00 00 00       	mov    $0x5,%eax
 2fa:	cd 40                	int    $0x40
 2fc:	c3                   	ret

000002fd <write>:
SYSCALL(write)
 2fd:	b8 10 00 00 00       	mov    $0x10,%eax
 302:	cd 40                	int    $0x40
 304:	c3                   	ret

00000305 <close>:
SYSCALL(close)
 305:	b8 15 00 00 00       	mov    $0x15,%eax
 30a:	cd 40                	int    $0x40
 30c:	c3                   	ret

0000030d <kill>:
SYSCALL(kill)
 30d:	b8 06 00 00 00       	mov    $0x6,%eax
 312:	cd 40                	int    $0x40
 314:	c3                   	ret

00000315 <exec>:
SYSCALL(exec)
 315:	b8 07 00 00 00       	mov    $0x7,%eax
 31a:	cd 40                	int    $0x40
 31c:	c3                   	ret

0000031d <open>:
SYSCALL(open)
 31d:	b8 0f 00 00 00       	mov    $0xf,%eax
 322:	cd 40                	int    $0x40
 324:	c3                   	ret

00000325 <mknod>:
SYSCALL(mknod)
 325:	b8 11 00 00 00       	mov    $0x11,%eax
 32a:	cd 40                	int    $0x40
 32c:	c3                   	ret

0000032d <unlink>:
SYSCALL(unlink)
 32d:	b8 12 00 00 00       	mov    $0x12,%eax
 332:	cd 40                	int    $0x40
 334:	c3                   	ret

00000335 <fstat>:
SYSCALL(fstat)
 335:	b8 08 00 00 00       	mov    $0x8,%eax
 33a:	cd 40                	int    $0x40
 33c:	c3                   	ret

0000033d <link>:
SYSCALL(link)
 33d:	b8 13 00 00 00       	mov    $0x13,%eax
 342:	cd 40                	int    $0x40
 344:	c3                   	ret

00000345 <mkdir>:
SYSCALL(mkdir)
 345:	b8 14 00 00 00       	mov    $0x14,%eax
 34a:	cd 40                	int    $0x40
 34c:	c3                   	ret

0000034d <chdir>:
SYSCALL(chdir)
 34d:	b8 09 00 00 00       	mov    $0x9,%eax
 352:	cd 40                	int    $0x40
 354:	c3                   	ret

00000355 <dup>:
SYSCALL(dup)
 355:	b8 0a 00 00 00       	mov    $0xa,%eax
 35a:	cd 40                	int    $0x40
 35c:	c3                   	ret

0000035d <getpid>:
SYSCALL(getpid)
 35d:	b8 0b 00 00 00       	mov    $0xb,%eax
 362:	cd 40                	int    $0x40
 364:	c3                   	ret

00000365 <sbrk>:
SYSCALL(sbrk)
 365:	b8 0c 00 00 00       	mov    $0xc,%eax
 36a:	cd 40                	int    $0x40
 36c:	c3                   	ret

0000036d <sleep>:
SYSCALL(sleep)
 36d:	b8 0d 00 00 00       	mov    $0xd,%eax
 372:	cd 40                	int    $0x40
 374:	c3                   	ret

00000375 <uptime>:
SYSCALL(uptime)
 375:	b8 0e 00 00 00       	mov    $0xe,%eax
 37a:	cd 40                	int    $0x40
 37c:	c3                   	ret

0000037d <getparentname>:
SYSCALL(getparentname)
 37d:	b8 16 00 00 00       	mov    $0x16,%eax
 382:	cd 40                	int    $0x40
 384:	c3                   	ret

00000385 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 385:	55                   	push   %ebp
 386:	89 e5                	mov    %esp,%ebp
 388:	83 ec 18             	sub    $0x18,%esp
 38b:	8b 45 0c             	mov    0xc(%ebp),%eax
 38e:	88 45 f4             	mov    %al,-0xc(%ebp)
  write(fd, &c, 1);
 391:	83 ec 04             	sub    $0x4,%esp
 394:	6a 01                	push   $0x1
 396:	8d 45 f4             	lea    -0xc(%ebp),%eax
 399:	50                   	push   %eax
 39a:	ff 75 08             	push   0x8(%ebp)
 39d:	e8 5b ff ff ff       	call   2fd <write>
 3a2:	83 c4 10             	add    $0x10,%esp
}
 3a5:	90                   	nop
 3a6:	c9                   	leave
 3a7:	c3                   	ret

000003a8 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 3a8:	55                   	push   %ebp
 3a9:	89 e5                	mov    %esp,%ebp
 3ab:	83 ec 28             	sub    $0x28,%esp
  static char digits[] = "0123456789ABCDEF";
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
 3ae:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  if(sgn && xx < 0){
 3b5:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
 3b9:	74 17                	je     3d2 <printint+0x2a>
 3bb:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
 3bf:	79 11                	jns    3d2 <printint+0x2a>
    neg = 1;
 3c1:	c7 45 f0 01 00 00 00 	movl   $0x1,-0x10(%ebp)
    x = -xx;
 3c8:	8b 45 0c             	mov    0xc(%ebp),%eax
 3cb:	f7 d8                	neg    %eax
 3cd:	89 45 ec             	mov    %eax,-0x14(%ebp)
 3d0:	eb 06                	jmp    3d8 <printint+0x30>
  } else {
    x = xx;
 3d2:	8b 45 0c             	mov    0xc(%ebp),%eax
 3d5:	89 45 ec             	mov    %eax,-0x14(%ebp)
  }

  i = 0;
 3d8:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  do{
    buf[i++] = digits[x % base];
 3df:	8b 4d 10             	mov    0x10(%ebp),%ecx
 3e2:	8b 45 ec             	mov    -0x14(%ebp),%eax
 3e5:	ba 00 00 00 00       	mov    $0x0,%edx
 3ea:	f7 f1                	div    %ecx
 3ec:	89 d1                	mov    %edx,%ecx
 3ee:	8b 45 f4             	mov    -0xc(%ebp),%eax
 3f1:	8d 50 01             	lea    0x1(%eax),%edx
 3f4:	89 55 f4             	mov    %edx,-0xc(%ebp)
 3f7:	0f b6 91 e4 0a 00 00 	movzbl 0xae4(%ecx),%edx
 3fe:	88 54 05 dc          	mov    %dl,-0x24(%ebp,%eax,1)
  }while((x /= base) != 0);
 402:	8b 4d 10             	mov    0x10(%ebp),%ecx
 405:	8b 45 ec             	mov    -0x14(%ebp),%eax
 408:	ba 00 00 00 00       	mov    $0x0,%edx
 40d:	f7 f1                	div    %ecx
 40f:	89 45 ec             	mov    %eax,-0x14(%ebp)
 412:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
 416:	75 c7                	jne    3df <printint+0x37>
  if(neg)
 418:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
 41c:	74 2d                	je     44b <printint+0xa3>
    buf[i++] = '-';
 41e:	8b 45 f4             	mov    -0xc(%ebp),%eax
 421:	8d 50 01             	lea    0x1(%eax),%edx
 424:	89 55 f4             	mov    %edx,-0xc(%ebp)
 427:	c6 44 05 dc 2d       	movb   $0x2d,-0x24(%ebp,%eax,1)

  while(--i >= 0)
 42c:	eb 1d                	jmp    44b <printint+0xa3>
    putc(fd, buf[i]);
 42e:	8d 55 dc             	lea    -0x24(%ebp),%edx
 431:	8b 45 f4             	mov    -0xc(%ebp),%eax
 434:	01 d0                	add    %edx,%eax
 436:	0f b6 00             	movzbl (%eax),%eax
 439:	0f be c0             	movsbl %al,%eax
 43c:	83 ec 08             	sub    $0x8,%esp
 43f:	50                   	push   %eax
 440:	ff 75 08             	push   0x8(%ebp)
 443:	e8 3d ff ff ff       	call   385 <putc>
 448:	83 c4 10             	add    $0x10,%esp
  while(--i >= 0)
 44b:	83 6d f4 01          	subl   $0x1,-0xc(%ebp)
 44f:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 453:	79 d9                	jns    42e <printint+0x86>
}
 455:	90                   	nop
 456:	90                   	nop
 457:	c9                   	leave
 458:	c3                   	ret

00000459 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 459:	55                   	push   %ebp
 45a:	89 e5                	mov    %esp,%ebp
 45c:	83 ec 28             	sub    $0x28,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
 45f:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  ap = (uint*)(void*)&fmt + 1;
 466:	8d 45 0c             	lea    0xc(%ebp),%eax
 469:	83 c0 04             	add    $0x4,%eax
 46c:	89 45 e8             	mov    %eax,-0x18(%ebp)
  for(i = 0; fmt[i]; i++){
 46f:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
 476:	e9 59 01 00 00       	jmp    5d4 <printf+0x17b>
    c = fmt[i] & 0xff;
 47b:	8b 55 0c             	mov    0xc(%ebp),%edx
 47e:	8b 45 f0             	mov    -0x10(%ebp),%eax
 481:	01 d0                	add    %edx,%eax
 483:	0f b6 00             	movzbl (%eax),%eax
 486:	0f be c0             	movsbl %al,%eax
 489:	25 ff 00 00 00       	and    $0xff,%eax
 48e:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(state == 0){
 491:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
 495:	75 2c                	jne    4c3 <printf+0x6a>
      if(c == '%'){
 497:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
 49b:	75 0c                	jne    4a9 <printf+0x50>
        state = '%';
 49d:	c7 45 ec 25 00 00 00 	movl   $0x25,-0x14(%ebp)
 4a4:	e9 27 01 00 00       	jmp    5d0 <printf+0x177>
      } else {
        putc(fd, c);
 4a9:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 4ac:	0f be c0             	movsbl %al,%eax
 4af:	83 ec 08             	sub    $0x8,%esp
 4b2:	50                   	push   %eax
 4b3:	ff 75 08             	push   0x8(%ebp)
 4b6:	e8 ca fe ff ff       	call   385 <putc>
 4bb:	83 c4 10             	add    $0x10,%esp
 4be:	e9 0d 01 00 00       	jmp    5d0 <printf+0x177>
      }
    } else if(state == '%'){
 4c3:	83 7d ec 25          	cmpl   $0x25,-0x14(%ebp)
 4c7:	0f 85 03 01 00 00    	jne    5d0 <printf+0x177>
      if(c == 'd'){
 4cd:	83 7d e4 64          	cmpl   $0x64,-0x1c(%ebp)
 4d1:	75 1e                	jne    4f1 <printf+0x98>
        printint(fd, *ap, 10, 1);
 4d3:	8b 45 e8             	mov    -0x18(%ebp),%eax
 4d6:	8b 00                	mov    (%eax),%eax
 4d8:	6a 01                	push   $0x1
 4da:	6a 0a                	push   $0xa
 4dc:	50                   	push   %eax
 4dd:	ff 75 08             	push   0x8(%ebp)
 4e0:	e8 c3 fe ff ff       	call   3a8 <printint>
 4e5:	83 c4 10             	add    $0x10,%esp
        ap++;
 4e8:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
 4ec:	e9 d8 00 00 00       	jmp    5c9 <printf+0x170>
      } else if(c == 'x' || c == 'p'){
 4f1:	83 7d e4 78          	cmpl   $0x78,-0x1c(%ebp)
 4f5:	74 06                	je     4fd <printf+0xa4>
 4f7:	83 7d e4 70          	cmpl   $0x70,-0x1c(%ebp)
 4fb:	75 1e                	jne    51b <printf+0xc2>
        printint(fd, *ap, 16, 0);
 4fd:	8b 45 e8             	mov    -0x18(%ebp),%eax
 500:	8b 00                	mov    (%eax),%eax
 502:	6a 00                	push   $0x0
 504:	6a 10                	push   $0x10
 506:	50                   	push   %eax
 507:	ff 75 08             	push   0x8(%ebp)
 50a:	e8 99 fe ff ff       	call   3a8 <printint>
 50f:	83 c4 10             	add    $0x10,%esp
        ap++;
 512:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
 516:	e9 ae 00 00 00       	jmp    5c9 <printf+0x170>
      } else if(c == 's'){
 51b:	83 7d e4 73          	cmpl   $0x73,-0x1c(%ebp)
 51f:	75 43                	jne    564 <printf+0x10b>
        s = (char*)*ap;
 521:	8b 45 e8             	mov    -0x18(%ebp),%eax
 524:	8b 00                	mov    (%eax),%eax
 526:	89 45 f4             	mov    %eax,-0xc(%ebp)
        ap++;
 529:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
        if(s == 0)
 52d:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 531:	75 25                	jne    558 <printf+0xff>
          s = "(null)";
 533:	c7 45 f4 6e 08 00 00 	movl   $0x86e,-0xc(%ebp)
        while(*s != 0){
 53a:	eb 1c                	jmp    558 <printf+0xff>
          putc(fd, *s);
 53c:	8b 45 f4             	mov    -0xc(%ebp),%eax
 53f:	0f b6 00             	movzbl (%eax),%eax
 542:	0f be c0             	movsbl %al,%eax
 545:	83 ec 08             	sub    $0x8,%esp
 548:	50                   	push   %eax
 549:	ff 75 08             	push   0x8(%ebp)
 54c:	e8 34 fe ff ff       	call   385 <putc>
 551:	83 c4 10             	add    $0x10,%esp
          s++;
 554:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
        while(*s != 0){
 558:	8b 45 f4             	mov    -0xc(%ebp),%eax
 55b:	0f b6 00             	movzbl (%eax),%eax
 55e:	84 c0                	test   %al,%al
 560:	75 da                	jne    53c <printf+0xe3>
 562:	eb 65                	jmp    5c9 <printf+0x170>
        }
      } else if(c == 'c'){
 564:	83 7d e4 63          	cmpl   $0x63,-0x1c(%ebp)
 568:	75 1d                	jne    587 <printf+0x12e>
        putc(fd, *ap);
 56a:	8b 45 e8             	mov    -0x18(%ebp),%eax
 56d:	8b 00                	mov    (%eax),%eax
 56f:	0f be c0             	movsbl %al,%eax
 572:	83 ec 08             	sub    $0x8,%esp
 575:	50                   	push   %eax
 576:	ff 75 08             	push   0x8(%ebp)
 579:	e8 07 fe ff ff       	call   385 <putc>
 57e:	83 c4 10             	add    $0x10,%esp
        ap++;
 581:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
 585:	eb 42                	jmp    5c9 <printf+0x170>
      } else if(c == '%'){
 587:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
 58b:	75 17                	jne    5a4 <printf+0x14b>
        putc(fd, c);
 58d:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 590:	0f be c0             	movsbl %al,%eax
 593:	83 ec 08             	sub    $0x8,%esp
 596:	50                   	push   %eax
 597:	ff 75 08             	push   0x8(%ebp)
 59a:	e8 e6 fd ff ff       	call   385 <putc>
 59f:	83 c4 10             	add    $0x10,%esp
 5a2:	eb 25                	jmp    5c9 <printf+0x170>
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 5a4:	83 ec 08             	sub    $0x8,%esp
 5a7:	6a 25                	push   $0x25
 5a9:	ff 75 08             	push   0x8(%ebp)
 5ac:	e8 d4 fd ff ff       	call   385 <putc>
 5b1:	83 c4 10             	add    $0x10,%esp
        putc(fd, c);
 5b4:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 5b7:	0f be c0             	movsbl %al,%eax
 5ba:	83 ec 08             	sub    $0x8,%esp
 5bd:	50                   	push   %eax
 5be:	ff 75 08             	push   0x8(%ebp)
 5c1:	e8 bf fd ff ff       	call   385 <putc>
 5c6:	83 c4 10             	add    $0x10,%esp
      }
      state = 0;
 5c9:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  for(i = 0; fmt[i]; i++){
 5d0:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
 5d4:	8b 55 0c             	mov    0xc(%ebp),%edx
 5d7:	8b 45 f0             	mov    -0x10(%ebp),%eax
 5da:	01 d0                	add    %edx,%eax
 5dc:	0f b6 00             	movzbl (%eax),%eax
 5df:	84 c0                	test   %al,%al
 5e1:	0f 85 94 fe ff ff    	jne    47b <printf+0x22>
    }
  }
}
 5e7:	90                   	nop
 5e8:	90                   	nop
 5e9:	c9                   	leave
 5ea:	c3                   	ret

000005eb <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 5eb:	55                   	push   %ebp
 5ec:	89 e5                	mov    %esp,%ebp
 5ee:	83 ec 10             	sub    $0x10,%esp
  Header *bp, *p;

  bp = (Header*)ap - 1;
 5f1:	8b 45 08             	mov    0x8(%ebp),%eax
 5f4:	83 e8 08             	sub    $0x8,%eax
 5f7:	89 45 f8             	mov    %eax,-0x8(%ebp)
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 5fa:	a1 00 0b 00 00       	mov    0xb00,%eax
 5ff:	89 45 fc             	mov    %eax,-0x4(%ebp)
 602:	eb 24                	jmp    628 <free+0x3d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 604:	8b 45 fc             	mov    -0x4(%ebp),%eax
 607:	8b 00                	mov    (%eax),%eax
 609:	39 45 fc             	cmp    %eax,-0x4(%ebp)
 60c:	72 12                	jb     620 <free+0x35>
 60e:	8b 45 f8             	mov    -0x8(%ebp),%eax
 611:	39 45 fc             	cmp    %eax,-0x4(%ebp)
 614:	72 24                	jb     63a <free+0x4f>
 616:	8b 45 fc             	mov    -0x4(%ebp),%eax
 619:	8b 00                	mov    (%eax),%eax
 61b:	39 45 f8             	cmp    %eax,-0x8(%ebp)
 61e:	72 1a                	jb     63a <free+0x4f>
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 620:	8b 45 fc             	mov    -0x4(%ebp),%eax
 623:	8b 00                	mov    (%eax),%eax
 625:	89 45 fc             	mov    %eax,-0x4(%ebp)
 628:	8b 45 f8             	mov    -0x8(%ebp),%eax
 62b:	39 45 fc             	cmp    %eax,-0x4(%ebp)
 62e:	73 d4                	jae    604 <free+0x19>
 630:	8b 45 fc             	mov    -0x4(%ebp),%eax
 633:	8b 00                	mov    (%eax),%eax
 635:	39 45 f8             	cmp    %eax,-0x8(%ebp)
 638:	73 ca                	jae    604 <free+0x19>
      break;
  if(bp + bp->s.size == p->s.ptr){
 63a:	8b 45 f8             	mov    -0x8(%ebp),%eax
 63d:	8b 40 04             	mov    0x4(%eax),%eax
 640:	8d 14 c5 00 00 00 00 	lea    0x0(,%eax,8),%edx
 647:	8b 45 f8             	mov    -0x8(%ebp),%eax
 64a:	01 c2                	add    %eax,%edx
 64c:	8b 45 fc             	mov    -0x4(%ebp),%eax
 64f:	8b 00                	mov    (%eax),%eax
 651:	39 c2                	cmp    %eax,%edx
 653:	75 24                	jne    679 <free+0x8e>
    bp->s.size += p->s.ptr->s.size;
 655:	8b 45 f8             	mov    -0x8(%ebp),%eax
 658:	8b 50 04             	mov    0x4(%eax),%edx
 65b:	8b 45 fc             	mov    -0x4(%ebp),%eax
 65e:	8b 00                	mov    (%eax),%eax
 660:	8b 40 04             	mov    0x4(%eax),%eax
 663:	01 c2                	add    %eax,%edx
 665:	8b 45 f8             	mov    -0x8(%ebp),%eax
 668:	89 50 04             	mov    %edx,0x4(%eax)
    bp->s.ptr = p->s.ptr->s.ptr;
 66b:	8b 45 fc             	mov    -0x4(%ebp),%eax
 66e:	8b 00                	mov    (%eax),%eax
 670:	8b 10                	mov    (%eax),%edx
 672:	8b 45 f8             	mov    -0x8(%ebp),%eax
 675:	89 10                	mov    %edx,(%eax)
 677:	eb 0a                	jmp    683 <free+0x98>
  } else
    bp->s.ptr = p->s.ptr;
 679:	8b 45 fc             	mov    -0x4(%ebp),%eax
 67c:	8b 10                	mov    (%eax),%edx
 67e:	8b 45 f8             	mov    -0x8(%ebp),%eax
 681:	89 10                	mov    %edx,(%eax)
  if(p + p->s.size == bp){
 683:	8b 45 fc             	mov    -0x4(%ebp),%eax
 686:	8b 40 04             	mov    0x4(%eax),%eax
 689:	8d 14 c5 00 00 00 00 	lea    0x0(,%eax,8),%edx
 690:	8b 45 fc             	mov    -0x4(%ebp),%eax
 693:	01 d0                	add    %edx,%eax
 695:	39 45 f8             	cmp    %eax,-0x8(%ebp)
 698:	75 20                	jne    6ba <free+0xcf>
    p->s.size += bp->s.size;
 69a:	8b 45 fc             	mov    -0x4(%ebp),%eax
 69d:	8b 50 04             	mov    0x4(%eax),%edx
 6a0:	8b 45 f8             	mov    -0x8(%ebp),%eax
 6a3:	8b 40 04             	mov    0x4(%eax),%eax
 6a6:	01 c2                	add    %eax,%edx
 6a8:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6ab:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 6ae:	8b 45 f8             	mov    -0x8(%ebp),%eax
 6b1:	8b 10                	mov    (%eax),%edx
 6b3:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6b6:	89 10                	mov    %edx,(%eax)
 6b8:	eb 08                	jmp    6c2 <free+0xd7>
  } else
    p->s.ptr = bp;
 6ba:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6bd:	8b 55 f8             	mov    -0x8(%ebp),%edx
 6c0:	89 10                	mov    %edx,(%eax)
  freep = p;
 6c2:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6c5:	a3 00 0b 00 00       	mov    %eax,0xb00
}
 6ca:	90                   	nop
 6cb:	c9                   	leave
 6cc:	c3                   	ret

000006cd <morecore>:

static Header*
morecore(uint nu)
{
 6cd:	55                   	push   %ebp
 6ce:	89 e5                	mov    %esp,%ebp
 6d0:	83 ec 18             	sub    $0x18,%esp
  char *p;
  Header *hp;

  if(nu < 4096)
 6d3:	81 7d 08 ff 0f 00 00 	cmpl   $0xfff,0x8(%ebp)
 6da:	77 07                	ja     6e3 <morecore+0x16>
    nu = 4096;
 6dc:	c7 45 08 00 10 00 00 	movl   $0x1000,0x8(%ebp)
  p = sbrk(nu * sizeof(Header));
 6e3:	8b 45 08             	mov    0x8(%ebp),%eax
 6e6:	c1 e0 03             	shl    $0x3,%eax
 6e9:	83 ec 0c             	sub    $0xc,%esp
 6ec:	50                   	push   %eax
 6ed:	e8 73 fc ff ff       	call   365 <sbrk>
 6f2:	83 c4 10             	add    $0x10,%esp
 6f5:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(p == (char*)-1)
 6f8:	83 7d f4 ff          	cmpl   $0xffffffff,-0xc(%ebp)
 6fc:	75 07                	jne    705 <morecore+0x38>
    return 0;
 6fe:	b8 00 00 00 00       	mov    $0x0,%eax
 703:	eb 26                	jmp    72b <morecore+0x5e>
  hp = (Header*)p;
 705:	8b 45 f4             	mov    -0xc(%ebp),%eax
 708:	89 45 f0             	mov    %eax,-0x10(%ebp)
  hp->s.size = nu;
 70b:	8b 45 f0             	mov    -0x10(%ebp),%eax
 70e:	8b 55 08             	mov    0x8(%ebp),%edx
 711:	89 50 04             	mov    %edx,0x4(%eax)
  free((void*)(hp + 1));
 714:	8b 45 f0             	mov    -0x10(%ebp),%eax
 717:	83 c0 08             	add    $0x8,%eax
 71a:	83 ec 0c             	sub    $0xc,%esp
 71d:	50                   	push   %eax
 71e:	e8 c8 fe ff ff       	call   5eb <free>
 723:	83 c4 10             	add    $0x10,%esp
  return freep;
 726:	a1 00 0b 00 00       	mov    0xb00,%eax
}
 72b:	c9                   	leave
 72c:	c3                   	ret

0000072d <malloc>:

void*
malloc(uint nbytes)
{
 72d:	55                   	push   %ebp
 72e:	89 e5                	mov    %esp,%ebp
 730:	83 ec 18             	sub    $0x18,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 733:	8b 45 08             	mov    0x8(%ebp),%eax
 736:	83 c0 07             	add    $0x7,%eax
 739:	c1 e8 03             	shr    $0x3,%eax
 73c:	83 c0 01             	add    $0x1,%eax
 73f:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if((prevp = freep) == 0){
 742:	a1 00 0b 00 00       	mov    0xb00,%eax
 747:	89 45 f0             	mov    %eax,-0x10(%ebp)
 74a:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
 74e:	75 23                	jne    773 <malloc+0x46>
    base.s.ptr = freep = prevp = &base;
 750:	c7 45 f0 f8 0a 00 00 	movl   $0xaf8,-0x10(%ebp)
 757:	8b 45 f0             	mov    -0x10(%ebp),%eax
 75a:	a3 00 0b 00 00       	mov    %eax,0xb00
 75f:	a1 00 0b 00 00       	mov    0xb00,%eax
 764:	a3 f8 0a 00 00       	mov    %eax,0xaf8
    base.s.size = 0;
 769:	c7 05 fc 0a 00 00 00 	movl   $0x0,0xafc
 770:	00 00 00 
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 773:	8b 45 f0             	mov    -0x10(%ebp),%eax
 776:	8b 00                	mov    (%eax),%eax
 778:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(p->s.size >= nunits){
 77b:	8b 45 f4             	mov    -0xc(%ebp),%eax
 77e:	8b 40 04             	mov    0x4(%eax),%eax
 781:	3b 45 ec             	cmp    -0x14(%ebp),%eax
 784:	72 4d                	jb     7d3 <malloc+0xa6>
      if(p->s.size == nunits)
 786:	8b 45 f4             	mov    -0xc(%ebp),%eax
 789:	8b 40 04             	mov    0x4(%eax),%eax
 78c:	39 45 ec             	cmp    %eax,-0x14(%ebp)
 78f:	75 0c                	jne    79d <malloc+0x70>
        prevp->s.ptr = p->s.ptr;
 791:	8b 45 f4             	mov    -0xc(%ebp),%eax
 794:	8b 10                	mov    (%eax),%edx
 796:	8b 45 f0             	mov    -0x10(%ebp),%eax
 799:	89 10                	mov    %edx,(%eax)
 79b:	eb 26                	jmp    7c3 <malloc+0x96>
      else {
        p->s.size -= nunits;
 79d:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7a0:	8b 40 04             	mov    0x4(%eax),%eax
 7a3:	2b 45 ec             	sub    -0x14(%ebp),%eax
 7a6:	89 c2                	mov    %eax,%edx
 7a8:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7ab:	89 50 04             	mov    %edx,0x4(%eax)
        p += p->s.size;
 7ae:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7b1:	8b 40 04             	mov    0x4(%eax),%eax
 7b4:	c1 e0 03             	shl    $0x3,%eax
 7b7:	01 45 f4             	add    %eax,-0xc(%ebp)
        p->s.size = nunits;
 7ba:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7bd:	8b 55 ec             	mov    -0x14(%ebp),%edx
 7c0:	89 50 04             	mov    %edx,0x4(%eax)
      }
      freep = prevp;
 7c3:	8b 45 f0             	mov    -0x10(%ebp),%eax
 7c6:	a3 00 0b 00 00       	mov    %eax,0xb00
      return (void*)(p + 1);
 7cb:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7ce:	83 c0 08             	add    $0x8,%eax
 7d1:	eb 3b                	jmp    80e <malloc+0xe1>
    }
    if(p == freep)
 7d3:	a1 00 0b 00 00       	mov    0xb00,%eax
 7d8:	39 45 f4             	cmp    %eax,-0xc(%ebp)
 7db:	75 1e                	jne    7fb <malloc+0xce>
      if((p = morecore(nunits)) == 0)
 7dd:	83 ec 0c             	sub    $0xc,%esp
 7e0:	ff 75 ec             	push   -0x14(%ebp)
 7e3:	e8 e5 fe ff ff       	call   6cd <morecore>
 7e8:	83 c4 10             	add    $0x10,%esp
 7eb:	89 45 f4             	mov    %eax,-0xc(%ebp)
 7ee:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 7f2:	75 07                	jne    7fb <malloc+0xce>
        return 0;
 7f4:	b8 00 00 00 00       	mov    $0x0,%eax
 7f9:	eb 13                	jmp    80e <malloc+0xe1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7fb:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7fe:	89 45 f0             	mov    %eax,-0x10(%ebp)
 801:	8b 45 f4             	mov    -0xc(%ebp),%eax
 804:	8b 00                	mov    (%eax),%eax
 806:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(p->s.size >= nunits){
 809:	e9 6d ff ff ff       	jmp    77b <malloc+0x4e>
  }
}
 80e:	c9                   	leave
 80f:	c3                   	ret
