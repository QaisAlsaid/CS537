
_test_3:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

#define MAX_NAME_LEN 256

int main(int argc, char* argv[]) {
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	51                   	push   %ecx
   e:	81 ec 14 02 00 00    	sub    $0x214,%esp
  char parent_name[MAX_NAME_LEN];
  char child_name[MAX_NAME_LEN];

  int empty_buffer_length = 0;
  14:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)

  if (getparentname(parent_name, child_name, empty_buffer_length, MAX_NAME_LEN) < 0 &&
  1b:	68 00 01 00 00       	push   $0x100
  20:	ff 75 f4             	push   -0xc(%ebp)
  23:	8d 85 f4 fd ff ff    	lea    -0x20c(%ebp),%eax
  29:	50                   	push   %eax
  2a:	8d 85 f4 fe ff ff    	lea    -0x10c(%ebp),%eax
  30:	50                   	push   %eax
  31:	e8 4e 03 00 00       	call   384 <getparentname>
  36:	83 c4 10             	add    $0x10,%esp
  39:	85 c0                	test   %eax,%eax
  3b:	79 39                	jns    76 <main+0x76>
    getparentname(parent_name, child_name, MAX_NAME_LEN, empty_buffer_length) < 0) {
  3d:	ff 75 f4             	push   -0xc(%ebp)
  40:	68 00 01 00 00       	push   $0x100
  45:	8d 85 f4 fd ff ff    	lea    -0x20c(%ebp),%eax
  4b:	50                   	push   %eax
  4c:	8d 85 f4 fe ff ff    	lea    -0x10c(%ebp),%eax
  52:	50                   	push   %eax
  53:	e8 2c 03 00 00       	call   384 <getparentname>
  58:	83 c4 10             	add    $0x10,%esp
  if (getparentname(parent_name, child_name, empty_buffer_length, MAX_NAME_LEN) < 0 &&
  5b:	85 c0                	test   %eax,%eax
  5d:	79 17                	jns    76 <main+0x76>
    printf(1, "XV6_TEST_OUTPUT Zero buffer length handled correctly.\n");
  5f:	83 ec 08             	sub    $0x8,%esp
  62:	68 18 08 00 00       	push   $0x818
  67:	6a 01                	push   $0x1
  69:	e8 f2 03 00 00       	call   460 <printf>
  6e:	83 c4 10             	add    $0x10,%esp
    exit();
  71:	e8 6e 02 00 00       	call   2e4 <exit>
  }

  printf(2, "XV6_TEST_ERROR Test failed! Zero buffer length not handled correctly.\n");
  76:	83 ec 08             	sub    $0x8,%esp
  79:	68 50 08 00 00       	push   $0x850
  7e:	6a 02                	push   $0x2
  80:	e8 db 03 00 00       	call   460 <printf>
  85:	83 c4 10             	add    $0x10,%esp
  exit();
  88:	e8 57 02 00 00       	call   2e4 <exit>

0000008d <stosb>:
               "cc");
}

static inline void
stosb(void *addr, int data, int cnt)
{
  8d:	55                   	push   %ebp
  8e:	89 e5                	mov    %esp,%ebp
  90:	57                   	push   %edi
  91:	53                   	push   %ebx
  asm volatile("cld; rep stosb" :
  92:	8b 4d 08             	mov    0x8(%ebp),%ecx
  95:	8b 55 10             	mov    0x10(%ebp),%edx
  98:	8b 45 0c             	mov    0xc(%ebp),%eax
  9b:	89 cb                	mov    %ecx,%ebx
  9d:	89 df                	mov    %ebx,%edi
  9f:	89 d1                	mov    %edx,%ecx
  a1:	fc                   	cld
  a2:	f3 aa                	rep stos %al,%es:(%edi)
  a4:	89 ca                	mov    %ecx,%edx
  a6:	89 fb                	mov    %edi,%ebx
  a8:	89 5d 08             	mov    %ebx,0x8(%ebp)
  ab:	89 55 10             	mov    %edx,0x10(%ebp)
               "=D" (addr), "=c" (cnt) :
               "0" (addr), "1" (cnt), "a" (data) :
               "memory", "cc");
}
  ae:	90                   	nop
  af:	5b                   	pop    %ebx
  b0:	5f                   	pop    %edi
  b1:	5d                   	pop    %ebp
  b2:	c3                   	ret

000000b3 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
  b3:	55                   	push   %ebp
  b4:	89 e5                	mov    %esp,%ebp
  b6:	83 ec 10             	sub    $0x10,%esp
  char *os;

  os = s;
  b9:	8b 45 08             	mov    0x8(%ebp),%eax
  bc:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while((*s++ = *t++) != 0)
  bf:	90                   	nop
  c0:	8b 55 0c             	mov    0xc(%ebp),%edx
  c3:	8d 42 01             	lea    0x1(%edx),%eax
  c6:	89 45 0c             	mov    %eax,0xc(%ebp)
  c9:	8b 45 08             	mov    0x8(%ebp),%eax
  cc:	8d 48 01             	lea    0x1(%eax),%ecx
  cf:	89 4d 08             	mov    %ecx,0x8(%ebp)
  d2:	0f b6 12             	movzbl (%edx),%edx
  d5:	88 10                	mov    %dl,(%eax)
  d7:	0f b6 00             	movzbl (%eax),%eax
  da:	84 c0                	test   %al,%al
  dc:	75 e2                	jne    c0 <strcpy+0xd>
    ;
  return os;
  de:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
  e1:	c9                   	leave
  e2:	c3                   	ret

000000e3 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  e3:	55                   	push   %ebp
  e4:	89 e5                	mov    %esp,%ebp
  while(*p && *p == *q)
  e6:	eb 08                	jmp    f0 <strcmp+0xd>
    p++, q++;
  e8:	83 45 08 01          	addl   $0x1,0x8(%ebp)
  ec:	83 45 0c 01          	addl   $0x1,0xc(%ebp)
  while(*p && *p == *q)
  f0:	8b 45 08             	mov    0x8(%ebp),%eax
  f3:	0f b6 00             	movzbl (%eax),%eax
  f6:	84 c0                	test   %al,%al
  f8:	74 10                	je     10a <strcmp+0x27>
  fa:	8b 45 08             	mov    0x8(%ebp),%eax
  fd:	0f b6 10             	movzbl (%eax),%edx
 100:	8b 45 0c             	mov    0xc(%ebp),%eax
 103:	0f b6 00             	movzbl (%eax),%eax
 106:	38 c2                	cmp    %al,%dl
 108:	74 de                	je     e8 <strcmp+0x5>
  return (uchar)*p - (uchar)*q;
 10a:	8b 45 08             	mov    0x8(%ebp),%eax
 10d:	0f b6 00             	movzbl (%eax),%eax
 110:	0f b6 d0             	movzbl %al,%edx
 113:	8b 45 0c             	mov    0xc(%ebp),%eax
 116:	0f b6 00             	movzbl (%eax),%eax
 119:	0f b6 c0             	movzbl %al,%eax
 11c:	29 c2                	sub    %eax,%edx
 11e:	89 d0                	mov    %edx,%eax
}
 120:	5d                   	pop    %ebp
 121:	c3                   	ret

00000122 <strlen>:

uint
strlen(const char *s)
{
 122:	55                   	push   %ebp
 123:	89 e5                	mov    %esp,%ebp
 125:	83 ec 10             	sub    $0x10,%esp
  int n;

  for(n = 0; s[n]; n++)
 128:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
 12f:	eb 04                	jmp    135 <strlen+0x13>
 131:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
 135:	8b 55 fc             	mov    -0x4(%ebp),%edx
 138:	8b 45 08             	mov    0x8(%ebp),%eax
 13b:	01 d0                	add    %edx,%eax
 13d:	0f b6 00             	movzbl (%eax),%eax
 140:	84 c0                	test   %al,%al
 142:	75 ed                	jne    131 <strlen+0xf>
    ;
  return n;
 144:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
 147:	c9                   	leave
 148:	c3                   	ret

00000149 <memset>:

void*
memset(void *dst, int c, uint n)
{
 149:	55                   	push   %ebp
 14a:	89 e5                	mov    %esp,%ebp
  stosb(dst, c, n);
 14c:	8b 45 10             	mov    0x10(%ebp),%eax
 14f:	50                   	push   %eax
 150:	ff 75 0c             	push   0xc(%ebp)
 153:	ff 75 08             	push   0x8(%ebp)
 156:	e8 32 ff ff ff       	call   8d <stosb>
 15b:	83 c4 0c             	add    $0xc,%esp
  return dst;
 15e:	8b 45 08             	mov    0x8(%ebp),%eax
}
 161:	c9                   	leave
 162:	c3                   	ret

00000163 <strchr>:

char*
strchr(const char *s, char c)
{
 163:	55                   	push   %ebp
 164:	89 e5                	mov    %esp,%ebp
 166:	83 ec 04             	sub    $0x4,%esp
 169:	8b 45 0c             	mov    0xc(%ebp),%eax
 16c:	88 45 fc             	mov    %al,-0x4(%ebp)
  for(; *s; s++)
 16f:	eb 14                	jmp    185 <strchr+0x22>
    if(*s == c)
 171:	8b 45 08             	mov    0x8(%ebp),%eax
 174:	0f b6 00             	movzbl (%eax),%eax
 177:	38 45 fc             	cmp    %al,-0x4(%ebp)
 17a:	75 05                	jne    181 <strchr+0x1e>
      return (char*)s;
 17c:	8b 45 08             	mov    0x8(%ebp),%eax
 17f:	eb 13                	jmp    194 <strchr+0x31>
  for(; *s; s++)
 181:	83 45 08 01          	addl   $0x1,0x8(%ebp)
 185:	8b 45 08             	mov    0x8(%ebp),%eax
 188:	0f b6 00             	movzbl (%eax),%eax
 18b:	84 c0                	test   %al,%al
 18d:	75 e2                	jne    171 <strchr+0xe>
  return 0;
 18f:	b8 00 00 00 00       	mov    $0x0,%eax
}
 194:	c9                   	leave
 195:	c3                   	ret

00000196 <gets>:

char*
gets(char *buf, int max)
{
 196:	55                   	push   %ebp
 197:	89 e5                	mov    %esp,%ebp
 199:	83 ec 18             	sub    $0x18,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 19c:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
 1a3:	eb 42                	jmp    1e7 <gets+0x51>
    cc = read(0, &c, 1);
 1a5:	83 ec 04             	sub    $0x4,%esp
 1a8:	6a 01                	push   $0x1
 1aa:	8d 45 ef             	lea    -0x11(%ebp),%eax
 1ad:	50                   	push   %eax
 1ae:	6a 00                	push   $0x0
 1b0:	e8 47 01 00 00       	call   2fc <read>
 1b5:	83 c4 10             	add    $0x10,%esp
 1b8:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if(cc < 1)
 1bb:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
 1bf:	7e 33                	jle    1f4 <gets+0x5e>
      break;
    buf[i++] = c;
 1c1:	8b 45 f4             	mov    -0xc(%ebp),%eax
 1c4:	8d 50 01             	lea    0x1(%eax),%edx
 1c7:	89 55 f4             	mov    %edx,-0xc(%ebp)
 1ca:	89 c2                	mov    %eax,%edx
 1cc:	8b 45 08             	mov    0x8(%ebp),%eax
 1cf:	01 c2                	add    %eax,%edx
 1d1:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
 1d5:	88 02                	mov    %al,(%edx)
    if(c == '\n' || c == '\r')
 1d7:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
 1db:	3c 0a                	cmp    $0xa,%al
 1dd:	74 16                	je     1f5 <gets+0x5f>
 1df:	0f b6 45 ef          	movzbl -0x11(%ebp),%eax
 1e3:	3c 0d                	cmp    $0xd,%al
 1e5:	74 0e                	je     1f5 <gets+0x5f>
  for(i=0; i+1 < max; ){
 1e7:	8b 45 f4             	mov    -0xc(%ebp),%eax
 1ea:	83 c0 01             	add    $0x1,%eax
 1ed:	39 45 0c             	cmp    %eax,0xc(%ebp)
 1f0:	7f b3                	jg     1a5 <gets+0xf>
 1f2:	eb 01                	jmp    1f5 <gets+0x5f>
      break;
 1f4:	90                   	nop
      break;
  }
  buf[i] = '\0';
 1f5:	8b 55 f4             	mov    -0xc(%ebp),%edx
 1f8:	8b 45 08             	mov    0x8(%ebp),%eax
 1fb:	01 d0                	add    %edx,%eax
 1fd:	c6 00 00             	movb   $0x0,(%eax)
  return buf;
 200:	8b 45 08             	mov    0x8(%ebp),%eax
}
 203:	c9                   	leave
 204:	c3                   	ret

00000205 <stat>:

int
stat(const char *n, struct stat *st)
{
 205:	55                   	push   %ebp
 206:	89 e5                	mov    %esp,%ebp
 208:	83 ec 18             	sub    $0x18,%esp
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 20b:	83 ec 08             	sub    $0x8,%esp
 20e:	6a 00                	push   $0x0
 210:	ff 75 08             	push   0x8(%ebp)
 213:	e8 0c 01 00 00       	call   324 <open>
 218:	83 c4 10             	add    $0x10,%esp
 21b:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(fd < 0)
 21e:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 222:	79 07                	jns    22b <stat+0x26>
    return -1;
 224:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 229:	eb 25                	jmp    250 <stat+0x4b>
  r = fstat(fd, st);
 22b:	83 ec 08             	sub    $0x8,%esp
 22e:	ff 75 0c             	push   0xc(%ebp)
 231:	ff 75 f4             	push   -0xc(%ebp)
 234:	e8 03 01 00 00       	call   33c <fstat>
 239:	83 c4 10             	add    $0x10,%esp
 23c:	89 45 f0             	mov    %eax,-0x10(%ebp)
  close(fd);
 23f:	83 ec 0c             	sub    $0xc,%esp
 242:	ff 75 f4             	push   -0xc(%ebp)
 245:	e8 c2 00 00 00       	call   30c <close>
 24a:	83 c4 10             	add    $0x10,%esp
  return r;
 24d:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
 250:	c9                   	leave
 251:	c3                   	ret

00000252 <atoi>:

int
atoi(const char *s)
{
 252:	55                   	push   %ebp
 253:	89 e5                	mov    %esp,%ebp
 255:	83 ec 10             	sub    $0x10,%esp
  int n;

  n = 0;
 258:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
  while('0' <= *s && *s <= '9')
 25f:	eb 25                	jmp    286 <atoi+0x34>
    n = n*10 + *s++ - '0';
 261:	8b 55 fc             	mov    -0x4(%ebp),%edx
 264:	89 d0                	mov    %edx,%eax
 266:	c1 e0 02             	shl    $0x2,%eax
 269:	01 d0                	add    %edx,%eax
 26b:	01 c0                	add    %eax,%eax
 26d:	89 c1                	mov    %eax,%ecx
 26f:	8b 45 08             	mov    0x8(%ebp),%eax
 272:	8d 50 01             	lea    0x1(%eax),%edx
 275:	89 55 08             	mov    %edx,0x8(%ebp)
 278:	0f b6 00             	movzbl (%eax),%eax
 27b:	0f be c0             	movsbl %al,%eax
 27e:	01 c8                	add    %ecx,%eax
 280:	83 e8 30             	sub    $0x30,%eax
 283:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while('0' <= *s && *s <= '9')
 286:	8b 45 08             	mov    0x8(%ebp),%eax
 289:	0f b6 00             	movzbl (%eax),%eax
 28c:	3c 2f                	cmp    $0x2f,%al
 28e:	7e 0a                	jle    29a <atoi+0x48>
 290:	8b 45 08             	mov    0x8(%ebp),%eax
 293:	0f b6 00             	movzbl (%eax),%eax
 296:	3c 39                	cmp    $0x39,%al
 298:	7e c7                	jle    261 <atoi+0xf>
  return n;
 29a:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
 29d:	c9                   	leave
 29e:	c3                   	ret

0000029f <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 29f:	55                   	push   %ebp
 2a0:	89 e5                	mov    %esp,%ebp
 2a2:	83 ec 10             	sub    $0x10,%esp
  char *dst;
  const char *src;

  dst = vdst;
 2a5:	8b 45 08             	mov    0x8(%ebp),%eax
 2a8:	89 45 fc             	mov    %eax,-0x4(%ebp)
  src = vsrc;
 2ab:	8b 45 0c             	mov    0xc(%ebp),%eax
 2ae:	89 45 f8             	mov    %eax,-0x8(%ebp)
  while(n-- > 0)
 2b1:	eb 17                	jmp    2ca <memmove+0x2b>
    *dst++ = *src++;
 2b3:	8b 55 f8             	mov    -0x8(%ebp),%edx
 2b6:	8d 42 01             	lea    0x1(%edx),%eax
 2b9:	89 45 f8             	mov    %eax,-0x8(%ebp)
 2bc:	8b 45 fc             	mov    -0x4(%ebp),%eax
 2bf:	8d 48 01             	lea    0x1(%eax),%ecx
 2c2:	89 4d fc             	mov    %ecx,-0x4(%ebp)
 2c5:	0f b6 12             	movzbl (%edx),%edx
 2c8:	88 10                	mov    %dl,(%eax)
  while(n-- > 0)
 2ca:	8b 45 10             	mov    0x10(%ebp),%eax
 2cd:	8d 50 ff             	lea    -0x1(%eax),%edx
 2d0:	89 55 10             	mov    %edx,0x10(%ebp)
 2d3:	85 c0                	test   %eax,%eax
 2d5:	7f dc                	jg     2b3 <memmove+0x14>
  return vdst;
 2d7:	8b 45 08             	mov    0x8(%ebp),%eax
}
 2da:	c9                   	leave
 2db:	c3                   	ret

000002dc <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 2dc:	b8 01 00 00 00       	mov    $0x1,%eax
 2e1:	cd 40                	int    $0x40
 2e3:	c3                   	ret

000002e4 <exit>:
SYSCALL(exit)
 2e4:	b8 02 00 00 00       	mov    $0x2,%eax
 2e9:	cd 40                	int    $0x40
 2eb:	c3                   	ret

000002ec <wait>:
SYSCALL(wait)
 2ec:	b8 03 00 00 00       	mov    $0x3,%eax
 2f1:	cd 40                	int    $0x40
 2f3:	c3                   	ret

000002f4 <pipe>:
SYSCALL(pipe)
 2f4:	b8 04 00 00 00       	mov    $0x4,%eax
 2f9:	cd 40                	int    $0x40
 2fb:	c3                   	ret

000002fc <read>:
SYSCALL(read)
 2fc:	b8 05 00 00 00       	mov    $0x5,%eax
 301:	cd 40                	int    $0x40
 303:	c3                   	ret

00000304 <write>:
SYSCALL(write)
 304:	b8 10 00 00 00       	mov    $0x10,%eax
 309:	cd 40                	int    $0x40
 30b:	c3                   	ret

0000030c <close>:
SYSCALL(close)
 30c:	b8 15 00 00 00       	mov    $0x15,%eax
 311:	cd 40                	int    $0x40
 313:	c3                   	ret

00000314 <kill>:
SYSCALL(kill)
 314:	b8 06 00 00 00       	mov    $0x6,%eax
 319:	cd 40                	int    $0x40
 31b:	c3                   	ret

0000031c <exec>:
SYSCALL(exec)
 31c:	b8 07 00 00 00       	mov    $0x7,%eax
 321:	cd 40                	int    $0x40
 323:	c3                   	ret

00000324 <open>:
SYSCALL(open)
 324:	b8 0f 00 00 00       	mov    $0xf,%eax
 329:	cd 40                	int    $0x40
 32b:	c3                   	ret

0000032c <mknod>:
SYSCALL(mknod)
 32c:	b8 11 00 00 00       	mov    $0x11,%eax
 331:	cd 40                	int    $0x40
 333:	c3                   	ret

00000334 <unlink>:
SYSCALL(unlink)
 334:	b8 12 00 00 00       	mov    $0x12,%eax
 339:	cd 40                	int    $0x40
 33b:	c3                   	ret

0000033c <fstat>:
SYSCALL(fstat)
 33c:	b8 08 00 00 00       	mov    $0x8,%eax
 341:	cd 40                	int    $0x40
 343:	c3                   	ret

00000344 <link>:
SYSCALL(link)
 344:	b8 13 00 00 00       	mov    $0x13,%eax
 349:	cd 40                	int    $0x40
 34b:	c3                   	ret

0000034c <mkdir>:
SYSCALL(mkdir)
 34c:	b8 14 00 00 00       	mov    $0x14,%eax
 351:	cd 40                	int    $0x40
 353:	c3                   	ret

00000354 <chdir>:
SYSCALL(chdir)
 354:	b8 09 00 00 00       	mov    $0x9,%eax
 359:	cd 40                	int    $0x40
 35b:	c3                   	ret

0000035c <dup>:
SYSCALL(dup)
 35c:	b8 0a 00 00 00       	mov    $0xa,%eax
 361:	cd 40                	int    $0x40
 363:	c3                   	ret

00000364 <getpid>:
SYSCALL(getpid)
 364:	b8 0b 00 00 00       	mov    $0xb,%eax
 369:	cd 40                	int    $0x40
 36b:	c3                   	ret

0000036c <sbrk>:
SYSCALL(sbrk)
 36c:	b8 0c 00 00 00       	mov    $0xc,%eax
 371:	cd 40                	int    $0x40
 373:	c3                   	ret

00000374 <sleep>:
SYSCALL(sleep)
 374:	b8 0d 00 00 00       	mov    $0xd,%eax
 379:	cd 40                	int    $0x40
 37b:	c3                   	ret

0000037c <uptime>:
SYSCALL(uptime)
 37c:	b8 0e 00 00 00       	mov    $0xe,%eax
 381:	cd 40                	int    $0x40
 383:	c3                   	ret

00000384 <getparentname>:
SYSCALL(getparentname)
 384:	b8 16 00 00 00       	mov    $0x16,%eax
 389:	cd 40                	int    $0x40
 38b:	c3                   	ret

0000038c <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 38c:	55                   	push   %ebp
 38d:	89 e5                	mov    %esp,%ebp
 38f:	83 ec 18             	sub    $0x18,%esp
 392:	8b 45 0c             	mov    0xc(%ebp),%eax
 395:	88 45 f4             	mov    %al,-0xc(%ebp)
  write(fd, &c, 1);
 398:	83 ec 04             	sub    $0x4,%esp
 39b:	6a 01                	push   $0x1
 39d:	8d 45 f4             	lea    -0xc(%ebp),%eax
 3a0:	50                   	push   %eax
 3a1:	ff 75 08             	push   0x8(%ebp)
 3a4:	e8 5b ff ff ff       	call   304 <write>
 3a9:	83 c4 10             	add    $0x10,%esp
}
 3ac:	90                   	nop
 3ad:	c9                   	leave
 3ae:	c3                   	ret

000003af <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 3af:	55                   	push   %ebp
 3b0:	89 e5                	mov    %esp,%ebp
 3b2:	83 ec 28             	sub    $0x28,%esp
  static char digits[] = "0123456789ABCDEF";
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
 3b5:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  if(sgn && xx < 0){
 3bc:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
 3c0:	74 17                	je     3d9 <printint+0x2a>
 3c2:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
 3c6:	79 11                	jns    3d9 <printint+0x2a>
    neg = 1;
 3c8:	c7 45 f0 01 00 00 00 	movl   $0x1,-0x10(%ebp)
    x = -xx;
 3cf:	8b 45 0c             	mov    0xc(%ebp),%eax
 3d2:	f7 d8                	neg    %eax
 3d4:	89 45 ec             	mov    %eax,-0x14(%ebp)
 3d7:	eb 06                	jmp    3df <printint+0x30>
  } else {
    x = xx;
 3d9:	8b 45 0c             	mov    0xc(%ebp),%eax
 3dc:	89 45 ec             	mov    %eax,-0x14(%ebp)
  }

  i = 0;
 3df:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  do{
    buf[i++] = digits[x % base];
 3e6:	8b 4d 10             	mov    0x10(%ebp),%ecx
 3e9:	8b 45 ec             	mov    -0x14(%ebp),%eax
 3ec:	ba 00 00 00 00       	mov    $0x0,%edx
 3f1:	f7 f1                	div    %ecx
 3f3:	89 d1                	mov    %edx,%ecx
 3f5:	8b 45 f4             	mov    -0xc(%ebp),%eax
 3f8:	8d 50 01             	lea    0x1(%eax),%edx
 3fb:	89 55 f4             	mov    %edx,-0xc(%ebp)
 3fe:	0f b6 91 0c 0b 00 00 	movzbl 0xb0c(%ecx),%edx
 405:	88 54 05 dc          	mov    %dl,-0x24(%ebp,%eax,1)
  }while((x /= base) != 0);
 409:	8b 4d 10             	mov    0x10(%ebp),%ecx
 40c:	8b 45 ec             	mov    -0x14(%ebp),%eax
 40f:	ba 00 00 00 00       	mov    $0x0,%edx
 414:	f7 f1                	div    %ecx
 416:	89 45 ec             	mov    %eax,-0x14(%ebp)
 419:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
 41d:	75 c7                	jne    3e6 <printint+0x37>
  if(neg)
 41f:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
 423:	74 2d                	je     452 <printint+0xa3>
    buf[i++] = '-';
 425:	8b 45 f4             	mov    -0xc(%ebp),%eax
 428:	8d 50 01             	lea    0x1(%eax),%edx
 42b:	89 55 f4             	mov    %edx,-0xc(%ebp)
 42e:	c6 44 05 dc 2d       	movb   $0x2d,-0x24(%ebp,%eax,1)

  while(--i >= 0)
 433:	eb 1d                	jmp    452 <printint+0xa3>
    putc(fd, buf[i]);
 435:	8d 55 dc             	lea    -0x24(%ebp),%edx
 438:	8b 45 f4             	mov    -0xc(%ebp),%eax
 43b:	01 d0                	add    %edx,%eax
 43d:	0f b6 00             	movzbl (%eax),%eax
 440:	0f be c0             	movsbl %al,%eax
 443:	83 ec 08             	sub    $0x8,%esp
 446:	50                   	push   %eax
 447:	ff 75 08             	push   0x8(%ebp)
 44a:	e8 3d ff ff ff       	call   38c <putc>
 44f:	83 c4 10             	add    $0x10,%esp
  while(--i >= 0)
 452:	83 6d f4 01          	subl   $0x1,-0xc(%ebp)
 456:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 45a:	79 d9                	jns    435 <printint+0x86>
}
 45c:	90                   	nop
 45d:	90                   	nop
 45e:	c9                   	leave
 45f:	c3                   	ret

00000460 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 460:	55                   	push   %ebp
 461:	89 e5                	mov    %esp,%ebp
 463:	83 ec 28             	sub    $0x28,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
 466:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  ap = (uint*)(void*)&fmt + 1;
 46d:	8d 45 0c             	lea    0xc(%ebp),%eax
 470:	83 c0 04             	add    $0x4,%eax
 473:	89 45 e8             	mov    %eax,-0x18(%ebp)
  for(i = 0; fmt[i]; i++){
 476:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
 47d:	e9 59 01 00 00       	jmp    5db <printf+0x17b>
    c = fmt[i] & 0xff;
 482:	8b 55 0c             	mov    0xc(%ebp),%edx
 485:	8b 45 f0             	mov    -0x10(%ebp),%eax
 488:	01 d0                	add    %edx,%eax
 48a:	0f b6 00             	movzbl (%eax),%eax
 48d:	0f be c0             	movsbl %al,%eax
 490:	25 ff 00 00 00       	and    $0xff,%eax
 495:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(state == 0){
 498:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
 49c:	75 2c                	jne    4ca <printf+0x6a>
      if(c == '%'){
 49e:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
 4a2:	75 0c                	jne    4b0 <printf+0x50>
        state = '%';
 4a4:	c7 45 ec 25 00 00 00 	movl   $0x25,-0x14(%ebp)
 4ab:	e9 27 01 00 00       	jmp    5d7 <printf+0x177>
      } else {
        putc(fd, c);
 4b0:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 4b3:	0f be c0             	movsbl %al,%eax
 4b6:	83 ec 08             	sub    $0x8,%esp
 4b9:	50                   	push   %eax
 4ba:	ff 75 08             	push   0x8(%ebp)
 4bd:	e8 ca fe ff ff       	call   38c <putc>
 4c2:	83 c4 10             	add    $0x10,%esp
 4c5:	e9 0d 01 00 00       	jmp    5d7 <printf+0x177>
      }
    } else if(state == '%'){
 4ca:	83 7d ec 25          	cmpl   $0x25,-0x14(%ebp)
 4ce:	0f 85 03 01 00 00    	jne    5d7 <printf+0x177>
      if(c == 'd'){
 4d4:	83 7d e4 64          	cmpl   $0x64,-0x1c(%ebp)
 4d8:	75 1e                	jne    4f8 <printf+0x98>
        printint(fd, *ap, 10, 1);
 4da:	8b 45 e8             	mov    -0x18(%ebp),%eax
 4dd:	8b 00                	mov    (%eax),%eax
 4df:	6a 01                	push   $0x1
 4e1:	6a 0a                	push   $0xa
 4e3:	50                   	push   %eax
 4e4:	ff 75 08             	push   0x8(%ebp)
 4e7:	e8 c3 fe ff ff       	call   3af <printint>
 4ec:	83 c4 10             	add    $0x10,%esp
        ap++;
 4ef:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
 4f3:	e9 d8 00 00 00       	jmp    5d0 <printf+0x170>
      } else if(c == 'x' || c == 'p'){
 4f8:	83 7d e4 78          	cmpl   $0x78,-0x1c(%ebp)
 4fc:	74 06                	je     504 <printf+0xa4>
 4fe:	83 7d e4 70          	cmpl   $0x70,-0x1c(%ebp)
 502:	75 1e                	jne    522 <printf+0xc2>
        printint(fd, *ap, 16, 0);
 504:	8b 45 e8             	mov    -0x18(%ebp),%eax
 507:	8b 00                	mov    (%eax),%eax
 509:	6a 00                	push   $0x0
 50b:	6a 10                	push   $0x10
 50d:	50                   	push   %eax
 50e:	ff 75 08             	push   0x8(%ebp)
 511:	e8 99 fe ff ff       	call   3af <printint>
 516:	83 c4 10             	add    $0x10,%esp
        ap++;
 519:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
 51d:	e9 ae 00 00 00       	jmp    5d0 <printf+0x170>
      } else if(c == 's'){
 522:	83 7d e4 73          	cmpl   $0x73,-0x1c(%ebp)
 526:	75 43                	jne    56b <printf+0x10b>
        s = (char*)*ap;
 528:	8b 45 e8             	mov    -0x18(%ebp),%eax
 52b:	8b 00                	mov    (%eax),%eax
 52d:	89 45 f4             	mov    %eax,-0xc(%ebp)
        ap++;
 530:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
        if(s == 0)
 534:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 538:	75 25                	jne    55f <printf+0xff>
          s = "(null)";
 53a:	c7 45 f4 97 08 00 00 	movl   $0x897,-0xc(%ebp)
        while(*s != 0){
 541:	eb 1c                	jmp    55f <printf+0xff>
          putc(fd, *s);
 543:	8b 45 f4             	mov    -0xc(%ebp),%eax
 546:	0f b6 00             	movzbl (%eax),%eax
 549:	0f be c0             	movsbl %al,%eax
 54c:	83 ec 08             	sub    $0x8,%esp
 54f:	50                   	push   %eax
 550:	ff 75 08             	push   0x8(%ebp)
 553:	e8 34 fe ff ff       	call   38c <putc>
 558:	83 c4 10             	add    $0x10,%esp
          s++;
 55b:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
        while(*s != 0){
 55f:	8b 45 f4             	mov    -0xc(%ebp),%eax
 562:	0f b6 00             	movzbl (%eax),%eax
 565:	84 c0                	test   %al,%al
 567:	75 da                	jne    543 <printf+0xe3>
 569:	eb 65                	jmp    5d0 <printf+0x170>
        }
      } else if(c == 'c'){
 56b:	83 7d e4 63          	cmpl   $0x63,-0x1c(%ebp)
 56f:	75 1d                	jne    58e <printf+0x12e>
        putc(fd, *ap);
 571:	8b 45 e8             	mov    -0x18(%ebp),%eax
 574:	8b 00                	mov    (%eax),%eax
 576:	0f be c0             	movsbl %al,%eax
 579:	83 ec 08             	sub    $0x8,%esp
 57c:	50                   	push   %eax
 57d:	ff 75 08             	push   0x8(%ebp)
 580:	e8 07 fe ff ff       	call   38c <putc>
 585:	83 c4 10             	add    $0x10,%esp
        ap++;
 588:	83 45 e8 04          	addl   $0x4,-0x18(%ebp)
 58c:	eb 42                	jmp    5d0 <printf+0x170>
      } else if(c == '%'){
 58e:	83 7d e4 25          	cmpl   $0x25,-0x1c(%ebp)
 592:	75 17                	jne    5ab <printf+0x14b>
        putc(fd, c);
 594:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 597:	0f be c0             	movsbl %al,%eax
 59a:	83 ec 08             	sub    $0x8,%esp
 59d:	50                   	push   %eax
 59e:	ff 75 08             	push   0x8(%ebp)
 5a1:	e8 e6 fd ff ff       	call   38c <putc>
 5a6:	83 c4 10             	add    $0x10,%esp
 5a9:	eb 25                	jmp    5d0 <printf+0x170>
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 5ab:	83 ec 08             	sub    $0x8,%esp
 5ae:	6a 25                	push   $0x25
 5b0:	ff 75 08             	push   0x8(%ebp)
 5b3:	e8 d4 fd ff ff       	call   38c <putc>
 5b8:	83 c4 10             	add    $0x10,%esp
        putc(fd, c);
 5bb:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 5be:	0f be c0             	movsbl %al,%eax
 5c1:	83 ec 08             	sub    $0x8,%esp
 5c4:	50                   	push   %eax
 5c5:	ff 75 08             	push   0x8(%ebp)
 5c8:	e8 bf fd ff ff       	call   38c <putc>
 5cd:	83 c4 10             	add    $0x10,%esp
      }
      state = 0;
 5d0:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  for(i = 0; fmt[i]; i++){
 5d7:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
 5db:	8b 55 0c             	mov    0xc(%ebp),%edx
 5de:	8b 45 f0             	mov    -0x10(%ebp),%eax
 5e1:	01 d0                	add    %edx,%eax
 5e3:	0f b6 00             	movzbl (%eax),%eax
 5e6:	84 c0                	test   %al,%al
 5e8:	0f 85 94 fe ff ff    	jne    482 <printf+0x22>
    }
  }
}
 5ee:	90                   	nop
 5ef:	90                   	nop
 5f0:	c9                   	leave
 5f1:	c3                   	ret

000005f2 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 5f2:	55                   	push   %ebp
 5f3:	89 e5                	mov    %esp,%ebp
 5f5:	83 ec 10             	sub    $0x10,%esp
  Header *bp, *p;

  bp = (Header*)ap - 1;
 5f8:	8b 45 08             	mov    0x8(%ebp),%eax
 5fb:	83 e8 08             	sub    $0x8,%eax
 5fe:	89 45 f8             	mov    %eax,-0x8(%ebp)
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 601:	a1 28 0b 00 00       	mov    0xb28,%eax
 606:	89 45 fc             	mov    %eax,-0x4(%ebp)
 609:	eb 24                	jmp    62f <free+0x3d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 60b:	8b 45 fc             	mov    -0x4(%ebp),%eax
 60e:	8b 00                	mov    (%eax),%eax
 610:	39 45 fc             	cmp    %eax,-0x4(%ebp)
 613:	72 12                	jb     627 <free+0x35>
 615:	8b 45 f8             	mov    -0x8(%ebp),%eax
 618:	39 45 fc             	cmp    %eax,-0x4(%ebp)
 61b:	72 24                	jb     641 <free+0x4f>
 61d:	8b 45 fc             	mov    -0x4(%ebp),%eax
 620:	8b 00                	mov    (%eax),%eax
 622:	39 45 f8             	cmp    %eax,-0x8(%ebp)
 625:	72 1a                	jb     641 <free+0x4f>
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 627:	8b 45 fc             	mov    -0x4(%ebp),%eax
 62a:	8b 00                	mov    (%eax),%eax
 62c:	89 45 fc             	mov    %eax,-0x4(%ebp)
 62f:	8b 45 f8             	mov    -0x8(%ebp),%eax
 632:	39 45 fc             	cmp    %eax,-0x4(%ebp)
 635:	73 d4                	jae    60b <free+0x19>
 637:	8b 45 fc             	mov    -0x4(%ebp),%eax
 63a:	8b 00                	mov    (%eax),%eax
 63c:	39 45 f8             	cmp    %eax,-0x8(%ebp)
 63f:	73 ca                	jae    60b <free+0x19>
      break;
  if(bp + bp->s.size == p->s.ptr){
 641:	8b 45 f8             	mov    -0x8(%ebp),%eax
 644:	8b 40 04             	mov    0x4(%eax),%eax
 647:	8d 14 c5 00 00 00 00 	lea    0x0(,%eax,8),%edx
 64e:	8b 45 f8             	mov    -0x8(%ebp),%eax
 651:	01 c2                	add    %eax,%edx
 653:	8b 45 fc             	mov    -0x4(%ebp),%eax
 656:	8b 00                	mov    (%eax),%eax
 658:	39 c2                	cmp    %eax,%edx
 65a:	75 24                	jne    680 <free+0x8e>
    bp->s.size += p->s.ptr->s.size;
 65c:	8b 45 f8             	mov    -0x8(%ebp),%eax
 65f:	8b 50 04             	mov    0x4(%eax),%edx
 662:	8b 45 fc             	mov    -0x4(%ebp),%eax
 665:	8b 00                	mov    (%eax),%eax
 667:	8b 40 04             	mov    0x4(%eax),%eax
 66a:	01 c2                	add    %eax,%edx
 66c:	8b 45 f8             	mov    -0x8(%ebp),%eax
 66f:	89 50 04             	mov    %edx,0x4(%eax)
    bp->s.ptr = p->s.ptr->s.ptr;
 672:	8b 45 fc             	mov    -0x4(%ebp),%eax
 675:	8b 00                	mov    (%eax),%eax
 677:	8b 10                	mov    (%eax),%edx
 679:	8b 45 f8             	mov    -0x8(%ebp),%eax
 67c:	89 10                	mov    %edx,(%eax)
 67e:	eb 0a                	jmp    68a <free+0x98>
  } else
    bp->s.ptr = p->s.ptr;
 680:	8b 45 fc             	mov    -0x4(%ebp),%eax
 683:	8b 10                	mov    (%eax),%edx
 685:	8b 45 f8             	mov    -0x8(%ebp),%eax
 688:	89 10                	mov    %edx,(%eax)
  if(p + p->s.size == bp){
 68a:	8b 45 fc             	mov    -0x4(%ebp),%eax
 68d:	8b 40 04             	mov    0x4(%eax),%eax
 690:	8d 14 c5 00 00 00 00 	lea    0x0(,%eax,8),%edx
 697:	8b 45 fc             	mov    -0x4(%ebp),%eax
 69a:	01 d0                	add    %edx,%eax
 69c:	39 45 f8             	cmp    %eax,-0x8(%ebp)
 69f:	75 20                	jne    6c1 <free+0xcf>
    p->s.size += bp->s.size;
 6a1:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6a4:	8b 50 04             	mov    0x4(%eax),%edx
 6a7:	8b 45 f8             	mov    -0x8(%ebp),%eax
 6aa:	8b 40 04             	mov    0x4(%eax),%eax
 6ad:	01 c2                	add    %eax,%edx
 6af:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6b2:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 6b5:	8b 45 f8             	mov    -0x8(%ebp),%eax
 6b8:	8b 10                	mov    (%eax),%edx
 6ba:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6bd:	89 10                	mov    %edx,(%eax)
 6bf:	eb 08                	jmp    6c9 <free+0xd7>
  } else
    p->s.ptr = bp;
 6c1:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6c4:	8b 55 f8             	mov    -0x8(%ebp),%edx
 6c7:	89 10                	mov    %edx,(%eax)
  freep = p;
 6c9:	8b 45 fc             	mov    -0x4(%ebp),%eax
 6cc:	a3 28 0b 00 00       	mov    %eax,0xb28
}
 6d1:	90                   	nop
 6d2:	c9                   	leave
 6d3:	c3                   	ret

000006d4 <morecore>:

static Header*
morecore(uint nu)
{
 6d4:	55                   	push   %ebp
 6d5:	89 e5                	mov    %esp,%ebp
 6d7:	83 ec 18             	sub    $0x18,%esp
  char *p;
  Header *hp;

  if(nu < 4096)
 6da:	81 7d 08 ff 0f 00 00 	cmpl   $0xfff,0x8(%ebp)
 6e1:	77 07                	ja     6ea <morecore+0x16>
    nu = 4096;
 6e3:	c7 45 08 00 10 00 00 	movl   $0x1000,0x8(%ebp)
  p = sbrk(nu * sizeof(Header));
 6ea:	8b 45 08             	mov    0x8(%ebp),%eax
 6ed:	c1 e0 03             	shl    $0x3,%eax
 6f0:	83 ec 0c             	sub    $0xc,%esp
 6f3:	50                   	push   %eax
 6f4:	e8 73 fc ff ff       	call   36c <sbrk>
 6f9:	83 c4 10             	add    $0x10,%esp
 6fc:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if(p == (char*)-1)
 6ff:	83 7d f4 ff          	cmpl   $0xffffffff,-0xc(%ebp)
 703:	75 07                	jne    70c <morecore+0x38>
    return 0;
 705:	b8 00 00 00 00       	mov    $0x0,%eax
 70a:	eb 26                	jmp    732 <morecore+0x5e>
  hp = (Header*)p;
 70c:	8b 45 f4             	mov    -0xc(%ebp),%eax
 70f:	89 45 f0             	mov    %eax,-0x10(%ebp)
  hp->s.size = nu;
 712:	8b 45 f0             	mov    -0x10(%ebp),%eax
 715:	8b 55 08             	mov    0x8(%ebp),%edx
 718:	89 50 04             	mov    %edx,0x4(%eax)
  free((void*)(hp + 1));
 71b:	8b 45 f0             	mov    -0x10(%ebp),%eax
 71e:	83 c0 08             	add    $0x8,%eax
 721:	83 ec 0c             	sub    $0xc,%esp
 724:	50                   	push   %eax
 725:	e8 c8 fe ff ff       	call   5f2 <free>
 72a:	83 c4 10             	add    $0x10,%esp
  return freep;
 72d:	a1 28 0b 00 00       	mov    0xb28,%eax
}
 732:	c9                   	leave
 733:	c3                   	ret

00000734 <malloc>:

void*
malloc(uint nbytes)
{
 734:	55                   	push   %ebp
 735:	89 e5                	mov    %esp,%ebp
 737:	83 ec 18             	sub    $0x18,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 73a:	8b 45 08             	mov    0x8(%ebp),%eax
 73d:	83 c0 07             	add    $0x7,%eax
 740:	c1 e8 03             	shr    $0x3,%eax
 743:	83 c0 01             	add    $0x1,%eax
 746:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if((prevp = freep) == 0){
 749:	a1 28 0b 00 00       	mov    0xb28,%eax
 74e:	89 45 f0             	mov    %eax,-0x10(%ebp)
 751:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
 755:	75 23                	jne    77a <malloc+0x46>
    base.s.ptr = freep = prevp = &base;
 757:	c7 45 f0 20 0b 00 00 	movl   $0xb20,-0x10(%ebp)
 75e:	8b 45 f0             	mov    -0x10(%ebp),%eax
 761:	a3 28 0b 00 00       	mov    %eax,0xb28
 766:	a1 28 0b 00 00       	mov    0xb28,%eax
 76b:	a3 20 0b 00 00       	mov    %eax,0xb20
    base.s.size = 0;
 770:	c7 05 24 0b 00 00 00 	movl   $0x0,0xb24
 777:	00 00 00 
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 77a:	8b 45 f0             	mov    -0x10(%ebp),%eax
 77d:	8b 00                	mov    (%eax),%eax
 77f:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(p->s.size >= nunits){
 782:	8b 45 f4             	mov    -0xc(%ebp),%eax
 785:	8b 40 04             	mov    0x4(%eax),%eax
 788:	3b 45 ec             	cmp    -0x14(%ebp),%eax
 78b:	72 4d                	jb     7da <malloc+0xa6>
      if(p->s.size == nunits)
 78d:	8b 45 f4             	mov    -0xc(%ebp),%eax
 790:	8b 40 04             	mov    0x4(%eax),%eax
 793:	39 45 ec             	cmp    %eax,-0x14(%ebp)
 796:	75 0c                	jne    7a4 <malloc+0x70>
        prevp->s.ptr = p->s.ptr;
 798:	8b 45 f4             	mov    -0xc(%ebp),%eax
 79b:	8b 10                	mov    (%eax),%edx
 79d:	8b 45 f0             	mov    -0x10(%ebp),%eax
 7a0:	89 10                	mov    %edx,(%eax)
 7a2:	eb 26                	jmp    7ca <malloc+0x96>
      else {
        p->s.size -= nunits;
 7a4:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7a7:	8b 40 04             	mov    0x4(%eax),%eax
 7aa:	2b 45 ec             	sub    -0x14(%ebp),%eax
 7ad:	89 c2                	mov    %eax,%edx
 7af:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7b2:	89 50 04             	mov    %edx,0x4(%eax)
        p += p->s.size;
 7b5:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7b8:	8b 40 04             	mov    0x4(%eax),%eax
 7bb:	c1 e0 03             	shl    $0x3,%eax
 7be:	01 45 f4             	add    %eax,-0xc(%ebp)
        p->s.size = nunits;
 7c1:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7c4:	8b 55 ec             	mov    -0x14(%ebp),%edx
 7c7:	89 50 04             	mov    %edx,0x4(%eax)
      }
      freep = prevp;
 7ca:	8b 45 f0             	mov    -0x10(%ebp),%eax
 7cd:	a3 28 0b 00 00       	mov    %eax,0xb28
      return (void*)(p + 1);
 7d2:	8b 45 f4             	mov    -0xc(%ebp),%eax
 7d5:	83 c0 08             	add    $0x8,%eax
 7d8:	eb 3b                	jmp    815 <malloc+0xe1>
    }
    if(p == freep)
 7da:	a1 28 0b 00 00       	mov    0xb28,%eax
 7df:	39 45 f4             	cmp    %eax,-0xc(%ebp)
 7e2:	75 1e                	jne    802 <malloc+0xce>
      if((p = morecore(nunits)) == 0)
 7e4:	83 ec 0c             	sub    $0xc,%esp
 7e7:	ff 75 ec             	push   -0x14(%ebp)
 7ea:	e8 e5 fe ff ff       	call   6d4 <morecore>
 7ef:	83 c4 10             	add    $0x10,%esp
 7f2:	89 45 f4             	mov    %eax,-0xc(%ebp)
 7f5:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
 7f9:	75 07                	jne    802 <malloc+0xce>
        return 0;
 7fb:	b8 00 00 00 00       	mov    $0x0,%eax
 800:	eb 13                	jmp    815 <malloc+0xe1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 802:	8b 45 f4             	mov    -0xc(%ebp),%eax
 805:	89 45 f0             	mov    %eax,-0x10(%ebp)
 808:	8b 45 f4             	mov    -0xc(%ebp),%eax
 80b:	8b 00                	mov    (%eax),%eax
 80d:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(p->s.size >= nunits){
 810:	e9 6d ff ff ff       	jmp    782 <malloc+0x4e>
  }
}
 815:	c9                   	leave
 816:	c3                   	ret
